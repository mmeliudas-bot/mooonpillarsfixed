/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.ChatColor
 */
package org.kloppie74.MoonPillars.PaperMC.API.PublicAPI;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.md_5.bungee.api.ChatColor;

public class MSG {
    public static String chatColors(String message) {
        if (message == null) {
            return "";
        }
        Pattern ampHexPattern = Pattern.compile("&#([a-fA-F0-9]{6})");
        Matcher ampHexMatcher = ampHexPattern.matcher(message);
        StringBuffer ampSb = new StringBuffer();
        while (ampHexMatcher.find()) {
            String hexCode = ampHexMatcher.group(1);
            StringBuilder colorBuilder = new StringBuilder("\u00a7x");
            for (char c : hexCode.toCharArray()) {
                colorBuilder.append("\u00a7").append(c);
            }
            ampHexMatcher.appendReplacement(ampSb, Matcher.quoteReplacement(colorBuilder.toString()));
        }
        ampHexMatcher.appendTail(ampSb);
        String processed = ampSb.toString();
        processed = processed.replace("&", "\u00a7");
        Pattern regularHexPattern = Pattern.compile("#([a-fA-F0-9]{6})");
        Matcher regularHexMatcher = regularHexPattern.matcher(processed);
        StringBuffer hexSb = new StringBuffer();
        while (regularHexMatcher.find()) {
            String hexCode = regularHexMatcher.group(1);
            StringBuilder colorBuilder = new StringBuilder("\u00a7x");
            for (char c : hexCode.toCharArray()) {
                colorBuilder.append("\u00a7").append(c);
            }
            regularHexMatcher.appendReplacement(hexSb, Matcher.quoteReplacement(colorBuilder.toString()));
        }
        regularHexMatcher.appendTail(hexSb);
        processed = hexSb.toString();
        Pattern gradientPattern = Pattern.compile("<gradient:(#[a-fA-F0-9]{6}),(#[a-fA-F0-9]{6})>(.*?)</gradient>");
        Matcher gradientMatcher = gradientPattern.matcher(processed);
        while (gradientMatcher.find()) {
            String startColor = gradientMatcher.group(1);
            String endColor = gradientMatcher.group(2);
            String text = gradientMatcher.group(3);
            String gradientText = MSG.applyGradient(startColor, endColor, text);
            processed = processed.replace(gradientMatcher.group(0), gradientText);
            gradientMatcher = gradientPattern.matcher(processed);
        }
        return ChatColor.translateAlternateColorCodes((char)'\u00a7', (String)processed);
    }

    private static String applyGradient(String startColor, String endColor, String text) {
        StringBuilder gradientText = new StringBuilder();
        int length = Math.min(text.length(), 16);
        for (int i = 0; i < length; ++i) {
            float ratio = (float)i / (float)(length - 1);
            String interpolatedColor = MSG.interpolateColor(startColor, endColor, ratio);
            gradientText.append(ChatColor.of((String)interpolatedColor)).append(text.charAt(i));
        }
        return gradientText.toString();
    }

    private static String interpolateColor(String startColor, String endColor, float ratio) {
        int startR = Integer.valueOf(startColor.substring(1, 3), 16);
        int startG = Integer.valueOf(startColor.substring(3, 5), 16);
        int startB = Integer.valueOf(startColor.substring(5, 7), 16);
        int endR = Integer.valueOf(endColor.substring(1, 3), 16);
        int endG = Integer.valueOf(endColor.substring(3, 5), 16);
        int endB = Integer.valueOf(endColor.substring(5, 7), 16);
        int red = (int)((float)startR + (float)(endR - startR) * ratio);
        int green = (int)((float)startG + (float)(endG - startG) * ratio);
        int blue = (int)((float)startB + (float)(endB - startB) * ratio);
        return String.format("#%02x%02x%02x", red, green, blue);
    }
}

