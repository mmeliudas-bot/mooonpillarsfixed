/*
 * Decompiled with CFR 0.152.
 */
package org.kloppie74.MoonPillars.PaperMC.API.PublicAPI;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public final class FileCopy {
    public void copy(InputStream in, File file) {
        try {
            int len;
            if (in == null) {
                throw new IllegalArgumentException("Input stream is null");
            }
            FileOutputStream out = new FileOutputStream(file);
            byte[] buf = new byte[1024];
            while ((len = in.read(buf)) > 0) {
                ((OutputStream)out).write(buf, 0, len);
            }
            ((OutputStream)out).close();
            in.close();
        }
        catch (Exception var6) {
            var6.printStackTrace();
        }
    }
}

