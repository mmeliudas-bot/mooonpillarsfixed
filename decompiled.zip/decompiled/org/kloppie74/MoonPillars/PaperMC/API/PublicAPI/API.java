/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.API.PublicAPI;

import java.io.File;
import java.util.Collections;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.PreItemGiveEvent;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.RandomItem;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.TeamManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class API {
    public static File getDataFolder() {
        return MoonLab.getInstance().getDataFolder();
    }

    public static MoonLab getInstance() {
        return MoonLab.getInstance();
    }

    public static String getVersion() {
        return MoonLab.getInstance().getDescription().getVersion();
    }

    public static File getAddonsFolder() {
        File addonsFolder = new File(API.getDataFolder(), "Addons");
        if (!addonsFolder.exists()) {
            addonsFolder.mkdirs();
        }
        return addonsFolder;
    }

    public static Plugin getPlugin() {
        return MoonLab.getInstance();
    }

    public static String getPlayerGameID(Player player) {
        return HashMapHandler.getPlayerGameID(player.getUniqueId());
    }

    public static String getGameTeam(Player player, String gameID) {
        return player != null && gameID != null ? TeamManager.getPlayerTeam(gameID, player) : null;
    }

    public static List<Player> getAllGameIdMembers(String gameID) {
        return gameID == null ? Collections.emptyList() : HashMapHandler.getMembersGameID(gameID);
    }

    public static FileConfiguration getConfigGameID(String gameID) {
        return HashMapHandler.getConfigGameID(gameID);
    }

    public static boolean addItem(String gameID, ItemStack item) {
        return RandomItem.addCustomItem(gameID, item);
    }

    public static boolean addCommand(String gameID, String command) {
        return RandomItem.addCustomCommand(gameID, command);
    }

    public static boolean onItemGive(String gameID, Player player) {
        if (gameID != null && player != null) {
            String baseGameID = RandomItem.getBaseGameID(gameID);
            FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
            if (config == null) {
                return false;
            }
            PreItemGiveEvent event = new PreItemGiveEvent(player, gameID, baseGameID);
            Bukkit.getPluginManager().callEvent((Event)event);
            return !event.isCancelled();
        }
        return false;
    }
}

