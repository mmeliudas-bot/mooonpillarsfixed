/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.event.HandlerList
 */
package org.kloppie74.MoonPillars.PaperMC.API.PublicAPI;

import java.util.List;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class OnGameStartEvent
extends Event {
    private static final HandlerList handlers = new HandlerList();
    private final String gameID;
    private final List<Player> gameMembers;

    public OnGameStartEvent(String gameID, List<Player> gameMembers) {
        this.gameID = gameID;
        this.gameMembers = gameMembers;
    }

    public String getGameID() {
        return this.gameID;
    }

    public List<Player> getGameMembers() {
        return this.gameMembers;
    }

    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }
}

