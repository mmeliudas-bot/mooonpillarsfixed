/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Cancellable
 *  org.bukkit.event.Event
 *  org.bukkit.event.HandlerList
 */
package org.kloppie74.MoonPillars.PaperMC.API.PublicAPI;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class PreItemGiveEvent
extends Event
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private final Player player;
    private final String gameID;
    private final String baseGameID;
    private boolean cancelled = false;

    public PreItemGiveEvent(Player player, String gameID, String baseGameID) {
        this.player = player;
        this.gameID = gameID;
        this.baseGameID = baseGameID;
    }

    public Player getPlayer() {
        return this.player;
    }

    public String getGameID() {
        return this.gameID;
    }

    public String getBaseGameID() {
        return this.baseGameID;
    }

    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }
}

