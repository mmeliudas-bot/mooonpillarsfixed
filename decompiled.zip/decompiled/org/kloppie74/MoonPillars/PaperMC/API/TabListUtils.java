/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.comphenix.protocol.PacketType$Play$Server
 *  com.comphenix.protocol.ProtocolLibrary
 *  com.comphenix.protocol.ProtocolManager
 *  com.comphenix.protocol.events.PacketContainer
 *  com.comphenix.protocol.wrappers.EnumWrappers$NativeGameMode
 *  com.comphenix.protocol.wrappers.EnumWrappers$PlayerInfoAction
 *  com.comphenix.protocol.wrappers.PlayerInfoData
 *  com.comphenix.protocol.wrappers.WrappedChatComponent
 *  com.comphenix.protocol.wrappers.WrappedGameProfile
 *  org.bukkit.GameMode
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.API;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.wrappers.EnumWrappers;
import com.comphenix.protocol.wrappers.PlayerInfoData;
import com.comphenix.protocol.wrappers.WrappedChatComponent;
import com.comphenix.protocol.wrappers.WrappedGameProfile;
import java.util.Collections;
import org.bukkit.GameMode;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class TabListUtils {
    private static final ProtocolManager protocolManager = ProtocolLibrary.getProtocolManager();

    public static void forceAddToTablist(Player receiver, Player target) {
        FileConfiguration Settings = SettingsManager.getInstance().getSettings();
        boolean UseProtocolLib = Settings.getBoolean("API.ProtocolLib");
        boolean useTabList = Settings.getBoolean("ProtocolLib.DisplayHiddenUsersOnTabList");
        if (UseProtocolLib && receiver.isOnline() && target.isOnline() && useTabList) {
            PacketContainer packet = protocolManager.createPacket(PacketType.Play.Server.PLAYER_INFO);
            packet.getPlayerInfoActions().write(0, Collections.singleton(EnumWrappers.PlayerInfoAction.ADD_PLAYER));
            WrappedGameProfile profile = WrappedGameProfile.fromPlayer((Player)target);
            WrappedChatComponent nameComponent = WrappedChatComponent.fromText((String)target.getName());
            PlayerInfoData data = new PlayerInfoData(profile, target.getPing(), EnumWrappers.NativeGameMode.fromBukkit((GameMode)target.getGameMode()), nameComponent);
            packet.getPlayerInfoDataLists().write(0, Collections.singletonList(data));
            try {
                protocolManager.sendServerPacket(receiver, packet);
            }
            catch (Exception var10) {
                var10.printStackTrace();
            }
        }
    }
}

