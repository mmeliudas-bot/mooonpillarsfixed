/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.PlaceholderAPI
 *  net.md_5.bungee.api.ChatMessageType
 *  net.md_5.bungee.api.chat.BaseComponent
 *  net.md_5.bungee.api.chat.TextComponent
 *  org.bukkit.Bukkit
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.API;

import me.clip.placeholderapi.PlaceholderAPI;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;

public class MessageSender {
    private static MessageSender instance;
    private final Plugin placeholderAPIPlugin;
    private final boolean isPlaceholderAPIEnabled;
    private final FileConfiguration langConfig;

    private MessageSender(FileConfiguration langConfig) {
        this.langConfig = langConfig;
        this.placeholderAPIPlugin = Bukkit.getPluginManager().getPlugin("PlaceholderAPI");
        this.isPlaceholderAPIEnabled = this.placeholderAPIPlugin != null && this.placeholderAPIPlugin.isEnabled();
    }

    public static void init(FileConfiguration langConfig) {
        instance = new MessageSender(langConfig);
    }

    public static MessageSender get() {
        if (instance == null) {
            throw new IllegalStateException("MessageSender not initialized! Call MessageSender.init(langConfig) first.");
        }
        return instance;
    }

    public static void SendMessage(Player player, String path, String ... replacements) {
        MessageSender.get().send(player, path, replacements);
    }

    private void send(Player player, String path, String ... replacements) {
        if (player != null && path != null) {
            String type = this.langConfig.getString(path + ".Type", "chat");
            String message = this.langConfig.getString(path + ".Text");
            if (message == null) {
                Bukkit.getLogger().warning("Message is null for path: " + path);
            } else {
                if (replacements != null && replacements.length >= 2) {
                    for (int i = 0; i < replacements.length - 1; i += 2) {
                        String oldReplace = replacements[i];
                        String newReplace = replacements[i + 1];
                        if (oldReplace == null || newReplace == null) continue;
                        message = message.replace(oldReplace, newReplace);
                    }
                }
                if (this.isPlaceholderAPIEnabled) {
                    message = PlaceholderAPI.setPlaceholders((Player)player, (String)message);
                }
                String coloredMessage = MSG.chatColors(message);
                switch (type == null ? "chat" : type.toLowerCase()) {
                    case "hotbar": {
                        player.spigot().sendMessage(ChatMessageType.ACTION_BAR, (BaseComponent)new TextComponent(coloredMessage));
                        break;
                    }
                    case "title": {
                        int fadeIn = this.langConfig.getInt("Settings.FadeIn", 10);
                        int stay = this.langConfig.getInt("Settings.Stay", 40);
                        int fadeOut = this.langConfig.getInt("Settings.FadeOut", 10);
                        player.sendTitle("", coloredMessage, fadeIn, stay, fadeOut);
                        break;
                    }
                    default: {
                        player.sendMessage(coloredMessage);
                    }
                }
            }
        } else {
            Bukkit.getLogger().warning("Player or path is null in sendMessage");
        }
    }
}

