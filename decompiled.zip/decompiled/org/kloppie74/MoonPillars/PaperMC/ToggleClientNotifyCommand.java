/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.ClientBrandChecker;

public class ToggleClientNotifyCommand
implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(MSG.chatColors("&cThis command can only be executed by a player."));
            return true;
        }
        Player player = (Player)sender;
        if (!player.hasPermission("mpa.notify.client")) {
            player.sendMessage(MSG.chatColors("&cYou don't have permission to use this command."));
            return true;
        }
        boolean enabled = ClientBrandChecker.toggleNotifications(player);
        if (enabled) {
            player.sendMessage(MSG.chatColors("&aClient notifications have been &2enabled&a."));
        } else {
            player.sendMessage(MSG.chatColors("&cClient notifications have been &4disabled&c."));
        }
        return true;
    }
}

