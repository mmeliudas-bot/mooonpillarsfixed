/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.entity.Player
 *  org.bukkit.scoreboard.DisplaySlot
 *  org.bukkit.scoreboard.Objective
 *  org.bukkit.scoreboard.Scoreboard
 *  org.bukkit.scoreboard.Team
 */
package org.kloppie74.MoonPillars.PaperMC.ScoreBoardAPI;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.TeamManager;

public class ScoreHelper {
    private static final Map<UUID, ScoreHelper> players = new ConcurrentHashMap<UUID, ScoreHelper>(64, 0.75f, 2);
    private static final String[] ENTRIES = new String[16];
    private static final Map<String, String> lastColorsCache = new ConcurrentHashMap<String, String>(64, 0.75f, 1);
    private static final char[] COLOR_CHARS = "0123456789abcdefABCDEFklmnor".toCharArray();
    private static final Set<Character> COLOR_CHAR_SET = new HashSet<Character>(32);
    private static final int MAX_PREFIX_LENGTH = 64;
    private static final int MAX_SUFFIX_LENGTH = 64;
    private final Scoreboard scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
    private final Objective sidebar;
    private final Map<Integer, String[]> cachedTextParts = new HashMap<Integer, String[]>(16, 0.9f);
    private final Set<Integer> activeSlots = new HashSet<Integer>(16, 0.9f);
    private String currentTitle = "";
    private static final Pattern IF_PATTERN;

    public static boolean hasScore(Player player) {
        return player != null && players.containsKey(player.getUniqueId());
    }

    public static ScoreHelper createScore(Player player) {
        return player == null ? null : new ScoreHelper(player);
    }

    public static ScoreHelper getByPlayer(Player player) {
        return player != null ? players.get(player.getUniqueId()) : null;
    }

    public static ScoreHelper removeScore(Player player) {
        if (player == null) {
            return null;
        }
        ScoreHelper helper = players.remove(player.getUniqueId());
        if (helper != null) {
            helper.cleanup();
        }
        return helper;
    }

    public static void clearScoreboard(Player player) {
        if (player != null && ScoreHelper.hasScore(player)) {
            ScoreHelper.removeScore(player);
            try {
                player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    public static void cleanupCache() {
        lastColorsCache.clear();
    }

    private ScoreHelper(Player player) {
        this.sidebar = this.scoreboard.registerNewObjective("sidebar", "dummy");
        this.sidebar.setDisplaySlot(DisplaySlot.SIDEBAR);
        for (int i = 1; i <= 15; ++i) {
            Team team = this.scoreboard.registerNewTeam("SLOT_" + i);
            team.addEntry(ENTRIES[i]);
        }
        player.setScoreboard(this.scoreboard);
        players.put(player.getUniqueId(), this);
    }

    private void cleanup() {
        this.cachedTextParts.clear();
        this.activeSlots.clear();
        try {
            this.sidebar.unregister();
            for (int i = 1; i <= 15; ++i) {
                Team team = this.scoreboard.getTeam("SLOT_" + i);
                if (team == null) continue;
                team.unregister();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public void setTitle(String title) {
        if (title == null) {
            title = "";
        }
        if (!title.equals(this.currentTitle)) {
            String displayTitle = title.length() > 32 ? title.substring(0, 32) : title;
            this.sidebar.setDisplayName(displayTitle);
            this.currentTitle = title;
        }
    }

    public void setSlot(int slot, String text) {
        if (slot >= 1 && slot <= 15) {
            Team team;
            if (text == null) {
                text = "";
            }
            if ((team = this.scoreboard.getTeam("SLOT_" + slot)) != null) {
                String[] cached;
                String entry = ENTRIES[slot];
                if (!this.activeSlots.contains(slot)) {
                    this.sidebar.getScore(entry).setScore(slot);
                    this.activeSlots.add(slot);
                }
                if ((cached = this.cachedTextParts.get(slot)) == null || !cached[0].equals(text)) {
                    String prefix = "";
                    Object suffix = "";
                    if (text.length() <= 64) {
                        prefix = text;
                    } else {
                        int splitPos = 64;
                        if (splitPos < text.length()) {
                            if (text.charAt(splitPos - 1) == '\u00a7') {
                                --splitPos;
                            } else if (splitPos >= 2 && text.charAt(splitPos - 2) == '\u00a7') {
                                splitPos -= 2;
                            }
                            for (int i = Math.max(0, splitPos - 14); i < splitPos; ++i) {
                                if (i + 1 >= text.length() || text.charAt(i) != '\u00a7' || text.charAt(i + 1) != 'x') continue;
                                boolean isCompleteHex = true;
                                for (int j = 0; j < 6; ++j) {
                                    int checkPos = i + 2 + j * 2;
                                    if (checkPos < splitPos && checkPos + 1 < text.length() && text.charAt(checkPos) == '\u00a7') continue;
                                    isCompleteHex = false;
                                    break;
                                }
                                if (!isCompleteHex || i + 14 <= splitPos) continue;
                                splitPos = i;
                                break;
                            }
                        }
                        prefix = text.substring(0, splitPos);
                        String lastColors = this.getLastColors(prefix);
                        int remainingLength = Math.min(text.length() - splitPos, 64 - lastColors.length());
                        suffix = remainingLength > 0 ? lastColors + text.substring(splitPos, splitPos + remainingLength) : lastColors;
                    }
                    team.setPrefix(prefix);
                    team.setSuffix((String)suffix);
                    this.cachedTextParts.put(slot, new String[]{text, prefix, suffix});
                }
            }
        }
    }

    public void removeSlot(int slot) {
        if (slot >= 1 && slot <= 15 && this.activeSlots.contains(slot)) {
            this.scoreboard.resetScores(ENTRIES[slot]);
            this.activeSlots.remove(slot);
            this.cachedTextParts.remove(slot);
        }
    }

    public void setSlotsFromList(List<String> list) {
        if (list != null && !list.isEmpty()) {
            int i;
            int size = Math.min(list.size(), 15);
            HashSet<Integer> updatedSlots = new HashSet<Integer>(size);
            for (i = 0; i < size; ++i) {
                int slot = size - i;
                updatedSlots.add(slot);
                this.setSlot(slot, list.get(i));
            }
            for (i = 1; i <= 15; ++i) {
                if (updatedSlots.contains(i) || !this.activeSlots.contains(i)) continue;
                this.removeSlot(i);
            }
        } else {
            for (int size = 1; size <= 15; ++size) {
                this.removeSlot(size);
            }
        }
    }

    public static List<ScoreboardLine> parseScoreboardLines(Map<String, Object> yamlLines) {
        ArrayList<Map.Entry<String, Object>> orderedEntries = new ArrayList<Map.Entry<String, Object>>(yamlLines.entrySet());
        ArrayList<ScoreboardLine> allLines = new ArrayList<ScoreboardLine>();
        int orderCounter = 0;
        for (Map.Entry entry : orderedEntries) {
            String key = (String)entry.getKey();
            String value = String.valueOf(entry.getValue());
            if (key.startsWith("if")) {
                Matcher m = IF_PATTERN.matcher(value);
                if (!m.matches()) continue;
                String typeStr = m.group(1);
                String op = m.group(2);
                int expected = Integer.parseInt(m.group(3));
                String line = m.group(4);
                NumericCondition.Type type = null;
                int var15 = -1;
                switch (typeStr.hashCode()) {
                    case -1654568797: {
                        if (!typeStr.equals("TEAM_SIZE")) break;
                        var15 = 0;
                        break;
                    }
                    case -1414654854: {
                        if (!typeStr.equals("TEAM_AMOUNT")) break;
                        var15 = 1;
                        break;
                    }
                    case -1303794028: {
                        if (!typeStr.equals("PLAYERS_LEFT")) break;
                        var15 = 2;
                    }
                }
                switch (var15) {
                    case 0: {
                        type = NumericCondition.Type.TEAM_SIZE;
                        break;
                    }
                    case 1: {
                        type = NumericCondition.Type.TEAM_AMOUNT;
                        break;
                    }
                    case 2: {
                        type = NumericCondition.Type.PLAYERS_LEFT;
                    }
                }
                if (type == null) continue;
                allLines.add(new ScoreboardLine(line, new NumericCondition(type, op, expected), key, orderCounter++));
                continue;
            }
            try {
                allLines.add(new ScoreboardLine(value, null, key, orderCounter++));
            }
            catch (NumberFormatException numberFormatException) {}
        }
        return allLines;
    }

    public void setSlotsFromScoreboardLines(List<ScoreboardLine> lines, Player player) {
        if (lines != null && !lines.isEmpty()) {
            ArrayList<ScoreboardLine> activeLines = new ArrayList<ScoreboardLine>();
            Iterator<ScoreboardLine> var4 = lines.iterator();
            while (true) {
                if (!var4.hasNext()) {
                    Collections.sort(activeLines, Comparator.comparingInt(l -> l.order));
                    ArrayList<String> displayLines = new ArrayList<String>();
                    for (ScoreboardLine line2 : activeLines) {
                        displayLines.add(line2.line);
                    }
                    this.setSlotsFromList(displayLines);
                    return;
                }
                ScoreboardLine line = var4.next();
                if (line.condition != null && !line.condition.evaluate(player)) continue;
                activeLines.add(line);
            }
        }
        for (int i = 1; i <= 15; ++i) {
            this.removeSlot(i);
        }
    }

    private String getLastColors(String text) {
        if (text != null && !text.isEmpty()) {
            StringBuilder result = new StringBuilder();
            String lastColor = "";
            Object lastFormat = "";
            boolean hasColor = false;
            for (int i = 0; i < text.length() - 1; ++i) {
                if (text.charAt(i) != '\u00a7') continue;
                char colorChar = text.charAt(i + 1);
                if (colorChar == 'x' && i + 13 < text.length()) {
                    boolean validHex = true;
                    for (int j = 0; j < 6; ++j) {
                        int pos = i + 2 + j * 2;
                        if (pos + 1 < text.length() && text.charAt(pos) == '\u00a7') continue;
                        validHex = false;
                        break;
                    }
                    if (!validHex) continue;
                    lastColor = text.substring(i, i + 14);
                    hasColor = true;
                    i += 13;
                    continue;
                }
                if (this.isColorChar(colorChar)) {
                    lastColor = text.substring(i, i + 2);
                    hasColor = true;
                    ++i;
                    continue;
                }
                if (!this.isFormatChar(colorChar)) continue;
                lastFormat = (String)lastFormat + text.substring(i, i + 2);
                ++i;
            }
            if (hasColor) {
                result.append(lastColor);
            }
            result.append((String)lastFormat);
            return result.toString();
        }
        return "";
    }

    private boolean isColorChar(char c) {
        return c >= '0' && c <= '9' || c >= 'a' && c <= 'f' || c >= 'A' && c <= 'F' || c == 'r';
    }

    private boolean isFormatChar(char c) {
        return c == 'k' || c == 'l' || c == 'm' || c == 'n' || c == 'o';
    }

    private boolean isHexDigit(char c) {
        return c >= '0' && c <= '9' || c >= 'a' && c <= 'f' || c >= 'A' && c <= 'F';
    }

    static {
        for (int i = 1; i <= 15; ++i) {
            ScoreHelper.ENTRIES[i] = ChatColor.values()[i].toString();
        }
        for (char c : COLOR_CHARS) {
            COLOR_CHAR_SET.add(Character.valueOf(c));
        }
        IF_PATTERN = Pattern.compile("^([A-Z_]+)\\s*(==|>=|<=|>|<)\\s*(\\d+)\\s*LINE=\"([^\"]+)\"$");
    }

    public static class NumericCondition
    implements ScoreboardCondition {
        private final Type type;
        private final String operator;
        private final int expected;

        public NumericCondition(Type type, String operator, int expected) {
            this.type = type;
            this.operator = operator;
            this.expected = expected;
        }

        @Override
        public boolean evaluate(Player player) {
            String playerGameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
            if (playerGameID == null && player.getPlayer() != null) {
                playerGameID = player.getPlayer().getWorld().getName().replace("Areas/", "");
            }
            int value = 0;
            try {
                switch (this.type.ordinal()) {
                    case 0: {
                        value = TeamManager.GetPlayersPerTeam(playerGameID);
                        break;
                    }
                    case 1: {
                        value = TeamManager.GetMaxTeams(playerGameID);
                        break;
                    }
                    case 2: {
                        value = HashMapHandler.getMembersGameID(playerGameID).size();
                    }
                }
                switch (this.operator) {
                    case "==": {
                        return value == this.expected;
                    }
                    case ">=": {
                        return value >= this.expected;
                    }
                    case "<=": {
                        return value <= this.expected;
                    }
                    case ">": {
                        return value > this.expected;
                    }
                    case "<": {
                        return value < this.expected;
                    }
                }
                return false;
            }
            catch (Exception var6) {
                return false;
            }
        }

        public static final class Type
        extends Enum<Type> {
            public static final /* enum */ Type TEAM_SIZE = new Type();
            public static final /* enum */ Type TEAM_AMOUNT = new Type();
            public static final /* enum */ Type PLAYERS_LEFT = new Type();
            private static final /* synthetic */ Type[] $VALUES;

            public static Type[] values() {
                return (Type[])$VALUES.clone();
            }

            public static Type valueOf(String name) {
                return Enum.valueOf(Type.class, name);
            }

            private static Type[] $values() {
                return new Type[]{TEAM_SIZE, TEAM_AMOUNT, PLAYERS_LEFT};
            }

            private static /* synthetic */ Type[] $values$() {
                return new Type[]{TEAM_SIZE, TEAM_AMOUNT, PLAYERS_LEFT};
            }

            static {
                $VALUES = Type.$values$();
            }
        }
    }

    public static class ScoreboardLine {
        public final String line;
        public final ScoreboardCondition condition;
        public final String key;
        public final int order;

        public ScoreboardLine(String line, ScoreboardCondition condition, String key, int order) {
            this.line = line;
            this.condition = condition;
            this.key = key;
            this.order = order;
        }
    }

    public static interface ScoreboardCondition {
        public boolean evaluate(Player var1);
    }
}

