/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.PlaceholderAPI
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.ScoreBoardAPI;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;
import org.kloppie74.MoonPillars.PaperMC.ScoreBoardAPI.ScoreHelper;

public class NewScoreboard
implements Listener {
    private static final Map<String, Boolean> enabledCache = new HashMap<String, Boolean>(8, 0.9f);
    private static final Map<String, String> titleCache = new HashMap<String, String>(8, 0.9f);
    private static final Map<String, Map<String, Object>> linesCache = new HashMap<String, Map<String, Object>>(8, 0.9f);
    private static final Map<String, List<String>> lineOrderCache = new HashMap<String, List<String>>(8, 0.9f);
    private static final Map<UUID, String> playerScoreboardState = new ConcurrentHashMap<UUID, String>(64, 0.75f, 2);
    private static final String SECTION_LOBBY = "Lobby";
    private static final String SECTION_GAME = "Game";
    private static final String SECTION_GAME_LOBBY = "Game_Lobby";
    private static final String SECTION_GAME_SPECTATE = "Game_Spectate";
    private static final String SECTION_GAME_ENDED = "Game_Ended";
    private static String lobbyWorld;
    private static boolean cacheInitialized;
    private static Plugin placeholderAPI;
    private static final Logger logger;
    private static final String[] SCOREBOARD_SECTIONS;

    private static void initializeCache() {
        if (!cacheInitialized) {
            FileConfiguration config = SettingsManager.getInstance().getScoreboard();
            FileConfiguration settings = SettingsManager.getInstance().getSettings();
            lobbyWorld = settings.getString("LobbySettings.World");
            placeholderAPI = Bukkit.getPluginManager().getPlugin("PlaceholderAPI");
            for (String section : SCOREBOARD_SECTIONS) {
                NewScoreboard.cacheScoreboardSection(config, section);
            }
            cacheInitialized = true;
        }
    }

    private static void cacheScoreboardSection(FileConfiguration config, String section) {
        String basePath = "ScoreBoards." + section + ".";
        String enabledPath = basePath + "Enabled";
        enabledCache.put(section, config.contains(enabledPath) && config.getBoolean(enabledPath));
        String titlePath = basePath + "Title";
        titleCache.put(section, config.getString(titlePath, ""));
        NewScoreboard.cacheLines(config, section);
    }

    private static void cacheLines(FileConfiguration config, String section) {
        String basePath = "ScoreBoards." + section + ".Lines";
        if (!config.contains(basePath)) {
            linesCache.put(section, Collections.emptyMap());
            lineOrderCache.put(section, Collections.emptyList());
        } else {
            ConfigurationSection linesSection = config.getConfigurationSection(basePath);
            if (linesSection == null) {
                linesCache.put(section, Collections.emptyMap());
                lineOrderCache.put(section, Collections.emptyList());
            } else {
                LinkedHashMap<String, String> lines = new LinkedHashMap<String, String>();
                ArrayList<String> lineOrder = new ArrayList<String>();
                for (String key : linesSection.getKeys(false)) {
                    String value = linesSection.getString(key);
                    if (value == null) continue;
                    lines.put(key, value);
                    lineOrder.add(key);
                }
                linesCache.put(section, lines);
                lineOrderCache.put(section, lineOrder);
            }
        }
    }

    public static void reloadCache(Player player) {
        enabledCache.clear();
        titleCache.clear();
        linesCache.clear();
        lineOrderCache.clear();
        cacheInitialized = false;
        System.gc();
        NewScoreboard.initializeCache();
        player.sendMessage(MSG.chatColors("&aAll scoreboard caches have been reloaded."));
    }

    public static void createOrUpdateScoreboard(Player player) {
        boolean isGamePlaying;
        String gameID;
        GameMode gameMode;
        if (!cacheInitialized) {
            NewScoreboard.initializeCache();
        }
        UUID uuid = player.getUniqueId();
        String worldName = player.getWorld().getName();
        String scoreboardType = NewScoreboard.determineScoreboardType(worldName, gameMode = player.getGameMode(), gameID, isGamePlaying = (gameID = HashMapHandler.getPlayerGameID(uuid)) != null && HashMapHandler.getIsGamePlaying(gameID) != false);
        if (scoreboardType == null) {
            NewScoreboard.removeScoreboardIfPresent(player);
        } else {
            String currentState = playerScoreboardState.get(uuid);
            if (scoreboardType.equals(currentState)) {
                NewScoreboard.updateExistingScoreboard(player, scoreboardType);
            } else {
                NewScoreboard.createNewScoreboard(player, scoreboardType);
            }
        }
    }

    private static void removeScoreboardIfPresent(Player player) {
        UUID uuid = player.getUniqueId();
        if (playerScoreboardState.containsKey(uuid)) {
            ScoreHelper.clearScoreboard(player);
            ScoreHelper.removeScore(player);
            playerScoreboardState.remove(uuid);
        }
    }

    private static void updateExistingScoreboard(Player player, String scoreboardType) {
        ScoreHelper helper = ScoreHelper.getByPlayer(player);
        if (helper != null) {
            NewScoreboard.updateScoreboardWithCache(player, scoreboardType, helper);
        }
    }

    private static void createNewScoreboard(Player player, String scoreboardType) {
        ScoreHelper helper = ScoreHelper.getByPlayer(player);
        if (helper == null) {
            helper = ScoreHelper.createScore(player);
        }
        NewScoreboard.updateScoreboardWithCache(player, scoreboardType, helper);
        playerScoreboardState.put(player.getUniqueId(), scoreboardType);
    }

    private static String determineScoreboardType(String worldName, GameMode gameMode, String gameID, boolean isGamePlaying) {
        if (worldName.equalsIgnoreCase(lobbyWorld) && enabledCache.getOrDefault(SECTION_LOBBY, false).booleanValue()) {
            return SECTION_LOBBY;
        }
        if (gameID != null && worldName.contains("Mini-") || worldName.startsWith("Areas/")) {
            if (gameID == null && worldName.startsWith("Areas/") && enabledCache.getOrDefault(SECTION_GAME_SPECTATE, false).booleanValue()) {
                return SECTION_GAME_SPECTATE;
            }
            if (gameID != null) {
                if (isGamePlaying && enabledCache.getOrDefault(SECTION_GAME, false).booleanValue()) {
                    return SECTION_GAME;
                }
                if (!isGamePlaying && enabledCache.getOrDefault(SECTION_GAME_LOBBY, false).booleanValue()) {
                    return SECTION_GAME_LOBBY;
                }
                if (gameMode.equals((Object)GameMode.SPECTATOR) && enabledCache.getOrDefault(SECTION_GAME_SPECTATE, false).booleanValue()) {
                    return SECTION_GAME_SPECTATE;
                }
                if (HashMapHandler.getItemTimer(gameID) == null && enabledCache.getOrDefault(SECTION_GAME_ENDED, false).booleanValue()) {
                    return SECTION_GAME_ENDED;
                }
            }
        }
        return null;
    }

    private static void updateScoreboardWithCache(Player player, String section, ScoreHelper helper) {
        try {
            String title = titleCache.getOrDefault(section, "");
            if (!title.isEmpty()) {
                if (placeholderAPI != null && placeholderAPI.isEnabled()) {
                    title = PlaceholderAPI.setPlaceholders((Player)player, (String)title);
                }
                title = MSG.chatColors(title);
                helper.setTitle(title);
            }
            Map lines = linesCache.getOrDefault(section, Collections.emptyMap());
            List lineOrder = lineOrderCache.getOrDefault(section, Collections.emptyList());
            if (!lines.isEmpty()) {
                LinkedHashMap<String, Object> processedLines = new LinkedHashMap<String, Object>(lines.size());
                boolean hasPlaceholders = placeholderAPI != null && placeholderAPI.isEnabled();
                Iterator var8 = lineOrder.iterator();
                while (true) {
                    if (!var8.hasNext()) {
                        List<ScoreHelper.ScoreboardLine> scoreboardLines = ScoreHelper.parseScoreboardLines(processedLines);
                        helper.setSlotsFromScoreboardLines(scoreboardLines, player);
                        return;
                    }
                    String key = (String)var8.next();
                    Object valueObj = lines.get(key);
                    if (valueObj == null) continue;
                    String value = String.valueOf(valueObj);
                    try {
                        if (key.startsWith("if")) {
                            int lineStart = value.indexOf("LINE=\"");
                            int lineEnd = value.lastIndexOf("\"");
                            if (lineStart >= 0 && lineEnd > lineStart + 6) {
                                String condition = value.substring(0, lineStart + 6);
                                String lineText = value.substring(lineStart + 6, lineEnd);
                                if (hasPlaceholders) {
                                    lineText = PlaceholderAPI.setPlaceholders((Player)player, (String)lineText);
                                }
                                lineText = MSG.chatColors(lineText);
                                processedLines.put(key, condition + lineText + "\"");
                                continue;
                            }
                            processedLines.put(key, value);
                            continue;
                        }
                        String processedValue = value;
                        if (hasPlaceholders) {
                            processedValue = PlaceholderAPI.setPlaceholders((Player)player, (String)value);
                        }
                        processedValue = MSG.chatColors(processedValue);
                        processedLines.put(key, processedValue);
                    }
                    catch (Exception var16) {
                        processedLines.put(key, value);
                    }
                }
            }
            for (int i = 1; i <= 15; ++i) {
                helper.removeSlot(i);
            }
        }
        catch (Exception var17) {
            var17.printStackTrace();
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        NewScoreboard.createOrUpdateScoreboard(event.getPlayer());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        if (ScoreHelper.hasScore(player)) {
            ScoreHelper.removeScore(player);
        }
        playerScoreboardState.remove(uuid);
    }

    public static void cleanup() {
        playerScoreboardState.clear();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!ScoreHelper.hasScore(player)) continue;
            ScoreHelper.removeScore(player);
        }
        enabledCache.clear();
        titleCache.clear();
        linesCache.clear();
        lineOrderCache.clear();
        cacheInitialized = false;
        System.gc();
    }

    static {
        cacheInitialized = false;
        logger = MoonLab.getInstance().getLogger();
        SCOREBOARD_SECTIONS = new String[]{SECTION_LOBBY, SECTION_GAME, SECTION_GAME_LOBBY, SECTION_GAME_SPECTATE, SECTION_GAME_ENDED};
    }
}

