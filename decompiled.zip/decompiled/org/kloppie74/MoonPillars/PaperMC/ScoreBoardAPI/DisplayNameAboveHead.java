/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.neznamy.tab.api.TabAPI
 *  me.neznamy.tab.api.TabPlayer
 *  me.neznamy.tab.api.nametag.NameTagManager
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.scoreboard.Scoreboard
 *  org.bukkit.scoreboard.ScoreboardManager
 *  org.bukkit.scoreboard.Team
 */
package org.kloppie74.MoonPillars.PaperMC.ScoreBoardAPI;

import java.util.Collection;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import me.neznamy.tab.api.TabAPI;
import me.neznamy.tab.api.TabPlayer;
import me.neznamy.tab.api.nametag.NameTagManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;
import org.bukkit.scoreboard.Team;

public class DisplayNameAboveHead {
    private static final Map<String, Scoreboard> playerScoreboards = new ConcurrentHashMap<String, Scoreboard>(64, 0.75f, 2);
    private static final boolean isTabEnabled = Bukkit.getPluginManager().isPluginEnabled("TAB");

    public static void setNick(Player player, String nick) {
        if (player != null) {
            String playerName = player.getName();
            if (isTabEnabled) {
                DisplayNameAboveHead.updateTabNameTag(playerName, nick, null);
            } else {
                DisplayNameAboveHead.updateVanillaNameTag(player, nick, "");
            }
        }
    }

    public static void removeNick(Player player) {
        if (player != null) {
            String playerName = player.getName();
            if (isTabEnabled) {
                DisplayNameAboveHead.updateTabNameTag(playerName, null, null);
            } else {
                DisplayNameAboveHead.updateVanillaNameTag(player, "", "");
            }
        }
    }

    private static void updateTabNameTag(String playerName, String prefix, String suffix) {
        TabPlayer tabPlayer;
        NameTagManager nameTagManager;
        TabAPI api = TabAPI.getInstance();
        if (api != null && (nameTagManager = api.getNameTagManager()) != null && (tabPlayer = api.getPlayer(playerName)) != null) {
            nameTagManager.setPrefix(tabPlayer, prefix);
            nameTagManager.setSuffix(tabPlayer, suffix);
        }
    }

    private static void updateVanillaNameTag(Player player, String prefix, String suffix) {
        Collection onlinePlayers = Bukkit.getOnlinePlayers();
        ScoreboardManager scoreboardManager = Bukkit.getScoreboardManager();
        if (scoreboardManager != null) {
            String playerName = player.getName();
            for (Player online : onlinePlayers) {
                if (!online.canSee(player)) continue;
                Scoreboard scoreboard = DisplayNameAboveHead.getPlayerScoreboard(online, scoreboardManager);
                Team team = scoreboard.getTeam(playerName);
                if (team == null) {
                    team = scoreboard.registerNewTeam(playerName);
                }
                team.setPrefix(Objects.requireNonNullElse(prefix, ""));
                team.setSuffix(Objects.requireNonNullElse(suffix, ""));
                if (!team.hasEntry(playerName)) {
                    team.addEntry(playerName);
                }
                online.setScoreboard(scoreboard);
            }
        }
    }

    private static Scoreboard getPlayerScoreboard(Player player, ScoreboardManager manager) {
        Scoreboard scoreboard = playerScoreboards.get(player.getUniqueId().toString());
        if (scoreboard == null || scoreboard == manager.getMainScoreboard()) {
            scoreboard = manager.getNewScoreboard();
            playerScoreboards.put(player.getUniqueId().toString(), scoreboard);
        }
        return scoreboard;
    }

    public static void cleanupPlayerScoreboard(String playerUUID) {
        playerScoreboards.remove(playerUUID);
    }
}

