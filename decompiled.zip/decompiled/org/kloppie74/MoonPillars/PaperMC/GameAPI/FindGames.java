/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.file.FileConfiguration
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.bukkit.configuration.file.FileConfiguration;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;

public class FindGames {
    public static List<String> FindTeamSize(int Size, int MaxTeams) {
        ArrayList<String> validGameIDs = new ArrayList<String>();
        for (String gameID : HashMapHandler.getAllMapGameIDs()) {
            FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
            if (config == null || !config.contains("SpawnLocations.PlayersPerTeam") || !config.contains("SpawnLocations.MaxTeams")) continue;
            int playersPerTeam = config.getInt("SpawnLocations.PlayersPerTeam");
            int maxTeams = config.getInt("SpawnLocations.MaxTeams");
            int var10000 = playersPerTeam * maxTeams;
            if (playersPerTeam != Size || maxTeams > MaxTeams) continue;
            validGameIDs.add(gameID);
        }
        return validGameIDs;
    }

    public static String FindRandomTeamSize(int Size, int MaxTeams) {
        List<String> validGameIDs = FindGames.FindTeamSize(Size, MaxTeams);
        if (validGameIDs.isEmpty()) {
            return null;
        }
        Random random = new Random();
        int randomIndex = random.nextInt(validGameIDs.size());
        return validGameIDs.get(randomIndex);
    }

    public static List<String> FindTeamMode(String Mode) {
        ArrayList<String> validGameIDs = new ArrayList<String>();
        for (String gameID : HashMapHandler.getAllMapGameIDs()) {
            String configMode;
            FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
            if (config == null || !config.contains("Settings.Mode") || !Mode.equalsIgnoreCase(configMode = config.getString("Settings.Mode"))) continue;
            validGameIDs.add(gameID);
        }
        return validGameIDs;
    }

    public static String FindRandomTeamMode(String Mode) {
        List<String> validGameIDs = FindGames.FindTeamMode(Mode);
        if (validGameIDs.isEmpty()) {
            return null;
        }
        Random random = new Random();
        return validGameIDs.get(random.nextInt(validGameIDs.size()));
    }
}

