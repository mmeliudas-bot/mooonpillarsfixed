/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Stream;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;

public class Spectate
implements CommandExecutor,
TabCompleter {
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (args.length == 1) {
            String input = args[0].toLowerCase();
            Stream<String> var10000 = HashMapHandler.getAllIsGamePlaying().stream().filter(Map.Entry::getValue).map(Map.Entry::getKey).filter(game -> game.toLowerCase().startsWith(input));
            Objects.requireNonNull(completions);
            completions.addAll(var10000.toList());
            var10000 = Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(name -> name.toLowerCase().startsWith(input));
            Objects.requireNonNull(completions);
            completions.addAll(var10000.toList());
        }
        return completions;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can execute this command!");
            return true;
        }
        Player spectator = (Player)sender;
        String gameID = HashMapHandler.getPlayerGameID(spectator.getUniqueId());
        if (gameID != null) {
            MessageSender.SendMessage(spectator, "Games.Player-Is-In-Game", "", "");
            return true;
        }
        if (args.length == 1) {
            String target = args[0];
            if (HashMapHandler.getIsGamePlaying(target) != null && HashMapHandler.getIsGamePlaying(target).booleanValue()) {
                Spectate.SpectateGameID(spectator, target);
                return true;
            }
            Player targetPlayer = Bukkit.getPlayer((String)target);
            if (targetPlayer != null) {
                Spectate.SpectateGame(targetPlayer, spectator);
                return true;
            }
            MessageSender.SendMessage(spectator, "Commands.Invalid-Target", "{target}", target);
            return true;
        }
        MessageSender.SendMessage(spectator, "Commands.SpectateUsage", "", "");
        return true;
    }

    public static void SpectateGameID(Player spectator, String gameID) {
        World world = Bukkit.getWorld((String)("Areas/" + gameID));
        if (world == null) {
            MessageSender.SendMessage(spectator, "Games.Game-Not-Found", "{gameid}", gameID);
        } else if (Boolean.TRUE.equals(HashMapHandler.getIsGamePlaying(gameID))) {
            FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
            int locX = config.getInt("Settings.SpawnPoint.X");
            int locY = config.getInt("Settings.SpawnPoint.Y");
            int locZ = config.getInt("Settings.SpawnPoint.Z");
            Location TPLoc = new Location(world, (double)locX, (double)locY, (double)locZ);
            spectator.teleport(TPLoc);
            MessageSender.SendMessage(spectator, "Commands.Spectating-Game", "{gameid}", gameID);
        } else {
            MessageSender.SendMessage(spectator, "Games.Game-Not-Started", "{gameid}", gameID);
        }
    }

    public static void SpectateGame(Player target, Player spectator) {
        if (target == spectator) {
            MessageSender.SendMessage(spectator, "Commands.Spectate-Is-Player", "", "");
        } else {
            String gameID = HashMapHandler.getPlayerGameID(target.getUniqueId());
            if (gameID != null && HashMapHandler.getIsGameStarted(gameID) != null) {
                World world = Bukkit.getWorld((String)("Areas/" + gameID));
                FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
                int locX = config.getInt("Settings.SpawnPoint.X");
                int locY = config.getInt("Settings.SpawnPoint.Y");
                int locZ = config.getInt("Settings.SpawnPoint.Z");
                Location TPLoc = new Location(world, (double)locX, (double)locY, (double)locZ);
                spectator.teleport(TPLoc);
                MessageSender.SendMessage(spectator, "Commands.Spectating-Player", "{target}", target.getName());
            } else {
                MessageSender.SendMessage(spectator, "Commands.Spectate-No-Game", "{target}", target.getName());
            }
        }
    }
}

