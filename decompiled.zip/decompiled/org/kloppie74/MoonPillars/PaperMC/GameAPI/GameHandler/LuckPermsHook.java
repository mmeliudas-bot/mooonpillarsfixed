/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.luckperms.api.LuckPerms
 *  net.luckperms.api.LuckPermsProvider
 *  net.luckperms.api.model.group.Group
 *  net.luckperms.api.model.user.User
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.DonatorItemManager;

public class LuckPermsHook {
    public static int getHighestCount(Player player, List<DonatorItemManager.DonatorEntry> entries) {
        LuckPerms api = LuckPermsProvider.get();
        User user = api.getPlayerAdapter(Player.class).getUser((Object)player);
        ArrayList<Object> groups = new ArrayList<Object>(user.getInheritedGroups(user.getQueryOptions()));
        groups.sort(Comparator.comparingInt(group -> ((Group)group).getWeight().orElse(0)).reversed());
        for (Group group2 : groups) {
            for (DonatorItemManager.DonatorEntry entry : entries) {
                String groupName = entry.permission.toLowerCase().startsWith("group.") ? entry.permission.substring(6) : entry.permission;
                if (!groupName.equalsIgnoreCase(group2.getName())) continue;
                return entry.count;
            }
        }
        return 0;
    }
}

