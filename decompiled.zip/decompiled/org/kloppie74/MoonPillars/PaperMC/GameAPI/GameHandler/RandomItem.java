package org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionData;
import org.bukkit.potion.PotionType;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.API;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;

public class RandomItem {
    private static final Map<String, List<ItemOrCommand>> gameItemCache = new ConcurrentHashMap<>();
    private static final List<Material> validItemMaterials = RandomItem.initializeValidMaterials();
    private static final Map<String, WeakReference<List<ItemOrCommand>>> softCache = new ConcurrentHashMap<>();
    private static final int MAX_CACHE_SIZE = 200;

    private static List<Material> initializeValidMaterials() {
        List<Material> materials = new ArrayList<>();
        for (Material material : Material.values()) {
            if (!material.isItem() || material.isAir()) continue;
            materials.add(material);
        }
        return Collections.unmodifiableList(materials);
    }

    public static void ItemGivingTask(String gameID, Player player) {
        FileConfiguration config;
        if (player != null && player.isOnline() && gameID != null && API.onItemGive(gameID, player) && (config = HashMapHandler.getConfigGameID(gameID)) != null) {
            String baseGameID = getBaseGameID(gameID);
            List<ItemOrCommand> items = getItemsForGame(baseGameID, config);
            if (items.isEmpty()) {
                addItemSafely(player, new ItemStack(Material.STONE));
            } else {
                ItemOrCommand randomItem = items.get(ThreadLocalRandom.current().nextInt(items.size()));
                if (randomItem.isCommand) {
                    String command = randomItem.command.replace("%player%", player.getName());
                    command = command.startsWith("/") ? command.substring(1) : command;
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
                } else if (randomItem.isCustomItem) {
                    addItemSafely(player, randomItem.customItem.clone());
                } else {
                    addItemSafely(player, new ItemStack(randomItem.material, 1));
                }
            }
        }
    }

    public static void SynchronizedItemGivingTask(String gameID, List<Player> players, World world) {
        FileConfiguration config;
        if (players != null && gameID != null && (config = HashMapHandler.getConfigGameID(gameID)) != null) {
            String baseGameID = getBaseGameID(gameID);
            List<ItemOrCommand> items = getItemsForGame(baseGameID, config);
            ItemOrCommand chosen = items.isEmpty() ? null : items.get(ThreadLocalRandom.current().nextInt(items.size()));
            for (Player player : players) {
                if (player == null || !player.isOnline() || world != null && !player.getWorld().equals(world) || !API.onItemGive(gameID, player)) continue;
                if (chosen == null) {
                    addItemSafely(player, new ItemStack(Material.STONE));
                    continue;
                }
                if (chosen.isCommand) {
                    String command = chosen.command.replace("%player%", player.getName());
                    command = command.startsWith("/") ? command.substring(1) : command;
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
                    continue;
                }
                if (chosen.isCustomItem) {
                    addItemSafely(player, chosen.customItem.clone());
                    continue;
                }
                addItemSafely(player, new ItemStack(chosen.material, 1));
            }
        }
    }

    public static void giveRandomItem(String gameID, Player player) {
        FileConfiguration config;
        if (player != null && player.isOnline() && gameID != null && (config = HashMapHandler.getConfigGameID(gameID)) != null) {
            String baseGameID = getBaseGameID(gameID);
            List<ItemOrCommand> items = getItemsForGame(baseGameID, config);
            if (items.isEmpty()) {
                addItemSafely(player, new ItemStack(Material.STONE));
            } else {
                ItemOrCommand randomItem = items.get(ThreadLocalRandom.current().nextInt(items.size()));
                if (randomItem.isCommand) {
                    String command = randomItem.command.replace("%player%", player.getName());
                    command = command.startsWith("/") ? command.substring(1) : command;
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
                } else if (randomItem.isCustomItem) {
                    addItemSafely(player, randomItem.customItem.clone());
                } else {
                    addItemSafely(player, new ItemStack(randomItem.material, 1));
                }
            }
        }
    }

    public static boolean addCustomItem(String gameID, ItemStack item) {
        if (gameID != null && item != null && item.getType() != Material.AIR) {
            String baseGameID = getBaseGameID(gameID);
            FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
            if (config == null) return false;
            List<ItemOrCommand> items = getItemsForGame(baseGameID, config);
            items.add(new ItemOrCommand(item));
            gameItemCache.put(baseGameID, items);
            cleanupCacheIfNeeded();
            return true;
        }
        return false;
    }

    public static boolean addCustomCommand(String gameID, String command) {
        if (gameID != null && command != null && !command.isEmpty()) {
            if (command.startsWith("/")) {
                command = command.substring(1);
            }
            String baseGameID = getBaseGameID(gameID);
            FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
            if (config == null) return false;
            List<ItemOrCommand> items = getItemsForGame(baseGameID, config);
            items.add(new ItemOrCommand(command));
            gameItemCache.put(baseGameID, items);
            cleanupCacheIfNeeded();
            return true;
        }
        return false;
    }

    private static void addItemSafely(Player player, ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return;
        PlayerInventory inventory = player.getInventory();

        if (item.getMaxStackSize() > 1) {
            for (int i = 0; i < 36; i++) {
                ItemStack slotItem = inventory.getItem(i);
                if (slotItem == null || slotItem.getType() != item.getType()) continue;
                if (slotItem.getDurability() != item.getDurability()) continue;
                if (slotItem.getAmount() >= slotItem.getMaxStackSize()) continue;
                ItemMeta slotMeta = slotItem.getItemMeta();
                ItemMeta itemMeta = item.getItemMeta();
                if (slotMeta != null && itemMeta != null && !slotMeta.equals(itemMeta)) continue;

                int space = slotItem.getMaxStackSize() - slotItem.getAmount();
                if (space >= item.getAmount()) {
                    slotItem.setAmount(slotItem.getAmount() + item.getAmount());
                    return;
                }
                slotItem.setAmount(slotItem.getMaxStackSize());
                item.setAmount(item.getAmount() - space);
            }
        }

        if (item.getAmount() <= 0) return;

        for (int i = 0; i < 36; i++) {
            ItemStack slotItem = inventory.getItem(i);
            if (slotItem == null || slotItem.getType() == Material.AIR) {
                inventory.setItem(i, item);
                return;
            }
        }

        Map<Integer, ItemStack> leftover = inventory.addItem(item);
        if (!leftover.isEmpty()) {
            player.getWorld().dropItem(player.getLocation(), item);
        }
    }

    public static String getBaseGameID(String gameID) {
        int lastDashIndex = gameID.lastIndexOf(45);
        if (lastDashIndex != -1) {
            String suffix = gameID.substring(lastDashIndex + 1);
            if (suffix.matches("\\d+")) {
                return gameID.substring(0, lastDashIndex);
            }
        }
        return gameID;
    }

    private static List<ItemOrCommand> getItemsForGame(String baseGameID, FileConfiguration config) {
        WeakReference<List<ItemOrCommand>> weakRef = softCache.get(baseGameID);
        if (weakRef != null) {
            List<ItemOrCommand> cachedItems = weakRef.get();
            if (cachedItems != null) return cachedItems;
        }
        List<ItemOrCommand> items = gameItemCache.computeIfAbsent(baseGameID, id -> loadItemsFromConfig(config));
        softCache.put(baseGameID, new WeakReference<>(items));
        return items;
    }

    private static List<ItemOrCommand> loadItemsFromConfig(FileConfiguration config) {
        String type = config.getString("Settings.RandomItems.Type", "Blacklisted");
        List<String> itemList = config.getStringList("Settings.RandomItems.List");
        List<ItemOrCommand> availableItems = new ArrayList<>();

        if ("Blacklisted".equalsIgnoreCase(type)) {
            Set<String> blacklist = new HashSet<>(itemList);

            for (Material material : validItemMaterials) {
                if (blacklist.contains(material.name())) continue;
                availableItems.add(new ItemOrCommand(material));
            }

            List<Material> potionMaterials = Arrays.asList(
                    Material.POTION, Material.SPLASH_POTION, Material.LINGERING_POTION
            );

            for (Material mat : potionMaterials) {
                if (blacklist.contains(mat.name())) continue;

                for (PotionType potionType : PotionType.values()) {
                    try {
                        ItemStack potion = new ItemStack(mat, 1);
                        PotionMeta meta = (PotionMeta) potion.getItemMeta();
                        if (meta == null) continue;

                        meta.setBasePotionData(new PotionData(potionType, false, false));
                        potion.setItemMeta(meta);
                        availableItems.add(new ItemOrCommand(potion.clone()));

                        if (potionType.isUpgradeable()) {
                            meta = (PotionMeta) potion.getItemMeta();
                            meta.setBasePotionData(new PotionData(potionType, false, true));
                            potion.setItemMeta(meta);
                            availableItems.add(new ItemOrCommand(potion.clone()));
                        }

                        if (potionType.isExtendable()) {
                            meta = (PotionMeta) potion.getItemMeta();
                            meta.setBasePotionData(new PotionData(potionType, true, false));
                            potion.setItemMeta(meta);
                            availableItems.add(new ItemOrCommand(potion.clone()));
                        }
                    } catch (Exception ignored) {}
                }
            }

            return availableItems;
        }

        for (String item : itemList) {
            if (item.startsWith("/")) {
                availableItems.add(new ItemOrCommand(item.substring(1)));
                continue;
            }

            try {
                if (item.startsWith("POTION:") || item.startsWith("SPLASH_POTION:") || item.startsWith("LINGERING_POTION:")) {
                    String[] split = item.split(":", 2);
                    Material mat = Material.valueOf(split[0]);
                    PotionType potionType = PotionType.valueOf(split[1]);
                    ItemStack potion = new ItemStack(mat, 1);
                    PotionMeta meta = (PotionMeta) potion.getItemMeta();
                    if (meta == null) continue;
                    meta.setBasePotionData(new PotionData(potionType, false, false));
                    potion.setItemMeta(meta);
                    availableItems.add(new ItemOrCommand(potion));
                    continue;
                }

                Material material = Material.valueOf(item);
                if (!material.isItem() || material.isAir()) continue;
                availableItems.add(new ItemOrCommand(material));
            } catch (IllegalArgumentException ignored) {}
        }

        return availableItems;
    }

    private static void cleanupCacheIfNeeded() {
        if (gameItemCache.size() > MAX_CACHE_SIZE) {
            List<String> keysToRemove = new ArrayList<>(gameItemCache.keySet());
            int removeCount = Math.min(40, keysToRemove.size());
            for (int i = 0; i < removeCount; i++) {
                String key = keysToRemove.get(i);
                gameItemCache.remove(key);
                softCache.remove(key);
            }
        }
    }

    public static void clearItemCache(String baseGameID) {
        if (baseGameID == null) {
            gameItemCache.clear();
            softCache.clear();
        } else {
            gameItemCache.remove(baseGameID);
            softCache.remove(baseGameID);
        }
    }

    private static class ItemOrCommand {
        final Material material;
        final ItemStack customItem;
        final String command;
        final boolean isCommand;
        final boolean isCustomItem;

        ItemOrCommand(Material material) {
            this.material = material;
            this.customItem = null;
            this.command = null;
            this.isCommand = false;
            this.isCustomItem = false;
        }

        ItemOrCommand(String command) {
            this.material = null;
            this.customItem = null;
            this.command = command;
            this.isCommand = true;
            this.isCustomItem = false;
        }

        ItemOrCommand(ItemStack customItem) {
            this.material = null;
            this.customItem = customItem;
            this.command = null;
            this.isCommand = false;
            this.isCustomItem = true;
        }
    }
}