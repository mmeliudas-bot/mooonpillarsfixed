/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.scheduler.BukkitRunnable
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.VoteListener;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class VoteEvent {
    private static final Random random = new Random();
    private static List<Material> solidBlocksCache = null;

    public static void VoteEvents(String gameID) {
        CharSequence mode = VoteListener.GetMostVoted(gameID);
        FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
        HashMapHandler.setFasterItemsMode(gameID, false);
        HashMapHandler.setSynchronizedItemsMode(gameID, false);
        if (mode != null && !((String)mode).isEmpty()) {
            if (((String)mode).contains(",")) {
                CharSequence[] tiedModes = ((String)mode).split(",");
                String tiedModesList = String.join((CharSequence)", ", tiedModes);
                mode = tiedModes[random.nextInt(tiedModes.length)];
                ArrayList<Player> voters = new ArrayList<Player>();
                CharSequence[] var6 = tiedModes;
                int var7 = tiedModes.length;
                for (int var8 = 0; var8 < var7; ++var8) {
                    CharSequence voteMode = var6[var8];
                    List<String> votersForMode = VoteListener.getVotersForMode(gameID, (String)voteMode);
                    for (String voterName : votersForMode) {
                        Player voter = Bukkit.getPlayer((String)voterName);
                        if (voter == null || voters.contains(voter)) continue;
                        voters.add(voter);
                    }
                }
                for (Player voter : voters) {
                    voter.sendMessage(SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.Tie").replace("{modes}", tiedModesList));
                    voter.sendMessage(SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.TieChosen").replace("{mode}", mode));
                }
            }
            HashMapHandler.setActiveMode(gameID, (String)mode);
            for (Player player : HashMapHandler.getMembersGameID(gameID)) {
                if (((String)mode).equalsIgnoreCase("1 Heart Mode") || ((String)mode).equalsIgnoreCase("Double HP")) continue;
                player.setMaxHealth(20.0);
                player.setHealth(20.0);
            }
            VoteEvent.notifyPlayers(gameID, (String)mode);
            VoteListener.clearVotes(gameID);
            if (((String)mode).equalsIgnoreCase("Floor is Lava")) {
                int timer = 10;
                VoteEvent.startLava(gameID, timer);
            } else if (((String)mode).equalsIgnoreCase("Elytra Mode")) {
                for (Player player : HashMapHandler.getMembersGameID(gameID)) {
                    ItemStack elytra = new ItemStack(Material.ELYTRA);
                    ItemMeta meta = elytra.getItemMeta();
                    if (meta != null) {
                        meta.addEnchant(Enchantment.VANISHING_CURSE, 1, true);
                        meta.addEnchant(Enchantment.BINDING_CURSE, 1, true);
                        elytra.setItemMeta(meta);
                    }
                    player.getInventory().setChestplate(elytra);
                }
            } else if (((String)mode).equalsIgnoreCase("NoFall Mode")) {
                for (Player player : HashMapHandler.getMembersGameID(gameID)) {
                    player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, Integer.MAX_VALUE, 0, false, false));
                }
            } else if (((String)mode).equalsIgnoreCase("1 Heart Mode")) {
                for (Player player : HashMapHandler.getMembersGameID(gameID)) {
                    player.setMaxHealth(2.0);
                    player.setHealth(2.0);
                }
            } else if (((String)mode).equalsIgnoreCase("Double HP")) {
                for (Player player : HashMapHandler.getMembersGameID(gameID)) {
                    player.setMaxHealth(40.0);
                    player.setHealth(40.0);
                }
            } else if (((String)mode).equalsIgnoreCase("Player Swap")) {
                VoteEvent.startPlayerSwap(gameID, false);
            } else if (((String)mode).equalsIgnoreCase("Inventory Swap")) {
                VoteEvent.startPlayerSwap(gameID, true);
            } else if (((String)mode).equalsIgnoreCase("2x Faster Items")) {
                HashMapHandler.setFasterItemsMode(gameID, true);
            } else if (((String)mode).equalsIgnoreCase("Apocalypse")) {
                VoteEvent.startApocalypse(gameID);
            } else if (((String)mode).equalsIgnoreCase("Synchronization")) {
                HashMapHandler.setSynchronizedItemsMode(gameID, true);
            }
        }
    }

    private static void notifyPlayers(String gameID, String mode) {
        List<Player> players = HashMapHandler.getMembersGameID(gameID);
        List<String> votersNames = VoteListener.getVotersForMode(gameID, mode);
        String votersMessage = votersNames.isEmpty() ? SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.NoVoters") : SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.VotedBy").replace("{voters}", String.join((CharSequence)", ", votersNames));
        for (Player player : players) {
            player.sendMessage(SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.ModeActivated").replace("{mode}", mode));
            player.sendMessage(votersMessage);
            String var10000 = mode.replace(" ", "");
            String explanationKey = "Events.Voting.Messages.Explanation." + var10000.replace("-", "");
            String explanation = SettingsManager.getInstance().getLang().getString(explanationKey);
            if (explanation == null) {
                explanation = SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.Explanation.Default");
            }
            player.sendMessage(explanation);
        }
    }

    private static List<Material> getSolidBlocks() {
        if (solidBlocksCache == null) {
            ArrayList<Material> blocks = new ArrayList<Material>();
            for (Material material : Material.values()) {
                if (!material.isBlock() || !material.isSolid() || material.isAir() || material.name().startsWith("LEGACY_")) continue;
                blocks.add(material);
            }
            solidBlocksCache = blocks;
        }
        return solidBlocksCache;
    }

    public static void startApocalypse(final String gameID) {
        FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
        ArrayList<BukkitRunnable> tasks = new ArrayList<BukkitRunnable>();
        final int deathHeight = config.getInt("Settings.DeathHeight");
        final int buildHeight = config.getInt("Settings.BuildHeight");
        final List<Material> solidBlocks = VoteEvent.getSolidBlocks();
        BukkitRunnable apocalypseTask = new BukkitRunnable(){

            public void run() {
                World world = Bukkit.getWorld((String)("Areas/" + gameID));
                if (world != null && HashMapHandler.getIsGamePlaying(gameID).booleanValue() && !solidBlocks.isEmpty()) {
                    int minY;
                    double angle = random.nextDouble() * 2.0 * Math.PI;
                    double distance = random.nextDouble() * 20.0;
                    int x = (int)Math.round(Math.cos(angle) * distance);
                    int z = (int)Math.round(Math.sin(angle) * distance);
                    int maxY = buildHeight > (minY = deathHeight + 5) ? buildHeight : minY + 30;
                    int y = minY + random.nextInt(Math.max(1, maxY - minY));
                    Block block = world.getBlockAt(x, y, z);
                    if (block.getType().isAir()) {
                        Material material = (Material)solidBlocks.get(random.nextInt(solidBlocks.size()));
                        block.setType(material);
                    }
                } else {
                    this.cancel();
                }
            }
        };
        apocalypseTask.runTaskTimer((Plugin)MoonLab.getInstance(), 10L, 10L);
        tasks.add(apocalypseTask);
        HashMapHandler.setActiveModeTasks(gameID, tasks);
    }

    public static void startPlayerSwap(final String gameID, final boolean inventoryOnly) {
        ArrayList<BukkitRunnable> tasks = new ArrayList<BukkitRunnable>();
        BukkitRunnable swapTask = new BukkitRunnable(){

            public void run() {
                List<Player> players = HashMapHandler.getMembersGameID(gameID);
                if (players.size() < 2) {
                    this.cancel();
                } else {
                    Collections.shuffle(players);
                    if (inventoryOnly) {
                        for (int i = 0; i < players.size() - 1; i += 2) {
                            Player player = players.get(i);
                            Player player2 = players.get(i + 1);
                            VoteEvent.swapInventories(player, player2);
                            player.sendMessage(SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.InventorySwapped").replace("{player}", player2.getName()));
                            player2.sendMessage(SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.InventorySwapped").replace("{player}", player.getName()));
                        }
                        if (players.size() % 2 != 0) {
                            Player lastPlayer = players.get(players.size() - 1);
                            lastPlayer.sendMessage(SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.InventoryLucky"));
                        }
                        for (Player player : players) {
                            player.sendMessage(SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.InventorySwapTriggered"));
                        }
                    } else {
                        for (int i = 0; i < players.size() - 1; i += 2) {
                            Player player = players.get(i);
                            Player player2 = players.get(i + 1);
                            VoteEvent.swapLocations(player, player2);
                            player.sendMessage(SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.PositionSwapped").replace("{player}", player2.getName()));
                            player2.sendMessage(SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.PositionSwapped").replace("{player}", player.getName()));
                        }
                        if (players.size() % 2 != 0) {
                            Player lastPlayer = players.get(players.size() - 1);
                            lastPlayer.sendMessage(SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.PositionLucky"));
                        }
                        for (Player player : players) {
                            player.sendMessage(SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.PlayerSwapTriggered"));
                        }
                    }
                }
            }
        };
        swapTask.runTaskTimer((Plugin)MoonLab.getInstance(), 600L, 600L);
        tasks.add(swapTask);
        HashMapHandler.setActiveModeTasks(gameID, tasks);
    }

    private static void swapInventories(Player player1, Player player2) {
        PlayerInventory inv1 = player1.getInventory();
        PlayerInventory inv2 = player2.getInventory();
        ItemStack[] contents1 = (ItemStack[])inv1.getContents().clone();
        ItemStack[] armor1 = (ItemStack[])inv1.getArmorContents().clone();
        ItemStack offHand1 = inv1.getItemInOffHand().clone();
        ItemStack[] contents2 = (ItemStack[])inv2.getContents().clone();
        ItemStack[] armor2 = (ItemStack[])inv2.getArmorContents().clone();
        ItemStack offHand2 = inv2.getItemInOffHand().clone();
        inv1.clear();
        inv2.clear();
        inv1.setContents(contents2);
        inv1.setArmorContents(armor2);
        inv1.setItemInOffHand(offHand2);
        inv2.setContents(contents1);
        inv2.setArmorContents(armor1);
        inv2.setItemInOffHand(offHand1);
        player1.updateInventory();
        player2.updateInventory();
    }

    private static void swapLocations(Player player1, Player player2) {
        Location loc1 = player1.getLocation();
        Location loc2 = player2.getLocation();
        player1.teleport(loc2);
        player2.teleport(loc1);
    }

    public static void startLava(final String gameID, int timePerRaise) {
        final FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
        ArrayList<BukkitRunnable> tasks = new ArrayList<BukkitRunnable>();
        final int initialLavaTimer = timePerRaise > 0 ? timePerRaise : config.getInt("Events.Voting.Floor-Is-Lava.Timer");
        final int[] remainingLavaTime = new int[]{initialLavaTimer};
        HashMapHandler.setLavaTime(gameID, initialLavaTimer);
        BukkitRunnable countdownTask = new BukkitRunnable(){
            int currentLavaHeight;
            {
                this.currentLavaHeight = config.getInt("Settings.DeathHeight");
            }

            public void run() {
                if (remainingLavaTime[0] <= 0) {
                    World world = Bukkit.getWorld((String)("Areas/" + gameID));
                    if (world == null) {
                        Bukkit.getLogger().warning(SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.WorldNotFound").replace("{gameID}", gameID));
                        this.cancel();
                        return;
                    }
                    int range = config.getInt("Settings.BuildRange");
                    int buildHeight = config.getInt("Settings.BuildHeight");
                    if (this.currentLavaHeight >= buildHeight) {
                        this.cancel();
                        return;
                    }
                    for (int x = -range; x <= range; ++x) {
                        for (int z = -range; z <= range; ++z) {
                            Block block = world.getBlockAt(x, this.currentLavaHeight, z);
                            block.setType(Material.LAVA);
                        }
                    }
                    ++this.currentLavaHeight;
                    remainingLavaTime[0] = initialLavaTimer;
                }
                int n = remainingLavaTime[0];
                remainingLavaTime[0] = n - 1;
                int var10002 = n;
                HashMapHandler.setLavaTime(gameID, remainingLavaTime[0]);
            }
        };
        countdownTask.runTaskTimer((Plugin)MoonLab.getInstance(), 0L, 20L);
        tasks.add(countdownTask);
        HashMapHandler.setActiveModeTasks(gameID, tasks);
    }

    public static void startLava(String gameID) {
        VoteEvent.startLava(gameID, 0);
    }

    public static void startLava(Player player, int timePerRaise) {
        if (player != null && player.isOnline()) {
            String gameID = null;
            String worldName = player.getWorld().getName();
            if (worldName.startsWith("Areas/Mini-")) {
                gameID = worldName.substring(6);
            }
            if (gameID == null) {
                gameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
            }
            if (gameID != null && !gameID.isEmpty()) {
                VoteEvent.startLava(gameID, timePerRaise);
            } else {
                Bukkit.getLogger().warning(SettingsManager.getInstance().getLang().getString("Events.Voting.Messages.GameIDNotFound").replace("{player}", player.getName()));
            }
        }
    }

    public static void startLava(Player player) {
        VoteEvent.startLava(player, 0);
    }
}

