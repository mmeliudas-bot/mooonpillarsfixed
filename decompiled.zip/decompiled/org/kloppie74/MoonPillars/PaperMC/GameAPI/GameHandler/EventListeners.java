/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.minimessage.MiniMessage
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.command.ConsoleCommandSender
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Arrow
 *  org.bukkit.entity.Egg
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Projectile
 *  org.bukkit.entity.Snowball
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 *  org.bukkit.event.entity.PlayerDeathEvent
 *  org.bukkit.event.inventory.CraftItemEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler;

import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Egg;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Snowball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.BedManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.GameManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.SpectatorInteractionHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.SpectatorInventoryManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.Rewards;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.TeamManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;
import org.kloppie74.MoonPillars.PaperMC.ScoreBoardAPI.DisplayNameAboveHead;

public class EventListeners
implements Listener {
    private static final EnumSet<Material> SHOVEL_MODIFIABLE_BLOCKS = EnumSet.of(Material.GRASS_BLOCK, Material.DIRT, Material.COARSE_DIRT, Material.PODZOL, Material.MYCELIUM);
    private static final EnumSet<Material> ALLOWED_TOOLS = EnumSet.of(Material.WOODEN_SHOVEL, new Material[]{Material.STONE_SHOVEL, Material.IRON_SHOVEL, Material.GOLDEN_SHOVEL, Material.DIAMOND_SHOVEL, Material.NETHERITE_SHOVEL, Material.WOODEN_HOE, Material.STONE_HOE, Material.IRON_HOE, Material.GOLDEN_HOE, Material.DIAMOND_HOE, Material.NETHERITE_HOE});
    private static final Map<String, Object> CACHE_LOCKS = new ConcurrentHashMap<String, Object>();
    private static final ThreadLocal<Location> CACHED_LOCATION = ThreadLocal.withInitial(() -> new Location((World)null, 0.0, 0.0, 0.0));
    private static final Map<UUID, Long> lastRespawnTimes = new ConcurrentHashMap<UUID, Long>();
    private static final long RESPAWN_COOLDOWN = 500L;
    private static final Map<String, String> worldToGameIDCache = new ConcurrentHashMap<String, String>();
    private static final String DEFAULT_DEATH_MESSAGE = "<gray>\u0421\u043f\u0430\u0441\u0438\u0431\u043e \u0437\u0430 \u0438\u0433\u0440\u0443, <white>{player}</white>!</gray><newline><click:run_command:'/joingame random'><hover:show_text:'<green>\u041d\u0430\u0436\u043c\u0438\u0442\u0435, \u0447\u0442\u043e\u0431\u044b \u043d\u0430\u0439\u0442\u0438 \u043d\u043e\u0432\u0443\u044e \u0438\u0433\u0440\u0443'><green><bold>[\u041d\u0430\u0439\u0442\u0438 \u043d\u043e\u0432\u0443\u044e \u0438\u0433\u0440\u0443]</bold></green></hover></click> <dark_gray>\u2726</dark_gray> <click:run_command:'/leavegame'><hover:show_text:'<red>\u0412\u0435\u0440\u043d\u0443\u0442\u044c\u0441\u044f \u043d\u0430 \u0441\u043f\u0430\u0432\u043d'><red><bold>[\u0412\u044b\u0439\u0442\u0438 \u043d\u0430 \u0441\u043f\u0430\u0432\u043d]</bold></red></hover></click>";

    public static String getBlockKey(Block block) {
        StringBuilder sb = new StringBuilder(64);
        sb.append(block.getWorld().getName()).append(':').append(block.getX()).append(',').append(block.getY()).append(',').append(block.getZ());
        return sb.toString();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void addBlock(Block block, String gameID) {
        if (block != null && gameID != null && !gameID.isEmpty()) {
            Object lock;
            String blockKey = EventListeners.getBlockKey(block);
            Object object = lock = CACHE_LOCKS.computeIfAbsent(gameID, k -> new Object());
            synchronized (object) {
                Set<String> placedBlocks = HashMapHandler.getGamePlacedBlocks(gameID);
                if (placedBlocks == null) {
                    placedBlocks = ConcurrentHashMap.newKeySet();
                    HashMapHandler.setGamePlacedBlocks(gameID, placedBlocks);
                    placedBlocks.add(blockKey);
                } else {
                    try {
                        placedBlocks.add(blockKey);
                    }
                    catch (UnsupportedOperationException var9) {
                        ConcurrentHashMap.KeySetView newSet = ConcurrentHashMap.newKeySet();
                        newSet.addAll(placedBlocks);
                        newSet.add(blockKey);
                        HashMapHandler.setGamePlacedBlocks(gameID, newSet);
                    }
                }
            }
            EventListeners.addAdjacentBlocksToHashMap(block.getLocation(), gameID, block.getType());
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void addAdjacentBlocksToHashMap(Location blockLocation, String gameID, Material blockType) {
        World world = blockLocation.getWorld();
        if (world != null) {
            Set<String> placedBlocks;
            Object lock;
            int baseX = blockLocation.getBlockX();
            int baseY = blockLocation.getBlockY();
            int baseZ = blockLocation.getBlockZ();
            Object object = lock = CACHE_LOCKS.computeIfAbsent(gameID, k -> new Object());
            synchronized (object) {
                placedBlocks = HashMapHandler.getGamePlacedBlocks(gameID);
                if (placedBlocks == null) {
                    placedBlocks = ConcurrentHashMap.newKeySet();
                    HashMapHandler.setGamePlacedBlocks(gameID, placedBlocks);
                } else {
                    try {
                        String testKey = "TEST_KEY_" + System.nanoTime();
                        placedBlocks.add(testKey);
                        placedBlocks.remove(testKey);
                    }
                    catch (UnsupportedOperationException var19) {
                        ConcurrentHashMap.KeySetView<String, Boolean> newSet = ConcurrentHashMap.newKeySet();
                        newSet.addAll(placedBlocks);
                        HashMapHandler.setGamePlacedBlocks(gameID, newSet);
                        placedBlocks = newSet;
                    }
                }
            }
            Set<String> finalPlacedBlocks = placedBlocks;
            StringBuilder keyBuilder = new StringBuilder(64);
            for (int x = -1; x <= 1; ++x) {
                block11: for (int y = -1; y <= 1; ++y) {
                    for (int z = -1; z <= 1; ++z) {
                        Block adjacentBlock;
                        if (x == 0 && y == 0 && z == 0 || (adjacentBlock = world.getBlockAt(baseX + x, baseY + y, baseZ + z)).getType() != blockType) continue;
                        keyBuilder.setLength(0);
                        keyBuilder.append(world.getName()).append(':').append(baseX + x).append(',').append(baseY + y).append(',').append(baseZ + z);
                        Object object2 = lock;
                        synchronized (object2) {
                            try {
                                finalPlacedBlocks.add(keyBuilder.toString());
                            }
                            catch (UnsupportedOperationException var21) {
                                ConcurrentHashMap.KeySetView newSet = ConcurrentHashMap.newKeySet();
                                newSet.addAll(finalPlacedBlocks);
                                newSet.add(keyBuilder.toString());
                                HashMapHandler.setGamePlacedBlocks(gameID, newSet);
                                continue block11;
                            }
                        }
                    }
                }
            }
        }
    }

    public static boolean canBuildHere(Player player, Block block, String gameID, FileConfiguration config) {
        if (!HashMapHandler.getIsGamePlaying(gameID).booleanValue()) {
            return false;
        }
        int maxY = config.getInt("Settings.BuildHeight");
        if (block.getY() >= maxY) {
            return false;
        }
        int maxRange = config.getInt("Settings.BuildRange");
        Location blockLocation = block.getLocation();
        Location center = player.getWorld().getSpawnLocation();
        int deltaX = Math.abs(blockLocation.getBlockX() - center.getBlockX());
        int deltaZ = Math.abs(blockLocation.getBlockZ() - center.getBlockZ());
        return deltaX <= maxRange && deltaZ <= maxRange;
    }

    public static boolean canBreakBlock(Player player, Block block, String gameID, FileConfiguration config) {
        if (HashMapHandler.getIsGamePlaying(gameID).booleanValue() && HashMapHandler.getIsGameStarted(gameID).booleanValue()) {
            if (config.getBoolean("Settings.Can-Break-Map-Blocks")) {
                return true;
            }
            boolean tntMode = config.getBoolean("Settings.TnTMode", false);
            if (block.getType() == Material.TNT && tntMode) {
                return true;
            }
            Set<String> placedBlocks = HashMapHandler.getGamePlacedBlocks(gameID);
            if (placedBlocks == null) {
                return false;
            }
            String blockKey = EventListeners.getBlockKey(block);
            return placedBlocks.contains(blockKey);
        }
        return false;
    }

    private Location calculateRespawnLocation(Player player, String gameID) {
        BedManager.BedInfo bedInfo;
        FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
        if (config == null) {
            return null;
        }
        boolean bedRespawnEnabled = config.getBoolean("Settings.Bed-Respawn", false);
        if (bedRespawnEnabled && (bedInfo = BedManager.playerBeds.get(player)) != null && BedManager.isBedValidForRespawn(bedInfo.getBed().getLocation())) {
            Location loc = CACHED_LOCATION.get();
            loc.setWorld(bedInfo.getBed().getWorld());
            loc.setX((double)bedInfo.getBed().getX());
            loc.setY((double)(bedInfo.getBed().getY() + 1));
            loc.setZ((double)bedInfo.getBed().getZ());
            return loc;
        }
        World world = Bukkit.getWorld((String)("Areas/" + gameID));
        if (world != null) {
            int locX = config.getInt("Settings.SpawnPoint.X");
            int locY = config.getInt("Settings.SpawnPoint.Y");
            int locZ = config.getInt("Settings.SpawnPoint.Z");
            Location loc = CACHED_LOCATION.get();
            loc.setWorld(world);
            loc.setX((double)locX);
            loc.setY((double)locY);
            loc.setZ((double)locZ);
            return loc;
        }
        return null;
    }

    private void sendDeathMessage(Player player) {
        String template = SettingsManager.getInstance().getLang().getString("Games.Death-Message", DEFAULT_DEATH_MESSAGE);
        if (template != null && !template.isEmpty()) {
            try {
                template = template.replace("{player}", player.getName());
                Component message = MiniMessage.miniMessage().deserialize((Object)template);
                player.sendMessage(message);
            }
            catch (Exception var4) {
                Bukkit.getLogger().warning("[MoonPillars] Failed to parse death message (MiniMessage): " + var4.getMessage());
            }
        }
    }

    private void finalizePlayerRespawn(Player player, String gameID, Location deathLocation, Player killer, Location respawnLocation) {
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        Long lastRespawn = lastRespawnTimes.get(uuid);
        if (lastRespawn == null || now - lastRespawn >= 500L) {
            boolean bedRespawnEnabled;
            lastRespawnTimes.put(uuid, now);
            FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
            boolean bl = bedRespawnEnabled = config != null && config.getBoolean("Settings.Bed-Respawn", false);
            if (respawnLocation != null) {
                player.teleport(respawnLocation);
            }
            boolean hasBed = false;
            if (bedRespawnEnabled) {
                BedManager.BedInfo bedInfo = BedManager.playerBeds.get(player);
                if (bedInfo != null && BedManager.isBedValidForRespawn(bedInfo.getBed().getLocation())) {
                    player.sendMessage(MSG.chatColors("&aYou respawned at your claimed bed!"));
                    hasBed = true;
                } else if (bedInfo != null) {
                    player.sendMessage(MSG.chatColors("&cYour bed has been blocked and is no longer valid for respawn!"));
                }
            }
            if (!hasBed) {
                List<Player> members = HashMapHandler.getMembersGameID(gameID);
                if (members != null) {
                    members.remove(player);
                    DatabaseManager.getInstance().updateSetting(uuid, "winstreak", 0);
                    Rewards.OnKillRewards(gameID, killer, player);
                }
                SpectatorInventoryManager.giveSpectatorInventory(player);
                this.sendDeathMessage(player);
                ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
                String var10001 = player.getName();
                var10000.sendMessage(MSG.chatColors("&c" + var10001 + " has been eliminated from game " + gameID + "!"));
                HashMapHandler.removePlayerGameID(uuid);
                DisplayNameAboveHead.removeNick(player);
                SpectatorInteractionHandler.setPlayerHidden(player, null);
                if (members != null && members.isEmpty()) {
                    HashMapHandler.removeMembersGameID(gameID);
                    HashMapHandler.setIsGamePlaying(gameID, false);
                    for (Player p : members) {
                        MessageSender.SendMessage(p, "Games.No-Players-Left", "{gameid}", gameID);
                    }
                    GameManager.endGame(gameID, false);
                    return;
                }
                GameManager.TeamChecks(player, gameID);
            }
        }
    }

    @EventHandler(priority=EventPriority.NORMAL)
    public void onPlayerMove(PlayerMoveEvent event) {
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null || from.getBlockX() != to.getBlockX() || from.getBlockZ() != to.getBlockZ() || from.getBlockY() != to.getBlockY()) {
            FileConfiguration config;
            UUID uuid;
            String gameID;
            Player player = event.getPlayer();
            World world = player.getWorld();
            String worldName = world.getName();
            if (worldName.startsWith("Areas/")) {
                String gameID2 = worldToGameIDCache.computeIfAbsent(worldName, name -> name.startsWith("Areas/") ? name.substring(6) : null);
                if (gameID2 == null) {
                    return;
                }
                FileConfiguration config2 = HashMapHandler.getConfigGameID(gameID2);
                if (config2 != null) {
                    GameMode playerMode;
                    int maxY = config2.getInt("Settings.DeathHeight");
                    if (to.getBlockY() <= maxY && ((playerMode = player.getGameMode()) == GameMode.SPECTATOR || playerMode == GameMode.CREATIVE)) {
                        int locX = config2.getInt("Settings.SpawnPoint.X");
                        int locY = config2.getInt("Settings.SpawnPoint.Y");
                        locX = config2.getInt("Settings.SpawnPoint.Z");
                        Location spawnLoc = CACHED_LOCATION.get();
                        spawnLoc.setWorld(world);
                        spawnLoc.setX((double)locX);
                        spawnLoc.setY((double)locY);
                        spawnLoc.setZ((double)locX);
                        player.teleport(spawnLoc);
                        return;
                    }
                }
            }
            if ((gameID = HashMapHandler.getPlayerGameID(uuid = player.getUniqueId())) != null && (config = HashMapHandler.getConfigGameID(gameID)) != null) {
                int maxY = config.getInt("Settings.DeathHeight");
                if (to.getBlockY() <= maxY && HashMapHandler.getIsGamePlaying(gameID).booleanValue() && HashMapHandler.getIsGameStarted(gameID).booleanValue()) {
                    List<Player> members = HashMapHandler.getMembersGameID(gameID);
                    int locY = TeamManager.getActiveTeamCount(gameID);
                    if (members != null && members.size() <= 1 || locY <= 1) {
                        int locX = config.getInt("Settings.SpawnPoint.X");
                        locY = config.getInt("Settings.SpawnPoint.Y");
                        int locZ = config.getInt("Settings.SpawnPoint.Z");
                        World gameWorld = Bukkit.getWorld((String)("Areas/" + gameID));
                        if (gameWorld != null) {
                            Location safeLoc = CACHED_LOCATION.get();
                            safeLoc.setWorld(gameWorld);
                            safeLoc.setX((double)locX);
                            safeLoc.setY((double)locY);
                            safeLoc.setZ((double)locZ);
                            player.teleport(safeLoc);
                        }
                        return;
                    }
                    player.setHealth(0.0);
                }
            }
        }
    }

    @EventHandler
    public void onPlayerBuild(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        String gameID = HashMapHandler.getPlayerGameID(uuid);
        if (gameID != null) {
            FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
            Block block = event.getBlock();
            if (!EventListeners.canBuildHere(player, block, gameID, config)) {
                event.setCancelled(true);
            } else {
                EventListeners.addBlock(block, gameID);
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventHandler
    public void onPlayerBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        UUID uuid = player.getUniqueId();
        String gameID = HashMapHandler.getPlayerGameID(uuid);
        if (gameID != null) {
            FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
            if (!EventListeners.canBreakBlock(player, block, gameID, config)) {
                event.setCancelled(true);
            } else if (!config.getBoolean("Settings.Can-Break-Map-Blocks")) {
                Object lock;
                String blockKey = EventListeners.getBlockKey(block);
                Object object = lock = CACHE_LOCKS.computeIfAbsent(gameID, k -> new Object());
                synchronized (object) {
                    Set<String> placedBlocks = HashMapHandler.getGamePlacedBlocks(gameID);
                    if (placedBlocks != null) {
                        placedBlocks.remove(blockKey);
                        if (placedBlocks.isEmpty()) {
                            HashMapHandler.removeGamePlacedBlocks(gameID);
                        }
                    }
                }
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        FileConfiguration config;
        UUID uuid;
        String gameID;
        Player player;
        Material heldItem;
        Block block;
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK && (block = event.getClickedBlock()) != null && SHOVEL_MODIFIABLE_BLOCKS.contains(block.getType()) && ALLOWED_TOOLS.contains(heldItem = (player = event.getPlayer()).getInventory().getItemInMainHand().getType()) && (gameID = HashMapHandler.getPlayerGameID(uuid = player.getUniqueId())) != null && !(config = HashMapHandler.getConfigGameID(gameID)).getBoolean("Settings.Can-Break-Map-Blocks")) {
            Object lock;
            Object object = lock = CACHE_LOCKS.computeIfAbsent(gameID, k -> new Object());
            synchronized (object) {
                Set<String> placedBlocks = HashMapHandler.getGamePlacedBlocks(gameID);
                String blockKey = EventListeners.getBlockKey(block);
                if (placedBlocks == null || !placedBlocks.contains(blockKey)) {
                    event.setCancelled(true);
                    player.sendMessage(MSG.chatColors("&cYou cannot transform this block."));
                }
            }
        }
    }

    @EventHandler
    public void onPlayerHit(EntityDamageByEntityEvent event) {
        Entity attacker = event.getDamager();
        Entity defender = event.getEntity();
        if (attacker instanceof Player && defender instanceof Player) {
            Player attackingPlayer = (Player)attacker;
            Player defendingPlayer = (Player)defender;
            UUID attackerUUID = attackingPlayer.getUniqueId();
            String gameID = HashMapHandler.getPlayerGameID(attackerUUID);
            if (gameID != null) {
                if (!HashMapHandler.getIsGamePlaying(gameID).booleanValue()) {
                    event.setCancelled(true);
                } else {
                    String attackerTeam = TeamManager.getPlayerTeam(gameID, attackingPlayer);
                    String defenderTeam = TeamManager.getPlayerTeam(gameID, defendingPlayer);
                    if (attackerTeam != null && attackerTeam.equals(defenderTeam)) {
                        event.setCancelled(true);
                    }
                }
            }
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        UUID uuid = player.getUniqueId();
        Location deathLocation = player.getLocation();
        String spawnWorld = SettingsManager.getInstance().getSettings().getString("LobbySettings.World");
        if (player.getWorld().getName().equalsIgnoreCase(spawnWorld)) {
            event.getDrops().clear();
            event.setKeepInventory(true);
            event.setDeathMessage((String)null);
            player.setBedSpawnLocation(player.getWorld().getSpawnLocation(), true);
            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> {
                player.spigot().respawn();
                player.getInventory().clear();
            }, 1L);
        } else {
            String gameID = HashMapHandler.getPlayerGameID(uuid);
            if (gameID != null && HashMapHandler.getIsGamePlaying(gameID).booleanValue()) {
                event.setDeathMessage((String)null);
                Player killer = event.getEntity().getKiller();
                Location respawnLocation = this.calculateRespawnLocation(player, gameID);
                if (respawnLocation != null) {
                    player.setBedSpawnLocation(respawnLocation, true);
                }
                Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> {
                    player.spigot().respawn();
                    this.finalizePlayerRespawn(player, gameID, deathLocation, killer, respawnLocation);
                }, 1L);
            }
        }
    }

    @EventHandler
    public void onPlayerCraft(CraftItemEvent event) {
        FileConfiguration config;
        Player player;
        UUID uuid;
        String gameID;
        if (event.getWhoClicked() instanceof Player && (gameID = HashMapHandler.getPlayerGameID(uuid = (player = (Player)event.getWhoClicked()).getUniqueId())) != null && (config = HashMapHandler.getConfigGameID(gameID)) != null && config.getBoolean("Settings.CraftingDisabled", false)) {
            event.setCancelled(true);
            player.sendMessage(MSG.chatColors("&cCrafting is disabled in this game."));
        }
    }

    @EventHandler
    public void onProjectileDamage(EntityDamageByEntityEvent event) {
        Projectile projectile;
        if (event.getDamager() instanceof Projectile && (projectile = (Projectile)event.getDamager()).getShooter() instanceof Player && event.getEntity() instanceof Player) {
            Player shooter = (Player)projectile.getShooter();
            Player victim = (Player)event.getEntity();
            UUID shooterUUID = shooter.getUniqueId();
            String gameID = HashMapHandler.getPlayerGameID(shooterUUID);
            if (gameID != null) {
                if (!HashMapHandler.getIsGamePlaying(gameID).booleanValue()) {
                    event.setCancelled(true);
                } else {
                    String shooterTeam = TeamManager.getPlayerTeam(gameID, shooter);
                    String victimTeam = TeamManager.getPlayerTeam(gameID, victim);
                    if (shooterTeam != null && shooterTeam.equals(victimTeam)) {
                        event.setCancelled(true);
                        if (projectile instanceof Arrow) {
                            shooter.sendMessage(MSG.chatColors("&cYou cannot shoot your teammates!"));
                        } else if (projectile instanceof Egg || projectile instanceof Snowball) {
                            shooter.sendMessage(MSG.chatColors("&cYou cannot hit your teammates!"));
                        }
                    }
                }
            }
        }
    }

    @EventHandler
    public void onExplosionDamage(EntityDamageByEntityEvent event) {
        String victimTeam;
        Player victim;
        UUID victimUUID;
        String gameID;
        if ((event.getCause() == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION || event.getCause() == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) && event.getEntity() instanceof Player && (gameID = HashMapHandler.getPlayerGameID(victimUUID = (victim = (Player)event.getEntity()).getUniqueId())) != null && HashMapHandler.getIsGamePlaying(gameID).booleanValue() && (victimTeam = TeamManager.getPlayerTeam(gameID, victim)) != null) {
            List<Player> members;
            Location explosionLoc = null;
            if (event.getDamager() instanceof Entity) {
                explosionLoc = event.getDamager().getLocation();
            } else if (event.getCause() == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) {
                explosionLoc = victim.getLocation();
            }
            if (explosionLoc != null && (members = HashMapHandler.getMembersGameID(gameID)) != null && !members.isEmpty()) {
                for (Player possibleTeammate : members) {
                    String teammateTeam;
                    if (possibleTeammate.equals((Object)victim) || !victimTeam.equals(teammateTeam = TeamManager.getPlayerTeam(gameID, possibleTeammate)) || !possibleTeammate.getWorld().equals((Object)explosionLoc.getWorld()) || !(possibleTeammate.getLocation().distance(explosionLoc) <= 10.0)) continue;
                    event.setCancelled(true);
                    return;
                }
            }
        }
    }

    public static void clearCaches() {
        worldToGameIDCache.clear();
        CACHE_LOCKS.clear();
        lastRespawnTimes.clear();
    }
}

