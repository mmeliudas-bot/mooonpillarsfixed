/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityPickupItemEvent
 *  org.bukkit.event.entity.EntityTargetEvent
 *  org.bukkit.event.entity.FoodLevelChangeEvent
 *  org.bukkit.event.entity.ProjectileLaunchEvent
 *  org.bukkit.event.hanging.HangingBreakByEntityEvent
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryDragEvent
 *  org.bukkit.event.inventory.InventoryInteractEvent
 *  org.bukkit.event.player.PlayerArmorStandManipulateEvent
 *  org.bukkit.event.player.PlayerBucketEmptyEvent
 *  org.bukkit.event.player.PlayerBucketFillEvent
 *  org.bukkit.event.player.PlayerChangedWorldEvent
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerEditBookEvent
 *  org.bukkit.event.player.PlayerFishEvent
 *  org.bukkit.event.player.PlayerInteractAtEntityEvent
 *  org.bukkit.event.player.PlayerInteractEntityEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerItemConsumeEvent
 *  org.bukkit.event.player.PlayerItemDamageEvent
 *  org.bukkit.event.player.PlayerPickupItemEvent
 *  org.bukkit.event.player.PlayerSwapHandItemsEvent
 *  org.bukkit.event.player.PlayerToggleSneakEvent
 *  org.bukkit.event.vehicle.VehicleDamageEvent
 *  org.bukkit.event.vehicle.VehicleDestroyEvent
 *  org.bukkit.event.vehicle.VehicleEnterEvent
 *  org.bukkit.event.vehicle.VehicleEntityCollisionEvent
 *  org.bukkit.event.vehicle.VehicleExitEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.scheduler.BukkitRunnable
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler;

import java.util.Iterator;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.GameMode;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryInteractEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerEditBookEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.event.vehicle.VehicleDamageEvent;
import org.bukkit.event.vehicle.VehicleDestroyEvent;
import org.bukkit.event.vehicle.VehicleEnterEvent;
import org.bukkit.event.vehicle.VehicleEntityCollisionEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.API.TabListUtils;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.SpectatorInventoryManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;
import org.kloppie74.MoonPillars.PaperMC.ScoreBoardAPI.DisplayNameAboveHead;

public class SpectatorInteractionHandler
implements Listener {
    private static final ConcurrentHashMap<UUID, Long> SPECTATOR_CACHE = new ConcurrentHashMap();
    private static final long CACHE_EXPIRY_MS = 5000L;

    public static void registerEvents() {
        MoonLab.getInstance().getServer().getPluginManager().registerEvents((Listener)new SpectatorInteractionHandler(), (Plugin)MoonLab.getInstance());
        new BukkitRunnable(){

            public void run() {
                long now = System.currentTimeMillis();
                SPECTATOR_CACHE.entrySet().removeIf(entry -> now - (Long)entry.getValue() > 5000L);
            }
        }.runTaskTimerAsynchronously((Plugin)MoonLab.getInstance(), 600L, 600L);
    }

    private boolean isSpectator(Player player) {
        boolean isSpec;
        long timestamp;
        if (player == null) {
            return false;
        }
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        if (SPECTATOR_CACHE.containsKey(uuid) && now - (timestamp = SPECTATOR_CACHE.get(uuid).longValue()) < 5000L) {
            return true;
        }
        String playerGameID = HashMapHandler.getPlayerGameID(uuid);
        boolean bl = isSpec = playerGameID == null && player.getWorld().getName().startsWith("Areas/");
        if (isSpec) {
            SPECTATOR_CACHE.put(uuid, now);
        } else {
            SPECTATOR_CACHE.remove(uuid);
        }
        return isSpec;
    }

    private boolean hasSpectatorOverride(Player player) {
        if (player == null) {
            return false;
        }
        boolean isVanished = DatabaseManager.getInstance().getVanishState(player.getUniqueId());
        return isVanished && player.getGameMode() == GameMode.CREATIVE;
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        Player player;
        if (event.getWhoClicked() instanceof Player && this.isSpectator(player = (Player)event.getWhoClicked()) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onInventoryDrag(InventoryDragEvent event) {
        Player player;
        if (event.getWhoClicked() instanceof Player && this.isSpectator(player = (Player)event.getWhoClicked()) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onInventoryInteract(InventoryInteractEvent event) {
        Player player;
        if (event.getWhoClicked() instanceof Player && this.isSpectator(player = (Player)event.getWhoClicked()) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
        Player player = event.getPlayer();
        if (this.isSpectator(player) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerInteractAtEntity(PlayerInteractAtEntityEvent event) {
        Player player = event.getPlayer();
        if (this.isSpectator(player) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (this.isSpectator(player)) {
            event.setCancelled(true);
            if (!(event.getAction() != Action.LEFT_CLICK_BLOCK && event.getAction() != Action.RIGHT_CLICK_BLOCK && event.getAction() != Action.PHYSICAL || this.hasSpectatorOverride(player))) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (this.isSpectator(player) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        if (this.isSpectator(player) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        Player player;
        if (event.getDamager() instanceof Player && this.isSpectator(player = (Player)event.getDamager()) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onEntityDamage(EntityDamageEvent event) {
        Player player;
        if (event.getEntity() instanceof Player && this.isSpectator(player = (Player)event.getEntity())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onEntityTarget(EntityTargetEvent event) {
        Player player;
        if (event.getTarget() instanceof Player && this.isSpectator(player = (Player)event.getTarget())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onFoodLevelChange(FoodLevelChangeEvent event) {
        Player player;
        if (event.getEntity() instanceof Player && this.isSpectator(player = (Player)event.getEntity())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onItemPickup(PlayerPickupItemEvent event) {
        Player player = event.getPlayer();
        if (this.isSpectator(player) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (this.isSpectator(player) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onItemDamage(PlayerItemDamageEvent event) {
        Player player = event.getPlayer();
        if (this.isSpectator(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onItemConsume(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        if (this.isSpectator(player) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onVehicleDamage(VehicleDamageEvent event) {
        Player player;
        if (event.getAttacker() instanceof Player && this.isSpectator(player = (Player)event.getAttacker()) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onVehicleDestroy(VehicleDestroyEvent event) {
        Player player;
        if (event.getAttacker() instanceof Player && this.isSpectator(player = (Player)event.getAttacker()) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onVehicleEnter(VehicleEnterEvent event) {
        Player player;
        if (event.getEntered() instanceof Player && this.isSpectator(player = (Player)event.getEntered()) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onVehicleCollision(VehicleEntityCollisionEvent event) {
        Player player;
        Entity entity = event.getEntity();
        if (entity instanceof Player && this.isSpectator(player = (Player)entity)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onVehicleExit(VehicleExitEvent event) {
        Player player;
        if (event.getExited() instanceof Player && this.isSpectator(player = (Player)event.getExited()) && !this.hasSpectatorOverride(player)) {
            new BukkitRunnable(){

                public void run() {
                    SpectatorInventoryManager.giveSpectatorInventory(player);
                }
            }.runTaskLater((Plugin)MoonLab.getInstance(), 1L);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onHangingBreak(HangingBreakByEntityEvent event) {
        Player player;
        if (event.getRemover() instanceof Player && this.isSpectator(player = (Player)event.getRemover()) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onArmorStandManipulate(PlayerArmorStandManipulateEvent event) {
        Player player = event.getPlayer();
        if (this.isSpectator(player) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onEntityPickup(EntityPickupItemEvent event) {
        Player player;
        if (event.getEntity() instanceof Player && this.isSpectator(player = (Player)event.getEntity()) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.NORMAL)
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        String playerGameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
        boolean isVanished = DatabaseManager.getInstance().getVanishState(player.getUniqueId());
        player.setWalkSpeed(0.2f);
        player.setFlySpeed(0.1f);
        player.removePotionEffect(PotionEffectType.SPEED);
        SPECTATOR_CACHE.remove(player.getUniqueId());
        if (event.getFrom().getName().startsWith("Areas/") && !player.getWorld().getName().startsWith("Areas/")) {
            if (!isVanished) {
                for (Player otherPlayer : MoonLab.getInstance().getServer().getOnlinePlayers()) {
                    otherPlayer.showPlayer((Plugin)MoonLab.getInstance(), player);
                }
            }
            player.setFlying(false);
            player.setAllowFlight(false);
            player.setInvulnerable(false);
            player.setCollidable(true);
            SpectatorInventoryManager.checkAndUpdateInventory(player);
        } else if (player.getWorld().getName().startsWith("Areas/") && playerGameID == null) {
            SpectatorInteractionHandler.setPlayerHidden(player, playerGameID);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerSneak(PlayerToggleSneakEvent event) {
        final Player player = event.getPlayer();
        if (this.isSpectator(player) && event.isSneaking()) {
            new BukkitRunnable(){

                public void run() {
                    SpectatorInventoryManager.giveSpectatorInventory(player);
                }
            }.runTaskLater((Plugin)MoonLab.getInstance(), 1L);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerBucketEmpty(PlayerBucketEmptyEvent event) {
        Player player = event.getPlayer();
        if (this.isSpectator(player) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerBucketFill(PlayerBucketFillEvent event) {
        Player player = event.getPlayer();
        if (this.isSpectator(player) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerSwapHandItems(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        if (this.isSpectator(player) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
            SpectatorInventoryManager.giveSpectatorInventory(player);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerEditBook(PlayerEditBookEvent event) {
        Player player = event.getPlayer();
        if (this.isSpectator(player) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerFish(PlayerFishEvent event) {
        Player player = event.getPlayer();
        if (this.isSpectator(player) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onProjectileLaunch(ProjectileLaunchEvent event) {
        Player player;
        if (event.getEntity().getShooter() instanceof Player && this.isSpectator(player = (Player)event.getEntity().getShooter()) && !this.hasSpectatorOverride(player)) {
            event.setCancelled(true);
        }
    }

    public static void toggleSpectatorsVisibility(Player player) {
        String playerGameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
        String lobbyWorld = SettingsManager.getInstance().getSettings().getString("LobbySettings.World");
        if (playerGameID == null && !player.getWorld().getName().equalsIgnoreCase(lobbyWorld)) {
            boolean currentlyHiding = SpectatorInventoryManager.isHidingSpectators(player);
            boolean newState = !currentlyHiding;
            SpectatorInventoryManager.setHidingSpectators(player, newState);
            for (Player otherPlayer : player.getWorld().getPlayers()) {
                String otherPlayerGameID;
                if (player.equals((Object)otherPlayer) || (otherPlayerGameID = HashMapHandler.getPlayerGameID(otherPlayer.getUniqueId())) != null) continue;
                if (newState) {
                    player.hidePlayer(otherPlayer);
                    continue;
                }
                player.showPlayer(otherPlayer);
            }
            if (newState) {
                MessageSender.SendMessage(player, "Games.Spectators-Hide", "", "");
            } else {
                MessageSender.SendMessage(player, "Games.Spectators-Show", "", "");
            }
        }
    }

    public static void setPlayerHidden(Player player, String playerGameID) {
        if (player != null && playerGameID == null) {
            boolean isVanished = DatabaseManager.getInstance().getVanishState(player.getUniqueId());
            Iterator var3 = player.getWorld().getPlayers().iterator();
            while (true) {
                boolean isHidingSpectators;
                if (!var3.hasNext()) {
                    player.setCollidable(false);
                    SpectatorInventoryManager.giveSpectatorInventory(player);
                    player.setAllowFlight(true);
                    player.setFlying(true);
                    player.setInvulnerable(true);
                    DisplayNameAboveHead.setNick(player, MSG.chatColors("\u00a78[#03FFAB\u00a7lSpectator\u00a78] #BFFF00"));
                    return;
                }
                Player otherPlayer = (Player)var3.next();
                if (otherPlayer == null) continue;
                String otherPlayerGameID = HashMapHandler.getPlayerGameID(otherPlayer.getUniqueId());
                if (otherPlayerGameID != null) {
                    otherPlayer.hidePlayer((Plugin)MoonLab.getInstance(), player);
                    continue;
                }
                if (isVanished) {
                    if (!otherPlayer.hasPermission("mpa.admin.seevanished")) {
                        otherPlayer.hidePlayer((Plugin)MoonLab.getInstance(), player);
                        TabListUtils.forceAddToTablist(otherPlayer, player);
                        continue;
                    }
                    otherPlayer.showPlayer((Plugin)MoonLab.getInstance(), player);
                    TabListUtils.forceAddToTablist(otherPlayer, player);
                    continue;
                }
                boolean bl = isHidingSpectators = otherPlayer != player && SpectatorInventoryManager.isHidingSpectators(otherPlayer);
                if (isHidingSpectators) {
                    otherPlayer.hidePlayer((Plugin)MoonLab.getInstance(), player);
                    TabListUtils.forceAddToTablist(otherPlayer, player);
                    continue;
                }
                otherPlayer.showPlayer((Plugin)MoonLab.getInstance(), player);
                TabListUtils.forceAddToTablist(otherPlayer, player);
            }
        }
    }

    public static void clearCache() {
        SPECTATOR_CACHE.clear();
    }
}

