/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.GameMode
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.player.PlayerRespawnEvent
 *  org.bukkit.event.player.PlayerTeleportEvent
 *  org.bukkit.event.player.PlayerTeleportEvent$TeleportCause
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.metadata.FixedMetadataValue
 *  org.bukkit.metadata.MetadataValue
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class SpectatorInventoryManager
implements Listener {
    private static String SPEED_GUI_TITLE = "\u00a78\u25cf \u00a7fSpeed Selection \u00a78\u25cf";
    private static final String SPECTATOR_HIDING_KEY = "hiding_spectators";
    private static final Map<UUID, Integer> PLAYER_SPEED_LEVELS = new ConcurrentHashMap<UUID, Integer>();
    private static Inventory SPEED_GUI_TEMPLATE = null;
    private static final Map<String, ItemStack> ITEM_CACHE = new HashMap<String, ItemStack>();
    private static final int MAX_CACHE_SIZE = 50;

    public static void registerEvents() {
        MoonLab.getInstance().getServer().getPluginManager().registerEvents((Listener)new SpectatorInventoryManager(), (Plugin)MoonLab.getInstance());
        SpectatorInventoryManager.initSpeedGuiTemplate();
    }

    private static void initSpeedGuiTemplate() {
        int slot;
        int[] innerSlots;
        FileConfiguration itemsConfig = SettingsManager.getInstance().getItems();
        ConfigurationSection speedMenu = itemsConfig.getConfigurationSection("Menu.Speed");
        SPEED_GUI_TITLE = itemsConfig.getString("Menu.Speed.Title", "\u00a78\u25cf \u00a7fSpeed Selection \u00a78\u25cf");
        SPEED_GUI_TEMPLATE = Bukkit.createInventory(null, (int)27, (String)SPEED_GUI_TITLE);
        ItemStack border = SpectatorInventoryManager.getMenuItem(speedMenu, "Border");
        ItemStack filler = SpectatorInventoryManager.getMenuItem(speedMenu, "Filler");
        for (int i = 0; i < 27; ++i) {
            SPEED_GUI_TEMPLATE.setItem(i, border != null ? border : new ItemStack(Material.BLACK_STAINED_GLASS_PANE));
        }
        int[] var5 = innerSlots = new int[]{10, 11, 12, 13, 14, 15, 16};
        int var6 = innerSlots.length;
        for (int var7 = 0; var7 < var6; ++var7) {
            slot = var5[var7];
            SPEED_GUI_TEMPLATE.setItem(slot, filler != null ? filler : new ItemStack(Material.GRAY_STAINED_GLASS_PANE));
        }
        ConfigurationSection speeds = speedMenu.getConfigurationSection("Speeds");
        if (speeds != null) {
            for (String key : speeds.getKeys(false)) {
                slot = speeds.getInt(key + ".Slot", 10);
                ItemStack speedItem = SpectatorInventoryManager.getMenuItem(speeds, key);
                SPEED_GUI_TEMPLATE.setItem(slot, speedItem);
                String itemKey = "speed_" + key;
                if (ITEM_CACHE.size() >= 50) continue;
                ITEM_CACHE.put(itemKey, speedItem);
            }
        }
        ItemStack closeButton = SpectatorInventoryManager.getMenuItem(speedMenu, "Close");
        SPEED_GUI_TEMPLATE.setItem(speedMenu.getInt("Close.Slot", 22), closeButton != null ? closeButton : new ItemStack(Material.BARRIER));
    }

    private static ItemStack getMenuItem(ConfigurationSection section, String key) {
        ItemStack item;
        ItemMeta meta;
        String var10000 = section.getName();
        String cacheKey = var10000 + "_" + key;
        if (ITEM_CACHE.containsKey(cacheKey)) {
            return ITEM_CACHE.get(cacheKey).clone();
        }
        if (section == null) {
            return null;
        }
        ConfigurationSection itemSec = section.getConfigurationSection(key);
        if (itemSec == null) {
            return null;
        }
        String materialName = itemSec.getString("Item", "BARRIER");
        Material mat = Material.getMaterial((String)materialName.toUpperCase());
        if (mat == null) {
            mat = Material.BARRIER;
        }
        if ((meta = (item = new ItemStack(mat)).getItemMeta()) != null) {
            meta.setDisplayName(itemSec.getString("Display-name", ""));
            List lores = itemSec.getStringList("Lores");
            if (lores != null && !lores.isEmpty()) {
                meta.setLore(lores);
            }
            item.setItemMeta(meta);
        }
        if (ITEM_CACHE.size() < 50) {
            ITEM_CACHE.put(cacheKey, item.clone());
        }
        return item;
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> SpectatorInventoryManager.checkAndUpdateInventory(event.getPlayer()));
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        HumanEntity humanEntity = event.getWhoClicked();
        if (humanEntity instanceof Player) {
            Player player = (Player)humanEntity;
            String title = event.getView().getTitle();
            if (title.equals(SPEED_GUI_TITLE)) {
                String closeName;
                event.setCancelled(true);
                ItemStack clickedItem = event.getCurrentItem();
                if (clickedItem == null || clickedItem.getItemMeta() == null) {
                    return;
                }
                String displayName = ChatColor.stripColor((String)clickedItem.getItemMeta().getDisplayName());
                FileConfiguration itemsConfig = SettingsManager.getInstance().getItems();
                ConfigurationSection speeds = itemsConfig.getConfigurationSection("Menu.Speed.Speeds");
                if (speeds != null) {
                    for (String key : speeds.getKeys(false)) {
                        String confName = ChatColor.stripColor((String)speeds.getString(key + ".Display-name", ""));
                        if (!displayName.equalsIgnoreCase(confName)) continue;
                        int speedLevel = speeds.getInt(key + ".SpeedLevel", 1);
                        SpectatorInventoryManager.setPlayerSpeed(player, speedLevel);
                        player.closeInventory();
                        return;
                    }
                }
                if (displayName.equalsIgnoreCase(closeName = ChatColor.stripColor((String)itemsConfig.getString("Menu.Speed.Close.Display-name", "Close Menu")))) {
                    player.closeInventory();
                }
            }
        }
    }

    public static void checkAndUpdateInventory(Player player) {
        String playerGameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
        if (playerGameID == null && player.getWorld().getName().startsWith("Areas/")) {
            SpectatorInventoryManager.giveSpectatorInventory(player);
        }
    }

    public static void giveSpectatorInventory(Player player) {
        player.getInventory().clear();
        player.setGameMode(GameMode.SPECTATOR);
        player.updateInventory();
    }

    public static void openSpeedGUI(Player player) {
        ItemStack item;
        int i;
        Inventory gui = Bukkit.createInventory(null, (int)27, (String)SPEED_GUI_TITLE);
        if (SPEED_GUI_TEMPLATE != null) {
            for (i = 0; i < 27; ++i) {
                item = SPEED_GUI_TEMPLATE.getItem(i);
                if (item == null) continue;
                gui.setItem(i, item.clone());
            }
        }
        i = SpectatorInventoryManager.getCurrentSpeedLevel(player);
        item = new ItemStack(Material.COMPASS);
        ItemMeta meta = item.getItemMeta();
        FileConfiguration config = SettingsManager.getInstance().getItems();
        ConfigurationSection infoSection = config.getConfigurationSection("Menu.Speed.Info");
        if (meta != null && infoSection != null) {
            String displayName = infoSection.getString("Display-name", "\u00a76\u00a7l\u2726 \u00a7f\u00a7lSpeed Selection \u00a76\u00a7l\u2726");
            int finalI = i;
            List lore = infoSection.getStringList("Lores").stream().map(line -> line.replace("%current_speed%", String.valueOf(finalI))).collect(Collectors.toList());
            meta.setDisplayName(displayName);
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        gui.setItem(4, item);
        player.openInventory(gui);
    }

    private static int getCurrentSpeedLevel(Player player) {
        UUID uuid = player.getUniqueId();
        if (PLAYER_SPEED_LEVELS.containsKey(uuid)) {
            return PLAYER_SPEED_LEVELS.get(uuid);
        }
        float walkSpeed = player.getWalkSpeed();
        int speedLevel = Math.max(1, Math.min(7, Math.round((walkSpeed - 0.2f) / 0.08f) + 1));
        PLAYER_SPEED_LEVELS.put(uuid, speedLevel);
        return speedLevel;
    }

    public static void setPlayerSpeed(Player player, int speedLevel) {
        speedLevel = Math.max(1, Math.min(7, speedLevel));
        PLAYER_SPEED_LEVELS.put(player.getUniqueId(), speedLevel);
        float walkSpeed = Math.min(1.0f, 0.2f + (float)speedLevel * 0.08f);
        player.setWalkSpeed(walkSpeed);
        float flySpeed = Math.min(1.0f, 0.1f + (float)speedLevel * 0.09f);
        player.setFlySpeed(flySpeed);
        player.removePotionEffect(PotionEffectType.SPEED);
        if (speedLevel > 1) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, speedLevel - 1, false, false));
        }
        MessageSender.SendMessage(player, "Games.Speed-Set", "{level}", String.valueOf(speedLevel));
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onTeleportMenu(PlayerTeleportEvent event) {
        String playerGameID;
        Player player = event.getPlayer();
        if (event.getCause() == PlayerTeleportEvent.TeleportCause.SPECTATE && (playerGameID = HashMapHandler.getPlayerGameID(player.getUniqueId())) == null && player.getWorld().getName().startsWith("Areas/")) {
            event.setCancelled(true);
            Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> SpectatorInventoryManager.giveSpectatorInventory(player));
        }
    }

    public static boolean isHidingSpectators(Player player) {
        return player.hasMetadata(SPECTATOR_HIDING_KEY) && ((MetadataValue)player.getMetadata(SPECTATOR_HIDING_KEY).get(0)).asBoolean();
    }

    public static void setHidingSpectators(Player player, boolean hiding) {
        player.setMetadata(SPECTATOR_HIDING_KEY, (MetadataValue)new FixedMetadataValue((Plugin)MoonLab.getInstance(), (Object)hiding));
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        PLAYER_SPEED_LEVELS.remove(event.getPlayer().getUniqueId());
    }

    public static void clearCache() {
        PLAYER_SPEED_LEVELS.clear();
        ITEM_CACHE.clear();
        SpectatorInventoryManager.initSpeedGuiTemplate();
    }
}

