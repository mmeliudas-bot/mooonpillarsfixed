/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.GameRule
 *  org.bukkit.World
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.weather.ThunderChangeEvent
 *  org.bukkit.event.weather.WeatherChangeEvent
 *  org.bukkit.event.world.WorldLoadEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.GameRule;
import org.bukkit.World;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.weather.ThunderChangeEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.event.world.WorldLoadEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class WorldTimeWeatherManager
implements Listener {
    private static final long MIDDAY_TIME = 6000L;
    private static final int CHECK_INTERVAL = 100;
    private final JavaPlugin plugin = MoonLab.getInstance();
    private final Map<String, BukkitTask> worldTasks = new HashMap<String, BukkitTask>();
    private boolean enabled = true;

    public WorldTimeWeatherManager() {
        this.plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
        this.initializeAllWorlds();
        this.plugin.getLogger().info("World Time & Weather Manager initialized - keeping all worlds at midday and sunny.");
    }

    private void initializeAllWorlds() {
        for (World world : Bukkit.getWorlds()) {
            this.setupWorldManagement(world);
        }
    }

    private void setupWorldManagement(final World world) {
        if (!this.worldTasks.containsKey(world.getName())) {
            this.setWorldConditions(world);
            BukkitTask task = new BukkitRunnable(){

                public void run() {
                    if (WorldTimeWeatherManager.this.enabled && world != null) {
                        WorldTimeWeatherManager.this.setWorldConditions(world);
                    }
                }
            }.runTaskTimer((Plugin)this.plugin, 100L, 100L);
            this.worldTasks.put(world.getName(), task);
        }
    }

    private void setWorldConditions(World world) {
        try {
            world.setTime(6000L);
            if (world.hasStorm() || world.isThundering()) {
                world.setStorm(false);
                world.setThundering(false);
            }
            world.setGameRule(GameRule.DO_WEATHER_CYCLE, (Object)false);
            world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, (Object)false);
        }
        catch (Exception var3) {
            this.plugin.getLogger().log(Level.WARNING, "Error setting time/weather for world " + world.getName(), var3);
        }
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent event) {
        this.setupWorldManagement(event.getWorld());
    }

    @EventHandler
    public void onWeatherChange(WeatherChangeEvent event) {
        if (this.enabled && event.toWeatherState()) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onThunderChange(ThunderChangeEvent event) {
        if (this.enabled && event.toThunderState()) {
            event.setCancelled(true);
        }
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        if (enabled) {
            for (World world : Bukkit.getWorlds()) {
                this.setWorldConditions(world);
            }
        }
    }

    public void shutdown() {
        for (BukkitTask task : this.worldTasks.values()) {
            task.cancel();
        }
        this.worldTasks.clear();
    }
}

