/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.scheduler.BukkitRunnable
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.TeamManager;

public class HashMapHandler {
    private static final Map<String, Integer> gameTimeMap = new ConcurrentHashMap<String, Integer>();
    private static final Map<String, Integer> itemTimeMap = new ConcurrentHashMap<String, Integer>();
    private static final Map<String, Integer> lavaTimeMap = new ConcurrentHashMap<String, Integer>();
    private static final Map<String, BukkitRunnable> gameTimers = new ConcurrentHashMap<String, BukkitRunnable>();
    private static final Map<String, Integer> gameTimes = new ConcurrentHashMap<String, Integer>();
    private static final Map<String, BukkitRunnable> itemTimers = new ConcurrentHashMap<String, BukkitRunnable>();
    private static final Map<String, Integer> itemTimes = new ConcurrentHashMap<String, Integer>();
    private static final Map<String, List<BukkitRunnable>> activeModeTasks = new ConcurrentHashMap<String, List<BukkitRunnable>>();
    private static final Map<String, BukkitRunnable> borderTasks = new ConcurrentHashMap<String, BukkitRunnable>();
    private static final Map<String, String> mapGameID = new ConcurrentHashMap<String, String>();
    private static final Map<String, FileConfiguration> configGameID = new ConcurrentHashMap<String, FileConfiguration>();
    private static final Map<String, Boolean> isGameStarted = new ConcurrentHashMap<String, Boolean>();
    private static final Map<String, Boolean> inactiveGameID = new ConcurrentHashMap<String, Boolean>();
    private static final Map<String, String> activeGameID = new ConcurrentHashMap<String, String>();
    private static final Map<String, Boolean> isGamePlaying = new ConcurrentHashMap<String, Boolean>();
    private static final Map<String, List<Player>> membersGameID = new ConcurrentHashMap<String, List<Player>>();
    private static final Map<String, Set<String>> gamePlacedBlocks = new ConcurrentHashMap<String, Set<String>>();
    private static final Map<String, Integer> playersStartedGameID = new ConcurrentHashMap<String, Integer>();
    private static final Map<UUID, String> playerGameID = new ConcurrentHashMap<UUID, String>();
    private static final Map<String, BukkitRunnable> activeTimers = new ConcurrentHashMap<String, BukkitRunnable>();
    private static final Map<String, Integer> remainingGameTimeMap = new ConcurrentHashMap<String, Integer>();
    private static final Map<String, Integer> remainingItemTimeMap = new ConcurrentHashMap<String, Integer>();
    private static final Map<UUID, Boolean> playerNoHunger = new ConcurrentHashMap<UUID, Boolean>();
    private static final Map<String, String> activeModes = new ConcurrentHashMap<String, String>();
    private static final Map<String, Boolean> gameEndingFlags = new ConcurrentHashMap<String, Boolean>();
    private static final Map<UUID, String> playerWaitingGameMap = new ConcurrentHashMap<UUID, String>();
    private static final Map<String, Boolean> fasterItemsMode = new ConcurrentHashMap<String, Boolean>();
    private static final Map<String, Boolean> synchronizedItemsMode = new ConcurrentHashMap<String, Boolean>();

    public static void setPlayerNoHunger(UUID uuid, boolean value) {
        playerNoHunger.put(uuid, value);
    }

    public static boolean getPlayerNoHunger(UUID uuid) {
        return playerNoHunger.getOrDefault(uuid, false);
    }

    public static void removePlayerNoHunger(UUID uuid) {
        playerNoHunger.remove(uuid);
    }

    public static Integer getRemainingItemTime(String gameID) {
        return remainingItemTimeMap.getOrDefault(gameID, 0);
    }

    public static void setRemainingItemTime(String gameID, Integer time) {
        remainingItemTimeMap.put(gameID, time);
    }

    public static void removeRemainingItemTime(String gameID) {
        remainingItemTimeMap.remove(gameID);
    }

    public static Integer getRemainingGameTime(String gameID) {
        return remainingGameTimeMap.getOrDefault(gameID, 0);
    }

    public static void setRemainingGameTime(String gameID, Integer time) {
        remainingGameTimeMap.put(gameID, time);
    }

    public static void removeRemainingGameTime(String gameID) {
        remainingGameTimeMap.remove(gameID);
    }

    public static Integer getGameTime(String gameID) {
        return gameTimeMap.getOrDefault(gameID, 0);
    }

    public static void setGameTime(String gameID, Integer time) {
        gameTimeMap.put(gameID, time);
    }

    public static Set<Map.Entry<String, Integer>> getAllGameTimes() {
        return gameTimeMap.entrySet();
    }

    public static void removeGameTime(String gameID) {
        gameTimeMap.remove(gameID);
    }

    public static Integer getItemTime(String gameID) {
        return itemTimeMap.getOrDefault(gameID, 0);
    }

    public static void setItemTime(String gameID, Integer time) {
        itemTimeMap.put(gameID, time);
    }

    public static Set<Map.Entry<String, Integer>> getAllItemTimes() {
        return itemTimeMap.entrySet();
    }

    public static void removeItemTime(String gameID) {
        itemTimeMap.remove(gameID);
    }

    public static Integer getLavaTime(String gameID) {
        return lavaTimeMap.getOrDefault(gameID, 0);
    }

    public static void setLavaTime(String gameID, Integer time) {
        lavaTimeMap.put(gameID, time);
    }

    public static Set<Map.Entry<String, Integer>> getAllLavaTimes() {
        return lavaTimeMap.entrySet();
    }

    public static void removeLavaTime(String gameID) {
        lavaTimeMap.remove(gameID);
    }

    public static BukkitRunnable getGameTimer(String gameID) {
        return gameTimers.getOrDefault(gameID, null);
    }

    public static void setGameTimer(String gameID, BukkitRunnable timer) {
        gameTimers.put(gameID, timer);
    }

    public static Set<Map.Entry<String, BukkitRunnable>> getAllGameTimers() {
        return gameTimers.entrySet();
    }

    public static void removeGameTimer(String gameID) {
        gameTimers.remove(gameID);
    }

    public static Integer getGameTimes(String gameID) {
        return gameTimes.getOrDefault(gameID, 0);
    }

    public static void setGameTimes(String gameID, Integer time) {
        gameTimes.put(gameID, time);
    }

    public static Set<Map.Entry<String, Integer>> getAllGameTimesEntries() {
        return gameTimes.entrySet();
    }

    public static void removeGameTimes(String gameID) {
        gameTimes.remove(gameID);
    }

    public static BukkitRunnable getItemTimer(String gameID) {
        return itemTimers.getOrDefault(gameID, null);
    }

    public static void setItemTimer(String gameID, BukkitRunnable timer) {
        itemTimers.put(gameID, timer);
    }

    public static Set<Map.Entry<String, BukkitRunnable>> getAllItemTimers() {
        return itemTimers.entrySet();
    }

    public static void removeItemTimer(String gameID) {
        itemTimers.remove(gameID);
    }

    public static Integer getItemTimes(String gameID) {
        return itemTimes.getOrDefault(gameID, 0);
    }

    public static void setItemTimes(String gameID, Integer time) {
        itemTimes.put(gameID, time);
    }

    public static Set<Map.Entry<String, Integer>> getAllItemTimesEntries() {
        return itemTimes.entrySet();
    }

    public static void removeItemTimes(String gameID) {
        itemTimes.remove(gameID);
    }

    public static List<BukkitRunnable> getActiveModeTasks(String gameID) {
        return activeModeTasks.getOrDefault(gameID, Collections.emptyList());
    }

    public static void setActiveModeTasks(String gameID, List<BukkitRunnable> tasks) {
        activeModeTasks.put(gameID, tasks);
    }

    public static Set<Map.Entry<String, List<BukkitRunnable>>> getAllActiveModeTasks() {
        return activeModeTasks.entrySet();
    }

    public static void removeActiveModeTasks(String gameID) {
        activeModeTasks.remove(gameID);
    }

    public static BukkitRunnable getBorderTask(String gameID) {
        return borderTasks.getOrDefault(gameID, null);
    }

    public static void setBorderTask(String gameID, BukkitRunnable task) {
        borderTasks.put(gameID, task);
    }

    public static Set<Map.Entry<String, BukkitRunnable>> getAllBorderTasks() {
        return borderTasks.entrySet();
    }

    public static void removeBorderTask(String gameID) {
        borderTasks.remove(gameID);
    }

    public static String getMapGameID(String gameID) {
        return mapGameID.getOrDefault(gameID, "");
    }

    public static void setMapGameID(String gameID, String mapID) {
        mapGameID.put(gameID, mapID);
    }

    public static Set<String> getAllMapGameIDs() {
        return mapGameID.keySet();
    }

    public static void removeMapGameID(String gameID) {
        mapGameID.remove(gameID);
    }

    public static FileConfiguration getConfigGameID(String gameID) {
        return configGameID.getOrDefault(gameID, null);
    }

    public static void setConfigGameID(String gameID, FileConfiguration config) {
        configGameID.put(gameID, config);
    }

    public static Set<Map.Entry<String, FileConfiguration>> getAllConfigGameIDs() {
        return configGameID.entrySet();
    }

    public static void removeConfigGameID(String gameID) {
        configGameID.remove(gameID);
    }

    public static Boolean getIsGameStarted(String gameID) {
        return isGameStarted.getOrDefault(gameID, false);
    }

    public static void setIsGameStarted(String gameID, Boolean started) {
        isGameStarted.put(gameID, started);
    }

    public static Set<Map.Entry<String, Boolean>> getAllIsGameStarted() {
        return isGameStarted.entrySet();
    }

    public static void removeIsGameStarted(String gameID) {
        isGameStarted.remove(gameID);
    }

    public static Boolean getInactiveGameID(String gameID) {
        return inactiveGameID.getOrDefault(gameID, false);
    }

    public static void setInactiveGameID(String gameID, Boolean inactive) {
        inactiveGameID.put(gameID, inactive);
    }

    public static Set<Map.Entry<String, Boolean>> getAllInactiveGameIDs() {
        return inactiveGameID.entrySet();
    }

    public static void removeInactiveGameID(String gameID) {
        inactiveGameID.remove(gameID);
    }

    public static String getActiveGameID(String gameID) {
        return activeGameID.getOrDefault(gameID, "");
    }

    public static void setActiveGameID(String gameID, String activeID) {
        activeGameID.put(gameID, activeID);
    }

    public static Set<Map.Entry<String, String>> getAllActiveGameIDs() {
        return activeGameID.entrySet();
    }

    public static void removeActiveGameID(String gameID) {
        activeGameID.remove(gameID);
    }

    public static Boolean getIsGamePlaying(String gameID) {
        return isGamePlaying.getOrDefault(gameID, false);
    }

    public static void setIsGamePlaying(String gameID, Boolean playing) {
        isGamePlaying.put(gameID, playing);
    }

    public static Set<Map.Entry<String, Boolean>> getAllIsGamePlaying() {
        return isGamePlaying.entrySet();
    }

    public static void removeIsGamePlaying(String gameID) {
        isGamePlaying.remove(gameID);
    }

    public static List<Player> getMembersGameID(String gameID) {
        return membersGameID.getOrDefault(gameID, Collections.emptyList());
    }

    public static void setMembersGameID(String gameID, List<Player> members) {
        membersGameID.put(gameID, members);
    }

    public static Set<Map.Entry<String, List<Player>>> getAllMembersGameIDs() {
        return membersGameID.entrySet();
    }

    public static void removeMembersGameID(String gameID) {
        membersGameID.remove(gameID);
    }

    public static Set<String> getGamePlacedBlocks(String gameID) {
        return gamePlacedBlocks.getOrDefault(gameID, Collections.emptySet());
    }

    public static void setGamePlacedBlocks(String gameID, Set<String> blocks) {
        gamePlacedBlocks.put(gameID, blocks);
    }

    public static Set<Map.Entry<String, Set<String>>> getAllGamePlacedBlocks() {
        return gamePlacedBlocks.entrySet();
    }

    public static void removeGamePlacedBlocks(String gameID) {
        gamePlacedBlocks.remove(gameID);
    }

    public static Integer getPlayersStartedGameID(String gameID) {
        return playersStartedGameID.getOrDefault(gameID, 0);
    }

    public static void setPlayersStartedGameID(String gameID, Integer players) {
        playersStartedGameID.put(gameID, players);
    }

    public static Set<Map.Entry<String, Integer>> getAllPlayersStartedGameIDs() {
        return playersStartedGameID.entrySet();
    }

    public static void removePlayersStartedGameID(String gameID) {
        playersStartedGameID.remove(gameID);
    }

    public static String getPlayerGameID(UUID playerID) {
        return playerGameID.get(playerID);
    }

    public static void setPlayerGameID(UUID playerID, String gameID) {
        playerGameID.put(playerID, gameID);
    }

    public static Set<Map.Entry<UUID, String>> getAllPlayerGameIDs() {
        return playerGameID.entrySet();
    }

    public static void removePlayerGameID(UUID playerID) {
        playerGameID.remove(playerID);
    }

    public static BukkitRunnable getActiveTimer(String gameID) {
        return activeTimers.getOrDefault(gameID, null);
    }

    public static void setActiveTimer(String gameID, BukkitRunnable timer) {
        activeTimers.put(gameID, timer);
    }

    public static Set<Map.Entry<String, BukkitRunnable>> getAllActiveTimers() {
        return activeTimers.entrySet();
    }

    public static void removeActiveTimer(String gameID) {
        activeTimers.remove(gameID);
    }

    public static void setActiveMode(String gameID, String mode) {
        activeModes.put(gameID, mode);
    }

    public static String getActiveMode(String gameID) {
        return activeModes.get(gameID);
    }

    public static boolean isGameEnding(String gameID) {
        return Boolean.TRUE.equals(gameEndingFlags.get(gameID));
    }

    public static void setGameEnding(String gameID, boolean isEnding) {
        if (isEnding) {
            gameEndingFlags.put(gameID, true);
        } else {
            gameEndingFlags.remove(gameID);
        }
    }

    public static void setPlayerWaitingGameID(UUID playerUUID, String gameID) {
        playerWaitingGameMap.put(playerUUID, gameID);
    }

    public static String getPlayerWaitingGameID(UUID playerUUID) {
        return playerWaitingGameMap.get(playerUUID);
    }

    public static void removePlayerWaitingGame(UUID playerUUID) {
        playerWaitingGameMap.remove(playerUUID);
    }

    public static void setFasterItemsMode(String gameID, boolean enabled) {
        fasterItemsMode.put(gameID, enabled);
    }

    public static boolean isFasterItemsMode(String gameID) {
        return fasterItemsMode.getOrDefault(gameID, false);
    }

    public static void setSynchronizedItemsMode(String gameID, boolean enabled) {
        synchronizedItemsMode.put(gameID, enabled);
    }

    public static boolean isSynchronizedItemsMode(String gameID) {
        return synchronizedItemsMode.getOrDefault(gameID, false);
    }

    public static void resetPlayerHealth(Player player) {
        if (player != null && player.isOnline()) {
            String activeMode;
            String gameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
            double maxHealth = 20.0;
            if (gameID != null && (activeMode = HashMapHandler.getActiveMode(gameID)) != null) {
                if (activeMode.equalsIgnoreCase("1 Heart Mode")) {
                    maxHealth = 2.0;
                } else if (activeMode.equalsIgnoreCase("Double HP")) {
                    maxHealth = 40.0;
                }
            }
            player.setMaxHealth(maxHealth);
            player.setHealth(maxHealth);
            player.setInvulnerable(false);
            player.setAllowFlight(false);
            player.setFlying(false);
            player.closeInventory();
            player.getInventory().clear();
            player.setGameMode(GameMode.SURVIVAL);
            player.setFireTicks(0);
            player.setFoodLevel(20);
            player.setSaturation(5.0f);
            player.setAbsorptionAmount(0.0);
            player.setNoDamageTicks(0);
            player.setFallDistance(0.0f);
            player.setLevel(0);
            player.getActivePotionEffects().forEach(effect -> player.removePotionEffect(effect.getType()));
            if (player.getBedSpawnLocation() != null) {
                player.setBedSpawnLocation((Location)null);
            }
        }
    }

    public static void CancelTasks(String gameID) {
        if (gameTimers.containsKey(gameID)) {
            gameTimers.get(gameID).cancel();
            gameTimers.remove(gameID);
        }
        if (itemTimers.containsKey(gameID)) {
            itemTimers.get(gameID).cancel();
            itemTimers.remove(gameID);
        }
        if (borderTasks.containsKey(gameID)) {
            borderTasks.get(gameID).cancel();
            borderTasks.remove(gameID);
        }
        if (activeModeTasks.containsKey(gameID)) {
            for (BukkitRunnable task : activeModeTasks.get(gameID)) {
                task.cancel();
            }
            activeModeTasks.remove(gameID);
        }
    }

    public static void resetGameData(String gameID) {
        HashMapHandler.CancelTasks(gameID);
        gameTimeMap.remove(gameID);
        itemTimeMap.remove(gameID);
        lavaTimeMap.remove(gameID);
        gameTimes.remove(gameID);
        itemTimes.remove(gameID);
        remainingGameTimeMap.remove(gameID);
        remainingItemTimeMap.remove(gameID);
        isGameStarted.remove(gameID);
        isGamePlaying.remove(gameID);
        inactiveGameID.remove(gameID);
        activeGameID.remove(gameID);
        membersGameID.remove(gameID);
        gamePlacedBlocks.remove(gameID);
        playersStartedGameID.remove(gameID);
        gameEndingFlags.remove(gameID);
        activeModes.remove(gameID);
        fasterItemsMode.remove(gameID);
        playerGameID.entrySet().removeIf(entry -> gameID.equals(entry.getValue()));
        playerWaitingGameMap.entrySet().removeIf(entry -> gameID.equals(entry.getValue()));
        if (membersGameID.containsKey(gameID)) {
            for (Player player : membersGameID.get(gameID)) {
                if (player == null) continue;
                playerNoHunger.remove(player.getUniqueId());
            }
        }
        TeamManager.clearGameTeams(gameID);
        Bukkit.getLogger().info("All game data for game ID " + gameID + " has been cleaned up.");
    }

    public static void clearAllMapGameIDs() {
        mapGameID.clear();
    }

    public static void clearAllConfigGameIDs() {
        configGameID.clear();
    }

    public static void clearAllIsGamePlaying() {
        isGamePlaying.clear();
    }

    public static void clearAllIsGameStarted() {
        isGameStarted.clear();
    }

    public static void clearAllInactiveGameIDs() {
        inactiveGameID.clear();
    }

    public static void clearAllActiveGameIDs() {
        activeGameID.clear();
    }

    public static void clearAllMembersGameIDs() {
        membersGameID.clear();
    }

    public static void clearAllGamePlacedBlocks() {
        gamePlacedBlocks.clear();
    }

    public static void clearAllPlayersStartedGameIDs() {
        playersStartedGameID.clear();
    }

    public static void clearAllPlayerGameIDs() {
        playerGameID.clear();
    }

    public static void clearAllGameTimes() {
        gameTimes.clear();
    }

    public static void clearAllItemTimes() {
        itemTimes.clear();
    }

    public static void clearAllLavaTimes() {
        lavaTimeMap.clear();
    }

    public static void clearAllGameTimers() {
        gameTimers.clear();
    }

    public static void clearAllItemTimers() {
        itemTimers.clear();
    }

    public static void clearAllActiveModeTasks() {
        activeModeTasks.clear();
    }

    public static void clearAllBorderTasks() {
        borderTasks.clear();
    }

    public static void clearAllActiveTimers() {
        activeTimers.clear();
    }

    public static void clearAllRemainingGameTimes() {
        remainingGameTimeMap.clear();
    }

    public static void clearAllRemainingItemTimes() {
        remainingItemTimeMap.clear();
    }

    public static int getTotalPlayerGames(Player player) {
        int totalGames = 0;
        for (Map.Entry<String, List<Player>> entry : membersGameID.entrySet()) {
            if (!entry.getValue().contains(player)) continue;
            ++totalGames;
        }
        return totalGames;
    }

    public static List<String> getAllPlayerGames(Player player) {
        ArrayList<String> playerGames = new ArrayList<String>();
        for (Map.Entry<String, List<Player>> entry : membersGameID.entrySet()) {
            if (!entry.getValue().contains(player)) continue;
            playerGames.add(entry.getKey());
        }
        return playerGames;
    }
}

