/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.scheduler.BukkitRunnable
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler;

import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.BedManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.GameManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.JoinGameHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.Rewards;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.PartyStaticClass;
import org.kloppie74.MoonPillars.PaperMC.ScoreBoardAPI.DisplayNameAboveHead;
import org.kloppie74.MoonPillars.PaperMC.UltimateGuis.InventoryItemAPI;

public class LeaveGameManager {
    public static void leaveGame(Player player) {
        UUID playerUUID = player.getUniqueId();
        int totalGames = HashMapHandler.getTotalPlayerGames(player);
        if (totalGames > 1) {
            List<String> playerGames = HashMapHandler.getAllPlayerGames(player);
            for (String gameID : playerGames) {
                LeaveGameManager.leaveSingleGame(player, gameID);
            }
        } else {
            LeaveGameManager.leaveSingleGame(player, HashMapHandler.getPlayerGameID(playerUUID));
        }
    }

    private static void leaveSingleGame(Player player, String gameID) {
        if (gameID == null) {
            HashMapHandler.removePlayerWaitingGame(player.getUniqueId());
            HashMapHandler.resetPlayerHealth(player);
            InventoryItemAPI.GiveLobbyItems(player);
            DisplayNameAboveHead.removeNick(player);
            BedManager.RemovePlayerBed(player);
            LeaveGameManager.teleportToSpawn(player);
        } else {
            World gameWorld = Bukkit.getWorld((String)("Areas/" + gameID));
            if (gameWorld != null && !player.getWorld().equals((Object)gameWorld) && !HashMapHandler.getIsGameStarted(gameID).booleanValue()) {
                HashMapHandler.removePlayerGameID(player.getUniqueId());
                player.sendMessage(MSG.chatColors("&cYou have been removed from the game because you are not in the correct world."));
                HashMapHandler.resetPlayerHealth(player);
                InventoryItemAPI.GiveLobbyItems(player);
                DisplayNameAboveHead.removeNick(player);
                BedManager.RemovePlayerBed(player);
                LeaveGameManager.teleportToSpawn(player);
            } else if (player.getWorld().getName().contains("Mini-") && player.getGameMode().equals((Object)GameMode.SPECTATOR)) {
                LeaveGameManager.teleportToSpawn(player);
                HashMapHandler.resetPlayerHealth(player);
                InventoryItemAPI.GiveLobbyItems(player);
                DisplayNameAboveHead.removeNick(player);
                BedManager.RemovePlayerBed(player);
            } else {
                UUID playerPartyOwnerUUID = PartyStaticClass.getPlayerPartyOwner(player);
                if (playerPartyOwnerUUID != null) {
                    if (!player.getUniqueId().equals(playerPartyOwnerUUID)) {
                        player.sendMessage(MSG.chatColors("&cOnly the party owner can leave the game for the entire party."));
                        return;
                    }
                    List<Player> partyMembers = PartyStaticClass.PartyMembers.get(playerPartyOwnerUUID);
                    if (partyMembers != null) {
                        for (Player member : partyMembers) {
                            LeaveGameManager.FinalLeaveGame(member, false);
                        }
                    }
                } else {
                    LeaveGameManager.FinalLeaveGame(player, false);
                }
            }
        }
    }

    public static void teleportToSpawn(Player player) {
        String World2 = SettingsManager.getInstance().getSettings().getString("LobbySettings.World");
        double X = SettingsManager.getInstance().getSettings().getDouble("LobbySettings.Spawn.X");
        double Y = SettingsManager.getInstance().getSettings().getDouble("LobbySettings.Spawn.Y");
        double Z = SettingsManager.getInstance().getSettings().getDouble("LobbySettings.Spawn.Z");
        float pitch = (float)SettingsManager.getInstance().getSettings().getDouble("LobbySettings.Spawn.Pitch");
        float yaw = (float)SettingsManager.getInstance().getSettings().getDouble("LobbySettings.Spawn.Rotate");
        World world = Bukkit.getWorld((String)World2);
        if (world != null) {
            Location location = new Location(world, X, Y, Z, yaw, pitch);
            player.teleport(location);
        } else {
            player.sendMessage(MSG.chatColors("&cError: Spawn world not found!"));
            Bukkit.getConsoleSender().sendMessage("\u00a77[\u00a7bMoonPillars\u00a77] \u00a7f- \u00a7cError: Spawn world '" + World2 + "' not found!");
        }
    }

    public static void FinalLeaveGame(Player player, boolean Forced) {
        UUID playerUUID = player.getUniqueId();
        String gameID = HashMapHandler.getPlayerGameID(playerUUID);
        if (gameID == null) {
            LeaveGameManager.teleportToSpawn(player);
            HashMapHandler.removePlayerWaitingGame(player.getUniqueId());
        } else {
            List<Player> members;
            if (Forced) {
                MessageSender.SendMessage(player, "Games.Forced-Kicked", "", "");
            }
            if ((members = HashMapHandler.getMembersGameID(gameID)) != null) {
                boolean hasActiveTimer;
                members.remove(player);
                Rewards.OnLeaveRewards(gameID, player);
                LeaveGameManager.teleportToSpawn(player);
                HashMapHandler.resetPlayerHealth(player);
                InventoryItemAPI.GiveLobbyItems(player);
                DisplayNameAboveHead.removeNick(player);
                BedManager.RemovePlayerBed(player);
                DatabaseManager.getInstance().updateSetting(player.getUniqueId(), "winstreak", 0);
                boolean gameNotStarted = HashMapHandler.getIsGamePlaying(gameID) == false;
                boolean bl = hasActiveTimer = HashMapHandler.getActiveTimer(gameID) != null;
                if (members.size() <= 2) {
                    BukkitRunnable activeTimer = HashMapHandler.getActiveTimer(gameID);
                    if (activeTimer != null && activeTimer.getTaskId() != -1) {
                        activeTimer.cancel();
                        HashMapHandler.removeActiveTimer(gameID);
                    }
                } else if (gameNotStarted && hasActiveTimer) {
                    JoinGameHandler.handleGameCountdown(gameID);
                }
            }
            HashMapHandler.removePlayerGameID(playerUUID);
            HashMapHandler.removePlayerWaitingGame(player.getUniqueId());
            if (members != null && members.isEmpty()) {
                HashMapHandler.removeMembersGameID(gameID);
                HashMapHandler.setIsGamePlaying(gameID, false);
                if (HashMapHandler.getIsGamePlaying(gameID).booleanValue()) {
                    GameManager.endGame(gameID, false);
                }
            } else {
                GameManager.TeamChecks(player, gameID);
            }
        }
    }

    public static boolean onTeleportLeave(Player player) {
        UUID playerUUID = player.getUniqueId();
        String gameID = HashMapHandler.getPlayerGameID(playerUUID);
        if (gameID == null) {
            return false;
        }
        List<Player> members = HashMapHandler.getMembersGameID(gameID);
        if (members != null) {
            boolean hasActiveTimer;
            members.remove(player);
            Rewards.OnLeaveRewards(gameID, player);
            HashMapHandler.resetPlayerHealth(player);
            InventoryItemAPI.GiveLobbyItems(player);
            DisplayNameAboveHead.removeNick(player);
            BedManager.RemovePlayerBed(player);
            DatabaseManager.getInstance().updateSetting(player.getUniqueId(), "winstreak", 0);
            boolean gameNotStarted = HashMapHandler.getIsGamePlaying(gameID) == false;
            boolean bl = hasActiveTimer = HashMapHandler.getActiveTimer(gameID) != null;
            if (members.size() <= 2) {
                BukkitRunnable activeTimer = HashMapHandler.getActiveTimer(gameID);
                if (activeTimer != null && activeTimer.getTaskId() != -1) {
                    activeTimer.cancel();
                    HashMapHandler.removeActiveTimer(gameID);
                }
            } else if (gameNotStarted && hasActiveTimer) {
                JoinGameHandler.handleGameCountdown(gameID);
            }
        }
        HashMapHandler.removePlayerGameID(playerUUID);
        HashMapHandler.removePlayerWaitingGame(player.getUniqueId());
        if (members != null && members.isEmpty()) {
            HashMapHandler.removeMembersGameID(gameID);
            HashMapHandler.setIsGamePlaying(gameID, false);
            if (HashMapHandler.getIsGamePlaying(gameID).booleanValue()) {
                GameManager.endGame(gameID, false);
            }
        } else {
            GameManager.TeamChecks(player, gameID);
        }
        MessageSender.SendMessage(player, "Games.Left-Game-Teleport", "", "");
        return true;
    }
}

