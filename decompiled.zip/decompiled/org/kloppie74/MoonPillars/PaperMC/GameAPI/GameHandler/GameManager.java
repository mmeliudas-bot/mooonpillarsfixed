/*
 * Decompiled with CFR 0.152.
 *
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.NamespacedKey
 *  org.bukkit.World
 *  org.bukkit.WorldBorder
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Warden
 *  org.bukkit.event.Event
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.HandlerList
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.EntityPotionEffectEvent
 *  org.bukkit.event.entity.EntityPotionEffectEvent$Action
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Warden;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.OnGameStartEvent;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.PlayerVisibilityListener;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.BedManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.ClearArea;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.DonatorItemManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.GearManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.LeaveGameManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.PlayerFreezeListener;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.RandomItem;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.VoteEvent;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameUtils;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.Rewards;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.TeamManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;
import org.kloppie74.MoonPillars.PaperMC.ScoreBoardAPI.DisplayNameAboveHead;
import org.kloppie74.MoonPillars.PaperMC.UltimateGuis.InventoryItemAPI;

public class GameManager {
    private static final Map<String, Set<Integer>> gameDelayedTasks = new ConcurrentHashMap<String, Set<Integer>>();
    private static WeakReference<Listener> effectListenerRef = null;
    private static WeakReference<PlayerFreezeListener> freezeListenerRef = null;
    private static final Set<String> gamesInCagePhase = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, String> frozenPlayers = new ConcurrentHashMap<UUID, String>();

    private static void registerDelayedTask(String gameID, int taskId) {
        gameDelayedTasks.computeIfAbsent(gameID, k -> ConcurrentHashMap.newKeySet()).add(taskId);
    }

    private static void cancelDelayedTasks(String gameID) {
        Set<Integer> tasks = gameDelayedTasks.remove(gameID);
        if (tasks != null) {
            for (Integer taskId : tasks) {
                try {
                    Bukkit.getScheduler().cancelTask(taskId.intValue());
                }
                catch (Exception exception) {}
            }
            tasks.clear();
        }
    }

    public static void startGameCountdown(final String gameID) {
        final List<Player> playersInGame = HashMapHandler.getMembersGameID(gameID);
        final FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
        HashMapHandler.setIsGamePlaying(gameID, false);
        int MinimumPlayers = config.getInt("SpawnLocations.MinimumPlayers");
        if (playersInGame != null && MinimumPlayers <= playersInGame.size()) {
            HashMapHandler.setActiveGameID(gameID, gameID);
            HashMapHandler.removeInactiveGameID(gameID);
            BukkitRunnable countdownTask = new BukkitRunnable(){
                int lobbyCountdown;
                int finalCountdown;
                {
                    this.lobbyCountdown = config.getInt("Settings.LobbyTimer");
                    this.finalCountdown = config.getInt("Settings.CageTimer");
                }

                public void run() {
                    try {
                        if (this.lobbyCountdown > 0) {
                            String time = MoonLab.formatTime(this.lobbyCountdown);
                            for (Player playerx : playersInGame) {
                                if (!playerx.isOnline()) continue;
                                playerx.setLevel(this.lobbyCountdown);
                                MessageSender.SendMessage(playerx, "Games.Starting-Teleport", "{time}", time);
                            }
                            --this.lobbyCountdown;
                        } else if (this.finalCountdown > 0) {
                            if (this.finalCountdown == config.getInt("Settings.CageTimer")) {
                                TeamManager.teleportPlayersToCages(gameID, config);
                                ClearArea.clearSpawnArea(gameID);
                                HashMapHandler.setIsGamePlaying(gameID, true);
                                gamesInCagePhase.add(gameID);
                                for (Player player : playersInGame) {
                                    if (!player.isOnline()) continue;
                                    frozenPlayers.put(player.getUniqueId(), gameID);
                                }
                                GameManager.registerPlayerFreezeListener();
                            }
                            String time = MoonLab.formatTime(this.finalCountdown);
                            for (Player playerx : playersInGame) {
                                if (!playerx.isOnline()) continue;
                                MessageSender.SendMessage(playerx, "Games.Starting-Game", "{time}", time);
                                playerx.setLevel(this.finalCountdown);
                            }
                            HashMapHandler.setRemainingGameTime(gameID, this.finalCountdown);
                            --this.finalCountdown;
                        } else {
                            gamesInCagePhase.remove(gameID);
                            for (Player player : playersInGame) {
                                if (!player.isOnline()) continue;
                                frozenPlayers.remove(player.getUniqueId());
                            }
                            GameManager.startGame(gameID);
                            this.cancel();
                            HashMapHandler.removeActiveTimer(gameID);
                        }
                    }
                    catch (Exception var4) {
                        this.cancel();
                        Logger var10000 = Bukkit.getLogger();
                        String var10001 = gameID;
                        var10000.warning("Error in countdown for game " + var10001 + ": " + var4.getMessage());
                        GameManager.endGame(gameID, true);
                    }
                }
            };
            HashMapHandler.setActiveTimer(gameID, countdownTask);
            countdownTask.runTaskTimer((Plugin)MoonLab.getInstance(), 0L, 20L);
        }
    }

    public static void startGame(String gameID) {
        List<Player> playersInGame = HashMapHandler.getMembersGameID(gameID);
        FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
        gamesInCagePhase.remove(gameID);
        Iterator<Map.Entry<UUID, String>> it = frozenPlayers.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, String> entry = it.next();
            if (!gameID.equals(entry.getValue())) continue;
            it.remove();
        }
        if (playersInGame != null && playersInGame.size() > 1) {
            HashMapHandler.setPlayersStartedGameID(gameID, playersInGame.size());
            HashMapHandler.setIsGameStarted(gameID, true);
            HashMapHandler.removeInactiveGameID(gameID);
            HashMapHandler.setActiveGameID(gameID, gameID);
            for (Player player : playersInGame) {
                if (!player.isOnline()) continue;
                HashMapHandler.removePlayerWaitingGame(player.getUniqueId());
                int mobSpawnTaskId = Integer.parseInt(DatabaseManager.getInstance().getSetting(player.getUniqueId(), "total_played_games")) + 1;
                DatabaseManager.getInstance().updateSetting(player.getUniqueId(), "total_played_games", mobSpawnTaskId);
                player.setGameMode(GameMode.SURVIVAL);
                GameManager.updatePlayerVisibility(player, playersInGame);
            }
            Rewards.StartGameRewards(gameID);
            World world = Bukkit.getWorld((String)("Areas/" + gameID));
            if (world == null) {
                Bukkit.getLogger().warning("Game world not found for " + gameID);
                GameManager.endGame(gameID, true);
            } else {
                for (Player player : playersInGame) {
                    if (!player.isOnline()) continue;
                    HashMapHandler.resetPlayerHealth(player);
                    player.setInvulnerable(true);
                    player.setFoodLevel(20);
                    player.setSaturation(20.0f);
                    HashMapHandler.setPlayerNoHunger(player.getUniqueId(), true);
                }
                int taskId = Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> {
                    for (Player player : playersInGame) {
                        if (!player.isOnline()) continue;
                        player.setInvulnerable(false);
                    }
                }, 30L).getTaskId();
                GameManager.registerDelayedTask(gameID, taskId);
                GearManager.GiveArmor(gameID);
                GameUtils.resetWorld(gameID, world, false, true);
                GameManager.setupGameTimers(gameID, config, world);
                int mobSpawnTaskId = Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> GameManager.spawnConfiguredMobs(gameID, world), 5L).getTaskId();
                GameManager.registerDelayedTask(gameID, mobSpawnTaskId);
                VoteEvent.VoteEvents(gameID);
                DonatorItemManager.giveStartItems(gameID, playersInGame);
                String NormilizedGameID = GameUtils.getNormalizedGameID(gameID);
                Bukkit.getPluginManager().callEvent((Event)new OnGameStartEvent(gameID, playersInGame));
            }
        } else {
            GameManager.endGame(gameID, false);
        }
    }

    public static void endGame(String gameID, boolean forced) {
        if (!HashMapHandler.isGameEnding(gameID)) {
            HashMapHandler.setGameEnding(gameID, true);
            gamesInCagePhase.remove(gameID);
            Iterator<Map.Entry<UUID, String>> it = frozenPlayers.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, String> entry = it.next();
                if (!gameID.equals(entry.getValue())) continue;
                it.remove();
            }
            FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
            Map<String, List<Player>> teams = TeamManager.teamsPerGame.get(gameID);
            boolean shouldStartBorder = false;
            if (!forced && teams != null && teams.size() > 1 && config != null) {
                shouldStartBorder = config.getBoolean("Events.Border.Enabled", false);
            }
            if (shouldStartBorder) {
                GameManager.StartBorderEvent(gameID, config);
                HashMapHandler.setGameEnding(gameID, false);
            } else {
                List<BukkitRunnable> modusTasks = HashMapHandler.getActiveModeTasks(gameID);
                if (modusTasks != null) {
                    for (BukkitRunnable modusTask : modusTasks) {
                        try {
                            modusTask.cancel();
                        }
                        catch (Exception exception) {}
                    }
                    HashMapHandler.removeActiveModeTasks(gameID);
                    modusTasks.clear();
                }
                GameManager.cancelDelayedTasks(gameID);
                List<Player> playersInGame = HashMapHandler.getMembersGameID(gameID);
                if (playersInGame != null) {
                    for (Player player : playersInGame) {
                        if (!player.isOnline()) continue;
                        HashMapHandler.resetPlayerHealth(player);
                        player.setInvulnerable(true);
                        if (!forced) continue;
                        MessageSender.SendMessage(player, "Games.Forced-End-Game", "", "");
                    }
                }
                HashMapHandler.CancelTasks(gameID);
                Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> GameManager.finalizeGameCleanup(gameID, playersInGame), 100L).getTaskId();
            }
        }
    }

    private static void finalizeGameCleanup(String gameID, List<Player> playersInGame) {
        try {
            World gameWorld = Bukkit.getWorld((String)("Areas/" + gameID));
            HashSet<Player> allPlayers = new HashSet<Player>();
            if (playersInGame != null) {
                allPlayers.addAll(playersInGame);
                playersInGame.clear();
            }
            if (gameWorld != null) {
                for (Player player : gameWorld.getPlayers()) {
                    allPlayers.add(player);
                }
            }
            for (Player player : allPlayers) {
                if (player == null || !player.isOnline()) continue;
                LeaveGameManager.teleportToSpawn(player);
                player.setGameMode(GameMode.SURVIVAL);
                player.getInventory().clear();
                HashMapHandler.resetPlayerHealth(player);
                InventoryItemAPI.GiveLobbyItems(player);
                DisplayNameAboveHead.removeNick(player);
                BedManager.RemovePlayerBed(player);
                HashMapHandler.removePlayerNoHunger(player.getUniqueId());
                HashMapHandler.removePlayerGameID(player.getUniqueId());
                frozenPlayers.remove(player.getUniqueId());
            }
            allPlayers.clear();
            if (gameWorld != null) {
                GameUtils.resetWorld(gameID, gameWorld, true, false);
            }
            HashMapHandler.resetGameData(gameID);
            HashMapHandler.setGameEnding(gameID, false);
            if (Math.random() < 0.05) {
                System.gc();
            }
        }
        catch (Exception var6) {
            Bukkit.getLogger().severe("Error during game cleanup: " + var6.getMessage());
            var6.printStackTrace();
            HashMapHandler.setGameEnding(gameID, false);
        }
    }

    public static void StartBorderEvent(final String gameID, final FileConfiguration config) {
        World world = Bukkit.getWorld((String)("Areas/" + gameID));
        if (world == null) {
            Bukkit.getLogger().warning("World not found for game " + gameID);
            GameManager.endGame(gameID, true);
        } else {
            WorldBorder border = world.getWorldBorder();
            int size = config.getInt("Settings.BuildRange") * 2;
            double targetSize = 0.0;
            long durationInSeconds = config.getInt("Events.Border.Close-Border-Timer");
            border.setCenter(world.getSpawnLocation());
            border.setDamageBuffer(0.0);
            border.setDamageAmount(1.0);
            border.setSize((double)size);
            border.setSize(targetSize, durationInSeconds);
            BukkitRunnable oldTask = HashMapHandler.getBorderTask(gameID);
            if (oldTask != null) {
                oldTask.cancel();
            }
            final List<Player> playersInGame = HashMapHandler.getMembersGameID(gameID);
            BukkitRunnable borderTimer = new BukkitRunnable(){
                int timeLeft;
                {
                    this.timeLeft = config.getInt("Events.Border.Close-Border-Timer");
                }

                public void run() {
                    try {
                        if (this.timeLeft <= 0) {
                            this.cancel();
                            HashMapHandler.removeBorderTask(gameID);
                            for (Player player : playersInGame) {
                                if (!player.isOnline()) continue;
                                MessageSender.SendMessage(player, "Games.Border-Shrink-End", "", "");
                            }
                            int endTaskId = Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> GameManager.endGame(gameID, true), 100L).getTaskId();
                            GameManager.registerDelayedTask(gameID, endTaskId);
                        } else {
                            String time = MoonLab.formatTime(this.timeLeft);
                            for (Player playerx : playersInGame) {
                                if (!playerx.isOnline()) continue;
                                MessageSender.SendMessage(playerx, "Games.Border-Shrinking", "{time}", time);
                            }
                            HashMapHandler.setRemainingGameTime(gameID, this.timeLeft);
                            --this.timeLeft;
                        }
                    }
                    catch (Exception var4) {
                        this.cancel();
                        Logger var10000 = Bukkit.getLogger();
                        String var10001 = gameID;
                        var10000.warning("Error in border timer for " + var10001 + ": " + var4.getMessage());
                        GameManager.endGame(gameID, true);
                    }
                }
            };
            HashMapHandler.setBorderTask(gameID, borderTimer);
            borderTimer.runTaskTimer((Plugin)MoonLab.getInstance(), 0L, 20L);
        }
    }

    public static void TeamChecks(Player player, String gameID) {
        Map<String, List<Player>> teams;
        if (HashMapHandler.getIsGamePlaying(gameID).booleanValue() && (teams = TeamManager.teamsPerGame.get(gameID)) != null) {
            String playerTeam = null;
            for (Map.Entry<String, List<Player>> entry : teams.entrySet()) {
                if (!entry.getValue().remove(player)) continue;
                playerTeam = entry.getKey();
                break;
            }
            if (playerTeam != null) {
                String teamName;
                FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
                if (teams.get(playerTeam).isEmpty()) {
                    teams.remove(playerTeam);
                    teamName = config.getString("SpawnLocations." + playerTeam + ".Name");
                    for (Player gamePlayer : HashMapHandler.getMembersGameID(gameID)) {
                        if (!gamePlayer.isOnline()) continue;
                        MessageSender.SendMessage(gamePlayer, "Games.Team-Died", "{team}", teamName);
                    }
                }
                if (teams.size() == 1) {
                    teamName = teams.keySet().iterator().next();
                    Rewards.OnGameEndRewards(gameID, teamName);
                    GameManager.endGame(gameID, false);
                }
            }
        }
    }

    private static void setupGameTimers(final String gameID, FileConfiguration config, final World world) {
        final List<Player> playersInGame = HashMapHandler.getMembersGameID(gameID);
        if (HashMapHandler.getGameTimer(gameID) != null) {
            HashMapHandler.getGameTimer(gameID).cancel();
            HashMapHandler.removeGameTimer(gameID);
        }
        if (HashMapHandler.getItemTimer(gameID) != null) {
            HashMapHandler.getItemTimer(gameID).cancel();
            HashMapHandler.removeItemTimer(gameID);
        }
        int gameDuration = config.getInt("Settings.GameTimer");
        HashMapHandler.setGameTimes(gameID, gameDuration);
        BukkitRunnable timerTask = new BukkitRunnable(){

            public void run() {
                try {
                    Integer remainingTime = HashMapHandler.getGameTimes(gameID);
                    if (remainingTime == null) {
                        this.cancel();
                        HashMapHandler.removeGameTimer(gameID);
                        GameManager.endGame(gameID, true);
                        return;
                    }
                    String formattedTime = MoonLab.formatTime(remainingTime);
                    for (Player player : playersInGame) {
                        if (!player.isOnline()) continue;
                        MessageSender.SendMessage(player, "Games.Time-Left", "{time}", formattedTime);
                        player.setLevel(remainingTime.intValue());
                    }
                    HashMapHandler.setRemainingGameTime(gameID, remainingTime);
                    if (remainingTime <= 0) {
                        GameManager.endGame(gameID, false);
                        this.cancel();
                        HashMapHandler.removeGameTimer(gameID);
                    } else {
                        HashMapHandler.setGameTimes(gameID, remainingTime - 1);
                    }
                }
                catch (Exception var5) {
                    this.cancel();
                    Logger var10000 = Bukkit.getLogger();
                    String var10001 = gameID;
                    var10000.warning("Error in game timer for " + var10001 + ": " + var5.getMessage());
                    HashMapHandler.removeGameTimer(gameID);
                }
            }
        };
        timerTask.runTaskTimer((Plugin)MoonLab.getInstance(), 0L, 20L);
        HashMapHandler.setGameTimer(gameID, timerTask);
        int itemDuration = config.getInt("Settings.ItemTimer");
        if (HashMapHandler.isFasterItemsMode(gameID)) {
            itemDuration = Math.max(1, itemDuration / 2);
        }
        HashMapHandler.setItemTimes(gameID, itemDuration);
        final int originalItemDuration = config.getInt("Settings.ItemTimer");
        final int fasterItemDuration = Math.max(1, originalItemDuration / 2);
        BukkitRunnable itemTask = new BukkitRunnable(){

            public void run() {
                try {
                    Integer remainingTime = HashMapHandler.getItemTimes(gameID);
                    if (remainingTime == null) {
                        this.cancel();
                        HashMapHandler.removeItemTimer(gameID);
                        HashMapHandler.removeItemTimes(gameID);
                        return;
                    }
                    if (remainingTime <= 0) {
                        if (HashMapHandler.isSynchronizedItemsMode(gameID)) {
                            RandomItem.SynchronizedItemGivingTask(gameID, playersInGame, world);
                        } else {
                            for (Player player : playersInGame) {
                                if (!player.isOnline() || !player.getWorld().equals((Object)world)) continue;
                                RandomItem.ItemGivingTask(gameID, player);
                            }
                        }
                        int nextItemDuration = HashMapHandler.isFasterItemsMode(gameID) ? fasterItemDuration : originalItemDuration;
                        HashMapHandler.setItemTimes(gameID, nextItemDuration);
                        HashMapHandler.setRemainingItemTime(gameID, nextItemDuration);
                    } else {
                        HashMapHandler.setItemTimes(gameID, remainingTime - 1);
                        HashMapHandler.setRemainingItemTime(gameID, remainingTime - 1);
                    }
                }
                catch (Exception var4) {
                    this.cancel();
                    Logger var10000 = Bukkit.getLogger();
                    String var10001 = gameID;
                    var10000.warning("Error in item timer for " + var10001 + ": " + var4.getMessage());
                    HashMapHandler.removeItemTimer(gameID);
                    HashMapHandler.removeItemTimes(gameID);
                }
            }
        };
        itemTask.runTaskTimer((Plugin)MoonLab.getInstance(), 0L, 20L);
        HashMapHandler.setItemTimer(gameID, itemTask);
    }

    private static void updatePlayerVisibility(Player player, List<Player> allPlayers) {
        if (!PlayerVisibilityListener.isVanished(player.getUniqueId())) {
            Iterator<Player> var2 = allPlayers.iterator();
            while (true) {
                if (!var2.hasNext()) {
                    return;
                }
                Player otherPlayer = var2.next();
                if (!otherPlayer.isOnline() || PlayerVisibilityListener.isVanished(otherPlayer.getUniqueId()) && !player.hasPermission("mpa.vanish.seeothers")) continue;
                player.showPlayer((Plugin)MoonLab.getInstance(), otherPlayer);
                otherPlayer.showPlayer((Plugin)MoonLab.getInstance(), player);
            }
        }
    }

    public static void spawnConfiguredMobs(String gameID, World world) {
        FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
        if (config != null && config.contains("SpawnMob") && config.getBoolean("SpawnMob.Enabled", false)) {
            Location baseLocation = world.getSpawnLocation();
            ConfigurationSection mobsSection = config.getConfigurationSection("SpawnMob.Mob");
            if (mobsSection != null) {
                for (String mobTypeKey : mobsSection.getKeys(false)) {
                    try {
                        EntityType mobType = EntityType.valueOf((String)mobTypeKey);
                        ConfigurationSection mobSection = mobsSection.getConfigurationSection(mobTypeKey);
                        if (mobSection == null) continue;
                        double x = mobSection.getDouble("X", 0.0);
                        double y = mobSection.getDouble("Y", 0.0);
                        double z = mobSection.getDouble("Z", 0.0);
                        Location spawnLoc = baseLocation.clone().add(x, y, z);
                        Entity entity = world.spawnEntity(spawnLoc, mobType);
                        if (mobType != EntityType.WARDEN || !(entity instanceof Warden)) continue;
                        NamespacedKey key = new NamespacedKey((Plugin)MoonLab.getInstance(), "no_darkness");
                        entity.getPersistentDataContainer().set(key, PersistentDataType.BOOLEAN, (Object)true);
                    }
                    catch (Exception var18) {
                        Bukkit.getLogger().warning("Error spawning mob " + mobTypeKey + ": " + var18.getMessage());
                    }
                }
                GameManager.registerEffectListener();
            }
        }
    }

    private static void registerEffectListener() {
        Listener currentListener;
        Listener listener = currentListener = effectListenerRef != null ? (Listener)effectListenerRef.get() : null;
        if (currentListener == null) {
            Listener newListener = new Listener(){

                @EventHandler(priority=EventPriority.HIGHEST)
                public void onPotionEffect(EntityPotionEffectEvent event) {
                    Player player;
                    String worldName;
                    if (event.getAction() == EntityPotionEffectEvent.Action.ADDED && event.getNewEffect() != null && event.getNewEffect().getType() == PotionEffectType.DARKNESS && event.getEntity() instanceof Player && (worldName = (player = (Player)event.getEntity()).getWorld().getName()).contains("warden")) {
                        event.setCancelled(true);
                    }
                }
            };
            Bukkit.getPluginManager().registerEvents(newListener, (Plugin)MoonLab.getInstance());
            effectListenerRef = new WeakReference<Listener>(newListener);
        }
    }

    private static void registerPlayerFreezeListener() {
        PlayerFreezeListener currentListener;
        PlayerFreezeListener playerFreezeListener = currentListener = freezeListenerRef != null ? (PlayerFreezeListener)freezeListenerRef.get() : null;
        if (currentListener == null) {
            PlayerFreezeListener newListener = new PlayerFreezeListener();
            Bukkit.getPluginManager().registerEvents((Listener)newListener, (Plugin)MoonLab.getInstance());
            freezeListenerRef = new WeakReference<PlayerFreezeListener>(newListener);
            BukkitTask bukkitTask = Bukkit.getScheduler().runTaskTimer((Plugin)MoonLab.getInstance(), () -> {
                if (gamesInCagePhase.isEmpty()) {
                    PlayerFreezeListener listener;
                    PlayerFreezeListener playerFreezeListener2 = listener = freezeListenerRef != null ? (PlayerFreezeListener)freezeListenerRef.get() : null;
                    if (listener != null) {
                        HandlerList.unregisterAll((Listener)listener);
                        freezeListenerRef.clear();
                    }
                }
            }, 100L, 100L);
        }
    }

    public static boolean isGameInCagePhase(String gameID) {
        return gamesInCagePhase.contains(gameID);
    }

    public static boolean isPlayerFrozen(UUID playerUUID) {
        return frozenPlayers.containsKey(playerUUID);
    }

    public static String getPlayerFrozenGameID(UUID playerUUID) {
        return frozenPlayers.get(playerUUID);
    }

    public static void unregisterEffectListener() {
        Listener listener;
        Listener listener2 = listener = effectListenerRef != null ? (Listener)effectListenerRef.get() : null;
        if (listener != null) {
            HandlerList.unregisterAll((Listener)listener);
            effectListenerRef.clear();
            effectListenerRef = null;
        }
    }

    public static void cleanupGlobalResources() {
        PlayerFreezeListener freezeListener;
        GameManager.unregisterEffectListener();
        PlayerFreezeListener playerFreezeListener = freezeListener = freezeListenerRef != null ? (PlayerFreezeListener)freezeListenerRef.get() : null;
        if (freezeListener != null) {
            HandlerList.unregisterAll((Listener)freezeListener);
            freezeListenerRef.clear();
            freezeListenerRef = null;
        }
        gamesInCagePhase.clear();
        frozenPlayers.clear();
        for (String gameID : new ArrayList<String>(gameDelayedTasks.keySet())) {
            GameManager.cancelDelayedTasks(gameID);
        }
        gameDelayedTasks.clear();
    }
}