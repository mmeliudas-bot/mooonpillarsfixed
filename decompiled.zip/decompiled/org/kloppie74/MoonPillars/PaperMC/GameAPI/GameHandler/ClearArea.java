/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.configuration.file.FileConfiguration
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameUtils;

public class ClearArea {
    private static final Set<String> activeClearTasks = ConcurrentHashMap.newKeySet();
    private static final int MAX_CACHE_SIZE = 100;
    private static final Map<String, int[]> spawnAreaCache = new ConcurrentHashMap<String, int[]>();

    public static void clearSpawnArea(String gameID) {
        if (activeClearTasks.add(gameID)) {
            World world = Bukkit.getWorld((String)("Areas/" + gameID));
            if (world == null) {
                Bukkit.getLogger().warning("Cannot clear area: world not found for game " + gameID);
                activeClearTasks.remove(gameID);
            } else {
                String normalizedID = GameUtils.getNormalizedGameID(gameID);
                int[] areaCoords = ClearArea.getSpawnAreaCoords(normalizedID, gameID);
                if (areaCoords == null) {
                    Bukkit.getLogger().warning("Cannot clear area: failed to load coordinates for game " + gameID);
                    activeClearTasks.remove(gameID);
                } else {
                    int minX = areaCoords[0];
                    int maxX = areaCoords[1];
                    int minY = areaCoords[2];
                    int maxY = areaCoords[3];
                    int minZ = areaCoords[4];
                    int maxZ = areaCoords[5];
                    Bukkit.getLogger().info("Starting to clear area for game " + gameID);
                    for (int x = minX; x <= maxX; ++x) {
                        for (int y = minY; y <= maxY; ++y) {
                            for (int z = minZ; z <= maxZ; ++z) {
                                Block block = world.getBlockAt(x, y, z);
                                if (block.getType() == Material.AIR) continue;
                                block.setType(Material.AIR, false);
                            }
                        }
                    }
                    Bukkit.getLogger().info("Finished clearing area for game " + gameID);
                    activeClearTasks.remove(gameID);
                }
            }
        }
    }

    private static int[] getSpawnAreaCoords(String normalizedID, String gameID) {
        int[] cachedCoords = spawnAreaCache.get(normalizedID);
        if (cachedCoords != null) {
            return cachedCoords;
        }
        FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
        if (config == null) {
            return null;
        }
        try {
            int loc1X = config.getInt("Settings.Spawn-Area.Loc1.X");
            int loc1Y = config.getInt("Settings.Spawn-Area.Loc1.Y");
            int loc1Z = config.getInt("Settings.Spawn-Area.Loc1.Z");
            int loc2X = config.getInt("Settings.Spawn-Area.Loc2.X");
            int loc2Y = config.getInt("Settings.Spawn-Area.Loc2.Y");
            int loc2Z = config.getInt("Settings.Spawn-Area.Loc2.Z");
            int[] coords = new int[]{Math.min(loc1X, loc2X), Math.max(loc1X, loc2X), Math.min(loc1Y, loc2Y), Math.max(loc1Y, loc2Y), Math.min(loc1Z, loc2Z), Math.max(loc1Z, loc2Z)};
            if (spawnAreaCache.size() >= 100) {
                String keyToRemove = spawnAreaCache.keySet().iterator().next();
                spawnAreaCache.remove(keyToRemove);
            }
            spawnAreaCache.put(normalizedID, coords);
            return coords;
        }
        catch (Exception var12) {
            Bukkit.getLogger().warning("Error loading spawn area coordinates for " + gameID + ": " + var12.getMessage());
            return null;
        }
    }

    public static void cancelClearingTasks(String gameID) {
        activeClearTasks.remove(gameID);
    }

    public static void cancelAllClearingTasks() {
        activeClearTasks.clear();
    }

    public static void clearCache(String normalizedID) {
        if (normalizedID == null) {
            spawnAreaCache.clear();
        } else {
            spawnAreaCache.remove(normalizedID);
        }
    }
}

