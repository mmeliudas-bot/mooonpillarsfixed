/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.LuckPermsHook;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.RandomItem;

public class DonatorItemManager {
    public static void giveStartItems(String gameID, List<Player> players) {
        List<DonatorEntry> entries;
        if (players != null && gameID != null && !(entries = DonatorItemManager.loadEntries()).isEmpty()) {
            for (Player player : players) {
                if (player == null || !player.isOnline()) continue;
                int count = DonatorItemManager.getExtraItemCount(player, entries);
                for (int i = 0; i < count; ++i) {
                    RandomItem.giveRandomItem(gameID, player);
                }
            }
        }
    }

    public static List<DonatorEntry> loadEntries() {
        ArrayList<DonatorEntry> entries = new ArrayList<DonatorEntry>();
        FileConfiguration settings = SettingsManager.getInstance().getSettings();
        if (settings == null) {
            return entries;
        }
        List rawList = settings.getMapList("DonatorItems.Permissions");
        for (Map entryMap : rawList) {
            int count;
            Object permObj = entryMap.get("permission");
            Object countObj = entryMap.get("count");
            if (permObj == null || countObj == null) continue;
            String permission = permObj.toString();
            try {
                count = countObj instanceof Number ? ((Number)countObj).intValue() : Integer.parseInt(countObj.toString());
            }
            catch (NumberFormatException var10) {
                continue;
            }
            if (permission.isEmpty() || count <= 0) continue;
            entries.add(new DonatorEntry(permission, count));
        }
        return entries;
    }

    public static int getExtraItemCount(Player player, List<DonatorEntry> entries) {
        if (Bukkit.getPluginManager().getPlugin("LuckPerms") != null) {
            try {
                int count = LuckPermsHook.getHighestCount(player, entries);
                if (count >= 0) {
                    return count;
                }
            }
            catch (Throwable var5) {
                Bukkit.getLogger().warning("[MoonPillars] LuckPerms lookup for donator items failed, falling back to Bukkit permissions: " + var5.getMessage());
            }
        }
        int best = 0;
        for (DonatorEntry entry : entries) {
            if (!player.hasPermission(entry.permission) || entry.count <= best) continue;
            best = entry.count;
        }
        return best;
    }

    public static class DonatorEntry {
        public final String permission;
        public final int count;

        public DonatorEntry(String permission, int count) {
            this.permission = permission;
            this.count = count;
        }
    }
}

