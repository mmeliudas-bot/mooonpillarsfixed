/*
 * Decompiled with CFR 0.152.
 *
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.PlayerVisibilityListener;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.BedManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.GameManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.LocalCache;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.PartyStaticClass;
import org.kloppie74.MoonPillars.PaperMC.ScoreBoardAPI.DisplayNameAboveHead;
import org.kloppie74.MoonPillars.PaperMC.UltimateGuis.InventoryItemAPI;

public class JoinGameHandler {
    private static final Pattern GAME_ID_PATTERN = Pattern.compile("Mini-([^-]+)-(\\d+)");
    private static final Map<UUID, Map<String, Pattern>> patternCacheByPlayer = new ConcurrentHashMap<UUID, Map<String, Pattern>>();

    public static void joinGame(Player player, String gameName) {
        if (player != null && gameName != null) {
            UUID playerUUID = player.getUniqueId();
            try {
                patternCacheByPlayer.computeIfAbsent(playerUUID, k -> new ConcurrentHashMap());
                Logger var10000 = Bukkit.getLogger();
                String var10001 = player.getName();
                var10000.info("Player " + var10001 + " attempting to join game: " + gameName);
                boolean inLobbyWorld = JoinGameHandler.isPlayerInLobbyWorld(player);
                if (!JoinGameHandler.isPlayerInGame(player) || inLobbyWorld) {
                    List<Player> partyMembers = JoinGameHandler.getPartyMembers(player);
                    if (partyMembers == null) {
                        return;
                    }
                    String gameID = JoinGameHandler.findBestGameForType(gameName.toLowerCase(), partyMembers, playerUUID);
                    if (gameID == null) {
                        Bukkit.getLogger().info("No suitable game found, creating new game for: " + gameName);
                        gameID = LocalCache.createExtraGameMap(gameName.toLowerCase());
                    }
                    if (gameID != null) {
                        JoinGameHandler.joinPlayersToGame(gameID, partyMembers);
                    } else {
                        MessageSender.SendMessage(player, "Games.Failed-To-Join", new String[0]);
                    }
                    return;
                }
                MessageSender.SendMessage(player, "Games.Already-In-Game", new String[0]);
            }
            finally {
                patternCacheByPlayer.remove(playerUUID);
            }
        }
    }

    public static void joinRandomGame(Player player) {
        if (player != null) {
            UUID playerUUID = player.getUniqueId();
            try {
                List<Player> members;
                int playerCount;
                patternCacheByPlayer.computeIfAbsent(playerUUID, k -> new ConcurrentHashMap());
                Bukkit.getLogger().info("Player " + player.getName() + " attempting to join random game");
                boolean inLobbyWorld = JoinGameHandler.isPlayerInLobbyWorld(player);
                if (JoinGameHandler.isPlayerInGame(player) && !inLobbyWorld) {
                    MessageSender.SendMessage(player, "Games.Already-In-Game", new String[0]);
                    return;
                }
                List<Player> partyMembers = JoinGameHandler.getPartyMembers(player);
                if (partyMembers == null) {
                    return;
                }
                int partySize = partyMembers.size();
                Set<String> allGameIDs = HashMapHandler.getAllMapGameIDs();
                ArrayList<String> availableGames = new ArrayList<String>();
                for (String gameID : allGameIDs) {
                    int maxPlayers;
                    FileConfiguration config;
                    if (HashMapHandler.getIsGamePlaying(gameID).booleanValue() || HashMapHandler.getInactiveGameID(gameID).booleanValue() || (config = HashMapHandler.getConfigGameID(gameID)) == null || (maxPlayers = config.getInt("SpawnLocations.MaximumPlayers", 8)) - (playerCount = (members = HashMapHandler.getMembersGameID(gameID)) != null ? members.size() : 0) < partySize) continue;
                    availableGames.add(gameID);
                }
                Bukkit.getLogger().info("Found " + availableGames.size() + " available games for random join");
                if (!availableGames.isEmpty()) {
                    String gameWithPlayers = null;
                    int mostPlayers = 0;
                    for (String gameID : availableGames) {
                        members = HashMapHandler.getMembersGameID(gameID);
                        playerCount = members != null ? members.size() : 0;
                        if (playerCount <= 0 || playerCount <= mostPlayers) continue;
                        mostPlayers = playerCount;
                        gameWithPlayers = gameID;
                    }
                    if (gameWithPlayers != null) {
                        Bukkit.getLogger().info("Found game with players: " + gameWithPlayers);
                        JoinGameHandler.joinPlayersToGame(gameWithPlayers, partyMembers);
                        return;
                    }
                    if (!availableGames.isEmpty()) {
                        String randomGame = (String)availableGames.get(new Random().nextInt(availableGames.size()));
                        Bukkit.getLogger().info("Joining random empty game: " + randomGame);
                        JoinGameHandler.joinPlayersToGame(randomGame, partyMembers);
                        return;
                    }
                    MessageSender.SendMessage(player, "Games.No-Available-Games", new String[0]);
                    return;
                }
                MessageSender.SendMessage(player, "Games.No-Available-Games", new String[0]);
            }
            finally {
                patternCacheByPlayer.remove(playerUUID);
            }
        }
    }

    private static List<Player> getPartyMembers(Player player) {
        UUID partyOwner = PartyStaticClass.getPlayerPartyOwner(player);
        if (partyOwner != null && !partyOwner.equals(player.getUniqueId())) {
            MessageSender.SendMessage(player, "Games.Not-Party-Owner", new String[0]);
            return null;
        }
        return partyOwner != null ? PartyStaticClass.PartyMembers.get(partyOwner) : Collections.singletonList(player);
    }

    private static String findBestGameForType(String gameType, List<Player> partyMembers, UUID playerUUID) {
        int partySize = partyMembers.size();
        String bestGameWithPlayers = null;
        ArrayList<String> emptyGames = new ArrayList<String>();
        int mostPlayers = -1;
        Map<String, Pattern> playerPatternCache = patternCacheByPlayer.get(playerUUID);
        Pattern pattern = playerPatternCache.computeIfAbsent(gameType, key -> Pattern.compile("Mini-" + Pattern.quote(key) + "-(\\d+)", 2));
        Set<String> gameIDs = HashMapHandler.getAllMapGameIDs();
        for (String gameID : gameIDs) {
            List<Player> members;
            int currentPlayers;
            int maxPlayers;
            FileConfiguration config;
            Matcher matcher = pattern.matcher(gameID);
            if (!matcher.matches() || HashMapHandler.getIsGamePlaying(gameID).booleanValue() || HashMapHandler.getInactiveGameID(gameID).booleanValue() || (config = HashMapHandler.getConfigGameID(gameID)) == null || (maxPlayers = config.getInt("SpawnLocations.MaximumPlayers", 8)) - (currentPlayers = (members = HashMapHandler.getMembersGameID(gameID)) != null ? members.size() : 0) < partySize) continue;
            if (currentPlayers > 0) {
                if (currentPlayers <= mostPlayers) continue;
                mostPlayers = currentPlayers;
                bestGameWithPlayers = gameID;
                continue;
            }
            emptyGames.add(gameID);
        }
        if (bestGameWithPlayers != null) {
            return bestGameWithPlayers;
        }
        if (!emptyGames.isEmpty()) {
            emptyGames.sort((a, b) -> {
                Matcher matcherA = pattern.matcher((CharSequence)a);
                Matcher matcherB = pattern.matcher((CharSequence)b);
                return matcherA.matches() && matcherB.matches() ? Integer.compare(Integer.parseInt(matcherA.group(1)), Integer.parseInt(matcherB.group(1))) : 0;
            });
            return (String)emptyGames.get(0);
        }
        return null;
    }

    public static void joinFinalGame(Player player, String gameID) {
        if (player != null && gameID != null) {
            ArrayList<Player> members;
            List<Player> currentMembers = HashMapHandler.getMembersGameID(gameID);
            ArrayList<Object> arrayList = members = currentMembers != null ? new ArrayList<Player>(currentMembers) : new ArrayList();
            if (!members.contains(player)) {
                members.add(player);
            }
            HashMapHandler.setMembersGameID(gameID, members);
            HashMapHandler.setPlayerGameID(player.getUniqueId(), gameID);
            MessageSender.SendMessage(player, "Games.Joined-Game", "{gameid}", gameID);
            JoinGameHandler.teleportPlayerToGameSpawn(player, gameID);
            HashMapHandler.resetPlayerHealth(player);
            DisplayNameAboveHead.removeNick(player);
            BedManager.RemovePlayerBed(player);
            JoinGameHandler.handleGameCountdown(gameID);
            HashMapHandler.resetPlayerHealth(player);
            InventoryItemAPI.GiveGameLobbyItems(player);
            HashMapHandler.setPlayerWaitingGameID(player.getUniqueId(), gameID);
            if (JoinGameHandler.isPlayerInLobbyWorld(player)) {
                for (Player online : Bukkit.getOnlinePlayers()) {
                    String onlineGameID;
                    if (online.equals((Object)player) || PlayerVisibilityListener.isVanished(online.getUniqueId()) || (onlineGameID = HashMapHandler.getPlayerGameID(online.getUniqueId())) != null) continue;
                    player.showPlayer((Plugin)MoonLab.getInstance(), online);
                    online.showPlayer((Plugin)MoonLab.getInstance(), player);
                }
            }
        }
    }

    private static void joinPlayersToGame(String gameID, List<Player> players) {
        HashMap<Player, Boolean> inLobbyMap = new HashMap<Player, Boolean>();
        for (Player member : players) {
            if (member == null) continue;
            inLobbyMap.put(member, JoinGameHandler.isPlayerInLobbyWorld(member));
        }
        for (Player member : players) {
            if (member == null) continue;
            String memberGameID = HashMapHandler.getPlayerGameID(member.getUniqueId());
            boolean inLobby = inLobbyMap.getOrDefault(member, false);
            if (memberGameID == null || inLobby) continue;
            MessageSender.SendMessage(member, "Games.Already-In-Game", new String[0]);
            return;
        }
        for (Player member : players) {
            if (member == null) continue;
            JoinGameHandler.joinFinalGame(member, gameID);
        }
    }

    private static void teleportPlayerToGameSpawn(Player player, String gameID) {
        FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
        World world = Bukkit.getWorld("Areas/" + gameID);
        if (world == null || config == null) return;

        Location cageLocation = findFreeCage(gameID, config, world, player);
        if (cageLocation != null) {
            player.teleport(cageLocation);

            try {
                Class<?> schematicClass = Class.forName("org.kloppie74.MoonPillars.PaperMC.GameAPI.SchematicHandler");
                java.lang.reflect.Method placeCage = schematicClass.getMethod("PlaceCage", Player.class, int.class);
                placeCage.invoke(null, player, 0);
            } catch (Exception e) {
                Bukkit.getLogger().warning("Не удалось построить клетку: " + e.getMessage());
            }

            Bukkit.getLogger().info("Player " + player.getName() + " teleported to cage.");
        }
        // НЕТ fallback в домик. Если клеток нет — игрок остаётся там, где был.
    }

    private static Location findFreeCage(String gameID, FileConfiguration config, World world, Player player) {
        List<Player> members = HashMapHandler.getMembersGameID(gameID);
        if (members == null) members = new ArrayList<>();

        int maxTeams = config.getInt("SpawnLocations.MaxTeams", 8);
        int playersPerTeam = config.getInt("SpawnLocations.PlayersPerTeam", 1);

        for (int teamIndex = 1; teamIndex <= maxTeams; teamIndex++) {
            String teamKey = "Team" + teamIndex;

            int playersInTeam = 0;
            for (Player member : members) {
                if (member == null || !member.isOnline()) continue;
                Location teamSpawn = getTeamSpawnLocation(config, teamKey, 1, world);
                if (teamSpawn != null && member.getWorld().equals(world)
                        && member.getLocation().distanceSquared(teamSpawn) < 25) {
                    playersInTeam++;
                }
            }

            if (playersInTeam < playersPerTeam) {
                Location spawn = getTeamSpawnLocation(config, teamKey, playersInTeam + 1, world);
                if (spawn != null) return spawn;
            }
        }
        return null;
    }

    private static Location getTeamSpawnLocation(FileConfiguration config, String teamKey, int playerIndex, World world) {
        String path = "SpawnLocations." + teamKey + ".Player" + playerIndex;
        if (!config.contains(path + ".X") || !config.contains(path + ".Y") || !config.contains(path + ".Z")) {
            return null;
        }
        double x = config.getDouble(path + ".X");
        double y = config.getDouble(path + ".Y");
        double z = config.getDouble(path + ".Z");
        float yaw = (float) config.getDouble(path + ".Yaw", 0.0);
        float pitch = (float) config.getDouble(path + ".Pitch", 0.0);
        return new Location(world, x, y, z, yaw, pitch);
    }

    public static void handleGameCountdown(String gameID) {
        if (!HashMapHandler.getIsGamePlaying(gameID).booleanValue()) {
            BukkitRunnable activeTimer = HashMapHandler.getActiveTimer(gameID);
            if (activeTimer != null) {
                try {
                    activeTimer.cancel();
                }
                catch (IllegalStateException illegalStateException) {
                    // empty catch block
                }
                HashMapHandler.removeActiveTimer(gameID);
            }
            GameManager.startGameCountdown(gameID);
        }
    }

    private static boolean isPlayerInGame(Player player) {
        return HashMapHandler.getTotalPlayerGames(player) > 0;
    }

    private static boolean isPlayerInLobbyWorld(Player player) {
        if (player != null && player.getWorld() != null) {
            String lobbyWorldName = SettingsManager.getInstance().getSettings().getString("LobbySettings.World");
            return player.getWorld().getName().equalsIgnoreCase(lobbyWorldName);
        }
        return false;
    }
}