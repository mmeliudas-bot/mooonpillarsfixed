/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;

public class GearManager {
    public static void GiveArmor(String gameID) {
        List<Player> playersInGame = HashMapHandler.getMembersGameID(gameID);
        FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
        if (config.getBoolean("GearManager.Enabled", false)) {
            for (Player player : playersInGame) {
                GearManager.GiveHelmet(player, config);
                GearManager.GiveChestplate(player, config);
                GearManager.GiveLeggings(player, config);
                GearManager.GiveBoots(player, config);
                GearManager.GiveWoodenSword(player, config);
            }
        }
    }

    private static void GiveWoodenSword(Player player, FileConfiguration config) {
        ItemStack sword = new ItemStack(Material.WOODEN_SWORD);
        ItemMeta meta = sword.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(MSG.chatColors("&eWooden Sword"));
            meta.setUnbreakable(true);
            sword.setItemMeta(meta);
            sword.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 4);
        }
        player.getInventory().addItem(new ItemStack[]{sword});
    }

    private static void GiveHelmet(Player player, FileConfiguration config) {
        ItemStack helmet;
        ConfigurationSection section = config.getConfigurationSection("GearManager.GearTypes.HEAD");
        if (section != null && section.contains("Item") && (helmet = GearManager.createArmorItem(section)) != null) {
            player.getInventory().setHelmet(helmet);
        }
    }

    private static void GiveChestplate(Player player, FileConfiguration config) {
        ItemStack chestplate;
        ConfigurationSection section = config.getConfigurationSection("GearManager.GearTypes.CHEST");
        if (section != null && section.contains("Item") && (chestplate = GearManager.createArmorItem(section)) != null) {
            player.getInventory().setChestplate(chestplate);
        }
    }

    private static void GiveLeggings(Player player, FileConfiguration config) {
        ItemStack leggings;
        ConfigurationSection section = config.getConfigurationSection("GearManager.GearTypes.LEGS");
        if (section != null && section.contains("Item") && (leggings = GearManager.createArmorItem(section)) != null) {
            player.getInventory().setLeggings(leggings);
        }
    }

    private static void GiveBoots(Player player, FileConfiguration config) {
        ItemStack boots;
        ConfigurationSection section = config.getConfigurationSection("GearManager.GearTypes.FEET");
        if (section != null && section.contains("Item") && (boots = GearManager.createArmorItem(section)) != null) {
            player.getInventory().setBoots(boots);
        }
    }

    private static ItemStack createArmorItem(ConfigurationSection section) {
        try {
            Material material = Material.valueOf((String)section.getString("Item"));
            ItemStack item = new ItemStack(material);
            ItemMeta meta = item.getItemMeta();
            if (section.contains("NAME")) {
                meta.setDisplayName(MSG.chatColors(section.getString("NAME")));
            }
            if (section.contains("Lores")) {
                ArrayList<String> lores = new ArrayList<String>();
                for (String lore : section.getStringList("Lores")) {
                    lores.add(MSG.chatColors(lore));
                }
                meta.setLore(lores);
            }
            item.setItemMeta(meta);
            if (section.contains("Enchants")) {
                for (String enchantString : section.getStringList("Enchants")) {
                    String[] parts = enchantString.split(":");
                    if (parts.length != 2) continue;
                    Enchantment enchantment = Enchantment.getByName((String)parts[0]);
                    int level = Integer.parseInt(parts[1]);
                    if (enchantment == null) continue;
                    item.addUnsafeEnchantment(enchantment, level);
                }
            }
            return item;
        }
        catch (Exception var9) {
            var9.printStackTrace();
            return null;
        }
    }
}

