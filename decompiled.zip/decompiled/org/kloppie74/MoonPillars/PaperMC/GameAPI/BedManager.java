/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.block.Block
 *  org.bukkit.block.data.BlockData
 *  org.bukkit.block.data.type.Bed
 *  org.bukkit.block.data.type.Bed$Part
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.player.PlayerBedEnterEvent
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Bed;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;

public class BedManager
implements Listener {
    public static final Map<Player, BedInfo> playerBeds = new HashMap<Player, BedInfo>();

    @EventHandler
    public void onPlayerEnterBed(PlayerBedEnterEvent event) {
        Player player = event.getPlayer();
        Block bed = event.getBed();
        String gameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
        if (gameID != null && HashMapHandler.getIsGamePlaying(gameID).booleanValue()) {
            boolean bedRespawnEnabled;
            FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
            boolean bl = bedRespawnEnabled = config != null && config.getBoolean("Settings.Bed-Respawn", false);
            if (bedRespawnEnabled) {
                Map.Entry<Player, BedInfo> entry;
                Iterator<Map.Entry<Player, BedInfo>> var7 = playerBeds.entrySet().iterator();
                while (true) {
                    Block headBlock;
                    if (!var7.hasNext()) {
                        if (playerBeds.containsKey(player)) {
                            player.sendMessage(MSG.chatColors("&cYou already own a bed! You cannot own more than one."));
                            event.setCancelled(true);
                            return;
                        }
                        BlockData bedData = bed.getBlockData();
                        if (bedData instanceof Bed) {
                            Bed bedType = (Bed)bedData;
                            if (bedType.getPart() == Bed.Part.FOOT) {
                                bed = headBlock = this.getOtherBedPart(bed, bedType);
                            }
                            BedInfo bedInfo = new BedInfo(bed, true);
                            playerBeds.put(player, bedInfo);
                            player.sendMessage(MSG.chatColors("&aYou have claimed this bed as your respawn point!"));
                            event.setCancelled(true);
                        }
                        return;
                    }
                    entry = var7.next();
                    headBlock = entry.getValue().getBed();
                    BlockData storedBedData = headBlock.getBlockData();
                    if (!(storedBedData instanceof Bed)) continue;
                    Block otherStoredPart = this.getOtherBedPart(headBlock, (Bed)storedBedData);
                    if (bed.equals((Object)headBlock) || bed.equals((Object)otherStoredPart)) break;
                }
                player.sendMessage(MSG.chatColors("&cThis bed is already owned by " + entry.getKey().getName() + "!"));
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onPlayerBreakBed(BlockBreakEvent event) {
        Player breaker = event.getPlayer();
        String gameID = HashMapHandler.getPlayerGameID(breaker.getUniqueId());
        Block brokenBlock = event.getBlock();
        if (gameID != null && HashMapHandler.getIsGamePlaying(gameID).booleanValue()) {
            boolean bedRespawnEnabled;
            FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
            boolean bl = bedRespawnEnabled = config != null && config.getBoolean("Settings.Bed-Respawn", false);
            if (bedRespawnEnabled && brokenBlock.getBlockData() instanceof Bed) {
                Player bedOwner = null;
                for (Map.Entry<Player, BedInfo> entry : playerBeds.entrySet()) {
                    Block ownerBed = entry.getValue().getBed();
                    BlockData ownerBedData = ownerBed.getBlockData();
                    if (!(ownerBedData instanceof Bed)) continue;
                    Block otherPart = this.getOtherBedPart(ownerBed, (Bed)ownerBedData);
                    if (!brokenBlock.equals((Object)ownerBed) && !brokenBlock.equals((Object)otherPart)) continue;
                    bedOwner = entry.getKey();
                    break;
                }
                if (bedOwner != null) {
                    playerBeds.remove(bedOwner);
                    breaker.sendMessage(MSG.chatColors("&cYou broke " + bedOwner.getName() + "'s bed!"));
                    bedOwner.sendMessage(MSG.chatColors("&cYour bed has been destroyed by " + breaker.getName() + "! You will no longer respawn there."));
                }
            }
        }
    }

    private Block getOtherBedPart(Block bedBlock, Bed bedData) {
        Location otherPartLocation = bedBlock.getLocation().clone();
        Bed.Part part = bedData.getPart();
        if (part == Bed.Part.HEAD) {
            switch (bedData.getFacing()) {
                case NORTH: {
                    otherPartLocation.add(0.0, 0.0, 1.0);
                    break;
                }
                case SOUTH: {
                    otherPartLocation.add(0.0, 0.0, -1.0);
                    break;
                }
                case EAST: {
                    otherPartLocation.add(-1.0, 0.0, 0.0);
                    break;
                }
                case WEST: {
                    otherPartLocation.add(1.0, 0.0, 0.0);
                }
            }
        } else {
            switch (bedData.getFacing()) {
                case NORTH: {
                    otherPartLocation.add(0.0, 0.0, -1.0);
                    break;
                }
                case SOUTH: {
                    otherPartLocation.add(0.0, 0.0, 1.0);
                    break;
                }
                case EAST: {
                    otherPartLocation.add(1.0, 0.0, 0.0);
                    break;
                }
                case WEST: {
                    otherPartLocation.add(-1.0, 0.0, 0.0);
                }
            }
        }
        return otherPartLocation.getBlock();
    }

    public Block getPlayerBed(Player player) {
        BedInfo bedInfo = playerBeds.get(player);
        return bedInfo != null ? bedInfo.getBed() : null;
    }

    public static void RemovePlayerBed(Player player) {
        playerBeds.remove(player);
    }

    public static boolean isBedValidForRespawn(Location bedLocation) {
        Block blockAbove1 = bedLocation.clone().add(0.0, 1.0, 0.0).getBlock();
        Block blockAbove2 = bedLocation.clone().add(0.0, 2.0, 0.0).getBlock();
        if (blockAbove1.getType().isAir() && blockAbove2.getType().isAir()) {
            int[] offsets;
            int[] var4 = offsets = new int[]{-1, 0, 1};
            int var5 = offsets.length;
            for (int var6 = 0; var6 < var5; ++var6) {
                int x = var4[var6];
                int[] var8 = offsets;
                int var9 = offsets.length;
                for (int var10 = 0; var10 < var9; ++var10) {
                    int z = var8[var10];
                    if (x == 0 && z == 0) continue;
                    Location checkLoc = bedLocation.clone().add((double)x, 0.0, (double)z);
                    Block ground = checkLoc.getBlock();
                    Block spaceAbove1 = checkLoc.clone().add(0.0, 1.0, 0.0).getBlock();
                    Block spaceAbove2 = checkLoc.clone().add(0.0, 2.0, 0.0).getBlock();
                    if (!ground.getType().isSolid() || !spaceAbove1.getType().isAir() || !spaceAbove2.getType().isAir()) continue;
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public static class BedInfo {
        private final Block bed;
        private final boolean playerOwnsBed;

        public BedInfo(Block bed, boolean playerOwnsBed) {
            this.bed = bed;
            this.playerOwnsBed = playerOwnsBed;
        }

        public Block getBed() {
            return this.bed;
        }

        public boolean isPlayerOwnsBed() {
            return this.playerOwnsBed;
        }
    }
}

