/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldedit.EditSession
 *  com.sk89q.worldedit.WorldEdit
 *  com.sk89q.worldedit.bukkit.BukkitAdapter
 *  com.sk89q.worldedit.extent.Extent
 *  com.sk89q.worldedit.extent.clipboard.Clipboard
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardReader
 *  com.sk89q.worldedit.function.operation.Operation
 *  com.sk89q.worldedit.function.operation.Operations
 *  com.sk89q.worldedit.math.transform.AffineTransform
 *  com.sk89q.worldedit.math.transform.Transform
 *  com.sk89q.worldedit.session.ClipboardHolder
 *  com.sk89q.worldedit.world.World
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.Extent;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.transform.AffineTransform;
import com.sk89q.worldedit.math.transform.Transform;
import com.sk89q.worldedit.session.ClipboardHolder;
import com.sk89q.worldedit.world.World;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler.CosmeticHandler;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class SchematicHandler {
    private static final Map<UUID, Location> pillarLocations = new HashMap<UUID, Location>();

    public static void setPillarLocation(Player player, Location location) {
        if (player != null && location != null) {
            pillarLocations.put(player.getUniqueId(), location.clone());
        }
    }

    public static void removePillarLocation(Player player) {
        if (player != null) {
            pillarLocations.remove(player.getUniqueId());
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void PlaceCage(Player player, int rotation) {
        FileInputStream fis = null;
        EditSession editSession = null;
        try {
            FileConfiguration config = SettingsManager.getInstance().getCosmetics();
            FileConfiguration settings = SettingsManager.getInstance().getSettings();
            String lobbyWorld = settings.getString("LobbySettings.World");
            if (lobbyWorld == null || !player.getWorld().getName().equalsIgnoreCase(lobbyWorld)) {
                Clipboard clipboard;
                String particleID = CosmeticHandler.getInstance().getSelectedCosmetic(player.getUniqueId(), "Cage_Particle");
                String cageFileName = null;
                if (particleID != null && !particleID.isEmpty()) {
                    String id = particleID.replace("Cages_", "");
                    cageFileName = config.getString("Settings.Cages." + id + ".Cage");
                    if (cageFileName == null) {
                        cageFileName = config.getString("Settings.Default-Settings.Cages");
                    }
                } else {
                    cageFileName = config.getString("Settings.Default-Settings.Cages");
                }
                if (cageFileName == null) {
                    Bukkit.getLogger().warning("Cage file name could not be determined for player: " + player.getName());
                    return;
                }
                File file = new File(MoonLab.getInstance().getDataFolder(), "Cages/" + cageFileName);
                if (!file.exists()) {
                    Bukkit.getLogger().warning("Cage file not found: " + cageFileName);
                    return;
                }
                ClipboardFormat format = ClipboardFormats.findByFile((File)file);
                if (format == null) {
                    Bukkit.getLogger().warning("Unknown schematic format for file: " + file.getName());
                    return;
                }
                fis = new FileInputStream(file);
                try (ClipboardReader reader = format.getReader((InputStream)fis);){
                    clipboard = reader.read();
                }
                fis.close();
                fis = null;
                if (clipboard == null) {
                    Bukkit.getLogger().warning("Failed to load cage schematic: " + cageFileName);
                    return;
                }
                Location pasteLocation = player.getLocation();
                World adaptedWorld = BukkitAdapter.adapt((org.bukkit.World)player.getWorld());
                editSession = WorldEdit.getInstance().newEditSession(adaptedWorld);
                ClipboardHolder holder = new ClipboardHolder(clipboard);
                if (rotation % 360 != 0) {
                    AffineTransform transform = new AffineTransform().rotateY((double)rotation);
                    holder.setTransform(holder.getTransform().combine((Transform)transform));
                }
                Operation operation = holder.createPaste((Extent)editSession).to(BukkitAdapter.asBlockVector((Location)pasteLocation)).ignoreAirBlocks(false).build();
                Operations.complete((Operation)operation);
                clipboard = null;
                return;
            }
            Bukkit.getLogger().warning("Attempted to place cage in lobby world for player: " + player.getName());
        }
        catch (Exception var33) {
            Logger var10000 = Bukkit.getLogger();
            String var10001 = player.getName();
            var10000.severe("Error in PlaceCage for " + var10001 + ": " + var33.getMessage());
            var33.printStackTrace();
            return;
        }
        finally {
            if (editSession != null) {
                editSession.close();
            }
            if (fis != null) {
                try {
                    fis.close();
                }
                catch (IOException var30) {
                    Bukkit.getLogger().warning("Failed to close FileInputStream: " + var30.getMessage());
                }
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void PlacePillar(Player player, int rotation) {
        FileInputStream fis = null;
        EditSession editSession = null;
        try {
            FileConfiguration config = SettingsManager.getInstance().getCosmetics();
            FileConfiguration settings = SettingsManager.getInstance().getSettings();
            String lobbyWorld = settings.getString("LobbySettings.World");
            Location pasteLocation = pillarLocations.getOrDefault(player.getUniqueId(), player.getLocation());
            if (lobbyWorld != null && pasteLocation.getWorld().getName().equalsIgnoreCase(lobbyWorld)) {
                Bukkit.getLogger().warning("Attempted to place pillar in lobby world for player: " + player.getName());
                return;
            }
            String particleID = CosmeticHandler.getInstance().getSelectedCosmetic(player.getUniqueId(), "Pillar_Particle");
            String pillarFileName = null;
            if (particleID != null && !particleID.isEmpty()) {
                String id = particleID.replace("Pillar_", "");
                pillarFileName = config.getString("Settings.Pillars." + id + ".Pillar");
                if (pillarFileName == null) {
                    pillarFileName = config.getString("Settings.Default-Settings.Pillar");
                }
            } else {
                pillarFileName = config.getString("Settings.Default-Settings.Pillar");
            }
            if (pillarFileName == null) {
                Bukkit.getLogger().warning("Pillar file name could not be determined for player: " + player.getName());
                return;
            }
            File file = new File(MoonLab.getInstance().getDataFolder(), "Pillars/" + pillarFileName);
            if (file.exists()) {
                Clipboard clipboard;
                ClipboardFormat format = ClipboardFormats.findByFile((File)file);
                if (format == null) {
                    Bukkit.getLogger().warning("Unknown schematic format for file: " + file.getName());
                    return;
                }
                fis = new FileInputStream(file);
                try (ClipboardReader reader = format.getReader((InputStream)fis);){
                    clipboard = reader.read();
                }
                fis.close();
                fis = null;
                if (clipboard == null) {
                    Bukkit.getLogger().warning("Failed to load pillar schematic: " + pillarFileName);
                    return;
                }
                World adaptedWorld = BukkitAdapter.adapt((org.bukkit.World)pasteLocation.getWorld());
                editSession = WorldEdit.getInstance().newEditSession(adaptedWorld);
                ClipboardHolder holder = new ClipboardHolder(clipboard);
                if (rotation % 360 != 0) {
                    AffineTransform transform = new AffineTransform().rotateY((double)rotation);
                    holder.setTransform(holder.getTransform().combine((Transform)transform));
                }
                Operation operation = holder.createPaste((Extent)editSession).to(BukkitAdapter.asBlockVector((Location)pasteLocation)).ignoreAirBlocks(false).build();
                Operations.complete((Operation)operation);
                clipboard = null;
                return;
            }
            Bukkit.getLogger().warning("Pillar file not found: " + pillarFileName);
        }
        catch (Exception var33) {
            Logger var10000 = Bukkit.getLogger();
            String var10001 = player.getName();
            var10000.severe("Error in PlacePillar for " + var10001 + ": " + var33.getMessage());
            var33.printStackTrace();
            return;
        }
        finally {
            if (editSession != null) {
                editSession.close();
            }
            if (fis != null) {
                try {
                    fis.close();
                }
                catch (IOException var30) {
                    Bukkit.getLogger().warning("Failed to close FileInputStream: " + var30.getMessage());
                }
            }
        }
    }
}

