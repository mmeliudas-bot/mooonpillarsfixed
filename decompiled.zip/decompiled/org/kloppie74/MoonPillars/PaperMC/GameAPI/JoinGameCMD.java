/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Listener
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.JoinGameHandler;

public class JoinGameCMD
implements CommandExecutor,
TabCompleter,
Listener {
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (args.length == 1) {
            completions.add("random");
            for (String gameKey : HashMapHandler.getAllMapGameIDs()) {
                String gameName;
                if (!gameKey.startsWith("Mini-") || !gameKey.contains("-") || completions.contains(gameName = gameKey.substring(5, gameKey.lastIndexOf(45)))) continue;
                completions.add(gameName);
            }
        }
        return completions;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player player = (Player)sender;
        String gameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
        if (gameID != null) {
            MessageSender.SendMessage(player, "Games.Player-Is-In-Game", "", "");
            return true;
        }
        if (args.length >= 1) {
            for (String gameKey : HashMapHandler.getAllMapGameIDs()) {
                if (!gameKey.startsWith("Mini-") || !gameKey.contains("-")) continue;
                String gameName = gameKey.substring(5, gameKey.lastIndexOf(45));
                if (gameName != null) {
                    if (args[0].equalsIgnoreCase("random")) {
                        JoinGameHandler.joinRandomGame(player);
                        return true;
                    }
                    if (!player.hasPermission("mpa.joingame.*") && !player.hasPermission("mpa.joingame." + gameName)) {
                        MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
                        return true;
                    }
                    if (!args[0].equalsIgnoreCase(gameName)) continue;
                    JoinGameHandler.joinGame(player, gameName);
                    return true;
                }
                MessageSender.SendMessage(player, "Games.Game-Failed", "", "");
            }
        }
        return true;
    }
}

