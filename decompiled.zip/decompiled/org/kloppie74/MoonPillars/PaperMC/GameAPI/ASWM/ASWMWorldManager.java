/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.infernalsuite.asp.api.AdvancedSlimePaperAPI
 *  com.infernalsuite.asp.api.loaders.SlimeLoader
 *  com.infernalsuite.asp.api.world.SlimeWorld
 *  com.infernalsuite.asp.api.world.SlimeWorldInstance
 *  org.bukkit.Bukkit
 *  org.bukkit.World
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI.ASWM;

import com.infernalsuite.asp.api.AdvancedSlimePaperAPI;
import com.infernalsuite.asp.api.loaders.SlimeLoader;
import com.infernalsuite.asp.api.world.SlimeWorld;
import com.infernalsuite.asp.api.world.SlimeWorldInstance;
import com.infernalsuite.asp.loaders.file.FileLoader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameUtils;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class ASWMWorldManager {
    private static final SlimeLoader loader = new FileLoader(new File("slime_worlds"));

    private static void ensureSlimeDirExists(String bukkitWorldName) {
        File dir;
        if (bukkitWorldName.contains("/") && !(dir = new File("slime_worlds", bukkitWorldName.substring(0, bukkitWorldName.lastIndexOf(47)))).exists()) {
            dir.mkdirs();
        }
    }

    public static void loadWorldAsync(File zipFile, String worldName, FileConfiguration config, String gameFilePath) {
        Bukkit.getScheduler().runTaskAsynchronously((Plugin)MoonLab.getInstance(), () -> {
            String bukkitWorldName = "Areas/" + worldName;
            File targetDir = new File(bukkitWorldName);
            try {
                ASWMWorldManager.ensureSlimeDirExists(bukkitWorldName);
                File slimeFile = new File("slime_worlds", bukkitWorldName + ".slime");
                if (slimeFile.exists()) {
                    if (slimeFile.delete()) {
                        Bukkit.getConsoleSender().sendMessage("\u00a7a[ASWM] Deleted existing slime file: " + slimeFile.getName());
                    } else {
                        Bukkit.getLogger().warning("[ASWM] Failed to delete slime file: " + slimeFile.getName());
                    }
                }
                if (targetDir.exists()) {
                    ASWMWorldManager.deleteDirectory(targetDir);
                }
                targetDir.mkdirs();
                try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile));){
                    ZipEntry entry;
                    while ((entry = zis.getNextEntry()) != null) {
                        File newFile = new File(targetDir, entry.getName());
                        if (entry.isDirectory()) {
                            newFile.mkdirs();
                            continue;
                        }
                        newFile.getParentFile().mkdirs();
                        Files.copy(zis, newFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                    }
                }
                AdvancedSlimePaperAPI asp = AdvancedSlimePaperAPI.instance();
                SlimeWorld slimeWorld = asp.readVanillaWorld(targetDir, bukkitWorldName, loader);
                Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> {
                    try {
                        SlimeWorldInstance worldInstance = asp.loadWorld(slimeWorld, true);
                        World bukkitWorld = worldInstance.getBukkitWorld();
                        if (bukkitWorld == null) {
                            Bukkit.getLogger().warning("[ASWM] Bukkit world is null for: " + bukkitWorldName);
                            return;
                        }
                        HashMapHandler.setMapGameID(worldName, gameFilePath);
                        HashMapHandler.setConfigGameID(worldName, config);
                        GameUtils.loadOriginalWorld(worldName, bukkitWorld);
                        Bukkit.getConsoleSender().sendMessage("\u00a7a[ASWM] Loaded world: " + bukkitWorldName);
                    }
                    catch (Exception var8) {
                        Bukkit.getLogger().warning("[ASWM] Failed to load world: " + bukkitWorldName + " - " + var8.getMessage());
                    }
                });
            }
            catch (Exception var12) {
                Bukkit.getLogger().warning("[ASWM] Failed to load world: " + bukkitWorldName + " - " + var12.getMessage());
            }
        });
    }

    private static void deleteDirectory(File dir) throws IOException {
        File[] entries;
        if (dir.isDirectory() && (entries = dir.listFiles()) != null) {
            File[] var2 = entries;
            int var3 = entries.length;
            for (int var4 = 0; var4 < var3; ++var4) {
                File entry = var2[var4];
                ASWMWorldManager.deleteDirectory(entry);
            }
        }
        if (!dir.delete()) {
            throw new IOException("Failed to delete " + String.valueOf(dir));
        }
    }

    public static void unloadAndDeleteWorld(String worldName) {
        String bukkitWorldName = "Areas/" + worldName;
        ASWMWorldManager.ensureSlimeDirExists(bukkitWorldName);
        Runnable unloadTask = () -> {
            try {
                File slimeFile;
                World world = Bukkit.getWorld((String)bukkitWorldName);
                if (world != null) {
                    Bukkit.unloadWorld((World)world, (boolean)true);
                }
                if ((slimeFile = new File("slime_worlds", bukkitWorldName + ".slime")).exists()) {
                    if (slimeFile.delete()) {
                        Bukkit.getConsoleSender().sendMessage("\u00a7a[ASWM] Deleted existing slime file: " + slimeFile.getName());
                    } else {
                        Bukkit.getLogger().warning("[ASWM] Failed to delete slime file: " + slimeFile.getName());
                    }
                }
                Bukkit.getConsoleSender().sendMessage("\u00a7a[ASWM] Unloaded world: " + bukkitWorldName);
            }
            catch (Exception var3) {
                Bukkit.getLogger().warning("[ASWM] Failed to unload world: " + bukkitWorldName + " - " + var3.getMessage());
            }
        };
        if (!MoonLab.getInstance().isEnabled()) {
            unloadTask.run();
        } else {
            Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), unloadTask);
        }
    }

    public static String createExtraGameMapASWM(String gameID, String fullGameID, File zipFile, FileConfiguration config) {
        String bukkitWorldName = "Areas/" + fullGameID;
        ASWMWorldManager.ensureSlimeDirExists(bukkitWorldName);
        try {
            AdvancedSlimePaperAPI asp = AdvancedSlimePaperAPI.instance();
            SlimeWorld slimeWorld = asp.readVanillaWorld(zipFile.getParentFile(), bukkitWorldName, loader);
            asp.loadWorld(slimeWorld, true);
            Bukkit.getConsoleSender().sendMessage("\u00a7a[ASWM] Extra game map created: " + bukkitWorldName);
            return bukkitWorldName;
        }
        catch (Exception var8) {
            Bukkit.getLogger().warning("[ASWM] Failed to create extra game map: " + bukkitWorldName + " - " + var8.getMessage());
            return null;
        }
    }
}

