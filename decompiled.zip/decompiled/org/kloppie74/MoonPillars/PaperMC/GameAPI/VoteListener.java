/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;

public class VoteListener
implements Listener {
    private static final Map<String, Map<String, Integer>> votes = new HashMap<String, Map<String, Integer>>();
    private static final Map<String, Set<UUID>> voters = new HashMap<String, Set<UUID>>();
    private static final Map<String, Map<UUID, String>> votesTracker = new HashMap<String, Map<UUID, String>>();

    public static void OpenInv(Player player) {
        String GameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
        if (GameID == null) {
            MessageSender.SendMessage(player, "Games.Player-Not-In-Game", "", "");
        } else {
            FileConfiguration config = HashMapHandler.getConfigGameID(GameID);
            if (config == null || !HashMapHandler.getIsGamePlaying(GameID).booleanValue()) {
                boolean isSynchronizationEnabled;
                boolean isFloorIsLavaEnabled = config.contains("Events.Voting.Floor-Is-Lava.Enabled") ? config.getBoolean("Events.Voting.Floor-Is-Lava.Enabled") : true;
                boolean isElytraModeEnabled = config.contains("Events.Voting.Elytra-Mode.Enabled") ? config.getBoolean("Events.Voting.Elytra-Mode.Enabled") : true;
                boolean isNoFallModeEnabled = config.contains("Events.Voting.No-Fall-Mode.Enabled") ? config.getBoolean("Events.Voting.No-Fall-Mode.Enabled") : true;
                boolean is1HeartModeEnabled = config.contains("Events.Voting.1-Heart-Mode.Enabled") ? config.getBoolean("Events.Voting.1-Heart-Mode.Enabled") : true;
                boolean isDoubleHPEnabled = config.contains("Events.Voting.Double-HP.Enabled") ? config.getBoolean("Events.Voting.Double-HP.Enabled") : true;
                boolean isPlayerSwapEnabled = config.contains("Events.Voting.Player-Swap.Enabled") ? config.getBoolean("Events.Voting.Player-Swap.Enabled") : true;
                boolean isInventorySwapEnabled = config.contains("Events.Voting.Inventory-Swap.Enabled") ? config.getBoolean("Events.Voting.Inventory-Swap.Enabled") : true;
                boolean isApocalypseEnabled = config.contains("Events.Voting.Apocalypse.Enabled") ? config.getBoolean("Events.Voting.Apocalypse.Enabled") : true;
                boolean bl = isSynchronizationEnabled = config.contains("Events.Voting.Synchronization.Enabled") ? config.getBoolean("Events.Voting.Synchronization.Enabled") : true;
                if (!(isFloorIsLavaEnabled || isElytraModeEnabled || isNoFallModeEnabled || is1HeartModeEnabled || isDoubleHPEnabled || isPlayerSwapEnabled || isInventorySwapEnabled || isApocalypseEnabled || isSynchronizationEnabled)) {
                    MessageSender.SendMessage(player, "Votes.Disabled", "", "");
                } else {
                    player.openInventory(VoteListener.VoteInv(player, GameID));
                }
            }
        }
    }

    public static Inventory VoteInv(Player player, String GameID) {
        String DisplayName = SettingsManager.getInstance().getLang().getString("Events.Voting.Menu.Title");
        Inventory votingGui = Bukkit.createInventory((InventoryHolder)player, (int)36, (String)MSG.chatColors(DisplayName));
        ItemStack fillItem = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fillMeta = fillItem.getItemMeta();
        if (fillMeta != null) {
            fillMeta.setDisplayName(" ");
            fillItem.setItemMeta(fillMeta);
        }
        for (int i = 0; i < votingGui.getSize(); ++i) {
            votingGui.setItem(i, fillItem);
        }
        FileConfiguration config = HashMapHandler.getConfigGameID(GameID);
        if (!config.contains("Events.Voting.Elytra-Mode.Enabled") || config.getBoolean("Events.Voting.Elytra-Mode.Enabled")) {
            votingGui.setItem(10, VoteListener.GetElytraMode(player, GameID));
        }
        if (!config.contains("Events.Voting.No-Fall-Mode.Enabled") || config.getBoolean("Events.Voting.No-Fall-Mode.Enabled")) {
            votingGui.setItem(12, VoteListener.GetNoFallMode(player, GameID));
        }
        if (!config.contains("Events.Voting.1-Heart-Mode.Enabled") || config.getBoolean("Events.Voting.1-Heart-Mode.Enabled")) {
            votingGui.setItem(14, VoteListener.Get1HeartMode(player, GameID));
        }
        if (!config.contains("Events.Voting.Double-HP.Enabled") || config.getBoolean("Events.Voting.Double-HP.Enabled")) {
            votingGui.setItem(16, VoteListener.GetDoubleHPMode(player, GameID));
        }
        if (!config.contains("Events.Voting.Player-Swap.Enabled") || config.getBoolean("Events.Voting.Player-Swap.Enabled")) {
            votingGui.setItem(19, VoteListener.GetPlayerSwapMode(player, GameID));
        }
        if (!config.contains("Events.Voting.Inventory-Swap.Enabled") || config.getBoolean("Events.Voting.Inventory-Swap.Enabled")) {
            votingGui.setItem(21, VoteListener.GetInventorySwapMode(player, GameID));
        }
        if (!config.contains("Events.Voting.Floor-Is-Lava.Enabled") || config.getBoolean("Events.Voting.Floor-Is-Lava.Enabled")) {
            votingGui.setItem(23, VoteListener.GetFloorIsLava(player, GameID));
        }
        if (!config.contains("Events.Voting.Faster-Items.Enabled") || config.getBoolean("Events.Voting.Faster-Items.Enabled")) {
            votingGui.setItem(25, VoteListener.GetFasterItemsMode(player, GameID));
        }
        if (!config.contains("Events.Voting.Apocalypse.Enabled") || config.getBoolean("Events.Voting.Apocalypse.Enabled")) {
            votingGui.setItem(30, VoteListener.GetApocalypseMode(player, GameID));
        }
        if (!config.contains("Events.Voting.Synchronization.Enabled") || config.getBoolean("Events.Voting.Synchronization.Enabled")) {
            votingGui.setItem(32, VoteListener.GetSynchronizationMode(player, GameID));
        }
        return votingGui;
    }

    public static ItemStack GetFloorIsLava(Player player, String GameID) {
        return VoteListener.getVoteItem(player, GameID, "Floor is Lava", Material.LAVA_BUCKET, "FloorisLava");
    }

    public static ItemStack GetElytraMode(Player player, String GameID) {
        return VoteListener.getVoteItem(player, GameID, "Elytra Mode", Material.ELYTRA, "ElytraMode");
    }

    public static ItemStack GetNoFallMode(Player player, String GameID) {
        return VoteListener.getVoteItem(player, GameID, "NoFall Mode", Material.FEATHER, "NoFallMode");
    }

    public static ItemStack Get1HeartMode(Player player, String GameID) {
        return VoteListener.getVoteItem(player, GameID, "1 Heart Mode", Material.APPLE, "1HeartMode");
    }

    public static ItemStack GetDoubleHPMode(Player player, String GameID) {
        return VoteListener.getVoteItem(player, GameID, "Double HP", Material.GOLDEN_APPLE, "DoubleHP");
    }

    public static ItemStack GetPlayerSwapMode(Player player, String GameID) {
        return VoteListener.getVoteItem(player, GameID, "Player Swap", Material.ENDER_PEARL, "PlayerSwap");
    }

    public static ItemStack GetInventorySwapMode(Player player, String GameID) {
        return VoteListener.getVoteItem(player, GameID, "Inventory Swap", Material.CHEST, "InventorySwap");
    }

    public static ItemStack GetFasterItemsMode(Player player, String GameID) {
        return VoteListener.getVoteItem(player, GameID, "2x Faster Items", Material.CLOCK, "FasterItems");
    }

    public static ItemStack GetApocalypseMode(Player player, String GameID) {
        return VoteListener.getVoteItem(player, GameID, "Apocalypse", Material.TNT, "Apocalypse");
    }

    public static ItemStack GetSynchronizationMode(Player player, String GameID) {
        return VoteListener.getVoteItem(player, GameID, "Synchronization", Material.NETHER_STAR, "Synchronization");
    }

    private static ItemStack getVoteItem(Player player, String GameID, String mode, Material material, String langKey) {
        String clickToVote;
        ItemStack itemStack = new ItemStack(material);
        ItemMeta itemMeta = itemStack.getItemMeta();
        Object displayName = SettingsManager.getInstance().getLang().getString("Events.Voting.Menu." + langKey + ".Name");
        if (displayName == null) {
            displayName = "&e&lVote for " + mode;
        }
        itemMeta.setDisplayName(MSG.chatColors((String)displayName));
        int currentVotes = ((Map)votes.getOrDefault(GameID, new HashMap())).getOrDefault(mode, 0);
        ArrayList<String> lores = new ArrayList<String>();
        String votesLore = SettingsManager.getInstance().getLang().getString("Events.Voting.Menu.Votes");
        if (votesLore == null) {
            votesLore = "&7Current votes: &e{votes}";
        }
        lores.add(MSG.chatColors(votesLore.replace("{votes}", String.valueOf(currentVotes))));
        List desc = SettingsManager.getInstance().getLang().getStringList("Events.Voting.Menu." + langKey + ".Lore");
        if (desc != null && !desc.isEmpty()) {
            for (String line : desc) {
                lores.add(MSG.chatColors(line));
            }
        }
        if ((clickToVote = SettingsManager.getInstance().getLang().getString("Events.Voting.Menu.ClickToVote")) == null) {
            clickToVote = "&eClick to vote!";
        }
        lores.add(MSG.chatColors(clickToVote));
        itemMeta.setLore(lores);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Player player = (Player)event.getWhoClicked();
        String GameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
        String DisplayName = SettingsManager.getInstance().getLang().getString("Events.Voting.Menu.Title");
        if (event.getView().getTitle().equalsIgnoreCase(MSG.chatColors(DisplayName))) {
            event.setCancelled(true);
            if (GameID == null) {
                return;
            }
            if (HashMapHandler.getIsGamePlaying(GameID).booleanValue()) {
                return;
            }
            voters.putIfAbsent(GameID, new HashSet());
            if (voters.get(GameID).contains(player.getUniqueId())) {
                MessageSender.SendMessage(player, "Votes.Player-Has-Voted", "", "");
                event.setCancelled(true);
                return;
            }
            ItemStack clicked = event.getCurrentItem();
            if (clicked != null && clicked.getType() != Material.AIR && clicked.getType() != Material.GRAY_STAINED_GLASS_PANE) {
                event.setCancelled(true);
                String mode = null;
                String permission = null;
                if (clicked.getType() == Material.LAVA_BUCKET) {
                    mode = "Floor is Lava";
                    permission = "mpa.vote.floorislava";
                } else if (clicked.getType() == Material.ELYTRA) {
                    mode = "Elytra Mode";
                    permission = "mpa.vote.elytra";
                } else if (clicked.getType() == Material.FEATHER) {
                    mode = "NoFall Mode";
                    permission = "mpa.vote.nofall";
                } else if (clicked.getType() == Material.APPLE) {
                    mode = "1 Heart Mode";
                    permission = "mpa.vote.oneheart";
                } else if (clicked.getType() == Material.GOLDEN_APPLE) {
                    mode = "Double HP";
                    permission = "mpa.vote.doublehp";
                } else if (clicked.getType() == Material.ENDER_PEARL) {
                    mode = "Player Swap";
                    permission = "mpa.vote.playerswap";
                } else if (clicked.getType() == Material.CHEST) {
                    mode = "Inventory Swap";
                    permission = "mpa.vote.inventoryswap";
                } else if (clicked.getType() == Material.CLOCK) {
                    mode = "2x Faster Items";
                    permission = "mpa.vote.fasteritems";
                } else if (clicked.getType() == Material.TNT) {
                    mode = "Apocalypse";
                    permission = "mpa.vote.apocalypse";
                } else if (clicked.getType() == Material.NETHER_STAR) {
                    mode = "Synchronization";
                    permission = "mpa.vote.synchronization";
                }
                if (mode != null) {
                    if (permission != null && !player.hasPermission(permission)) {
                        MessageSender.SendMessage(player, "Votes.No-Perms", "", "");
                        event.setCancelled(true);
                        return;
                    }
                    votes.putIfAbsent(GameID, new HashMap());
                    Map<String, Integer> gameVotes = votes.get(GameID);
                    gameVotes.put(mode, gameVotes.getOrDefault(mode, 0) + 1);
                    votesTracker.putIfAbsent(GameID, new HashMap());
                    votesTracker.get(GameID).put(player.getUniqueId(), mode);
                    voters.get(GameID).add(player.getUniqueId());
                    int currentVotes = ((Map)votes.getOrDefault(GameID, new HashMap())).getOrDefault(mode, 0);
                    String votedMsg = SettingsManager.getInstance().getLang().getString("Events.Voting.Menu.Voted");
                    if (votedMsg == null) {
                        votedMsg = "&a&lYou've voted for &e{mode} &a&l(&e{votes} votes&a&l)";
                    }
                    player.sendMessage(MSG.chatColors(votedMsg.replace("{mode}", mode).replace("{votes}", String.valueOf(currentVotes))));
                    player.closeInventory();
                }
            }
        }
    }

    public static String GetMostVoted(String GameID) {
        Map<String, Integer> gameVotes = votes.get(GameID);
        return gameVotes != null && !gameVotes.isEmpty() ? (String)gameVotes.entrySet().stream().max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse(null) : null;
    }

    public static void clearVotes(String GameID) {
        votes.remove(GameID);
        voters.remove(GameID);
    }

    public static int getTotalVotes(String GameID) {
        Map<String, Integer> gameVotes = votes.get(GameID);
        return gameVotes == null ? 0 : gameVotes.values().stream().mapToInt(Integer::intValue).sum();
    }

    public static List<String> getVotersForMode(String gameID, String mode) {
        ArrayList<String> votersNames = new ArrayList<String>();
        if (!voters.containsKey(gameID)) {
            return votersNames;
        }
        Set<UUID> gameVoters = voters.get(gameID);
        for (UUID voterUUID : gameVoters) {
            Player voter = Bukkit.getPlayer((UUID)voterUUID);
            String playerVote = VoteListener.getPlayerVote(gameID, voterUUID);
            if (!mode.equals(playerVote)) continue;
            if (voter != null) {
                votersNames.add(voter.getName());
                continue;
            }
            String playerName = Bukkit.getOfflinePlayer((UUID)voterUUID).getName();
            if (playerName == null) continue;
            votersNames.add(playerName);
        }
        return votersNames;
    }

    private static String getPlayerVote(String gameID, UUID playerUUID) {
        Map playerVotes = votesTracker.getOrDefault(gameID, new HashMap());
        return (String)playerVotes.get(playerUUID);
    }
}

