/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI;

import java.util.List;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.ClearArea;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.GameManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.TeamManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class ForceStart {
    public static void ForceStart(Player player, final String GameID) {
        if (GameID != null) {
            FileConfiguration config = HashMapHandler.getConfigGameID(GameID);
            List<Player> playersInGame = HashMapHandler.getMembersGameID(GameID);
            int currentPlayers = playersInGame.size();
            int requiredPlayers = config.getInt("SpawnLocations.MinimumPlayers");
            boolean hasBypass = player.hasPermission("mpa.forcestart.bypass");
            if (currentPlayers < requiredPlayers && !hasBypass) {
                MessageSender.SendMessage(player, "Games.Not-Enough-Players", "", "");
            } else {
                if (HashMapHandler.getActiveTimer(GameID) != null) {
                    HashMapHandler.getActiveTimer(GameID).cancel();
                }
                TeamManager.teleportPlayersToCages(GameID, config);
                ClearArea.clearSpawnArea(GameID);
                HashMapHandler.setIsGamePlaying(GameID, true);
                int countdown = 3;
                BukkitRunnable countdownTask = new BukkitRunnable(){
                    int timer = 3;

                    public void run() {
                        if (this.timer > 0) {
                            List<Player> playersInGame = HashMapHandler.getMembersGameID(GameID);
                            for (Player player : playersInGame) {
                                String timeMessage = MoonLab.formatTime(this.timer);
                                MessageSender.SendMessage(player, "Games.Starting-Game", "{time}", timeMessage);
                            }
                            --this.timer;
                        } else {
                            GameManager.startGame(GameID);
                            this.cancel();
                        }
                    }
                };
                countdownTask.runTaskTimer((Plugin)MoonLab.getInstance(), 0L, 20L);
            }
        } else {
            MessageSender.SendMessage(player, "Games.Player-Not-In-Game", "", "");
        }
    }
}

