/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.World
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.OnGameEndEvent;
import org.kloppie74.MoonPillars.PaperMC.Cosmetics.Events.ParticleEventWins;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler.CosmeticHandler;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.TeamManager;
import org.kloppie74.MoonPillars.PaperMC.UltimateGuis.MenuManager;

public class Rewards {
    public static void StartGameRewards(String GameID) {
        FileConfiguration config = HashMapHandler.getConfigGameID(GameID);
        World world = Bukkit.getWorld((String)("Areas/" + GameID));
        List<Player> members = HashMapHandler.getMembersGameID(GameID);
        if (config != null && world != null && members != null && config.getBoolean("Rewards.OnStartGameRewards.Enabled")) {
            List rewards = config.getStringList("Rewards.OnStartGameRewards.Rewards");
            for (Player player : members) {
                MenuManager.executeCommands(player, rewards);
            }
        }
    }

    public static void OnKillRewards(String GameID, Player Killer, Player Death) {
        FileConfiguration config = HashMapHandler.getConfigGameID(GameID);
        World world = Bukkit.getWorld((String)("Areas/" + GameID));
        List<Player> members = HashMapHandler.getMembersGameID(GameID);
        if (config != null && world != null && members != null && config.getBoolean("Rewards.OnKillRewards.Enabled")) {
            if (Killer == null) {
                Rewards.handleNotKilledByPlayerRewards(config, members, Death);
            } else {
                Rewards.handleKilledByPlayerRewards(config, members, Killer, Death);
            }
        }
    }

    private static void handleNotKilledByPlayerRewards(FileConfiguration config, List<Player> members, Player Death) {
        List<String> remainingPlayers;
        if (config.getBoolean("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Rewards.Killed-Player.Enabled")) {
            remainingPlayers = config.getStringList("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Rewards.Killed-Player.Rewards").stream().map(reward -> reward.replace("${death}", Death.getName())).collect(Collectors.toList());
            MenuManager.executeCommands(Death, remainingPlayers);
        }
        if (config.getBoolean("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Rewards.Remaining-Players.Enabled")) {
            remainingPlayers = members.stream().filter(playerx -> !playerx.getUniqueId().equals(Death.getUniqueId())).collect(Collectors.toList());
            List<String> rewards = config.getStringList("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Rewards.Remaining-Players.Rewards").stream().map(reward -> reward.replace("${death}", Death.getName())).collect(Collectors.toList());
            for (Player player : remainingPlayers) {
                MenuManager.executeCommands(player, rewards);
            }
        }
    }

    private static void handleKilledByPlayerRewards(FileConfiguration config, List<Player> members, Player Killer, Player Death) {
        if (Killer.equals((Object)Death)) {
            Rewards.handleNotKilledByPlayerRewards(config, members, Death);
        } else {
            ArrayList<String> rewards;
            String message;
            String killMessageParticle = CosmeticHandler.getInstance().getSelectedCosmetic(Killer.getUniqueId(), "Kill_Message_Particle");
            String customKillMessage = killMessageParticle != null ? ((message = SettingsManager.getInstance().getCosmetics().getString("Settings.Particles.KillMessage." + killMessageParticle + ".Message")) != null ? message.replace("${killer}", Killer.getName()).replace("${death}", Death.getName()) : null) : null;
            if (config.getBoolean("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killed-Player.Enabled")) {
                rewards = new ArrayList<String>();
                if (customKillMessage != null) {
                    rewards.add("[MESSAGE:PLAYER] " + customKillMessage);
                    for (String reward : config.getStringList("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killed-Player.Rewards")) {
                        if (reward.contains("[MESSAGE:PLAYER]")) continue;
                        rewards.add(reward.replace("${death}", Death.getName()).replace("${killer}", Killer.getName()));
                    }
                } else {
                    rewards.addAll(config.getStringList("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killed-Player.Rewards").stream().map(rewardx -> rewardx.replace("${death}", Death.getName()).replace("${killer}", Killer.getName())).collect(Collectors.toList()));
                }
                MenuManager.executeCommands(Death, rewards);
                UUID uuid = Killer.getUniqueId();
                DatabaseManager db = DatabaseManager.getInstance();
                int currentWins = Rewards.parseOrDefault(db.getSetting(uuid, "Kills"), 0);
                db.updateSetting(uuid, "Kills", currentWins + 1);
            }
            if (!Killer.equals((Object)Death) && config.getBoolean("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killer.Enabled")) {
                rewards = new ArrayList();
                if (customKillMessage != null) {
                    rewards.add("[MESSAGE:PLAYER] " + customKillMessage);
                    for (String reward : config.getStringList("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killer.Rewards")) {
                        if (reward.contains("[MESSAGE:PLAYER]")) continue;
                        rewards.add(reward.replace("${killer}", Killer.getName()).replace("${death}", Death.getName()));
                    }
                } else {
                    rewards.addAll(config.getStringList("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killer.Rewards").stream().map(rewardx -> rewardx.replace("${killer}", Killer.getName()).replace("${death}", Death.getName())).collect(Collectors.toList()));
                }
                MenuManager.executeCommands(Killer, rewards);
            }
            if (config.getBoolean("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Remaining-Players.Enabled")) {
                List remainingPlayers = members.stream().filter(playerx -> !playerx.getUniqueId().equals(Killer.getUniqueId()) && !playerx.getUniqueId().equals(Death.getUniqueId())).collect(Collectors.toList());
                rewards = new ArrayList();
                if (customKillMessage != null) {
                    rewards.add("[MESSAGE:PLAYER] " + customKillMessage);
                    for (String reward : config.getStringList("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Remaining-Players.Rewards")) {
                        if (reward.contains("[MESSAGE:PLAYER]")) continue;
                        rewards.add(reward.replace("${killer}", Killer.getName()).replace("${death}", Death.getName()));
                    }
                } else {
                    rewards.addAll(config.getStringList("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Remaining-Players.Rewards").stream().map(rewardx -> rewardx.replace("${killer}", Killer.getName()).replace("${death}", Death.getName())).collect(Collectors.toList()));
                }
                for (Player player : remainingPlayers) {
                    MenuManager.executeCommands(player, rewards);
                }
            }
        }
    }

    public static void OnLeaveRewards(String GameID, Player leftPlayer) {
        FileConfiguration config = HashMapHandler.getConfigGameID(GameID);
        World world = Bukkit.getWorld((String)("Areas/" + GameID));
        List<Player> members = HashMapHandler.getMembersGameID(GameID);
        if (config != null && world != null && members != null && config.getBoolean("Rewards.OnLeaveRewards.Enabled")) {
            List<String> remainingPlayers;
            if (config.getBoolean("Rewards.OnLeaveRewards.Rewards.left-Player.Enabled")) {
                remainingPlayers = config.getStringList("Rewards.OnLeaveRewards.Rewards.left-Player.Rewards").stream().map(reward -> reward.replace("${leftplayer}", leftPlayer.getName())).collect(Collectors.toList());
                MenuManager.executeCommands(leftPlayer, remainingPlayers);
            }
            if (config.getBoolean("Rewards.OnLeaveRewards.Rewards.Remaining-Players.Enabled")) {
                remainingPlayers = members.stream().filter(playerx -> !playerx.equals((Object)leftPlayer)).collect(Collectors.toList());
                List<String> rewards = config.getStringList("Rewards.OnLeaveRewards.Rewards.Remaining-Players.Rewards").stream().map(reward -> reward.replace("${leftplayer}", leftPlayer.getName())).collect(Collectors.toList());
                for (Player player : remainingPlayers) {
                    MenuManager.executeCommands(player, rewards);
                }
            }
        }
    }

    public static void OnGameEndRewards(String GameID, String TeamID) {
        FileConfiguration config = HashMapHandler.getConfigGameID(GameID);
        World world = Bukkit.getWorld((String)("Areas/" + GameID));
        if (config != null && world != null) {
            List allWorldPlayers = world.getPlayers();
            List<UUID> winnerUUIDs = TeamManager.getAllTeamPlayerUUIDs(GameID, TeamID);
            List<Player> winnerPlayers = winnerUUIDs.stream().map(Bukkit::getPlayer).filter(playerx -> playerx != null && playerx.isOnline()).collect(Collectors.toList());
            String TeamName = config.getString("SpawnLocations." + TeamID + ".Name");
            Bukkit.getPluginManager().callEvent((Event)new OnGameEndEvent(GameID, winnerPlayers, allWorldPlayers));
            if (config.getBoolean("Rewards.OnEndGameRewards.Enabled")) {
                List<String> rewards;
                if (config.getBoolean("Rewards.OnEndGameRewards.Rewards.Winners.Enabled")) {
                    rewards = config.getStringList("Rewards.OnEndGameRewards.Rewards.Winners.Rewards").stream().map(reward -> reward.replace("${winnerteamname}", TeamName)).collect(Collectors.toList());
                    for (UUID winnerUUID : winnerUUIDs) {
                        Player player = Bukkit.getPlayer((UUID)winnerUUID);
                        if (player == null || !player.isOnline()) continue;
                        DatabaseManager db = DatabaseManager.getInstance();
                        int currentWins = Rewards.parseOrDefault(db.getSetting(winnerUUID, "wins"), 0);
                        db.updateSetting(winnerUUID, "wins", currentWins + 1);
                        int currentWinStreak = Rewards.parseOrDefault(db.getSetting(winnerUUID, "winstreak"), 0);
                        int newWinStreak = currentWinStreak + 1;
                        db.updateSetting(winnerUUID, "winstreak", newWinStreak);
                        int totalWinStreak = Rewards.parseOrDefault(db.getSetting(winnerUUID, "total_winstreak"), 0);
                        if (newWinStreak > totalWinStreak) {
                            db.updateSetting(winnerUUID, "total_winstreak", newWinStreak);
                        }
                        ParticleEventWins.OnWinEvent(player);
                        MenuManager.executeCommands(player, rewards);
                    }
                }
                if (config.getBoolean("Rewards.OnEndGameRewards.Rewards.Spectators.Enabled")) {
                    rewards = config.getStringList("Rewards.OnEndGameRewards.Rewards.Spectators.Rewards").stream().map(reward -> reward.replace("${winnerteamname}", TeamName)).collect(Collectors.toList());
                    List spectators = allWorldPlayers.stream().filter(playerx -> !winnerUUIDs.contains(playerx.getUniqueId())).collect(Collectors.toList());
                    for (Player player : spectators) {
                        MenuManager.executeCommands(player, rewards);
                    }
                }
            }
        }
    }

    private static int parseOrDefault(String value, int defaultValue) {
        try {
            return value != null ? Integer.parseInt(value) : defaultValue;
        }
        catch (NumberFormatException var3) {
            return defaultValue;
        }
    }
}

