/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Chunk
 *  org.bukkit.World
 *  org.bukkit.WorldCreator
 *  org.bukkit.command.ConsoleCommandSender
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerLoginEvent
 *  org.bukkit.event.player.PlayerLoginEvent$Result
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.ASWM.ASWMWorldManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameUtils;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class LocalCache
implements Listener {
    private static final Map<String, Long> gameConfigLastModified = new WeakHashMap<String, Long>();
    private static final int BATCH_SIZE = 100;
    private static final int DELAY_BETWEEN_BATCHES = 60;
    private static final int BUFFER_SIZE = 8192;
    private static volatile boolean isLoadingWorlds = false;
    private static final Set<String> scannedDirectories = new HashSet<String>();
    private static final ThreadLocal<byte[]> bufferPool = ThreadLocal.withInitial(() -> new byte[8192]);

    @EventHandler(priority=EventPriority.LOWEST)
    public void onPlayerLogin(PlayerLoginEvent event) {
        if (!event.getPlayer().hasPermission("mpa.prejoin") && isLoadingWorlds) {
            event.disallow(PlayerLoginEvent.Result.KICK_OTHER, "\u00a7cServer is restarting. Please try again in a few moments.");
        }
    }

    private static void kickAllPlayers() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.kickPlayer("\u00a7cServer is restarting. Please try again in a few moments.");
        }
    }

    public static int getTotalGames(String gameID) {
        Set<String> allMapGameIDs = HashMapHandler.getAllMapGameIDs();
        return allMapGameIDs == null ? 0 : (int)allMapGameIDs.stream().filter(game -> game.toLowerCase().contains(gameID.toLowerCase())).count();
    }

    public static int getRunningGames(String gameID) {
        Set<String> allMapGameIDs = HashMapHandler.getAllMapGameIDs();
        return allMapGameIDs == null ? 0 : (int)allMapGameIDs.stream().filter(game -> game.toLowerCase().contains(gameID.toLowerCase()) && Boolean.TRUE.equals(HashMapHandler.getIsGamePlaying(game))).count();
    }

    private static List<File> findGameFiles(File directory) {
        File[] files;
        String directoryPath = directory.getAbsolutePath();
        if (scannedDirectories.contains(directoryPath)) {
            return Collections.emptyList();
        }
        ArrayList<File> gameFiles = new ArrayList<File>();
        if (directory.exists() && directory.isDirectory() && (files = directory.listFiles()) != null) {
            File[] var4 = files;
            int var5 = files.length;
            for (int var6 = 0; var6 < var5; ++var6) {
                File file = var4[var6];
                if (file.isDirectory()) {
                    gameFiles.addAll(LocalCache.findGameFiles(file));
                    continue;
                }
                if (!file.getName().endsWith(".yml")) continue;
                gameFiles.add(file);
            }
        }
        scannedDirectories.add(directoryPath);
        return gameFiles;
    }

    public static void onServerStart() {
        File gamesFolder = new File(MoonLab.getInstance().getDataFolder(), "Games");
        Bukkit.getConsoleSender().sendMessage("\u00a7aStarting preloading worlds!");
        isLoadingWorlds = true;
        LocalCache.kickAllPlayers();
        scannedDirectories.clear();
        if (gamesFolder.exists() && gamesFolder.isDirectory()) {
            List<File> gameFiles = LocalCache.findGameFiles(gamesFolder);
            if (gameFiles.isEmpty()) {
                Bukkit.getLogger().warning("No game configuration files found!");
                isLoadingWorlds = false;
            } else {
                Bukkit.getConsoleSender().sendMessage("\u00a7aFound " + gameFiles.size() + " game configs! Loading worlds in batches...");
                Bukkit.getConsoleSender().sendMessage("\u00a7f");
                ArrayList<File> filesToProcess = new ArrayList<File>();
                HashMap<String, FileConfiguration> configCache = new HashMap<String, FileConfiguration>();
                for (File gameFile : gameFiles) {
                    FileConfiguration config = configCache.computeIfAbsent(gameFile.getName(), k -> YamlConfiguration.loadConfiguration((File)gameFile));
                    if (config.getBoolean("Settings.LoadMap", true)) {
                        filesToProcess.add(gameFile);
                        continue;
                    }
                    ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
                    String var10001 = gameFile.getName();
                    var10000.sendMessage("Skipping preload for map: " + var10001.replace(".yml", "") + " (LoadMap set to false)");
                }
                int preloadedWorlds = SettingsManager.getInstance().getSettings().getInt("PreloadSettings.Worlds");
                int totalWorlds = filesToProcess.size() * preloadedWorlds;
                AtomicInteger loaded = new AtomicInteger(0);
                LocalCache.processWorldsInBatches(filesToProcess, loaded, totalWorlds, preloadedWorlds, configCache);
            }
        } else {
            Bukkit.getLogger().warning("Games folder does not exist or is not a directory!");
            isLoadingWorlds = false;
        }
    }

    private static void processWorldsInBatches(final List<File> gameFiles, final AtomicInteger loaded, final int totalWorlds, final int preloadedWorlds, final Map<String, FileConfiguration> configCache) {
        final boolean useASWM = SettingsManager.getInstance().getSettings().getBoolean("API.ASWM");
        new BukkitRunnable(){
            private int fileIndex = 0;
            private int worldIndex = 0;
            private int batchCounter = 0;

            public void run() {
                if (this.fileIndex >= gameFiles.size()) {
                    Bukkit.getConsoleSender().sendMessage("\u00a7aAll worlds preloaded successfully!");
                    isLoadingWorlds = false;
                    configCache.clear();
                    scannedDirectories.clear();
                    System.gc();
                    this.cancel();
                } else {
                    for (int i = 0; i < 100 && this.fileIndex < gameFiles.size(); ++i) {
                        File gameFile = (File)gameFiles.get(this.fileIndex);
                        String gameID = gameFile.getName().replace(".yml", "").toLowerCase();
                        String normalizedGameID = GameUtils.getNormalizedGameID(gameID);
                        FileConfiguration config = (FileConfiguration)configCache.get(gameFile.getName());
                        if (config == null) {
                            config = YamlConfiguration.loadConfiguration((File)gameFile);
                            configCache.put(gameFile.getName(), config);
                        }
                        if (this.worldIndex < preloadedWorlds) {
                            String worldName = "Mini-" + gameID + "-" + (this.worldIndex + 1);
                            File zipFile = new File(gameFile.getParentFile(), gameID + ".zip");
                            if (zipFile.exists()) {
                                int currentLoaded = loaded.incrementAndGet();
                                Bukkit.getConsoleSender().sendMessage("\u00a7eLoading world " + currentLoaded + "/" + totalWorlds + ": " + worldName + " (normalized ID: " + normalizedGameID + ")");
                                if (useASWM) {
                                    ASWMWorldManager.loadWorldAsync(zipFile, worldName, config, gameFile.getAbsolutePath());
                                } else {
                                    LocalCache.loadWorldAsync(zipFile, worldName, config, gameFile.getAbsolutePath());
                                }
                            }
                            ++this.worldIndex;
                        } else {
                            ++this.fileIndex;
                            this.worldIndex = 0;
                            --i;
                        }
                        ++this.batchCounter;
                    }
                    if (this.batchCounter >= 20) {
                        ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
                        int var10001 = loaded.get();
                        var10000.sendMessage("\u00a77Processing worlds: " + var10001 + "/" + totalWorlds + " completed...");
                        this.batchCounter = 0;
                        System.gc();
                    }
                }
            }
        }.runTaskTimer((Plugin)MoonLab.getInstance(), 20L, 60L);
    }

    private static void loadWorldAsync(File zipFile, String worldName, FileConfiguration config, String gameFilePath) {
        boolean useASWM = SettingsManager.getInstance().getSettings().getBoolean("API.ASWM");
        if (useASWM) {
            ASWMWorldManager.loadWorldAsync(zipFile, worldName, config, gameFilePath);
        } else {
            CompletableFuture.runAsync(() -> {
                try {
                    File worldFolder = new File(Bukkit.getWorldContainer(), "Areas/" + worldName);
                    if (worldFolder.exists()) {
                        LocalCache.deleteDirectory(worldFolder);
                    }
                    LocalCache.unzipWorld(zipFile, worldFolder);
                    Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> {
                        try {
                            WorldCreator creator = new WorldCreator("Areas/" + worldName);
                            World world = Bukkit.createWorld((WorldCreator)creator);
                            if (world != null) {
                                world.setKeepSpawnInMemory(false);
                                HashMapHandler.setMapGameID(worldName, gameFilePath);
                                HashMapHandler.setConfigGameID(worldName, config);
                                GameUtils.loadOriginalWorld(worldName, world);
                                for (Chunk chunk : world.getLoadedChunks()) {
                                    if (!chunk.isEntitiesLoaded()) continue;
                                    world.unloadChunk(chunk);
                                }
                                Bukkit.getConsoleSender().sendMessage("\u00a7aLoaded world: " + worldName);
                            } else {
                                Bukkit.getLogger().warning("Failed to create world: " + worldName);
                            }
                        }
                        catch (Exception var9) {
                            Bukkit.getLogger().log(Level.SEVERE, "Error loading world " + worldName, var9);
                        }
                    });
                }
                catch (IOException var5) {
                    Bukkit.getLogger().log(Level.SEVERE, "Failed to unzip world: " + worldName, var5);
                }
            });
        }
    }

    private static void unzipWorld(File zipFile, File targetFolder) throws IOException {
        if (!targetFolder.exists()) {
            targetFolder.mkdirs();
        }
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile));){
            ZipEntry entry;
            byte[] buffer = bufferPool.get();
            while ((entry = zis.getNextEntry()) != null) {
                File newFile = new File(targetFolder, entry.getName());
                String canonicalDestinationPath = targetFolder.getCanonicalPath();
                String canonicalEntryPath = newFile.getCanonicalPath();
                if (!canonicalEntryPath.startsWith(canonicalDestinationPath + File.separator)) {
                    Bukkit.getLogger().warning("Entry is outside of the target directory: " + entry.getName());
                    continue;
                }
                if (entry.isDirectory()) {
                    newFile.mkdirs();
                } else {
                    File parent = new File(newFile.getParent());
                    if (!parent.exists()) {
                        parent.mkdirs();
                    }
                    try (FileOutputStream fos = new FileOutputStream(newFile);){
                        int length;
                        while ((length = zis.read(buffer)) > 0) {
                            fos.write(buffer, 0, length);
                        }
                    }
                }
                zis.closeEntry();
            }
        }
    }

    public static void onServerStop() {
        Bukkit.getLogger().info("Unloading all game worlds...");
        boolean useASWM = SettingsManager.getInstance().getSettings().getBoolean("API.ASWM");
        ArrayList<String> worldsToUnload = new ArrayList<String>(HashMapHandler.getAllMapGameIDs());
        int total = worldsToUnload.size();
        AtomicInteger processed = new AtomicInteger(0);
        for (int i = 0; i < worldsToUnload.size(); i += 5) {
            int endIndex = Math.min(i + 5, worldsToUnload.size());
            for (int j = i; j < endIndex; ++j) {
                String worldName = (String)worldsToUnload.get(j);
                if (useASWM) {
                    ASWMWorldManager.unloadAndDeleteWorld(worldName);
                } else {
                    World world = Bukkit.getWorld((String)("Areas/" + worldName));
                    if (world != null) {
                        for (Chunk chunk : world.getLoadedChunks()) {
                            world.unloadChunk(chunk);
                        }
                        if (Bukkit.unloadWorld((World)world, (boolean)true)) {
                            File worldFolder = new File(Bukkit.getWorldContainer(), "Areas/" + worldName);
                            CompletableFuture.runAsync(() -> {
                                try {
                                    LocalCache.deleteDirectory(worldFolder);
                                    Bukkit.getLogger().info("Deleted world folder: " + worldName);
                                }
                                catch (Exception var3) {
                                    Bukkit.getLogger().warning("Failed to delete world folder: " + worldName);
                                }
                            });
                        } else {
                            Bukkit.getLogger().warning("Failed to unload world: " + worldName);
                        }
                    }
                }
                processed.incrementAndGet();
            }
            Logger var10000 = Bukkit.getLogger();
            int var10001 = processed.get();
            var10000.info("Processed " + var10001 + "/" + total + " worlds");
        }
        LocalCache.clearAllMaps();
        gameConfigLastModified.clear();
        scannedDirectories.clear();
        bufferPool.remove();
        System.gc();
        Bukkit.getLogger().info("All game data, worlds, and folders have been successfully unloaded and deleted.");
    }

    private static boolean deleteDirectory(File directory) {
        if (directory.exists()) {
            try {
                return LocalCache.deleteDirectoryRecursively(directory.toPath());
            }
            catch (IOException var2) {
                Bukkit.getLogger().log(Level.WARNING, "Error deleting directory: " + String.valueOf(directory), var2);
                return false;
            }
        }
        return true;
    }

    private static boolean deleteDirectoryRecursively(Path path) throws IOException {
        if (Files.exists(path, new LinkOption[0])) {
            Files.walkFileTree(path, (FileVisitor<? super Path>)new SimpleFileVisitor<Path>(){

                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    Files.delete(file);
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                    Files.delete(dir);
                    return FileVisitResult.CONTINUE;
                }
            });
        }
        return true;
    }

    public static void clearAllMaps() {
        HashMapHandler.clearAllMapGameIDs();
        HashMapHandler.clearAllConfigGameIDs();
        HashMapHandler.clearAllIsGamePlaying();
        HashMapHandler.clearAllIsGameStarted();
        HashMapHandler.clearAllInactiveGameIDs();
        HashMapHandler.clearAllActiveGameIDs();
        HashMapHandler.clearAllMembersGameIDs();
        HashMapHandler.clearAllGamePlacedBlocks();
        HashMapHandler.clearAllPlayersStartedGameIDs();
        HashMapHandler.clearAllPlayerGameIDs();
        HashMapHandler.clearAllGameTimes();
        HashMapHandler.clearAllItemTimes();
        HashMapHandler.clearAllLavaTimes();
        HashMapHandler.clearAllGameTimers();
        HashMapHandler.clearAllItemTimers();
        HashMapHandler.clearAllActiveModeTasks();
        HashMapHandler.clearAllBorderTasks();
        HashMapHandler.clearAllActiveTimers();
        HashMapHandler.clearAllRemainingGameTimes();
        HashMapHandler.clearAllRemainingItemTimes();
    }

    public static String createExtraGameMap(String gameID) {
        if (gameID != null && !gameID.isEmpty()) {
            File gamesFolder = new File(MoonLab.getInstance().getDataFolder(), "Games");
            File gameFile = LocalCache.findGameFile(gamesFolder, gameID);
            if (gameFile == null) {
                Bukkit.getLogger().warning("Game configuration file does not exist: " + gameID);
                return null;
            }
            YamlConfiguration config = YamlConfiguration.loadConfiguration((File)gameFile);
            int currentTotal = LocalCache.getTotalGames(gameID);
            int nextInstance = currentTotal + 1;
            String fullGameID = "Mini-" + gameID + "-" + nextInstance;
            Bukkit.getConsoleSender().sendMessage("\u00a7aCreating extra game map: " + fullGameID);
            File zipFile = new File(gameFile.getParentFile(), gameID + ".zip");
            if (!zipFile.exists() && (zipFile = LocalCache.findZipFile(gamesFolder, gameID)) == null) {
                Bukkit.getLogger().warning("Game zip file does not exist: " + gameID);
                return null;
            }
            boolean useASWM = SettingsManager.getInstance().getSettings().getBoolean("API.ASWM");
            if (useASWM) {
                return ASWMWorldManager.createExtraGameMapASWM(gameID, fullGameID, zipFile, (FileConfiguration)config);
            }
            try {
                File worldFolder = new File(Bukkit.getWorldContainer(), "Areas/" + fullGameID);
                if (worldFolder.exists()) {
                    LocalCache.deleteDirectory(worldFolder);
                }
                worldFolder.mkdirs();
                LocalCache.unzipWorld(zipFile, worldFolder);
                WorldCreator creator = new WorldCreator("Areas/" + fullGameID);
                World world = Bukkit.createWorld((WorldCreator)creator);
                if (world != null) {
                    LocalCache.initializeGameState(fullGameID, (FileConfiguration)config);
                    int spawnX = world.getSpawnLocation().getBlockX() >> 4;
                    int spawnZ = world.getSpawnLocation().getBlockZ() >> 4;
                    world.setChunkForceLoaded(spawnX, spawnZ, true);
                    String normalizedGameID = GameUtils.getNormalizedGameID(fullGameID);
                    if (!GameUtils.isSchematicCached(normalizedGameID)) {
                        GameUtils.loadOriginalWorld(fullGameID, world);
                    }
                    Bukkit.getConsoleSender().sendMessage("\u00a7aExtra game map created and registered successfully: " + fullGameID);
                    return fullGameID;
                }
                Bukkit.getLogger().warning("Failed to create world for " + fullGameID);
                return null;
            }
            catch (Exception var15) {
                Bukkit.getLogger().log(Level.SEVERE, "Error creating extra game map: " + fullGameID, var15);
                return null;
            }
        }
        Bukkit.getLogger().warning("Cannot create extra game map: gameID is null or empty");
        return null;
    }

    private static void initializeGameState(String fullGameID, FileConfiguration config) {
        HashMapHandler.setMapGameID(fullGameID, fullGameID);
        HashMapHandler.setConfigGameID(fullGameID, config);
        HashMapHandler.setIsGamePlaying(fullGameID, false);
        HashMapHandler.setIsGameStarted(fullGameID, false);
        HashMapHandler.setInactiveGameID(fullGameID, false);
        HashMapHandler.setGameEnding(fullGameID, false);
        HashMapHandler.setMembersGameID(fullGameID, new ArrayList<Player>());
        HashMapHandler.setPlayersStartedGameID(fullGameID, 0);
        HashMapHandler.setGamePlacedBlocks(fullGameID, new HashSet<String>());
        HashMapHandler.setGameTime(fullGameID, 0);
        HashMapHandler.setItemTime(fullGameID, 0);
        HashMapHandler.setRemainingGameTime(fullGameID, 0);
        HashMapHandler.setRemainingItemTime(fullGameID, 0);
        HashMapHandler.setActiveMode(fullGameID, "Normal");
        HashMapHandler.setFasterItemsMode(fullGameID, false);
        HashMapHandler.setSynchronizedItemsMode(fullGameID, false);
    }

    private static File findGameFile(File directory, String gameID) {
        if (directory.exists() && directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files == null) {
                return null;
            }
            File directFile = new File(directory, gameID + ".yml");
            if (directFile.exists() && directFile.isFile()) {
                return directFile;
            }
            File[] var4 = files;
            int var5 = files.length;
            for (int var6 = 0; var6 < var5; ++var6) {
                File file = var4[var6];
                if (file.isDirectory()) {
                    File result = LocalCache.findGameFile(file, gameID);
                    if (result == null) continue;
                    return result;
                }
                if (!file.getName().equalsIgnoreCase(gameID + ".yml")) continue;
                return file;
            }
            return null;
        }
        return null;
    }

    private static File findZipFile(File directory, String gameID) {
        if (directory.exists() && directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files == null) {
                return null;
            }
            File directFile = new File(directory, gameID + ".zip");
            if (directFile.exists() && directFile.isFile()) {
                return directFile;
            }
            File[] var4 = files;
            int var5 = files.length;
            for (int var6 = 0; var6 < var5; ++var6) {
                File file = var4[var6];
                if (file.isDirectory()) {
                    File result = LocalCache.findZipFile(file, gameID);
                    if (result == null) continue;
                    return result;
                }
                if (!file.getName().equalsIgnoreCase(gameID + ".zip")) continue;
                return file;
            }
            return null;
        }
        return null;
    }
}

