/*
 * Decompiled with CFR 0.152.
 *
 * Could not load the following classes:
 *  me.clip.placeholderapi.PlaceholderAPI
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.World
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.GameManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.LeaveGameManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.SchematicHandler;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.PartyStaticClass;
import org.kloppie74.MoonPillars.PaperMC.ScoreBoardAPI.DisplayNameAboveHead;

public class TeamManager {
    public static final Map<String, Map<String, List<Player>>> teamsPerGame = new ConcurrentHashMap<String, Map<String, List<Player>>>();
    private static final Map<String, Map<String, Boolean>> isTeamAlive = new ConcurrentHashMap<String, Map<String, Boolean>>();
    private static final Map<String, Map<String, Location>> gameSpawnLocationsCache = new ConcurrentHashMap<String, Map<String, Location>>();
    private static final Map<String, Map<String, List<UUID>>> deadPlayersByGameAndTeam = new ConcurrentHashMap<String, Map<String, List<UUID>>>();
    private static final Map<String, Map<String, List<UUID>>> originalTeamMembers = new ConcurrentHashMap<String, Map<String, List<UUID>>>();

    public static void teleportPlayersToCages(String gameID, FileConfiguration config) {
        List<Player> players = HashMapHandler.getMembersGameID(gameID);
        if (players != null && !players.isEmpty()) {
            int playersPerTeam = config.getInt("SpawnLocations.PlayersPerTeam", 1);
            int maxTeams = config.getInt("SpawnLocations.MaxTeams", 1);
            Map spawnLocations = gameSpawnLocationsCache.computeIfAbsent(gameID, id -> TeamManager.loadSpawnLocations(config));
            World gameWorld = Bukkit.getWorld((String)("Areas/" + gameID));
            if (gameWorld == null) {
                Bukkit.getLogger().severe("Game world for " + gameID + " not found!");
            } else {
                Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> TeamManager.organizeTeamsAndTeleport(gameID, players, playersPerTeam, maxTeams, spawnLocations, gameWorld, config));
            }
        } else {
            Bukkit.getLogger().warning("No players found for gameID " + gameID);
            GameManager.endGame(gameID, true);
        }
    }

    private static void organizeTeamsAndTeleport(String gameID, List<Player> players, int playersPerTeam, int maxTeams, Map<String, Location> spawnLocations, World gameWorld, FileConfiguration config) {
        ArrayList<Player> validPlayers = new ArrayList<Player>(players.size());
        for (Player player : players) {
            if (!player.getWorld().equals((Object)gameWorld)) {
                LeaveGameManager.leaveGame(player);
                continue;
            }
            validPlayers.add(player);
        }
        if (validPlayers.isEmpty()) {
            Bukkit.getLogger().warning("No valid players for gameID " + gameID + " after filtering");
            GameManager.endGame(gameID, true);
        } else {
            // ИЗМЕНЕНО: передаём spawnLocations в distributePlayersToTeams
            Map<String, List<Player>> teams = TeamManager.distributePlayersToTeams(validPlayers, playersPerTeam, maxTeams, spawnLocations);
            teamsPerGame.put(gameID, teams);
            TeamManager.recordOriginalTeamMembers(gameID, teams);
            HashMap teamStatus = new HashMap(teams.size());
            teams.keySet().forEach(team -> teamStatus.put(team, true));
            isTeamAlive.put(gameID, teamStatus);
            TeamManager.teleportPlayersToPositions(gameID, teams, spawnLocations, gameWorld, config);
        }
    }

    private static void recordOriginalTeamMembers(String gameID, Map<String, List<Player>> teams) {
        HashMap gameTeams = new HashMap();
        for (Map.Entry<String, List<Player>> entry : teams.entrySet()) {
            List playerUUIDs = entry.getValue().stream().map(OfflinePlayer::getUniqueId).collect(Collectors.toList());
            gameTeams.put(entry.getKey(), playerUUIDs);
        }
        originalTeamMembers.put(gameID, gameTeams);
    }

    // ============================================================
    // ИЗМЕНЕНО: распределение по фактической локации игрока
    // (то есть по той клетке, куда его поставил JoinGameHandler)
    // ============================================================
    private static Map<String, List<Player>> distributePlayersToTeams(List<Player> players, int playersPerTeam, int maxTeams, Map<String, Location> spawnLocations) {
        HashMap<String, List<Player>> teams = new HashMap<String, List<Player>>();
        for (int i = 1; i <= maxTeams; ++i) {
            teams.put("Team" + i, new ArrayList());
        }

        // Партии — по локации первого участника
        Map<String, List<Player>> parties = TeamManager.getPlayerParties(players);
        Set<Player> assigned = new HashSet<Player>();

        for (Map.Entry<String, List<Player>> partyEntry : parties.entrySet()) {
            List<Player> party = partyEntry.getValue();
            if (party.isEmpty() || party.size() > playersPerTeam) continue;

            Player first = party.get(0);
            String bestTeam = findNearestFreeTeam(first, teams, playersPerTeam, maxTeams, spawnLocations);
            if (bestTeam != null) {
                teams.get(bestTeam).addAll(party);
                assigned.addAll(party);
            }
        }

        // Остальные — по локации
        for (Player player : players) {
            if (assigned.contains(player)) continue;
            String bestTeam = findNearestFreeTeam(player, teams, playersPerTeam, maxTeams, spawnLocations);
            if (bestTeam != null) {
                teams.get(bestTeam).add(player);
            }
        }

        teams.entrySet().removeIf(entry -> ((List)entry.getValue()).isEmpty());
        return teams;
    }

    // Ищет ближайшую свободную команду к позиции игрока
    private static String findNearestFreeTeam(Player player, Map<String, List<Player>> teams, int playersPerTeam, int maxTeams, Map<String, Location> spawnLocations) {
        String bestTeam = null;
        double bestDist = Double.MAX_VALUE;

        for (int i = 1; i <= maxTeams; i++) {
            String teamKey = "Team" + i;
            List<Player> teamList = teams.get(teamKey);
            if (teamList == null || teamList.size() >= playersPerTeam) continue;

            Location teamLoc = spawnLocations.get(teamKey + ".Player1");
            if (teamLoc == null) continue;

            teamLoc = teamLoc.clone();
            teamLoc.setWorld(player.getWorld());

            double dist = player.getLocation().distanceSquared(teamLoc);
            if (dist < bestDist) {
                bestDist = dist;
                bestTeam = teamKey;
            }
        }
        return bestTeam;
    }

    private static Map<String, List<Player>> getPlayerParties(List<Player> players) {
        HashMap<String, List<Player>> parties = new HashMap<String, List<Player>>();
        for (Player player : players) {
            String partyId = TeamManager.getPlayerPartyId(player);
            if (partyId == null) continue;
            parties.computeIfAbsent(partyId, k -> new ArrayList()).add(player);
        }
        return parties;
    }

    private static String getPlayerPartyId(Player player) {
        if (player == null) {
            return null;
        }
        UUID partyOwnerUUID = PartyStaticClass.getPlayerPartyOwner(player);
        return partyOwnerUUID != null ? partyOwnerUUID.toString() : null;
    }

    public static void recordPlayerDeath(String gameID, Player player) {
        String teamKey = TeamManager.getPlayerTeam(gameID, player);
        if (teamKey != null) {
            ((List)deadPlayersByGameAndTeam.computeIfAbsent(gameID, k -> new ConcurrentHashMap()).computeIfAbsent(teamKey, k -> new ArrayList())).add(player.getUniqueId());
        }
    }

    public static boolean wasPlayerOnTeam(String gameID, String teamKey, UUID playerUUID) {
        List<Player> teamPlayers;
        Map<String, List<Player>> teams = teamsPerGame.get(gameID);
        if (teams != null && (teamPlayers = teams.get(teamKey)) != null && teamPlayers.stream().anyMatch(p -> p.getUniqueId().equals(playerUUID))) {
            return true;
        }
        Map<String, List<UUID>> deadPlayers = deadPlayersByGameAndTeam.get(gameID);
        if (deadPlayers != null) {
            List<UUID> teamDeadPlayers = deadPlayers.get(teamKey);
            return teamDeadPlayers != null && teamDeadPlayers.contains(playerUUID);
        }
        Map<String, List<UUID>> originalTeams = originalTeamMembers.get(gameID);
        if (originalTeams == null) {
            return false;
        }
        List<UUID> originalTeamPlayers = originalTeams.get(teamKey);
        return originalTeamPlayers != null && originalTeamPlayers.contains(playerUUID);
    }

    public static List<UUID> getAllTeamPlayerUUIDs(String gameID, String teamKey) {
        List<UUID> originalTeamPlayers;
        Map<String, List<UUID>> originalTeams;
        List<UUID> teamDeadPlayers;
        Map<String, List<UUID>> deadPlayers;
        List<Player> teamPlayers;
        ArrayList<UUID> allPlayers = new ArrayList<UUID>();
        Map<String, List<Player>> teams = teamsPerGame.get(gameID);
        if (teams != null && (teamPlayers = teams.get(teamKey)) != null) {
            teamPlayers.forEach(p -> allPlayers.add(p.getUniqueId()));
        }
        if ((deadPlayers = deadPlayersByGameAndTeam.get(gameID)) != null && (teamDeadPlayers = deadPlayers.get(teamKey)) != null) {
            allPlayers.addAll(teamDeadPlayers);
        }
        if ((originalTeams = originalTeamMembers.get(gameID)) != null && (originalTeamPlayers = originalTeams.get(teamKey)) != null) {
            allPlayers.addAll(originalTeamPlayers);
        }
        return allPlayers.stream().distinct().collect(Collectors.toList());
    }

    private static void teleportPlayersToPositions(String gameID, Map<String, List<Player>> teams, Map<String, Location> spawnLocations, World gameWorld, FileConfiguration config) {
        Location gameWorldSpawn = spawnLocations.get("GameWorldSpawn");
        if (gameWorldSpawn != null) {
            gameWorldSpawn.setWorld(gameWorld);
        }
        boolean tntMode = config.getBoolean("Settings.TnTMode", false);
        String nameTagPrefix = SettingsManager.getInstance().getSettings().getString("GameSettings.NameTags.Prefix", "");
        boolean usePlaceholders = Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI");
        for (Map.Entry<String, List<Player>> teamEntry : teams.entrySet()) {
            String teamKey = teamEntry.getKey();
            List<Player> teamPlayers = teamEntry.getValue();
            for (int i = 0; i < teamPlayers.size(); ++i) {
                int playerIndex;
                String spawnKey;
                Location spawnLocation;
                Player player = teamPlayers.get(i);
                if (gameWorldSpawn != null) {
                    player.teleport(gameWorldSpawn);
                    MessageSender.SendMessage(player, "Games.Teleported-World", "", "");
                }
                if ((spawnLocation = spawnLocations.get(spawnKey = teamKey + ".Player" + (playerIndex = i + 1))) != null) {
                    spawnLocation.setWorld(gameWorld);
                    player.teleport(spawnLocation);
                    player.setGameMode(GameMode.ADVENTURE);
                    int cageRotation = config.getInt("SpawnLocations." + teamKey + ".Player" + playerIndex + ".Cage-Rotation", 0);
                    SchematicHandler.PlaceCage(player, cageRotation);
                    if (!tntMode) {
                        SchematicHandler.setPillarLocation(player, spawnLocation);
                        SchematicHandler.PlacePillar(player, 0);
                    }
                    MessageSender.SendMessage(player, "Games.Teleported-Cage", "", "");
                }
                player.getInventory().clear();
                String prefix = nameTagPrefix;
                if (usePlaceholders) {
                    prefix = PlaceholderAPI.setPlaceholders((Player)player, (String)nameTagPrefix);
                }
                DisplayNameAboveHead.setNick(player, MSG.chatColors(prefix));
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private static Map<String, Location> loadSpawnLocations(FileConfiguration config) {
        spawnLocations = new HashMap<String, Location>();
        if (config.contains("SpawnLocations.GameWorldSpawn") && (location = TeamManager.getLocationFromConfig(config, path = "SpawnLocations.GameWorldSpawn")) != null) {
            spawnLocations.put("GameWorldSpawn", location);
        }
        if ((spawnSection = config.getConfigurationSection("SpawnLocations")) == null) {
            Bukkit.getLogger().warning("SpawnLocations section is missing in configuration");
            return spawnLocations;
        }
        var11 = spawnSection.getKeys(false).iterator();
        block0: while (true) {
            if (!var11.hasNext()) {
                return spawnLocations;
            }
            key = (String)var11.next();
            if (key.equals("MaxTeams") || key.equals("PlayersPerTeam") || key.equals("MaximumPlayers") || key.equals("MinimumPlayers") || key.equals("GameWorldSpawn") || !key.startsWith("Team") || (teamSection = spawnSection.getConfigurationSection(key)) == null) continue;
            var6 = teamSection.getKeys(false).iterator();
            while (true) {
                if (var6.hasNext()) ** break;
                continue block0;
                playerKey = (String)var6.next();
                if (!playerKey.startsWith("Player") || (location = TeamManager.getLocationFromConfig(config, path = "SpawnLocations." + key + "." + playerKey)) == null) continue;
                spawnLocations.put(key + "." + playerKey, location);
            }
            break;
        }
    }

    private static Location getLocationFromConfig(FileConfiguration config, String path) {
        if (config.contains(path + ".X") && config.contains(path + ".Y") && config.contains(path + ".Z") && config.contains(path + ".Yaw") && config.contains(path + ".Pitch")) {
            double x = config.getDouble(path + ".X");
            double y = config.getDouble(path + ".Y");
            double z = config.getDouble(path + ".Z");
            float yaw = (float)config.getDouble(path + ".Yaw");
            float pitch = (float)config.getDouble(path + ".Pitch");
            return new Location((World)null, x, y, z, yaw, pitch);
        }
        return null;
    }

    public static String getPlayerTeam(String gameID, Player player) {
        Map.Entry<String, List<Player>> entry;
        Map<String, List<Player>> gameTeams = teamsPerGame.get(gameID);
        if (gameTeams == null) {
            return null;
        }
        Iterator<Map.Entry<String, List<Player>>> var3 = gameTeams.entrySet().iterator();
        do {
            if (var3.hasNext()) continue;
            return null;
        } while (!(entry = var3.next()).getValue().contains(player));
        return entry.getKey();
    }

    public static void clearGameTeams(String gameID) {
        teamsPerGame.remove(gameID);
        isTeamAlive.remove(gameID);
        gameSpawnLocationsCache.remove(gameID);
        deadPlayersByGameAndTeam.remove(gameID);
        originalTeamMembers.remove(gameID);
    }

    public static boolean isTeamAlive(String gameID, String teamKey) {
        Map<String, Boolean> gameTeamStatus = isTeamAlive.get(gameID);
        return gameTeamStatus != null && Boolean.TRUE.equals(gameTeamStatus.get(teamKey));
    }

    public static void setTeamAlive(String gameID, String teamKey, boolean alive) {
        isTeamAlive.computeIfAbsent(gameID, k -> new HashMap()).put(teamKey, alive);
    }

    public static int getActiveTeamCount(String gameID) {
        Map<String, Boolean> teamStatus = isTeamAlive.get(gameID);
        if (teamStatus == null) {
            return 0;
        }
        int count = 0;
        for (Boolean alive : teamStatus.values()) {
            if (!Boolean.TRUE.equals(alive)) continue;
            ++count;
        }
        return count;
    }

    public static boolean isPlayerAlive(String gameID, Player player) {
        String teamKey = TeamManager.getPlayerTeam(gameID, player);
        if (teamKey == null) {
            return false;
        }
        Map<String, List<UUID>> deadPlayers = deadPlayersByGameAndTeam.get(gameID);
        if (deadPlayers == null) {
            return true;
        }
        List<UUID> teamDeadPlayers = deadPlayers.get(teamKey);
        if (teamDeadPlayers == null) {
            return true;
        }
        return !teamDeadPlayers.contains(player.getUniqueId());
    }

    public static int GetPlayersPerTeam(String gameID) {
        FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
        return config != null ? config.getInt("SpawnLocations.PlayersPerTeam", 1) : 1;
    }

    public static int GetMaxTeams(String gameID) {
        FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
        return config != null ? config.getInt("SpawnLocations.MaxTeams", 1) : 1;
    }
}