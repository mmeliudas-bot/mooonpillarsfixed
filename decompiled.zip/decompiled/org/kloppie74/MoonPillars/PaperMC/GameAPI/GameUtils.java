/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldedit.EditSession
 *  com.sk89q.worldedit.EditSession$ReorderMode
 *  com.sk89q.worldedit.WorldEdit
 *  com.sk89q.worldedit.bukkit.BukkitAdapter
 *  com.sk89q.worldedit.extent.Extent
 *  com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard
 *  com.sk89q.worldedit.extent.clipboard.Clipboard
 *  com.sk89q.worldedit.extent.clipboard.io.BuiltInClipboardFormat
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardReader
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardWriter
 *  com.sk89q.worldedit.function.operation.ForwardExtentCopy
 *  com.sk89q.worldedit.function.operation.Operation
 *  com.sk89q.worldedit.function.operation.Operations
 *  com.sk89q.worldedit.math.BlockVector3
 *  com.sk89q.worldedit.regions.CuboidRegion
 *  com.sk89q.worldedit.regions.Region
 *  com.sk89q.worldedit.session.ClipboardHolder
 *  com.sk89q.worldedit.world.World
 *  org.bukkit.Bukkit
 *  org.bukkit.Chunk
 *  org.bukkit.World
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 */
package org.kloppie74.MoonPillars.PaperMC.GameAPI;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.Extent;
import com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.BuiltInClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardWriter;
import com.sk89q.worldedit.function.operation.ForwardExtentCopy;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.CuboidRegion;
import com.sk89q.worldedit.regions.Region;
import com.sk89q.worldedit.session.ClipboardHolder;
import com.sk89q.worldedit.world.World;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.ClearArea;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.SchematicHandler;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class GameUtils {
    public static final File SCHEMATICS_FOLDER = new File(MoonLab.getInstance().getDataFolder(), "Logs/GameCache");
    private static final Pattern GAME_ID_PATTERN = Pattern.compile("^Mini-(.*)-\\d+$");
    private static final int CHUNKS_PER_TICK = 4;

    public static String getNormalizedGameID(String gameID) {
        if (gameID != null && !gameID.isEmpty()) {
            Matcher matcher = GAME_ID_PATTERN.matcher(gameID);
            return matcher.matches() ? matcher.group(1) : gameID;
        }
        return "";
    }

    public static boolean isSchematicCached(String normalizedGameID) {
        return GameUtils.getSchematicFile(normalizedGameID).exists();
    }

    public static void loadOriginalWorld(String gameID, org.bukkit.World world) {
        String normalizedGameID = GameUtils.getNormalizedGameID(gameID);
        Bukkit.getLogger().info("Map normalization: " + gameID + " -> " + normalizedGameID);
        if (!GameUtils.isSchematicCached(normalizedGameID)) {
            Bukkit.getLogger().info("No schematic found for " + normalizedGameID + ", creating new one...");
            GameUtils.createSchematic(gameID, normalizedGameID, world);
        }
    }

    private static Clipboard loadSchematic(String normalizedGameID) {
        File schematicFile = GameUtils.getSchematicFile(normalizedGameID);
        if (!schematicFile.exists()) {
            return null;
        }
        try {
            Clipboard var6;
            try (FileInputStream fis = new FileInputStream(schematicFile);){
                BuiltInClipboardFormat format = BuiltInClipboardFormat.SPONGE_SCHEMATIC;
                try (ClipboardReader reader = format.getReader((InputStream)fis);){
                    Clipboard clipboard = reader.read();
                    Bukkit.getLogger().info("Successfully loaded schematic for " + normalizedGameID);
                    var6 = clipboard;
                }
            }
            return var6;
        }
        catch (IOException var11) {
            Bukkit.getLogger().warning("Failed to load schematic for " + normalizedGameID + ": " + var11.getMessage());
            return null;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void createSchematic(String gameID, String normalizedGameID, org.bukkit.World world) {
        FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
        int saveWorld = config.getInt("Settings.BuildRange", 100) + 16;
        int maxY = config.getInt("Settings.BuildHeight", 100) + 16;
        int minY = -64;
        BlockVector3 min = BlockVector3.at((int)(-saveWorld), (int)minY, (int)(-saveWorld));
        BlockVector3 max = BlockVector3.at((int)saveWorld, (int)maxY, (int)saveWorld);
        World weWorld = BukkitAdapter.adapt((org.bukkit.World)world);
        try (EditSession editSession = null;){
            editSession = WorldEdit.getInstance().newEditSession(weWorld);
            editSession.setReorderMode(EditSession.ReorderMode.FAST);
            CuboidRegion region = new CuboidRegion(weWorld, min, max);
            BlockArrayClipboard clipboard = new BlockArrayClipboard((Region)region);
            clipboard.setOrigin(BlockVector3.at((int)0, (int)0, (int)0));
            ForwardExtentCopy copy = new ForwardExtentCopy((Extent)editSession, (Region)region, (Extent)clipboard, region.getMinimumPoint());
            copy.setCopyingEntities(false);
            Operations.complete((Operation)copy);
            File schematicFile = GameUtils.getSchematicFile(normalizedGameID);
            GameUtils.ensureParentDirExists(schematicFile);
            try (FileOutputStream fos = new FileOutputStream(schematicFile);){
                BuiltInClipboardFormat format = BuiltInClipboardFormat.SPONGE_SCHEMATIC;
                try (ClipboardWriter writer = format.getWriter((OutputStream)fos);){
                    writer.write((Clipboard)clipboard);
                }
            }
            Bukkit.getLogger().info("Created and saved schematic for " + normalizedGameID);
        }
    }

    public static void resetWorld(final String gameID, final org.bukkit.World world, final boolean fullReset, final boolean resetSpawnArea) {
        String normalizedGameID = GameUtils.getNormalizedGameID(gameID);
        final FileConfiguration config = HashMapHandler.getConfigGameID(gameID);
        Clipboard clipboard = GameUtils.loadSchematic(normalizedGameID);
        if (clipboard == null) {
            Bukkit.getLogger().warning("Schematic for gameID " + gameID + " (normalized: " + normalizedGameID + ") not found! Creating one...");
            GameUtils.createSchematic(gameID, normalizedGameID, world);
            clipboard = GameUtils.loadSchematic(normalizedGameID);
            if (clipboard == null) {
                Bukkit.getLogger().severe("Failed to create or load schematic for " + normalizedGameID);
                return;
            }
        }
        final Clipboard finalClipboard = clipboard;
        new BukkitRunnable(){

            /*
             * WARNING - Removed try catching itself - possible behaviour change.
             */
            public void run() {
                try {
                    World weWorld = BukkitAdapter.adapt((org.bukkit.World)world);
                    try (EditSession editSession = null;){
                        editSession = WorldEdit.getInstance().newEditSession(weWorld);
                        editSession.setReorderMode(EditSession.ReorderMode.FAST);
                        Operation operation = new ClipboardHolder(finalClipboard).createPaste((Extent)editSession).to(BlockVector3.at((int)0, (int)0, (int)0)).ignoreAirBlocks(false).build();
                        Operations.complete((Operation)operation);
                    }
                    new BukkitRunnable(){

                        public void run() {
                            try {
                                if (fullReset) {
                                    GameUtils.resetEntities(world);
                                    world.getWorldBorder().reset();
                                }
                                if (resetSpawnArea) {
                                    ClearArea.clearSpawnArea(gameID);
                                    boolean tntMode = config.getBoolean("Settings.TnTMode", false);
                                    List<Player> playersInGame = HashMapHandler.getMembersGameID(gameID);
                                    if (playersInGame != null) {
                                        for (Player player : playersInGame) {
                                            if (player == null || !player.isOnline()) continue;
                                            HashMapHandler.setPlayerNoHunger(player.getUniqueId(), true);
                                            if (tntMode) continue;
                                            SchematicHandler.PlacePillar(player, 0);
                                            SchematicHandler.removePillarLocation(player);
                                        }
                                    }
                                }
                                GameUtils.unloadUnnecessaryChunks(world);
                                Bukkit.getLogger().info("World reset for game " + gameID + " completed!");
                            }
                            catch (Exception var5) {
                                Logger var10000 = Bukkit.getLogger();
                                String var10001 = gameID;
                                var10000.severe("Error in post-reset operations for " + var10001 + ": " + var5.getMessage());
                                var5.printStackTrace();
                            }
                        }
                    }.runTask((Plugin)MoonLab.getInstance());
                }
                catch (Exception var8) {
                    Logger var10000 = Bukkit.getLogger();
                    String var10001 = gameID;
                    var10000.severe("Error resetting world for " + var10001 + ": " + var8.getMessage());
                    var8.printStackTrace();
                }
            }
        }.runTask((Plugin)MoonLab.getInstance());
    }

    private static File getSchematicFile(String normalizedGameID) {
        return new File(SCHEMATICS_FOLDER, normalizedGameID + ".schem");
    }

    private static void ensureParentDirExists(File file) {
        File parentDir = file.getParentFile();
        if (parentDir != null && !parentDir.exists() && !parentDir.mkdirs()) {
            Bukkit.getLogger().warning("Failed to create parent directory: " + String.valueOf(parentDir));
        }
    }

    private static void resetEntities(org.bukkit.World world) {
        List entities = world.getEntities();
        int count = 0;
        for (Entity entity : entities) {
            if (entity instanceof Player) continue;
            entity.remove();
            ++count;
        }
        if (count > 0) {
            Bukkit.getLogger().info("Removed " + count + " entities from world " + world.getName());
        }
    }

    private static void unloadUnnecessaryChunks(final org.bukkit.World world) {
        int spawnX = world.getSpawnLocation().getBlockX() >> 4;
        int spawnZ = world.getSpawnLocation().getBlockZ() >> 4;
        Chunk[] loadedChunks = world.getLoadedChunks();
        final ArrayList<Chunk> chunksToUnload = new ArrayList<Chunk>();
        Chunk[] var5 = loadedChunks;
        int var6 = loadedChunks.length;
        for (int var7 = 0; var7 < var6; ++var7) {
            Chunk chunk = var5[var7];
            int x = chunk.getX();
            int z = chunk.getZ();
            if (x == spawnX && z == spawnZ) {
                world.setChunkForceLoaded(x, z, true);
                continue;
            }
            chunksToUnload.add(chunk);
        }
        if (!chunksToUnload.isEmpty()) {
            final int totalChunks = chunksToUnload.size();
            new BukkitRunnable(){
                int processed = 0;

                public void run() {
                    int end = Math.min(this.processed + 4, totalChunks);
                    for (int i = this.processed; i < end; ++i) {
                        Chunk chunk = (Chunk)chunksToUnload.get(i);
                        world.unloadChunk(chunk.getX(), chunk.getZ(), true);
                    }
                    this.processed = end;
                    if (this.processed >= totalChunks) {
                        Logger var10000 = Bukkit.getLogger();
                        int var10001 = totalChunks;
                        var10000.info("Unloaded " + var10001 + " chunks in world " + world.getName());
                        this.cancel();
                    }
                }
            }.runTaskTimer((Plugin)MoonLab.getInstance(), 1L, 1L);
        }
    }

    static {
        if (!SCHEMATICS_FOLDER.exists() && !SCHEMATICS_FOLDER.mkdirs()) {
            Bukkit.getLogger().severe("Failed to create schematics folder: " + SCHEMATICS_FOLDER.getAbsolutePath());
        }
    }
}

