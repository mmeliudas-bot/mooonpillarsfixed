/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.messaging.PluginMessageListener
 */
package org.kloppie74.MoonPillars.PaperMC;

import com.google.common.collect.Maps;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class ClientBrandChecker
implements Listener,
PluginMessageListener {
    private static final String BRAND_CHANNEL = "minecraft:brand";
    private static final String BUNGEECORD_CHANNEL = "bungeecord:main";
    private static final Map<UUID, PlayerClientData> clientDataCache = Maps.newConcurrentMap();
    private static final Set<UUID> notificationsDisabled = ConcurrentHashMap.newKeySet();
    private static final Set<UUID> modListRequested = ConcurrentHashMap.newKeySet();
    private static boolean channelsRegistered = false;
    private static final String LOG_DIRECTORY = "Logs/ClientLogs";
    private static File currentLogFile;
    private static final SimpleDateFormat dateFormat;
    private static final Map<String, String> KNOWN_CLIENTS;
    private static final Set<String> COMMON_MOD_TERMS;
    private static final Pattern HACK_CLIENT_PATTERN;

    public static void init() {
        MoonLab plugin = MoonLab.getInstance();
        Bukkit.getPluginManager().registerEvents((Listener)new ClientBrandChecker(), (Plugin)plugin);
        ClientBrandChecker.registerChannels(plugin);
        ClientBrandChecker.initLogging();
    }

    private static void registerChannels(MoonLab plugin) {
        if (!channelsRegistered) {
            Bukkit.getMessenger().registerIncomingPluginChannel((Plugin)plugin, BRAND_CHANNEL, (PluginMessageListener)new ClientBrandChecker());
            ClientBrandChecker.registerChannel(plugin, BRAND_CHANNEL);
            ClientBrandChecker.registerChannel(plugin, "FML|HS");
            ClientBrandChecker.registerChannel(plugin, "fabric:registry/sync");
            ClientBrandChecker.registerChannel(plugin, "lunar:client");
            ClientBrandChecker.registerChannel(plugin, "badlion:mods");
            channelsRegistered = true;
        }
    }

    private static void registerChannel(MoonLab plugin, String channel) {
        try {
            Bukkit.getMessenger().registerIncomingPluginChannel((Plugin)plugin, channel, (PluginMessageListener)new ClientBrandChecker());
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public void onPluginMessageReceived(String channel, Player player, byte[] message) {
        UUID uuid = player.getUniqueId();
        PlayerClientData data = clientDataCache.computeIfAbsent(uuid, id -> new PlayerClientData());
        if (channel.equals(BRAND_CHANNEL)) {
            try {
                String channelLower;
                data.clientBrand = channelLower = new String(message, 1, message.length - 1, StandardCharsets.UTF_8);
                this.detectModsFromBrand(data, channelLower);
            }
            catch (Exception var7) {
                data.clientBrand = "malformed";
            }
        } else if (!channel.startsWith("minecraft:") && !channel.equals(BUNGEECORD_CHANNEL)) {
            String channelLower = channel.toLowerCase();
            this.processModChannel(data, channel, channelLower);
        }
    }

    private void processModChannel(PlayerClientData data, String channel, String channelLower) {
        String modId;
        if (HACK_CLIENT_PATTERN.matcher(channelLower).find()) {
            modId = channelLower.split(":")[0];
            data.mods.add(modId + " (potential hack client)");
            data.hasSuspiciousMods = true;
        }
        if (channel.contains(":") && !channel.startsWith("minecraft:")) {
            modId = channel.split(":")[0].toLowerCase();
            if (COMMON_MOD_TERMS.contains(modId)) {
                data.mods.add(modId + " (mod)");
            } else if (data.mods.size() < 50) {
                data.mods.add(modId + " (channel)");
            }
        }
    }

    private void detectModsFromBrand(PlayerClientData data, String brand) {
        String brandLower = brand.toLowerCase();
        if (brandLower.contains("fabric")) {
            data.mods.add("Fabric (mod loader)");
        }
        if (brandLower.contains("forge")) {
            data.mods.add("Forge (mod loader)");
        }
        for (Map.Entry<String, String> entry : KNOWN_CLIENTS.entrySet()) {
            if (!brandLower.contains(entry.getKey())) continue;
            data.mods.add(entry.getValue());
            break;
        }
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        PlayerClientData data = clientDataCache.remove(uuid);
        if (data != null) {
            data.clear();
        }
        modListRequested.remove(uuid);
    }

    @EventHandler(priority=EventPriority.LOW)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        boolean notificationsDisabled = DatabaseManager.getInstance().getClientNotificationsDisabled(uuid);
        ClientBrandChecker.setNotificationsDisabled(uuid, notificationsDisabled);
        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> {
            if (player.isOnline()) {
                PlayerClientData data = clientDataCache.computeIfAbsent(uuid, id -> new PlayerClientData());
                if (data.clientBrand.equals("Unknown")) {
                    data.clientBrand = this.isBedrockPlayer(player) ? "Geyser" : "vanilla";
                }
                this.sendConsolidatedNotification(player);
            }
        }, 40L);
    }

    private void sendConsolidatedNotification(Player player) {
        UUID uuid = player.getUniqueId();
        PlayerClientData data = clientDataCache.get(uuid);
        if (data != null && !data.notified) {
            String var10000 = player.getName();
            String formattedMessage = MSG.chatColors("&8[&cMPA&8] &f" + var10000 + " &7is using &f" + data.getClientType() + " &7client &8(&f" + data.clientBrand + "&8) &8| &7" + (String)(data.mods.isEmpty() ? "No mods detected" : data.mods.size() + " mods detected") + " &7- Check with &f/client " + player.getName());
            Bukkit.getOnlinePlayers().stream().filter(staff -> staff.hasPermission("mpa.notify.client") && !notificationsDisabled.contains(staff.getUniqueId())).forEach(staff -> staff.sendMessage(formattedMessage));
            ClientBrandChecker.logClientToFile(player, data);
            data.notified = true;
            if (data.hasSuspiciousMods) {
                String hackMessage = MSG.chatColors("&8[&c!&8] &cWarning: &f" + player.getName() + "&7may be using a &chack client&7.");
                Bukkit.getOnlinePlayers().stream().filter(admin -> admin.hasPermission("mpa.notify.hacks") && !notificationsDisabled.contains(admin.getUniqueId())).forEach(admin -> admin.sendMessage(hackMessage));
            }
        }
    }

    private boolean isBedrockPlayer(Player player) {
        return player.getName().startsWith(".") || player.hasPermission("floodgate.player") || player.getListeningPluginChannels().contains("geyser:client");
    }

    public static void setNotificationsDisabled(UUID uuid, boolean disabled) {
        if (disabled) {
            notificationsDisabled.add(uuid);
        } else {
            notificationsDisabled.remove(uuid);
        }
    }

    public static boolean hasNotificationsDisabled(Player player) {
        return notificationsDisabled.contains(player.getUniqueId());
    }

    public static String getClientTypeName(String clientBrand) {
        Map.Entry<String, String> entry;
        String clientLower = clientBrand.toLowerCase();
        Iterator<Map.Entry<String, String>> var2 = KNOWN_CLIENTS.entrySet().iterator();
        do {
            if (var2.hasNext()) continue;
            if (clientLower.contains("vanilla")) {
                return "Vanilla";
            }
            if (!clientLower.contains("bukkit") && !clientLower.contains("craftbukkit")) {
                if (clientLower.contains("fabric")) {
                    return "Fabric";
                }
                if (!clientLower.contains("forge") && !clientLower.contains("fml")) {
                    if (!clientLower.contains("+") && !clientLower.contains("modified")) {
                        return "Unknown";
                    }
                    return "Modified";
                }
                return "Forge";
            }
            return "Bukkit";
        } while (!clientLower.contains((entry = var2.next()).getKey()));
        return entry.getValue();
    }

    public static String getPlayerClientBrand(Player player) {
        PlayerClientData data = clientDataCache.get(player.getUniqueId());
        return data != null ? data.clientBrand : "Unknown";
    }

    public static List<String> getPlayerMods(Player player) {
        PlayerClientData data = clientDataCache.get(player.getUniqueId());
        return data != null ? new ArrayList<String>(data.mods) : Collections.emptyList();
    }

    public static boolean hasHackedClient(Player player) {
        PlayerClientData data = clientDataCache.get(player.getUniqueId());
        return data == null ? false : data.hasSuspiciousMods;
    }

    public static void clearCache() {
        clientDataCache.clear();
        modListRequested.clear();
        System.gc();
    }

    public static boolean toggleNotifications(Player player) {
        UUID uuid;
        boolean currentState = notificationsDisabled.contains(uuid = player.getUniqueId());
        ClientBrandChecker.setNotificationsDisabled(uuid, !currentState);
        DatabaseManager.getInstance().setClientNotificationsDisabled(uuid, !currentState);
        return !notificationsDisabled.contains(uuid);
    }

    public static void initLogging() {
        File oldLog;
        MoonLab plugin = MoonLab.getInstance();
        File directory = new File(plugin.getDataFolder(), LOG_DIRECTORY);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        if ((oldLog = new File(directory, "log.txt")).exists()) {
            String timestamp = dateFormat.format(new Date(oldLog.lastModified()));
            File newFile = new File(directory, timestamp + "_log.txt");
            oldLog.renameTo(newFile);
        }
        currentLogFile = new File(directory, "log.txt");
        try {
            if (!currentLogFile.exists()) {
                currentLogFile.createNewFile();
            }
            try (FileWriter writer = new FileWriter(currentLogFile);){
                writer.write("=== MoonPillars Client Log ===\n");
                SimpleDateFormat var10001 = dateFormat;
                Date var10002 = new Date();
                writer.write("Started at: " + var10001.format(var10002) + "\n\n");
            }
        }
        catch (IOException var8) {
            Bukkit.getLogger().severe("[MPA] Failed to initialize client logging: " + var8.getMessage());
        }
    }

    private static void logClientToFile(Player player, PlayerClientData data) {
        try {
            FileWriter writer;
            MoonLab plugin = MoonLab.getInstance();
            File directory = new File(plugin.getDataFolder(), LOG_DIRECTORY);
            if (!directory.exists()) {
                directory.mkdirs();
            }
            if (currentLogFile == null || !currentLogFile.exists()) {
                currentLogFile = new File(directory, "log.txt");
                writer = new FileWriter(currentLogFile);
                try {
                    writer.write("=== MoonPillars Client Log ===\n");
                    SimpleDateFormat var10001 = dateFormat;
                    Date var10002 = new Date();
                    writer.write("Started at: " + var10001.format(var10002) + "\n\n");
                }
                finally {
                    writer.close();
                }
            }
            writer = new FileWriter(currentLogFile, true);
            try {
                SimpleDateFormat timeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                writer.write("====================\n");
                String var13 = timeFormat.format(new Date());
                writer.write("Time: " + var13 + "\n");
                var13 = player.getName();
                writer.write("Player: " + var13 + " (" + String.valueOf(player.getUniqueId()) + ")\n");
                writer.write("IP: " + player.getAddress().getAddress().getHostAddress() + "\n");
                var13 = data.getClientType();
                writer.write("Client: " + var13 + " (" + data.clientBrand + ")\n\n");
                if (data.mods.isEmpty()) {
                    writer.write("No mods detected\n");
                } else {
                    writer.write("Mods (" + data.mods.size() + "):\n");
                    for (String mod : data.mods) {
                        writer.write("- " + mod + "\n");
                    }
                }
                writer.write("====================\n\n");
            }
            finally {
                writer.close();
            }
        }
        catch (IOException var12) {
            Bukkit.getLogger().severe("[MPA] Failed to log client info: " + var12.getMessage());
        }
    }

    static {
        dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        KNOWN_CLIENTS = new HashMap<String, String>(16);
        COMMON_MOD_TERMS = new HashSet<String>(64);
        KNOWN_CLIENTS.put("lunar", "Lunar Client");
        KNOWN_CLIENTS.put("badlion", "Badlion Client");
        KNOWN_CLIENTS.put("feather", "Feather Client");
        KNOWN_CLIENTS.put("pvplounge", "PvPLounge Client");
        KNOWN_CLIENTS.put("salwyrr", "Salwyrr Client");
        KNOWN_CLIENTS.put("hyperium", "Hyperium Client");
        KNOWN_CLIENTS.put("labymod", "LabyMod");
        KNOWN_CLIENTS.put("optifine", "OptiFine");
        KNOWN_CLIENTS.put("geyser", "Bedrock Edition");
        KNOWN_CLIENTS.put("forge", "Forge");
        KNOWN_CLIENTS.put("fabric", "Fabric");
        KNOWN_CLIENTS.put("rift", "Rift");
        KNOWN_CLIENTS.put("liteloader", "LiteLoader");
        COMMON_MOD_TERMS.addAll(Arrays.asList("optifine", "sodium", "lithium", "phosphor", "iris", "jei", "rei", "journeymap", "voxelmap", "xaero", "minimap", "xaerominimap", "pixelmon", "applied", "ae2", "mekanism", "thermal", "wurst", "impact", "aristois", "meteor", "inertia", "salhack", "ares", "baritone", "huzuni", "future", "xray", "sigma", "liquidbounce", "nodus", "flux", "wolfram", "hyperium", "badlion", "lunar", "labymod", "envy", "vape", "ghost", "raven", "zeroday"));
        HACK_CLIENT_PATTERN = Pattern.compile("wurst|meteor|inertia|impact|sigma|vape|hack|cheat|xray|bypass|ghost", 2);
    }

    private static class PlayerClientData {
        private String clientBrand = "Unknown";
        private final Set<String> mods = new HashSet<String>();
        private boolean notified = false;
        private boolean hasSuspiciousMods = false;
        private String clientType = null;

        private PlayerClientData() {
        }

        public String getClientType() {
            if (this.clientType == null) {
                this.clientType = ClientBrandChecker.getClientTypeName(this.clientBrand);
            }
            return this.clientType;
        }

        public void clear() {
            this.mods.clear();
        }
    }
}

