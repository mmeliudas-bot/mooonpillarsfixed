/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.PlaceholderAPI
 *  org.apache.logging.log4j.LogManager
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandMap
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.defaults.BukkitCommand
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryAction
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryCloseEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.UltimateGuis;

import java.io.File;
import java.lang.reflect.Field;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.clip.placeholderapi.PlaceholderAPI;
import org.apache.logging.log4j.LogManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.Cooldowns;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler.CosmeticGui;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler.CosmeticHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.FindGames;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.ForceStart;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.JoinGameHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.LeaveGameManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.VoteListener;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class MenuManager
implements Listener {
    private static final Map<String, BukkitCommand> registeredCommands = new ConcurrentHashMap<String, BukkitCommand>();
    private static final Map<String, String> commandToFileMap = new ConcurrentHashMap<String, String>();
    private static final Map<UUID, String> openMenus = new ConcurrentHashMap<UUID, String>();
    private static final Map<String, FileConfiguration> menuCache = new ConcurrentHashMap<String, FileConfiguration>();
    public static File menuFolder = new File(MoonLab.getInstance().getDataFolder(), "Menus");
    static final boolean isPlaceholderAPIEnabled = Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI");

    public MenuManager() {
        MenuManager.loadMenuConfigs();
    }

    public static void reloadMenus(Player player) {
        menuCache.clear();
        commandToFileMap.clear();
        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            if (!openMenus.containsKey(onlinePlayer.getUniqueId())) continue;
            onlinePlayer.closeInventory();
        }
        openMenus.clear();
        MenuManager.loadMenuConfigs();
        MenuManager.registerMenuCommands();
        MoonLab.getInstance().getLogger().info("All menus and commands have been reloaded.");
        player.sendMessage(MSG.chatColors("&aAll menus and commands have been reloaded."));
    }

    public static void loadMenuConfigs() {
        if (menuFolder.exists() && menuFolder.isDirectory()) {
            File[] menuFiles = menuFolder.listFiles((dir, name) -> name.endsWith(".yml"));
            if (menuFiles != null) {
                File[] var1 = menuFiles;
                int var2 = menuFiles.length;
                for (int var3 = 0; var3 < var2; ++var3) {
                    File file = var1[var3];
                    YamlConfiguration config = YamlConfiguration.loadConfiguration((File)file);
                    menuCache.put(file.getName(), (FileConfiguration)config);
                    ConfigurationSection settingsSection = config.getConfigurationSection("Settings");
                    if (settingsSection == null) continue;
                    String commandName = settingsSection.getString("Command");
                    List aliases = settingsSection.getStringList("aliases");
                    if (commandName != null) {
                        commandToFileMap.put(commandName.toLowerCase(), file.getName());
                    }
                    for (String alias : aliases) {
                        commandToFileMap.put(alias.toLowerCase(), file.getName());
                    }
                }
                MoonLab.getInstance().getLogger().info("Loaded " + menuCache.size() + " menu configurations.");
            }
        } else {
            MoonLab.getInstance().getLogger().warning("Menus folder does not exist or is not a directory!");
        }
    }

    public static void registerMenuCommands() {
        File[] menuFiles;
        CommandMap commandMap = MenuManager.getCommandMap();
        registeredCommands.forEach((name, commandx) -> commandx.unregister(commandMap));
        registeredCommands.clear();
        if (menuFolder.exists() && menuFolder.isDirectory() && (menuFiles = menuFolder.listFiles((dir, name) -> name.endsWith(".yml"))) != null) {
            File[] var2 = menuFiles;
            int var3 = menuFiles.length;
            for (int var4 = 0; var4 < var3; ++var4) {
                File file = var2[var4];
                YamlConfiguration config = YamlConfiguration.loadConfiguration((File)file);
                final ConfigurationSection settingsSection = config.getConfigurationSection("Settings");
                if (settingsSection == null) continue;
                String commandName = settingsSection.getString("Command");
                List aliases = settingsSection.getStringList("aliases");
                String description = settingsSection.getString("Description", "Een menu commando");
                if (commandName == null) continue;
                BukkitCommand command = new BukkitCommand(commandName, description, "/" + commandName, aliases, (FileConfiguration)config, file){
                    final /* synthetic */ FileConfiguration val$config;
                    final /* synthetic */ File val$file;
                    {
                        this.val$config = fileConfiguration;
                        this.val$file = file;
                        super(name, description, usageMessage, aliases);
                    }

                    public boolean execute(CommandSender sender, String label, String[] args) {
                        if (sender instanceof Player) {
                            Player player = (Player)sender;
                            List commandsToExecute = settingsSection.getStringList("Commands");
                            MenuManager.executeCommands(player, commandsToExecute);
                            Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> {
                                ConfigurationSection settings = this.val$config.getConfigurationSection("Settings");
                                if (settings != null) {
                                    boolean requirePermission = settings.getBoolean("Permissions.Required-Permission", false);
                                    String permission = settings.getString("Permissions.Permission");
                                    String permissionDeniedMsg = settings.getString("Permissions.Permissions-Denied", "&cYou do not have permissions for this gui!");
                                    if (requirePermission && (permission == null || !player.hasPermission(permission))) {
                                        player.sendMessage(ChatColor.translateAlternateColorCodes((char)'&', (String)permissionDeniedMsg));
                                        return;
                                    }
                                    Inventory gui = MenuManager.createGui(this.val$config, player);
                                    player.openInventory(gui);
                                    openMenus.put(player.getUniqueId(), this.val$file.getName());
                                }
                            });
                        }
                        return true;
                    }

                    public List<String> tabComplete(CommandSender sender, String alias, String[] args) {
                        return new ArrayList<String>();
                    }
                };
                commandMap.register("moonlab", (Command)command);
                registeredCommands.put(commandName.toLowerCase(), command);
                commandToFileMap.put(commandName.toLowerCase(), file.getName());
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onInventoryClick(InventoryClickEvent e) {
        FileConfiguration menuConfig;
        Player player;
        UUID playerId;
        String currentMenu;
        if (e.getWhoClicked() instanceof Player && (currentMenu = openMenus.get(playerId = (player = (Player)e.getWhoClicked()).getUniqueId())) != null && (menuConfig = menuCache.get(currentMenu)) != null) {
            String guiTitle = MSG.chatColors(menuConfig.getString("Settings.Gui-Title", "MoonPillars"));
            if (e.getView().getTitle().equalsIgnoreCase(guiTitle)) {
                if (Cooldowns.isOnCooldown(player)) {
                    e.setCancelled(true);
                } else {
                    Optional<AbstractMap.SimpleEntry> matchedEntry;
                    Cooldowns.startCooldown(player);
                    e.setCancelled(true);
                    int slot = e.getRawSlot();
                    ConfigurationSection guiSection = menuConfig.getConfigurationSection("Gui");
                    if (guiSection != null && (matchedEntry = guiSection.getKeys(false).stream().filter(key -> {
                        int configuredSlot = guiSection.getInt(key + ".Slot", -1);
                        return configuredSlot == slot;
                    }).map(key -> new AbstractMap.SimpleEntry<String, Object>((String)key, guiSection.get(key))).findFirst()).isPresent()) {
                        String guiKey = (String)matchedEntry.get().getKey();
                        ConfigurationSection itemSection = guiSection.getConfigurationSection(guiKey);
                        if (itemSection == null) {
                            return;
                        }
                        List commands = itemSection.getStringList("Commands");
                        if (e.getAction() == InventoryAction.MOVE_TO_OTHER_INVENTORY || e.isShiftClick()) {
                            e.setCancelled(true);
                            player.sendMessage(MSG.chatColors("&cYou cannot shift-click items in this menu!"));
                            return;
                        }
                        MenuManager.executeCommands(player, commands);
                    }
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent e) {
        if (e.getPlayer() instanceof Player) {
            Player player = (Player)e.getPlayer();
            openMenus.remove(player.getUniqueId());
        }
    }

    /*
     * Unable to fully structure code
     */
    private static Inventory createGui(FileConfiguration config, Player player) {
        title = MSG.chatColors(config.getString("Settings.Gui-Title", "MoonPillars"));
        if (MenuManager.isPlaceholderAPIEnabled) {
            title = PlaceholderAPI.setPlaceholders((Player)player, (String)title);
        }
        size = config.getInt("Settings.Gui-Size", 54);
        inventory = Bukkit.createInventory((InventoryHolder)null, (int)size, (String)title);
        guiSection = config.getConfigurationSection("Gui");
        if (guiSection == null) {
            return inventory;
        }
        var6 = guiSection.getKeys(false).iterator();
        block0: while (true) {
            if (!var6.hasNext()) {
                return inventory;
            }
            key = (String)var6.next();
            itemSection = guiSection.getConfigurationSection(key);
            if (itemSection == null) continue;
            slots = new ArrayList<Integer>();
            if (itemSection.isList("Slot")) {
                slots.addAll(itemSection.getIntegerList("Slot"));
            } else {
                slot = itemSection.getInt("Slot", -1);
                if (slot >= 0 && slot < size) {
                    slots.add(slot);
                }
            }
            displayName = MSG.chatColors(itemSection.getString("DisplayName", "Unnamed Item"));
            if (MenuManager.isPlaceholderAPIEnabled) {
                displayName = PlaceholderAPI.setPlaceholders((Player)player, (String)displayName);
            }
            lores = itemSection.getStringList("Lores");
            coloredLores = new ArrayList<String>();
            for (String lore : lores) {
                lore = MSG.chatColors(lore);
                if (MenuManager.isPlaceholderAPIEnabled) {
                    lore = PlaceholderAPI.setPlaceholders((Player)player, (String)lore);
                }
                coloredLores.add(lore);
            }
            material = Material.matchMaterial((String)itemSection.getString("Item", "AIR"));
            glowing = itemSection.getBoolean("Glowing", false);
            if (material == null) continue;
            item = new ItemStack(material);
            meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(displayName);
                meta.setLore(coloredLores);
                if (glowing) {
                    meta.addEnchant(Enchantment.SILK_TOUCH, 1, true);
                    meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
                }
                item.setItemMeta(meta);
            }
            var17 = slots.iterator();
            while (true) {
                if (var17.hasNext()) ** break;
                continue block0;
                slot = (Integer)var17.next();
                if (slot < 0 || slot >= size) continue;
                inventory.setItem(slot, item);
            }
            break;
        }
    }

    public static CommandMap getCommandMap() {
        try {
            Field f = Bukkit.getPluginManager().getClass().getDeclaredField("commandMap");
            f.setAccessible(true);
            return (CommandMap)f.get(Bukkit.getPluginManager());
        }
        catch (IllegalAccessException | NoSuchFieldException | SecurityException var1) {
            var1.printStackTrace();
            return null;
        }
    }

    public static void executeCommands(Player player, List<String> commands) {
        for (String command : commands) {
            String chosenGame;
            String modeType;
            String[] parts;
            String selectionType;
            String gameMode;
            String commandType;
            int end;
            int start;
            String cleanCommand;
            String gameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
            command = gameID != null ? command.replace("{gameid}", gameID) : command;
            command = command.replace("${player}", player.getName()).replace("${ClickedPlayer}", player.getName());
            if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
                command = PlaceholderAPI.setPlaceholders((Player)player, (String)command);
            }
            if (command.startsWith("[COMMAND:PLAYER]")) {
                cleanCommand = command.substring("[COMMAND:PLAYER]".length()).trim();
                Bukkit.dispatchCommand((CommandSender)player, (String)cleanCommand);
                continue;
            }
            if (command.startsWith("[COMMAND:CONSOLE]")) {
                cleanCommand = command.substring("[COMMAND:CONSOLE]".length()).trim();
                Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)cleanCommand);
                continue;
            }
            if (command.startsWith("[MESSAGE:PLAYER]")) {
                cleanCommand = command.substring("[MESSAGE:PLAYER]".length()).trim();
                cleanCommand = PlaceholderAPI.setPlaceholders((Player)player, (String)cleanCommand);
                player.sendMessage(MSG.chatColors(cleanCommand));
                continue;
            }
            if (command.startsWith("[MOONGAME:FORCESTART]")) {
                ForceStart.ForceStart(player, gameID);
                continue;
            }
            if (command.startsWith("[MOONGAME:VOTE]")) {
                VoteListener.OpenInv(player);
                continue;
            }
            if (command.startsWith("[MOONGAME:LEAVEGAME]")) {
                LeaveGameManager.leaveGame(player);
                continue;
            }
            if (command.startsWith("[MESSAGE:CONSOLE]")) {
                cleanCommand = command.substring("[MESSAGE:CONSOLE]".length()).trim();
                cleanCommand = PlaceholderAPI.setPlaceholders((Player)player, (String)cleanCommand);
                Bukkit.getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes((char)'&', (String)cleanCommand.replace("${ClickedPlayer}", player.getName())));
                continue;
            }
            if (command.startsWith("[INVENTORY:CLOSE]")) {
                player.closeInventory();
                continue;
            }
            if (command.startsWith("[INVENTORY:OPEN:")) {
                start = command.indexOf("[INVENTORY:OPEN:") + "[INVENTORY:OPEN:".length();
                end = command.indexOf("]", start);
                if (end <= start) continue;
                commandType = command.substring(start, end).replace("${", "").replace("}", "");
                FileConfiguration newMenuConfig = menuCache.get(commandType);
                if (newMenuConfig != null) {
                    Inventory newGui = MenuManager.createGui(newMenuConfig, player);
                    player.openInventory(newGui);
                    openMenus.put(player.getUniqueId(), commandType);
                    continue;
                }
                String var10001 = String.valueOf(ChatColor.RED);
                player.sendMessage(var10001 + "GUI configuration not found: " + commandType);
                continue;
            }
            if (command.startsWith("[COSMETIC:SELECT:")) {
                start = command.indexOf("[COSMETIC:SELECT:") + "[COSMETIC:SELECT:".length();
                end = command.indexOf("]", start);
                if (end <= start) continue;
                commandType = command.substring(start, end).replace("${SECTION:", "").replace("${ID:", "").replace("}", "");
                String[] parts2 = commandType.split(":");
                if (parts2.length == 2) {
                    gameMode = parts2[0];
                    selectionType = parts2[1];
                    CosmeticHandler.getInstance().updateSelectedCosmetic(player.getUniqueId(), gameMode, selectionType);
                    continue;
                }
                System.out.println("Command format is invalid.");
                continue;
            }
            if (command.startsWith("[SELECTCOSMETIC:MENU:")) {
                start = command.indexOf("[SELECTCOSMETIC:MENU:") + "[SELECTCOSMETIC:MENU:".length();
                end = command.indexOf("]", start);
                if (end <= start) continue;
                commandType = command.substring(start, end).replace("${", "").replace("}", "");
                CosmeticGui.openCosmeticGUI(player, commandType);
                continue;
            }
            if (command.startsWith("[JOINGAME:RANDOM]")) {
                JoinGameHandler.joinRandomGame(player);
                continue;
            }
            if (command.startsWith("[JOINGAME:CUSTOM:")) {
                start = command.indexOf("[JOINGAME:CUSTOM:") + "[JOINGAME:CUSTOM:".length();
                end = command.indexOf("]", start);
                if (end <= start) continue;
                commandType = command.substring(start, end).replace("${", "").replace("}", "");
                JoinGameHandler.joinGame(player, commandType);
                continue;
            }
            if (command.startsWith("[JOINGAME:TEAMSIZE:")) {
                cleanCommand = command.substring(1, command.length() - 1);
                parts = cleanCommand.split(":");
                if (parts.length == 6) {
                    commandType = parts[0];
                    modeType = parts[1];
                    gameMode = parts[2];
                    selectionType = parts[4];
                    chosenGame = parts[5];
                    try {
                        int size = Integer.parseInt(gameMode);
                        int maxTeams = Integer.parseInt(selectionType);
                        if (chosenGame.equalsIgnoreCase("RANDOM")) {
                            String chosenTeam = FindGames.FindRandomTeamSize(size, maxTeams);
                            if (chosenTeam == null) continue;
                            String formattedTeam = chosenTeam.replace("Mini-", "").replaceAll("-\\d+$", "");
                            JoinGameHandler.joinGame(player, formattedTeam);
                            continue;
                        }
                        LogManager.getLogger().info("Invalid team type specified: " + chosenGame);
                    }
                    catch (NumberFormatException var16) {
                        player.sendMessage("Invalid TeamSize or MaxTeams: " + gameMode + ", " + selectionType);
                        LogManager.getLogger().info("Error parsing TeamSize or MaxTeams: " + gameMode + ", " + selectionType);
                        var16.printStackTrace();
                    }
                    continue;
                }
                LogManager.getLogger().info("Command format is incorrect. Expected [JOINGAME:TEAMSIZE:<size>:MAXTEAMS:<max>:<type>].");
                continue;
            }
            if (!command.startsWith("[JOINGAME:MODE:")) continue;
            cleanCommand = command.substring(1, command.length() - 1);
            parts = cleanCommand.split(":");
            if (parts.length == 4) {
                commandType = parts[0];
                modeType = parts[1];
                gameMode = parts[2];
                selectionType = parts[3];
                if (selectionType.equalsIgnoreCase("RANDOM")) {
                    chosenGame = FindGames.FindRandomTeamMode(gameMode);
                    if (chosenGame == null) continue;
                    String formattedGame = chosenGame.replace("Mini-", "").replaceAll("-\\d+$", "");
                    JoinGameHandler.joinGame(player, formattedGame);
                    continue;
                }
                LogManager.getLogger().info("Invalid selection type: " + selectionType);
                continue;
            }
            LogManager.getLogger().info("Command format is incorrect. Expected [JOINGAME:MODE:<mode>:<type>].");
        }
    }
}

