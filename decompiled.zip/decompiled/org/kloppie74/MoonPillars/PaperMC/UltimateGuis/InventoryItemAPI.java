/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 *  org.bukkit.persistence.PersistentDataContainer
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.UltimateGuis;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.Cooldowns;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.SpectatorInteractionHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.SpectatorInventoryManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class InventoryItemAPI
implements Listener {
    private static final NamespacedKey CUSTOM_TAG_KEY = new NamespacedKey((Plugin)MoonLab.getInstance(), "custom_tag");
    private static final double TAG_VALUE = Math.PI;

    public static void GiveLobbyItems(Player player) {
        InventoryItemAPI.giveItems(player, "Items.Lobby");
    }

    public static void GiveGameLobbyItems(Player player) {
        InventoryItemAPI.giveItems(player, "Items.GameLobby");
    }

    public static void GiveSpectatorItems(Player player) {
        InventoryItemAPI.giveItems(player, "Items.Spectator");
    }

    private static void giveItems(Player player, String sectionPath) {
        FileConfiguration config = SettingsManager.getInstance().getItems();
        ConfigurationSection section = config.getConfigurationSection(sectionPath);
        if (section != null) {
            Iterator var4 = section.getKeys(false).iterator();
            while (true) {
                ItemStack item;
                String permission;
                if (!var4.hasNext()) {
                    return;
                }
                String itemKey = (String)var4.next();
                ConfigurationSection itemSection = section.getConfigurationSection(itemKey);
                if (itemSection == null || (permission = itemSection.getString("Permissions")) != null && !player.hasPermission(permission)) continue;
                int slot = itemSection.getInt("Slot");
                String displayName = itemSection.getString("Display-name", "");
                String materialName = itemSection.getString("Item", "");
                if (materialName == null || materialName.isEmpty()) continue;
                boolean isPlayerHead = materialName.equalsIgnoreCase("PLAYER_HEAD");
                if (isPlayerHead) {
                    item = InventoryItemAPI.createPlayerHeadItem(player, displayName, itemSection.getStringList("Lores"));
                } else {
                    Material material = Material.getMaterial((String)materialName.toUpperCase());
                    if (material == null) continue;
                    item = InventoryItemAPI.createItem(material, displayName, itemSection.getStringList("Lores"));
                }
                player.getInventory().setItem(slot, item);
            }
        }
    }

    private static ItemStack createPlayerHeadItem(Player player, String displayName, List<String> lores) {
        ItemStack item = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta)item.getItemMeta();
        if (meta != null) {
            meta.setOwningPlayer(Bukkit.getOfflinePlayer((UUID)player.getUniqueId()));
            InventoryItemAPI.setItemMetaProperties((ItemMeta)meta, displayName, lores);
            item.setItemMeta((ItemMeta)meta);
        }
        return item;
    }

    private static ItemStack createItem(Material material, String displayName, List<String> lores) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            InventoryItemAPI.setItemMetaProperties(meta, displayName, lores);
            item.setItemMeta(meta);
        }
        return item;
    }

    private static void setItemMetaProperties(ItemMeta meta, String displayName, List<String> lores) {
        meta.setDisplayName(MSG.chatColors(displayName));
        if (lores != null && !lores.isEmpty()) {
            ArrayList<String> coloredLores = new ArrayList<String>(lores.size());
            for (String lore : lores) {
                coloredLores.add(MSG.chatColors(lore));
            }
            meta.setLore(coloredLores);
        }
        meta.getPersistentDataContainer().set(CUSTOM_TAG_KEY, PersistentDataType.DOUBLE, (Object)Math.PI);
    }

    @EventHandler
    public void OnPlayerDrop(PlayerDropItemEvent event) {
        FileConfiguration config;
        boolean canDropItems;
        ItemStack item = event.getItemDrop().getItemStack();
        if (item != null && item.hasItemMeta() && this.isCustomTaggedItem(item.getItemMeta()) && !(canDropItems = (config = SettingsManager.getInstance().getSettings()).getBoolean("LobbySettings.Can-Drop-Items", false))) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void OnPlayerInteract(PlayerInteractEvent event) {
        ItemMeta meta;
        String gameId;
        Player player = event.getPlayer();
        if (player.getWorld().getName().contains("MPA") && !HashMapHandler.getIsGameStarted(gameId = HashMapHandler.getPlayerGameID(player.getUniqueId())).booleanValue()) {
            event.setCancelled(true);
            return;
        }
        ItemStack item = event.getItem();
        if (item != null && item.hasItemMeta() && (meta = item.getItemMeta()) != null && this.isCustomTaggedItem(meta)) {
            if (Cooldowns.isOnCooldown(player)) {
                return;
            }
            String displayName = meta.getDisplayName();
            FileConfiguration itemsConfig = SettingsManager.getInstance().getItems();
            this.handleItemCommand(player, displayName, itemsConfig, "Items.Lobby");
            this.handleItemCommand(player, displayName, itemsConfig, "Items.GameLobby");
            this.handleItemCommand(player, displayName, itemsConfig, "Items.Spectator");
            Cooldowns.startCooldown(player);
        }
    }

    private boolean isCustomTaggedItem(ItemMeta meta) {
        PersistentDataContainer container = meta.getPersistentDataContainer();
        return container.has(CUSTOM_TAG_KEY, PersistentDataType.DOUBLE);
    }

    private void handleItemCommand(Player player, String displayName, FileConfiguration config, String sectionPath) {
        ConfigurationSection section = config.getConfigurationSection(sectionPath);
        if (section != null) {
            for (String itemKey : section.getKeys(false)) {
                String itemDisplayName;
                ConfigurationSection itemSection = section.getConfigurationSection(itemKey);
                if (itemSection == null || !displayName.equalsIgnoreCase(itemDisplayName = MSG.chatColors(itemSection.getString("Display-name", "")))) continue;
                String command = itemSection.getString("Command", "").replace("/", "");
                if (command.isEmpty()) break;
                if (command.equalsIgnoreCase("$update-visibility")) {
                    SpectatorInteractionHandler.toggleSpectatorsVisibility(player);
                    break;
                }
                if (command.equalsIgnoreCase("$speed-menu")) {
                    SpectatorInventoryManager.openSpeedGUI(player);
                    break;
                }
                player.performCommand(command);
                break;
            }
        }
    }
}

