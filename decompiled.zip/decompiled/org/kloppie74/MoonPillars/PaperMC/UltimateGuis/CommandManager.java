/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandMap
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.defaults.BukkitCommand
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.UltimateGuis;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.UltimateGuis.MenuManager;

public class CommandManager {
    private static final Map<String, BukkitCommand> registeredCommands = new ConcurrentHashMap<String, BukkitCommand>(8, 0.75f, 1);
    private static CommandMap commandMapCache;

    public static void registerMenuCommands() {
        CommandMap commandMap = CommandManager.getCommandMap();
        for (BukkitCommand command : registeredCommands.values()) {
            command.unregister(commandMap);
        }
        registeredCommands.clear();
        FileConfiguration configuration = SettingsManager.getInstance().getCommands();
        ConfigurationSection commandsSection = configuration.getConfigurationSection("Commands");
        if (commandsSection != null) {
            for (String key : commandsSection.getKeys(false)) {
                String commandName;
                ConfigurationSection commandSection = commandsSection.getConfigurationSection(key);
                if (commandSection == null || (commandName = commandSection.getString("Command")) == null) continue;
                CommandManager.registerSingleCommand(commandMap, commandName, commandSection);
            }
        }
    }

    private static void registerSingleCommand(CommandMap commandMap, String commandName, final ConfigurationSection commandSection) {
        List aliases = commandSection.getStringList("Aliases");
        String description = commandSection.getString("Description", "A Menu Command!");
        final String permission = commandSection.getString("Permission", "none");
        BukkitCommand command = new BukkitCommand(commandName, description, "/" + commandName, aliases){

            public boolean execute(CommandSender sender, String label, String[] args) {
                if (sender instanceof Player) {
                    Player player = (Player)sender;
                    if (!permission.equalsIgnoreCase("none") && !player.hasPermission(permission)) {
                        MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
                        return true;
                    }
                    CommandManager.processCommandArguments(player, args, commandSection);
                    return true;
                }
                sender.sendMessage("Only players can execute this command.");
                return false;
            }

            public List<String> tabComplete(CommandSender sender, String alias, String[] args) {
                return CommandManager.generateTabCompletion(commandSection, args);
            }
        };
        commandMap.register("moonlab", (Command)command);
        registeredCommands.put(commandName.toLowerCase(), command);
    }

    private static String substituteArguments(String command, int level, String currentArg) {
        String placeholder = "${arg-level" + level + "}";
        return command.replace(placeholder, currentArg);
    }

    private static void processCommandArguments(Player player, String[] args, ConfigurationSection commandSection) {
        List defaultCommands;
        ConfigurationSection currentSection = commandSection.getConfigurationSection("Args");
        boolean executed = false;
        for (int i = 0; i < args.length && currentSection != null; ++i) {
            String currentArg = args[i];
            ConfigurationSection matchedConfig = null;
            for (String key : currentSection.getKeys(false)) {
                List commandsToExecute;
                String expectedArg;
                ConfigurationSection argConfig = currentSection.getConfigurationSection(key);
                if (argConfig == null || (expectedArg = argConfig.getString("Arg")) == null || !expectedArg.equalsIgnoreCase(currentArg)) continue;
                matchedConfig = argConfig;
                if (i != args.length - 1 || (commandsToExecute = argConfig.getStringList("Commands")).isEmpty()) break;
                ArrayList<String> processedCommands = new ArrayList<String>(commandsToExecute.size());
                for (String cmd : commandsToExecute) {
                    processedCommands.add(CommandManager.substituteArguments(cmd, i + 1, currentArg));
                }
                MenuManager.executeCommands(player, processedCommands);
                executed = true;
                break;
            }
            if (matchedConfig == null) break;
            currentSection = matchedConfig.getConfigurationSection("Args");
        }
        if (!executed && !(defaultCommands = commandSection.getStringList("Commands")).isEmpty()) {
            MenuManager.executeCommands(player, defaultCommands);
        }
    }

    private static List<String> generateTabCompletion(ConfigurationSection commandSection, String[] args) {
        if (args.length == 0) {
            return Collections.emptyList();
        }
        ConfigurationSection currentSection = commandSection.getConfigurationSection("Args");
        if (currentSection == null) {
            return Collections.emptyList();
        }
        for (int i = 0; i < args.length - 1 && currentSection != null; ++i) {
            String argPrefix = args[i].toLowerCase();
            ConfigurationSection nextSection = null;
            for (String key : currentSection.getKeys(false)) {
                String expectedArg;
                ConfigurationSection argConfig = currentSection.getConfigurationSection(key);
                if (argConfig == null || (expectedArg = argConfig.getString("Arg")) == null || !expectedArg.equalsIgnoreCase(argPrefix)) continue;
                nextSection = argConfig.getConfigurationSection("Args");
                break;
            }
            currentSection = nextSection;
        }
        if (currentSection == null) {
            return Collections.emptyList();
        }
        String currentPrefix = args[args.length - 1].toLowerCase();
        ArrayList<String> suggestions = new ArrayList<String>();
        for (String key : currentSection.getKeys(false)) {
            String expectedArg;
            ConfigurationSection argConfig = currentSection.getConfigurationSection(key);
            if (argConfig == null || (expectedArg = argConfig.getString("Arg")) == null || !expectedArg.toLowerCase().startsWith(currentPrefix)) continue;
            suggestions.add(expectedArg);
        }
        return suggestions;
    }

    public static CommandMap getCommandMap() {
        if (commandMapCache != null) {
            return commandMapCache;
        }
        try {
            Field f = Bukkit.getPluginManager().getClass().getDeclaredField("commandMap");
            f.setAccessible(true);
            commandMapCache = (CommandMap)f.get(Bukkit.getPluginManager());
            return commandMapCache;
        }
        catch (IllegalAccessException | NoSuchFieldException | SecurityException var1) {
            var1.printStackTrace();
            return null;
        }
    }
}

