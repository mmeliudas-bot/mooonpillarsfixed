/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.PlaceholderAPIPlugin
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryCloseEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.scheduler.BukkitRunnable
 */
package org.kloppie74.MoonPillars.PaperMC;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import me.clip.placeholderapi.PlaceholderAPIPlugin;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.API.UpdateChecker;
import org.kloppie74.MoonPillars.PaperMC.AddonsManager.AddonsCommand;
import org.kloppie74.MoonPillars.PaperMC.AddonsManager.AddonsManager;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminCommandManager;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminMenu.GameManager;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.SignFunctions.ClickableSignListener;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.EditItems;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.EditorMenu;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.RewardCommandEditorGUI;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.TeamManagerMenu;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.VoteSetting;
import org.kloppie74.MoonPillars.PaperMC.Admin.V5Setup.FirstSetupDB;
import org.kloppie74.MoonPillars.PaperMC.Admin.V5Setup.SetupMenu;
import org.kloppie74.MoonPillars.PaperMC.BlockedEvents;
import org.kloppie74.MoonPillars.PaperMC.ClientBrandChecker;
import org.kloppie74.MoonPillars.PaperMC.ClientCommand;
import org.kloppie74.MoonPillars.PaperMC.ConfigUpdater;
import org.kloppie74.MoonPillars.PaperMC.Cosmetics.Events.ParticleEventBows;
import org.kloppie74.MoonPillars.PaperMC.Cosmetics.Events.ParticleEventKills;
import org.kloppie74.MoonPillars.PaperMC.EasterEggs.EasterEggCommand;
import org.kloppie74.MoonPillars.PaperMC.EasterEggs.EasterEggListener;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.ChatCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.ClearChatCMD;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.IgnoreCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.MSGCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.MSGToggleCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.ReplyCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.SpyChatCMD;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.SpyCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler.CosmeticGui;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler.JoinHandler;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler.SelectCosmeticCMD;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.FlyCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.LevelManager.LevelCMD;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.LevelManager.LevelMenuManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.LevelManager.LevelRewardsCMD;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.LobbyHandler.LobbyProtectionListener;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.PlayTime;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Portals.PortalListener;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.TeleportCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.CancelTasks.VanishInteractionListener;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.CancelTasks.VanishMobTargetingListener;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.HideMeCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.HideOthersCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.PlayerVisibilityListener;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.ShowOthersCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.VanishCommand;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.BedManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.EventListeners;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.LeaveGameManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.SpectatorInteractionHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.SpectatorInventoryManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.WorldTimeWeatherManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameUtils;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.JoinGameCMD;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.LocalCache;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.Spectate;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.VoteListener;
import org.kloppie74.MoonPillars.PaperMC.MemoryCommand;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.PartyStaticClass;
import org.kloppie74.MoonPillars.PaperMC.PlaceHolder;
import org.kloppie74.MoonPillars.PaperMC.RefreshCommand;
import org.kloppie74.MoonPillars.PaperMC.ScoreBoardAPI.NewScoreboard;
import org.kloppie74.MoonPillars.PaperMC.ScoreBoardAPI.ScoreHelper;
import org.kloppie74.MoonPillars.PaperMC.ToggleClientNotifyCommand;
import org.kloppie74.MoonPillars.PaperMC.UltimateGuis.CommandManager;
import org.kloppie74.MoonPillars.PaperMC.UltimateGuis.InventoryItemAPI;
import org.kloppie74.MoonPillars.PaperMC.UltimateGuis.MenuManager;
import org.kloppie74.MoonPillars.PaperMC.WebEditor.DebugCommand;
import org.kloppie74.MoonPillars.PaperMC.WebEditor.MoonPillarsTracker;
import org.kloppie74.MoonPillars.PaperMC.WebEditor.StatsCommand;

public final class MoonLab
extends JavaPlugin
implements Listener,
TabCompleter {
    public static Map<UUID, String> PlayerMenu = new HashMap<UUID, String>();
    private static MoonLab instance;
    private static ThreadMonitor threadMonitor;
    private WorldTimeWeatherManager worldTimeWeatherManager;
    private AddonsManager addonsManager;
    public static final List<String> ignoredSectionsMessagesYML;
    public static final List<String> ignoredSectionsSettingsYML;

    public static String formatTime(int seconds) {
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    public static MoonLab getInstance() {
        return instance;
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        PartyStaticClass.onPlayerDisconnect(player);
        LeaveGameManager.leaveGame(player);
        IgnoreCommand.saveIgnoredPlayers(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        HumanEntity var3 = event.getPlayer();
        if (var3 instanceof Player) {
            Player player = (Player)var3;
            PlayerMenu.put(player.getUniqueId(), "YourCustomKeyHere");
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        String Setup;
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        String name = player.getName();
        if (SettingsManager.getInstance().getSettings().getString("LobbySettings.Reset-Lobby-Inventory").equalsIgnoreCase("true")) {
            player.getInventory().clear();
        }
        InventoryItemAPI.GiveLobbyItems(player);
        if (player.isOp() && ((Setup = FirstSetupDB.getInstance().getSetting("SetupComplete")) == null || !Setup.equalsIgnoreCase("true"))) {
            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> {
                player.sendMessage(MSG.chatColors("&eWelcome to &6MoonPillars&e!"));
                player.sendMessage(MSG.chatColors("&eTo setup our plugin, run the &6/mpa &ecommand!"));
                player.sendMessage(MSG.chatColors("&eWe will help you setting up the full plugin!"));
                player.sendMessage(MSG.chatColors("&eDo you have any issues? Join our discord!"));
                player.sendMessage(MSG.chatColors("&ehttps://discord.gg/Ya6NwdEMd6"));
            }, 60L);
        }
        IgnoreCommand.loadIgnoredPlayers(event.getPlayer().getUniqueId());
        MemoryCommand.incrementJoins();
    }

    private void extractResource(String resourcePath, File outputFile) throws IOException {
        File parentDir = outputFile.getParentFile();
        if (!parentDir.exists()) {
            parentDir.mkdirs();
        }
        try (InputStream in = this.getResource(resourcePath);
             FileOutputStream out = new FileOutputStream(outputFile);){
            int bytesRead;
            if (in == null) {
                throw new IOException("Resource " + resourcePath + " not found!");
            }
            byte[] buffer = new byte[1024];
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }
    }

    public void printMoonStar() {
        Bukkit.getConsoleSender().sendMessage(" ");
        Bukkit.getConsoleSender().sendMessage("\u00a77\u00a7l\u256d\u2501\u256e\u256d\u2501\u256e\u2571\u2571\u2571\u2571\u2571\u2571\u2571\u2571\u256d\u2501\u2501\u2501\u256e\u256d\u256e\u2571\u2571\u2571\u2571\u2571\u2571\u256d\u2501\u2501\u2501\u256e\u256d\u256e\u2571\u2571\u2571\u2571\u2571\u256d\u256e");
        Bukkit.getConsoleSender().sendMessage("\u00a77\u00a7l\u2503\u2503\u2570\u256f\u2503\u2503\u2571\u2571\u2571\u2571\u2571\u2571\u2571\u2571\u2503\u256d\u2501\u256e\u2523\u256f\u2570\u256e\u2571\u2571\u2571\u2571\u2571\u2503\u256d\u2501\u256e\u2523\u256f\u2570\u256e\u2571\u2571\u2571\u2571\u2503\u2503");
        Bukkit.getConsoleSender().sendMessage("\u00a77\u00a7l\u2503\u256d\u256e\u256d\u256e\u2523\u2501\u2501\u2533\u2501\u2501\u2533\u2501\u256e\u2503\u2570\u2501\u2501\u254b\u256e\u256d\u254b\u2501\u2501\u2533\u2501\u256e\u2503\u2570\u2501\u2501\u254b\u256e\u256d\u254b\u256e\u256d\u2533\u2501\u256f\u2523\u2533\u2501\u2501\u2533\u2501\u2501\u256e");
        Bukkit.getConsoleSender().sendMessage("\u00a77\u00a7l\u2503\u2503\u2503\u2503\u2503\u2503\u256d\u256e\u2503\u256d\u256e\u2503\u256d\u256e\u254b\u2501\u2501\u256e\u2503\u2503\u2503\u2503\u256d\u256e\u2503\u256d\u256f\u2570\u2501\u2501\u256e\u2503\u2503\u2503\u2503\u2503\u2503\u2503\u256d\u256e\u2523\u252b\u256d\u256e\u2503\u2501\u2501\u252b");
        Bukkit.getConsoleSender().sendMessage("\u00a77\u00a7l\u2503\u2503\u2503\u2503\u2503\u2503\u2570\u256f\u2503\u2570\u256f\u2503\u2503\u2503\u2503\u2570\u2501\u256f\u2503\u2503\u2570\u252b\u256d\u256e\u2503\u2503\u2571\u2503\u2570\u2501\u256f\u2503\u2503\u2570\u252b\u2570\u256f\u2503\u2570\u256f\u2503\u2503\u2570\u256f\u2523\u2501\u2501\u2503");
        Bukkit.getConsoleSender().sendMessage("\u00a77\u00a7l\u2570\u256f\u2570\u256f\u2570\u253b\u2501\u2501\u253b\u2501\u2501\u253b\u256f\u2570\u253b\u2501\u2501\u2501\u256f\u2570\u2501\u253b\u256f\u2570\u253b\u256f\u2571\u2570\u2501\u2501\u2501\u256f\u2570\u2501\u253b\u2501\u2501\u253b\u2501\u2501\u253b\u253b\u2501\u2501\u253b\u2501\u2501\u256f");
        Bukkit.getConsoleSender().sendMessage(" ");
        Bukkit.getConsoleSender().sendMessage("\u00a77\u00a7l\u256d\u2501\u256e\u256d\u2501\u256e\u2571\u2571\u2571\u2571\u2571\u2571\u2571\u2571\u256d\u2501\u2501\u2501\u256e\u256d\u256e\u256d\u256e");
        Bukkit.getConsoleSender().sendMessage("\u00a77\u00a7l\u2503\u2503\u2570\u256f\u2503\u2503\u2571\u2571\u2571\u2571\u2571\u2571\u2571\u2571\u2503\u256d\u2501\u256e\u2503\u2503\u2503\u2503\u2503");
        Bukkit.getConsoleSender().sendMessage("\u00a77\u00a7l\u2503\u256d\u256e\u256d\u256e\u2523\u2501\u2501\u2533\u2501\u2501\u2533\u2501\u256e\u2503\u2570\u2501\u256f\u2523\u252b\u2503\u2503\u2503\u256d\u2501\u2501\u2533\u2501\u2533\u2501\u2501\u256e");
        Bukkit.getConsoleSender().sendMessage("\u00a77\u00a7l\u2503\u2503\u2503\u2503\u2503\u2503\u256d\u256e\u2503\u256d\u256e\u2503\u256d\u256e\u252b\u256d\u2501\u2501\u254b\u252b\u2503\u2503\u2503\u2503\u256d\u256e\u2503\u256d\u252b\u2501\u2501\u252b");
        Bukkit.getConsoleSender().sendMessage("\u00a77\u00a7l\u2503\u2503\u2503\u2503\u2503\u2503\u2570\u256f\u2503\u2570\u256f\u2503\u2503\u2503\u2503\u2503\u2571\u2571\u2503\u2503\u2570\u252b\u2570\u252b\u256d\u256e\u2503\u2503\u2523\u2501\u2501\u2503");
        Bukkit.getConsoleSender().sendMessage("\u00a77\u00a7l\u2570\u256f\u2570\u256f\u2570\u253b\u2501\u2501\u253b\u2501\u2501\u253b\u256f\u2570\u253b\u256f\u2571\u2571\u2570\u253b\u2501\u253b\u2501\u253b\u256f\u2570\u253b\u256f\u2570\u2501\u2501\u256f");
        Bukkit.getConsoleSender().sendMessage(" ");
    }

    public void onEnable() {
        instance = this;
        this.printMoonStar();
        this.getLogger().info("\u00a7eMoonPillars \u00a7c" + this.getDescription().getVersion());
        this.getLogger().info("\u00a7eMade with love by kloppie74!");
        this.getLogger().info("\u00a7cReport issues on the official discord!");
        this.getLogger().info("\u00a7bhttps://discord.gg/Ya6NwdEMd6");
        this.getLogger().info("\u00a7f");
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7fInitializing core systems...");
        SettingsManager.setup((Plugin)this);
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7fSetting up metrics...");
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7fExtracting required resources...");
        this.extractRequiredResources();
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7fChecking setup status...");
        this.handleFirstTimeSetup();
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7fRegistering event listeners...");
        this.registerCoreListeners();
        this.registerAdminListeners();
        this.registerGameListeners();
        this.registerCosmeticListeners();
        this.registerVanishListeners();
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7fRegistering commands...");
        this.registerCoreCommands();
        this.registerAdminCommands();
        this.registerChatCommands();
        this.registerGameCommands();
        this.registerCosmeticCommands();
        this.registerEasterEggCommands();
        this.registerVanishCommands();
        this.getCommand("refresh").setExecutor((CommandExecutor)new RefreshCommand(this));
        this.getCommand("refresh").setTabCompleter((TabCompleter)new RefreshCommand(this));
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7fSetting up integrations...");
        this.setupIntegrations();
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7fStarting scheduled tasks...");
        this.startScheduledTasks();
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7fChecking for updates...");
        this.checkUpdateSettings();
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7fPreparing game cache...");
        this.prepareGameCache();
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7fInitializing subsystems...");
        this.initializeSubsystems();
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7fInitializing weather manager...");
        this.worldTimeWeatherManager = new WorldTimeWeatherManager();
        if (this.worldTimeWeatherManager != null) {
            this.worldTimeWeatherManager.shutdown();
        }
        StatsCommand statsCommand = new StatsCommand();
        this.getCommand("stats").setExecutor((CommandExecutor)statsCommand);
        this.getCommand("stats").setTabCompleter((TabCompleter)statsCommand);
        DebugCommand debugCommand = new DebugCommand(this);
        this.getCommand("debug").setExecutor((CommandExecutor)debugCommand);
        this.getCommand("debug").setTabCompleter((TabCompleter)debugCommand);
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7fPlugin startup complete!");
        SpectatorInteractionHandler.registerEvents();
        SpectatorInventoryManager.registerEvents();
        this.initializeAddonsSystem();
        MoonPillarsTracker.getInstance().AtStartUp();
    }

    private void extractRequiredResources() {
        try {
            File placeholdersFile;
            File schematicFile;
            File zipFile = new File(this.getDataFolder(), "Storage/World.zip");
            if (!zipFile.exists()) {
                this.getLogger().info("\u00a7e[MoonPillars] \u00a7fExtracting World.zip...");
                this.extractResource("MCE/World.zip", zipFile);
            }
            if (!(schematicFile = new File(this.getDataFolder(), "Cages/Default1.schem")).exists()) {
                this.getLogger().info("\u00a7e[MoonPillars] \u00a7fExtracting Default1.schem...");
                this.extractResource("MCE/Default1.schem", schematicFile);
            }
            if (!(placeholdersFile = new File(this.getDataFolder(), "placeholders.txt")).exists()) {
                this.getLogger().info("\u00a7e[MoonPillars] \u00a7fExtracting placeholders.txt...");
                this.extractResource("placeholders.txt", placeholdersFile);
            }
            this.getLogger().info("\u00a7e[MoonPillars] \u00a7fResource extraction complete");
        }
        catch (IOException var4) {
            this.getLogger().severe("\u00a7c[MoonPillars] \u00a7fFailed to extract resources: " + var4.getMessage());
            var4.printStackTrace();
        }
    }

    private void handleFirstTimeSetup() {
        String setup2 = FirstSetupDB.getInstance().getSetting("SetupComplete");
        String serverID = FirstSetupDB.getInstance().getSetting("serverID");
        if (serverID != null && setup2 != null && !setup2.equalsIgnoreCase("true")) {
            String importData = FirstSetupDB.getInstance().getSetting("ImportData");
            if (importData != null && importData.equalsIgnoreCase("true")) {
                try {
                    File zipFile;
                    this.getLogger().info("\u00a7e[MoonPillars] \u00a7fImporting settings...");
                    File dataFolder = this.getDataFolder();
                    if (!dataFolder.exists()) {
                        dataFolder.mkdirs();
                    }
                    if (!(zipFile = new File(dataFolder, "ImportSettings.zip")).exists()) {
                        this.extractResource("MCE/ImportSettings.zip", zipFile);
                    }
                    this.unzipFile(zipFile, dataFolder);
                    if (zipFile.delete()) {
                        this.getLogger().info("\u00a7e[MoonPillars] \u00a7fImportSettings.zip has been deleted after successful extraction.");
                    } else {
                        this.getLogger().warning("\u00a7e[MoonPillars] \u00a7fFailed to delete ImportSettings.zip.");
                    }
                    this.getLogger().info("\u00a7e[MoonPillars] \u00a7fImportSettings.zip is successfully imported into your server!");
                    FirstSetupDB.getInstance().updateSetting("SetupComplete", "true");
                }
                catch (IOException var6) {
                    this.getLogger().severe("\u00a7c[MoonPillars] \u00a7fError importing settings: " + var6.getMessage());
                    var6.printStackTrace();
                }
            } else {
                FirstSetupDB.getInstance().updateSetting("SetupComplete", "true");
            }
        }
    }

    protected void registerCoreListeners() {
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Registering core listeners...");
        this.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new NewScoreboard(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new InventoryItemAPI(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new VoteListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new LevelMenuManager(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new MenuManager(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new LobbyProtectionListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new BlockedEvents(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new DatabaseManager(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new LocalCache(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new SpyCommand(), (Plugin)this);
        PortalListener portalListener = new PortalListener(this);
        this.getServer().getPluginManager().registerEvents((Listener)portalListener, (Plugin)this);
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Registering FlyCommand...");
        FlyCommand flyCommand = new FlyCommand();
        this.getCommand("fly").setExecutor((CommandExecutor)flyCommand);
        this.getCommand("fly").setTabCompleter((TabCompleter)flyCommand);
        StatsCommand statsCommand = new StatsCommand();
        this.getCommand("stats").setExecutor((CommandExecutor)statsCommand);
        this.getCommand("stats").setTabCompleter((TabCompleter)statsCommand);
    }

    protected void registerAdminListeners() {
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Registering admin listeners...");
        this.getServer().getPluginManager().registerEvents((Listener)new org.kloppie74.MoonPillars.PaperMC.Admin.AdminMenu.MenuManager(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new GameManager(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new RewardCommandEditorGUI(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new SetupMenu(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ClickableSignListener(this), (Plugin)this);
    }

    protected void registerGameListeners() {
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Registering game listeners...");
        this.getServer().getPluginManager().registerEvents((Listener)new TeamManagerMenu(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new EditorMenu(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new EditItems(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new VoteSetting(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new BedManager(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new EventListeners(), (Plugin)this);
    }

    protected void registerCosmeticListeners() {
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Registering cosmetic listeners...");
        this.getServer().getPluginManager().registerEvents((Listener)new ParticleEventBows(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ParticleEventKills(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new CosmeticGui(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new JoinHandler(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new EasterEggListener(), (Plugin)this);
    }

    protected void registerVanishListeners() {
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Registering vanish system listeners...");
        this.getServer().getPluginManager().registerEvents((Listener)new PlayerVisibilityListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new VanishInteractionListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new VanishMobTargetingListener(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new VanishCommand(), (Plugin)this);
    }

    protected void registerCoreCommands() {
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Registering core commands...");
        this.getCommand("memory").setExecutor((CommandExecutor)new MemoryCommand());
        this.getCommand("client").setExecutor((CommandExecutor)new ClientCommand());
        this.getCommand("client").setTabCompleter((TabCompleter)new ClientCommand());
        this.getCommand("toggleclientnotify").setExecutor((CommandExecutor)new ToggleClientNotifyCommand());
        this.getCommand("playtime").setExecutor((CommandExecutor)new PlayTime());
        this.getCommand("playtime").setTabCompleter((TabCompleter)new PlayTime());
        this.getCommand("level").setExecutor((CommandExecutor)new LevelCMD());
        this.getCommand("level").setTabCompleter((TabCompleter)new LevelCMD());
        this.getCommand("levelrewards").setExecutor((CommandExecutor)new LevelRewardsCMD());
        this.getCommand("chat").setExecutor((CommandExecutor)new ChatCommand());
        this.getCommand("chat").setTabCompleter((TabCompleter)new ChatCommand());
        this.getCommand("clearchat").setExecutor((CommandExecutor)new ClearChatCMD());
    }

    protected void registerAdminCommands() {
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Registering admin commands...");
        this.getCommand("mpa").setExecutor((CommandExecutor)new AdminCommandManager());
        this.getCommand("mpa").setTabCompleter((TabCompleter)new AdminCommandManager());
    }

    protected void registerChatCommands() {
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Registering chat commands...");
        this.getCommand("msgtoggle").setExecutor((CommandExecutor)new MSGToggleCommand());
        this.getCommand("msg").setExecutor((CommandExecutor)new MSGCommand());
        this.getCommand("msg").setTabCompleter((TabCompleter)new MSGCommand());
        this.getCommand("reply").setExecutor((CommandExecutor)new ReplyCommand());
        this.getCommand("spychat").setExecutor((CommandExecutor)new SpyChatCMD());
        this.getCommand("spycommand").setExecutor((CommandExecutor)new SpyCommand());
        this.getCommand("ignore").setExecutor((CommandExecutor)new IgnoreCommand());
        this.getCommand("ignore").setTabCompleter((TabCompleter)new IgnoreCommand());
        this.getCommand("tp").setExecutor((CommandExecutor)new TeleportCommand());
        this.getCommand("tp").setTabCompleter((TabCompleter)new TeleportCommand());
    }

    protected void registerGameCommands() {
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Registering game commands...");
        this.getCommand("joingame").setExecutor((CommandExecutor)new JoinGameCMD());
        this.getCommand("joingame").setTabCompleter((TabCompleter)new JoinGameCMD());
        this.getCommand("spectate").setExecutor((CommandExecutor)new Spectate());
        this.getCommand("spectate").setTabCompleter((TabCompleter)new Spectate());
        this.getCommand("party").setExecutor((CommandExecutor)new org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.CommandManager());
        this.getCommand("party").setTabCompleter((TabCompleter)new org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.CommandManager());
    }

    protected void registerVanishCommands() {
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Registering visibility commands...");
        this.getCommand("vanish").setExecutor((CommandExecutor)new VanishCommand());
        this.getCommand("hideme").setExecutor((CommandExecutor)new HideMeCommand());
        this.getCommand("hideothers").setExecutor((CommandExecutor)new HideOthersCommand());
        this.getCommand("showothers").setExecutor((CommandExecutor)new ShowOthersCommand());
        this.getCommand("showothers").setTabCompleter((TabCompleter)new ShowOthersCommand());
    }

    protected void registerCosmeticCommands() {
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Registering cosmetic commands...");
        this.getCommand("selectcosmetic").setExecutor((CommandExecutor)new SelectCosmeticCMD());
        this.getCommand("selectcosmetic").setTabCompleter((TabCompleter)new SelectCosmeticCMD());
    }

    protected void registerEasterEggCommands() {
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Registering easter egg commands...");
        EasterEggCommand.setup();
        this.getCommand("easteregg").setExecutor((CommandExecutor)new EasterEggCommand());
        this.getCommand("easteregg").setTabCompleter((TabCompleter)new EasterEggCommand());
    }

    private void initializeAddonsSystem() {
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Initializing Addons system...");
        File addonsFolder = new File(this.getDataFolder(), "Addons");
        this.addonsManager = new AddonsManager(this);
        this.addonsManager.loadAddons(addonsFolder);
        this.getCommand("addons").setExecutor((CommandExecutor)new AddonsCommand(this, this.addonsManager));
        this.getCommand("addons").setTabCompleter((TabCompleter)new AddonsCommand(this, this.addonsManager));
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Addons system initialized!");
    }

    private void setupIntegrations() {
        PlaceholderAPIPlugin placeHolderAPIPlugin = PlaceholderAPIPlugin.getInstance();
        if (placeHolderAPIPlugin != null && placeHolderAPIPlugin.isEnabled()) {
            this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Hooking into PlaceholderAPI...");
            new PlaceHolder().register();
        } else {
            this.getLogger().warning("\u00a7e[MoonPillars] \u00a7fPlaceholderAPI not found, some features will be limited.");
        }
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Setting up GUI systems...");
        MenuManager.registerMenuCommands();
        CommandManager.registerMenuCommands();
    }

    private void startScheduledTasks() {
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Starting scoreboard update task...");
        new BukkitRunnable(){

            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    NewScoreboard.createOrUpdateScoreboard(player);
                }
            }
        }.runTaskTimer((Plugin)this, 20L, 20L);
    }

    private void checkUpdateSettings() {
        FileConfiguration settings = SettingsManager.getInstance().getSettings();
        String autoUpdate = settings.getString("Settings.Auto-Update");
        if ("true".equalsIgnoreCase(autoUpdate)) {
            this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Checking for updates...");
            this.checkForUpdates();
        }
        settings.set("Settings.Plugin-Version", (Object)this.getDescription().getVersion());
        settings.set("Settings.ConfigFiles-Version", (Object)"8.1.0");
        settings.set("Settings.API-Version", (Object)"Release-8.1.0");
        SettingsManager.getInstance();
        SettingsManager.saveSettings("Settings");
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Updating configuration files...");
        try {
            File langFile = new File(this.getDataFolder(), "LangFiles/en.yml");
            ConfigUpdater.update((Plugin)this, "LangFiles/en.yml", langFile, ignoredSectionsMessagesYML);
            File settingsFile = new File(this.getDataFolder(), "Settings.yml");
            ConfigUpdater.update((Plugin)this, "Settings.yml", settingsFile, ignoredSectionsSettingsYML);
            this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Configuration files updated successfully");
        }
        catch (IOException var5) {
            this.getLogger().severe("\u00a7c[MoonPillars] \u00a7fFailed to update configuration files: " + var5.getMessage());
            var5.printStackTrace();
        }
    }

    private void prepareGameCache() {
        if (GameUtils.SCHEMATICS_FOLDER.exists()) {
            try {
                MoonLab.deleteDirectory(GameUtils.SCHEMATICS_FOLDER);
                this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Deleted existing GameCache folder");
            }
            catch (IOException var2) {
                this.getLogger().severe("\u00a7c[MoonPillars] \u00a7fError deleting GameCache folder: " + var2.getMessage());
                var2.printStackTrace();
            }
        }
        if (GameUtils.SCHEMATICS_FOLDER.mkdirs()) {
            this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Created new GameCache folder");
        } else {
            this.getLogger().warning("\u00a7e[MoonPillars] \u00a7fFailed to create GameCache folder");
        }
    }

    private void initializeSubsystems() {
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Initializing LocalCache...");
        LocalCache.onServerStart();
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Starting player visibility system...");
        PlayerVisibilityListener.startVisibilityTask();
        this.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Initializing client brand checker...");
        ClientBrandChecker.init();
    }

    private static void deleteDirectory(File directory) throws IOException {
        if (directory.exists()) {
            File[] files = directory.listFiles();
            if (files != null) {
                File[] var2 = files;
                int var3 = files.length;
                for (int var4 = 0; var4 < var3; ++var4) {
                    File file = var2[var4];
                    if (file.isDirectory()) {
                        MoonLab.deleteDirectory(file);
                        continue;
                    }
                    if (file.delete()) continue;
                    throw new IOException("Failed to delete file: " + String.valueOf(file));
                }
            }
            if (!directory.delete()) {
                throw new IOException("Failed to delete directory: " + String.valueOf(directory));
            }
        }
    }

    public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.setGameMode(GameMode.ADVENTURE);
        }
        PlayerVisibilityListener.shutdown();
        NewScoreboard.cleanup();
        ScoreHelper.cleanupCache();
        LocalCache.onServerStop();
        this.printMoonStar();
        Bukkit.getConsoleSender().sendMessage("\u00a7eMoonPillars \u00a7c" + MoonLab.getInstance().getDescription().getVersion());
        Bukkit.getConsoleSender().sendMessage("\u00a7eMade with love by kloppie74!");
        Bukkit.getConsoleSender().sendMessage("\u00a7cReport issues on the official discord!");
        Bukkit.getConsoleSender().sendMessage("\u00a7bhttps://wiki.moonstarstudios.xyz/discord");
        Bukkit.getConsoleSender().sendMessage("\u00a7f");
        MoonPillarsTracker.getInstance().AtServerStop();
    }

    private void checkForUpdates() {
        try {
            new UpdateChecker(this, 116071).getVersion(version -> {
                String currentVersion = this.getDescription().getVersion();
                if (this.isNewerVersion(currentVersion, (String)version)) {
                    Bukkit.getConsoleSender().sendMessage("\u00a7f");
                    Bukkit.getConsoleSender().sendMessage("\u00a7e\u00a7lMoonPillars \u00a7fhas found a newer version, Downloading this version...");
                    Bukkit.getConsoleSender().sendMessage("\u00a7rUpgrading from \u00a7e" + currentVersion + " \u00a7fTo \u00a7e" + version);
                    Bukkit.getConsoleSender().sendMessage("\u00a7f");
                    Bukkit.getConsoleSender().sendMessage("\u00a7f  Restart server to apply changes!");
                    Bukkit.getConsoleSender().sendMessage("\u00a7f");
                    MoonLab.updatePlugin(version);
                }
            });
        }
        catch (Exception var2) {
            this.getLogger().warning("Error while trying to look for new updates: " + var2.getMessage());
        }
    }

    private int extractVersionNumber(String version) {
        Matcher matcher = Pattern.compile("\\d+").matcher(version);
        return matcher.find() ? Integer.parseInt(matcher.group()) : 0;
    }

    public boolean isNewerVersion(String oldVersion, String newVersion) {
        int oldNum = this.extractVersionNumber(oldVersion);
        int newNum = this.extractVersionNumber(newVersion);
        return newNum > oldNum;
    }

    public static String getLatestVersion() {
        try {
            String var2;
            try (InputStream is = new URL("https://api.spigotmc.org/legacy/update.php?resource=116071").openStream();
                 Scanner scann = new Scanner(is);){
                var2 = scann.hasNext() ? scann.next() : "Unknown";
            }
            return var2;
        }
        catch (IOException var8) {
            Bukkit.getLogger().warning("Error while fetching latest version: " + var8.getMessage());
            return "Unknown";
        }
    }

    public static void updatePlugin(String latestVersion) {
        try {
            File oldPluginFile = new File(MoonLab.getInstance().getDataFolder().getParent(), "MoonPillars-papermc-" + MoonLab.getInstance().getDescription().getVersion() + ".jar");
            if (oldPluginFile.exists() && !oldPluginFile.delete()) {
                MoonLab.getInstance().getLogger().warning("Error while trying to delete old plugin jar");
            }
            String downloadUrl = "https://api.spiget.org/v2/resources/116071/download";
            URL url = new URL(downloadUrl);
            ReadableByteChannel rbc = Channels.newChannel(url.openStream());
            String var10002 = MoonLab.getInstance().getDataFolder().getParent();
            FileOutputStream fos = new FileOutputStream(var10002 + File.separator + "MoonPillars-papermc-" + latestVersion + ".jar");
            fos.getChannel().transferFrom(rbc, 0L, Long.MAX_VALUE);
            fos.close();
            rbc.close();
            MoonLab.getInstance().getLogger().info("Plugin updated to " + latestVersion + ". Restart the server/plugin to apply changes!");
        }
        catch (Exception var6) {
            MoonLab.getInstance().getLogger().warning("Error while trying to update plugin: " + var6.getMessage());
        }
    }

    public static void CheckUpdateSettings() {
        File LangFile = new File(MoonLab.getInstance().getDataFolder(), "LangFiles/en.yml");
        try {
            ConfigUpdater.update((Plugin)MoonLab.getInstance(), "LangFiles/en.yml", LangFile, ignoredSectionsMessagesYML);
        }
        catch (IOException var4) {
            var4.printStackTrace();
        }
        File SettingsFile = new File(MoonLab.getInstance().getDataFolder(), "Settings.yml");
        try {
            ConfigUpdater.update((Plugin)MoonLab.getInstance(), "Settings.yml", SettingsFile, ignoredSectionsSettingsYML);
        }
        catch (IOException var3) {
            var3.printStackTrace();
        }
    }

    private void unzipFile(File zipFile, File outputFolder) throws IOException {
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile));){
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                File newFile = new File(outputFolder, entry.getName());
                if (entry.isDirectory()) {
                    if (newFile.exists()) continue;
                    newFile.mkdirs();
                    continue;
                }
                new File(newFile.getParent()).mkdirs();
                try (FileOutputStream fos = new FileOutputStream(newFile);){
                    int length;
                    byte[] buffer = new byte[1024];
                    while ((length = zis.read(buffer)) > 0) {
                        fos.write(buffer, 0, length);
                    }
                }
            }
            zis.closeEntry();
        }
    }

    public AddonsManager getAddonsManager() {
        return this.addonsManager;
    }

    static {
        ignoredSectionsMessagesYML = Arrays.asList(new String[0]);
        ignoredSectionsSettingsYML = Arrays.asList(new String[0]);
    }

    private static class ThreadMonitor {
        private final JavaPlugin plugin;
        private final Map<Long, Thread> knownThreads = new HashMap<Long, Thread>();
        private BukkitRunnable monitorTask;
        private boolean running = false;

        public ThreadMonitor(JavaPlugin plugin) {
            this.plugin = plugin;
        }

        public void start() {
            if (!this.running) {
                Thread[] threads = new Thread[Thread.activeCount() * 2];
                Thread.enumerate(threads);
                Thread[] var2 = threads;
                int var3 = threads.length;
                for (int var4 = 0; var4 < var3; ++var4) {
                    Thread thread = var2[var4];
                    if (thread == null) continue;
                    this.knownThreads.put(thread.getId(), thread);
                }
                this.plugin.getLogger().info("Thread monitor started. Currently tracking " + this.knownThreads.size() + " threads.");
                this.monitorTask = new BukkitRunnable(){

                    public void run() {
                        this.checkForNewThreads();
                    }
                };
                this.monitorTask.runTaskTimer((Plugin)this.plugin, 200L, 200L);
                this.running = true;
                this.installThreadFactoryHook();
            }
        }

        private void installThreadFactoryHook() {
            try {
                ThreadFactory originalFactory = Executors.defaultThreadFactory();
                ThreadFactory var10000 = r -> {
                    Thread thread = originalFactory.newThread(r);
                    this.logNewThread(thread);
                    return thread;
                };
                this.plugin.getLogger().info("Thread factory hook installed");
            }
            catch (Exception var3) {
                this.plugin.getLogger().log(Level.WARNING, "Failed to install thread factory hook", var3);
            }
        }

        private void checkForNewThreads() {
            Thread[] threads = new Thread[Thread.activeCount() * 2];
            int count = Thread.enumerate(threads);
            for (int i = 0; i < count; ++i) {
                Thread thread = threads[i];
                if (thread == null || this.knownThreads.containsKey(thread.getId())) continue;
                this.logNewThread(thread);
                this.knownThreads.put(thread.getId(), thread);
            }
        }

        private void logNewThread(Thread thread) {
            String threadInfo = String.format("New server thread created - ID: %d, Name: %s, Group: %s, Priority: %d, State: %s, Daemon: %b, Stack: %s", thread.getId(), thread.getName(), thread.getThreadGroup() != null ? thread.getThreadGroup().getName() : "null", thread.getPriority(), thread.getState().name(), thread.isDaemon(), this.formatStackTrace(thread.getStackTrace()));
            this.plugin.getLogger().info(threadInfo);
        }

        private String formatStackTrace(StackTraceElement[] stackTrace) {
            if (stackTrace != null && stackTrace.length != 0) {
                StringBuilder sb = new StringBuilder();
                int limit = Math.min(5, stackTrace.length);
                for (int i = 0; i < limit; ++i) {
                    if (i > 0) {
                        sb.append(" <- ");
                    }
                    sb.append(stackTrace[i].getClassName()).append(".").append(stackTrace[i].getMethodName()).append(":").append(stackTrace[i].getLineNumber());
                }
                if (stackTrace.length > limit) {
                    sb.append(" (... ").append(stackTrace.length - limit).append(" more)");
                }
                return sb.toString();
            }
            return "No stack trace available";
        }

        public void shutdown() {
            if (this.running) {
                if (this.monitorTask != null) {
                    this.monitorTask.cancel();
                }
                this.plugin.getLogger().info("Thread monitor stopped. Tracked " + this.knownThreads.size() + " threads.");
                this.running = false;
            }
        }
    }
}

