/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.WebEditor;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.WebEditor.PlayerStatsSessionManager;

public class StatsCommand
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player target;
        if (args.length == 0) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "Console must specify a player: /stats <player>");
                return true;
            }
            target = (Player)sender;
        } else {
            target = Bukkit.getPlayer((String)args[0]);
            if (target == null) {
                sender.sendMessage(MSG.chatColors("&cPlayer &e" + args[0] + " &cis not online."));
                return true;
            }
        }
        String url = PlayerStatsSessionManager.sendPlayerStats(target);
        if (url == null) {
            sender.sendMessage(MSG.chatColors("&cFailed to send player stats. Please check the server logs for details."));
            return true;
        }
        String var10001 = target.getName();
        sender.sendMessage(MSG.chatColors("&eView stats for player &6" + var10001 + " &eat: &6" + url));
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (args.length == 1) {
            String partial = args[0].toLowerCase();
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (!player.getName().toLowerCase().startsWith(partial)) continue;
                completions.add(player.getName());
            }
        }
        return completions;
    }
}

