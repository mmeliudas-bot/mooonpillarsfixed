/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 */
package org.kloppie74.MoonPillars.PaperMC.WebEditor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public class WebEditorSessionManager {
    private static final Map<String, SessionData> sessions = new HashMap<String, SessionData>();
    private static final String WEBEDITOR_BASE_URL = "https://moonstarstudios.xyz/webeditor/moonpillars=sessionid=";
    private static final String BACKEND_API_BASE = "https://moonstarstudios.xyz/api/webeditor/session/";

    public static List<String> createSession(Player player, String token, JavaPlugin plugin) {
        List<FileEntry> fileEntries = WebEditorSessionManager.getAllValidYmlFileEntries(plugin.getDataFolder(), plugin.getDataFolder());
        ArrayList<String> filePaths = new ArrayList<String>();
        for (FileEntry entry : fileEntries) {
            filePaths.add(entry.path);
        }
        sessions.put(token, new SessionData(player.getUniqueId(), filePaths));
        WebEditorSessionManager.pushSessionToBackend(token, player.getUniqueId(), fileEntries);
        String url = WebEditorSessionManager.buildEditorUrl(token);
        player.sendMessage("\u00a7aOpen the webeditor: \u00a7b" + url);
        return filePaths;
    }

    private static String buildEditorUrl(String token) {
        return WEBEDITOR_BASE_URL + token;
    }

    private static List<FileEntry> getAllValidYmlFileEntries(File root, File folder) {
        ArrayList<FileEntry> entries = new ArrayList<FileEntry>();
        File[] files = folder.listFiles();
        if (files != null) {
            File[] var4 = files;
            int var5 = files.length;
            for (int var6 = 0; var6 < var5; ++var6) {
                File file = var4[var6];
                String relPath = root.toPath().relativize(file.toPath()).toString().replace("\\", "/");
                String relPathLower = relPath.toLowerCase(Locale.ROOT);
                if (relPathLower.startsWith("backups/") || relPathLower.startsWith("logs/") || relPathLower.startsWith("tasks/")) continue;
                if (file.isDirectory()) {
                    entries.addAll(WebEditorSessionManager.getAllValidYmlFileEntries(root, file));
                    continue;
                }
                if (!relPathLower.endsWith(".yml")) continue;
                String content = WebEditorSessionManager.safeReadFile(file);
                entries.add(new FileEntry(relPath, content));
            }
        }
        return entries;
    }

    private static String safeReadFile(File file) {
        try {
            StringBuilder sb = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader((InputStream)new FileInputStream(file), StandardCharsets.UTF_8));){
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
            }
            return sb.toString();
        }
        catch (IOException var7) {
            return "";
        }
    }

    private static void pushSessionToBackend(String token, UUID playerId, List<FileEntry> fileEntries) {
        Bukkit.getScheduler().runTaskAsynchronously((Plugin)JavaPlugin.getProvidingPlugin(WebEditorSessionManager.class), () -> {
            try {
                int code;
                URL url = new URL(BACKEND_API_BASE + token);
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setDoOutput(true);
                StringBuilder json = new StringBuilder();
                json.append("{");
                json.append("\"playerId\":\"").append(playerId).append("\",");
                json.append("\"files\":[");
                for (code = 0; code < fileEntries.size(); ++code) {
                    FileEntry entry = (FileEntry)fileEntries.get(code);
                    json.append("{");
                    json.append("\"path\":\"").append(WebEditorSessionManager.escapeJson(entry.path)).append("\",");
                    json.append("\"content\":\"").append(WebEditorSessionManager.escapeJson(entry.content)).append("\"");
                    json.append("}");
                    if (code >= fileEntries.size() - 1) continue;
                    json.append(",");
                }
                json.append("]}");
                try (OutputStream os = conn.getOutputStream();){
                    os.write(json.toString().getBytes(StandardCharsets.UTF_8));
                }
                code = conn.getResponseCode();
                if (code != 201 && code != 200) {
                    Bukkit.getLogger().warning("[MoonPillars] WebEditor API POST failed: " + code);
                }
            }
            catch (Exception var11) {
                Bukkit.getLogger().warning("[MoonPillars] WebEditor API POST error: " + var11.getMessage());
            }
        });
    }

    private static void fetchAndOverwriteFilesFromBackend(String token, JavaPlugin plugin) {
        Bukkit.getScheduler().runTaskAsynchronously((Plugin)plugin, () -> {
            try {
                URL url = new URL(BACKEND_API_BASE + token + "/files-with-content");
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");
                conn.setConnectTimeout(7000);
                conn.setReadTimeout(10000);
                int code = conn.getResponseCode();
                if (code != 200) {
                    Bukkit.getLogger().warning("[MoonPillars] WebEditor API GET files-with-content failed: " + code);
                    return;
                }
                StringBuilder response = new StringBuilder();
                try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));){
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                }
                List<FileEntry> entries = WebEditorSessionManager.parseFilesWithContentJson(response.toString());
                File dataFolder = plugin.getDataFolder();
                for (FileEntry entry : entries) {
                    File target = new File(dataFolder, entry.path);
                    File parent = target.getParentFile();
                    if (parent != null && !parent.exists()) {
                        parent.mkdirs();
                    }
                    try (OutputStreamWriter writer = new OutputStreamWriter((OutputStream)new FileOutputStream(target), StandardCharsets.UTF_8);){
                        writer.write(entry.content);
                    }
                }
                Bukkit.getLogger().info("[MoonPillars] WebEditor configs gesynchroniseerd vanuit webeditor backend (" + entries.size() + " files)");
            }
            catch (Exception var19) {
                Bukkit.getLogger().warning("[MoonPillars] WebEditor API fetch/overwrite error: " + var19.getMessage());
            }
        });
    }

    private static List<FileEntry> parseFilesWithContentJson(String json) {
        String[] objs;
        ArrayList<FileEntry> files = new ArrayList<FileEntry>();
        String segment = "\"files\":[";
        int idx = json.indexOf(segment);
        if (idx < 0) {
            return files;
        }
        String arr = json.substring(idx + segment.length());
        arr = arr.substring(0, arr.lastIndexOf("]"));
        String[] var6 = objs = arr.split("\\},\\{");
        int var7 = objs.length;
        for (int var8 = 0; var8 < var7; ++var8) {
            String obj = var6[var8];
            String o = obj.replace("{", "").replace("}", "");
            String[] parts = o.split(",\"content\":\"");
            if (parts.length != 2) continue;
            String path = parts[0].replaceFirst("\"path\":\"", "").replaceAll("\"$", "");
            String content = parts[1];
            content = content.replace("\\n", "\n").replace("\\r", "\r").replace("\\\"", "\"").replace("\\\\", "\\");
            files.add(new FileEntry(path, content));
        }
        return files;
    }

    private static String escapeJson(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }

    public static void handleWebEditorSave(Player player, String saveId) {
        Bukkit.getScheduler().runTask((Plugin)JavaPlugin.getProvidingPlugin(WebEditorSessionManager.class), () -> {
            player.performCommand("save " + saveId);
            player.sendMessage("\u00a7aConfig changes saved! (ID: " + saveId + ")");
            WebEditorSessionManager.fetchAndOverwriteFilesFromBackend(saveId, JavaPlugin.getProvidingPlugin(WebEditorSessionManager.class));
            WebEditorSessionManager.cleanupSessionOnBackend(saveId);
            WebEditorSessionManager.removeSession(saveId);
        });
    }

    private static void cleanupSessionOnBackend(String token) {
        Bukkit.getScheduler().runTaskAsynchronously((Plugin)JavaPlugin.getProvidingPlugin(WebEditorSessionManager.class), () -> {
            try {
                URL url = new URL(BACKEND_API_BASE + token + "/cleanup");
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(8000);
                int code = conn.getResponseCode();
                if (code != 200) {
                    Bukkit.getLogger().warning("[MoonPillars] WebEditor API CLEANUP failed: " + code);
                }
            }
            catch (Exception var4) {
                Bukkit.getLogger().warning("[MoonPillars] WebEditor API CLEANUP error: " + var4.getMessage());
            }
        });
    }

    public static UUID getPlayerId(String token) {
        SessionData data = sessions.get(token);
        return data != null ? data.playerId : null;
    }

    public static List<String> getSessionFiles(String token) {
        SessionData data = sessions.get(token);
        return data != null ? data.files : Collections.emptyList();
    }

    public static void removeSession(String token) {
        sessions.remove(token);
    }

    public static String openSession(String token) {
        return WebEditorSessionManager.buildEditorUrl(token);
    }

    private static class FileEntry {
        final String path;
        final String content;

        FileEntry(String path, String content) {
            this.path = path;
            this.content = content;
        }
    }

    private static class SessionData {
        private final UUID playerId;
        private final List<String> files;

        SessionData(UUID playerId, List<String> files) {
            this.playerId = playerId;
            this.files = files;
        }
    }
}

