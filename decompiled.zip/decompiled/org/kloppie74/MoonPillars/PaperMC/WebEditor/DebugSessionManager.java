/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  org.bukkit.Bukkit
 *  org.bukkit.Server
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginDescriptionFile
 *  org.bukkit.plugin.java.JavaPlugin
 */
package org.kloppie74.MoonPillars.PaperMC.WebEditor;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.java.JavaPlugin;

public class DebugSessionManager {
    private static final String LOG_PATH = "logs/latest.log";
    private static final String SERVER_PROPERTIES_PATH = "server.properties";
    private static final String PLUGIN_SETTINGS_PATH = "plugins/MoonPillars/Settings.yml";
    public static String recentException = "";

    public static String sendDebugInfo(Player player, String debugId, JsonObject debugData, JavaPlugin pluginInstance) {
        try {
            debugData.addProperty("osName", System.getProperty("os.name"));
            debugData.addProperty("osVersion", System.getProperty("os.version"));
            debugData.addProperty("javaVersion", System.getProperty("java.version"));
            debugData.addProperty("javaVendor", System.getProperty("java.vendor"));
            RuntimeMXBean mxBean = ManagementFactory.getRuntimeMXBean();
            long uptime = mxBean.getUptime();
            debugData.addProperty("serverUptime", (Number)uptime);
            Runtime rt = Runtime.getRuntime();
            debugData.addProperty("maxMemory", (Number)rt.maxMemory());
            debugData.addProperty("freeMemory", (Number)rt.freeMemory());
            debugData.addProperty("usedMemory", (Number)(rt.totalMemory() - rt.freeMemory()));
            debugData.addProperty("pluginVersion", pluginInstance.getDescription().getVersion());
            Server server = Bukkit.getServer();
            debugData.addProperty("serverVersion", server.getVersion());
            debugData.addProperty("serverSoftware", server.getName());
            JsonArray pluginsArray = new JsonArray();
            List<Plugin> allPlugins = Arrays.asList(Bukkit.getPluginManager().getPlugins());
            for (Plugin p : allPlugins) {
                JsonObject pluginObj = new JsonObject();
                PluginDescriptionFile desc = p.getDescription();
                pluginObj.addProperty("name", desc.getName());
                pluginObj.addProperty("version", desc.getVersion());
                pluginObj.addProperty("enabled", Boolean.valueOf(p.isEnabled()));
                pluginObj.addProperty("updateAvailable", Boolean.valueOf(false));
                pluginsArray.add((JsonElement)pluginObj);
            }
            debugData.add("pluginList", (JsonElement)pluginsArray);
            List<String> logLinesRaw = DebugSessionManager.readLastNLinesSimple(LOG_PATH, 750);
            List<String> logLines = logLinesRaw.stream().map(DebugSessionManager::maskIpAddresses).collect(Collectors.toList());
            JsonArray logArray = new JsonArray();
            for (String line : logLines) {
                logArray.add(line);
            }
            debugData.add("lastLogLines", (JsonElement)logArray);
            List<String> lastErrors = DebugSessionManager.extractLastErrorLines(logLines, 5);
            JsonArray errArray = new JsonArray();
            for (String line : lastErrors) {
                errArray.add(line);
            }
            debugData.add("recentErrors", (JsonElement)errArray);
            debugData.addProperty("recentException", recentException);
            debugData.addProperty("settingsSnapshot", DebugSessionManager.readWholeFile(PLUGIN_SETTINGS_PATH));
            JsonObject sProps = new JsonObject();
            Properties props = new Properties();
            try (FileInputStream in2 = new FileInputStream(SERVER_PROPERTIES_PATH);){
                String[] keys;
                props.load(in2);
                String[] var20 = keys = new String[]{"server-port", "max-players", "motd", "online-mode", "difficulty", "view-distance", "allow-flight"};
                int var21 = keys.length;
                for (int var22 = 0; var22 < var21; ++var22) {
                    String k = var20[var22];
                    if (!props.containsKey(k)) continue;
                    sProps.addProperty(k, props.getProperty(k));
                }
            }
            catch (Exception in2) {
                // empty catch block
            }
            debugData.add("serverProperties", (JsonElement)sProps);
            double tps = DebugSessionManager.getServerTPS();
            debugData.addProperty("tps", (Number)tps);
            String ip = Bukkit.getIp();
            if (ip == null || ip.isEmpty() || ip.equals("0.0.0.0")) {
                ip = DebugSessionManager.getExternalIpFallback();
            }
            debugData.addProperty("serverIp", ip);
            debugData.addProperty("serverPort", (Number)Bukkit.getPort());
            JsonArray worldsArray = new JsonArray();
            for (World world : Bukkit.getWorlds()) {
                JsonObject w = new JsonObject();
                w.addProperty("name", world.getName());
                w.addProperty("environment", world.getEnvironment().toString());
                w.addProperty("uuid", world.getUID().toString());
                w.addProperty("seed", (Number)world.getSeed());
                w.addProperty("players", (Number)world.getPlayers().size());
                w.addProperty("loadedChunks", (Number)world.getLoadedChunks().length);
                worldsArray.add((JsonElement)w);
            }
            debugData.add("loadedWorlds", (JsonElement)worldsArray);
            if (player != null) {
                debugData.addProperty("playerName", player.getName());
                debugData.addProperty("uuid", player.getUniqueId().toString());
                debugData.addProperty("location", player.getLocation().toString());
            }
            String urlStr = "https://moonstarstudios.xyz/api/debug=" + debugId;
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream();){
                os.write(debugData.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            if (code != 200 && code != 201) {
                Bukkit.getLogger().warning("[MoonPillars] Debug POST failed: " + code);
            }
            String resultUrl = "https://moonstarstudios.xyz/debug/" + debugId;
            return resultUrl;
        }
        catch (Exception var33) {
            Bukkit.getLogger().warning("[MoonPillars] Debug POST error: " + var33.getMessage());
            return null;
        }
    }

    private static List<String> readLastNLinesSimple(String filePath, int n) {
        ArrayList<String> lines = new ArrayList<String>();
        File file = new File(filePath);
        if (!file.exists()) {
            return lines;
        }
        try (RandomAccessFile raf = new RandomAccessFile(file, "r");){
            long fileLength = raf.length();
            long pos = fileLength - 1L;
            int lineCount = 0;
            StringBuilder sb = new StringBuilder();
            while (true) {
                if (pos < 0L || lineCount >= n) {
                    if (sb.length() > 0 && lineCount < n) {
                        lines.add(0, sb.reverse().toString());
                    }
                    break;
                }
                raf.seek(pos);
                char c = (char)raf.read();
                if (c == '\n') {
                    if (sb.length() > 0) {
                        lines.add(0, sb.reverse().toString());
                        sb.setLength(0);
                        ++lineCount;
                    }
                } else {
                    sb.append(c);
                }
                --pos;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return lines;
    }

    private static String maskIpAddresses(String logLine) {
        String out = logLine.replaceAll("\\[/[0-9a-fA-F\\.:]+(:\\d+)?\\]", "[/IP-HIDDEN$1]");
        out = out.replaceAll("/([0-9]{1,3}\\.){3}[0-9]{1,3}(:\\d+)?", "/IP-HIDDEN$2");
        out = out.replaceAll("/[a-fA-F0-9:]+(:\\d+)?", "/IP-HIDDEN$1");
        return out;
    }

    private static List<String> extractLastErrorLines(List<String> lines, int max) {
        Pattern p = Pattern.compile("\\b(ERROR|WARN|Exception|Throwable|Caused by:)\\b", 2);
        ArrayList<String> result = new ArrayList<String>();
        for (int i = lines.size() - 1; i >= 0 && result.size() < max; --i) {
            if (!p.matcher(lines.get(i)).find()) continue;
            result.add(0, lines.get(i));
        }
        return result;
    }

    private static String readWholeFile(String path) {
        File f = new File(path);
        if (!f.exists()) {
            return "";
        }
        try {
            String var5;
            try (BufferedReader br = new BufferedReader(new FileReader(f));){
                StringBuilder sb = new StringBuilder();
                while (true) {
                    String line;
                    if ((line = br.readLine()) == null) {
                        var5 = sb.toString();
                        break;
                    }
                    sb.append(line).append("\n");
                }
            }
            return var5;
        }
        catch (Exception var8) {
            return "";
        }
    }

    public static double getServerTPS() {
        try {
            Server server = Bukkit.getServer();
            Method getTPS = server.getClass().getMethod("getTPS", new Class[0]);
            double[] tps = (double[])getTPS.invoke((Object)server, new Object[0]);
            return tps.length > 0 ? tps[0] : -1.0;
        }
        catch (Exception var3) {
            return -1.0;
        }
    }

    private static String getExternalIpFallback() {
        try {
            InetAddress local = InetAddress.getLocalHost();
            String ip = local.getHostAddress();
            return !ip.startsWith("127.") && !ip.startsWith("192.168.") && !ip.startsWith("10.") && !ip.startsWith("172.") ? ip : ip + " (local)";
        }
        catch (Exception var2) {
            return "unknown";
        }
    }
}

