/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  org.bukkit.Bukkit
 *  org.bukkit.Statistic
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.WebEditor;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class PlayerStatsSessionManager {
    public static String sendPlayerStats(Player player) {
        try {
            UUID uuid = player.getUniqueId();
            String serverId = SettingsManager.getInstance().getSettings().getString("Settings.ServerID");
            if (serverId != null && !serverId.trim().isEmpty()) {
                Object resultUrl;
                int value;
                String var10000 = uuid.toString();
                String urlStr = "https://moonstarstudios.xyz/api/stats/player=" + var10000 + "&serverid=" + serverId;
                var10000 = uuid.toString();
                String skinUrl = "https://crafatar.com/skins/" + var10000.replace("-", "");
                JsonObject stats = new JsonObject();
                for (Statistic stat : Statistic.values()) {
                    try {
                        value = player.getStatistic(stat);
                        stats.addProperty(stat.name(), (Number)value);
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                }
                DatabaseManager db = DatabaseManager.getInstance();
                String[] settingKeys = new String[]{"Level", "XP", "Kills", "name", "wins", "total_played_games", "winstreak", "total_winstreak"};
                JsonObject settings = new JsonObject();
                String[] var22 = settingKeys;
                value = settingKeys.length;
                for (int var11 = 0; var11 < value; ++var11) {
                    String key = var22[var11];
                    resultUrl = db.getSetting(uuid, key);
                    if (resultUrl != null) {
                        settings.addProperty(key, ((String)resultUrl).toString());
                        continue;
                    }
                    settings.add(key, (JsonElement)null);
                }
                JsonObject body = new JsonObject();
                body.addProperty("playerName", player.getName());
                body.addProperty("uuid", uuid.toString());
                body.addProperty("skinUrl", skinUrl);
                body.add("stats", (JsonElement)stats);
                body.add("settings", (JsonElement)settings);
                body.addProperty("serverid", serverId);
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setDoOutput(true);
                try (OutputStream os = conn.getOutputStream();){
                    os.write(body.toString().getBytes("UTF-8"));
                }
                int code = conn.getResponseCode();
                if (code != 200 && code != 201) {
                    Bukkit.getLogger().warning("[MoonPillars] Player stats POST failed: " + code);
                }
                resultUrl = "https://moonstarstudios.xyz/player-stats/" + serverId + "/" + String.valueOf(uuid);
                return resultUrl;
            }
            Bukkit.getLogger().warning("[MoonPillars] ServerID is not set in the config! Player stats not sent.");
            return null;
        }
        catch (Exception var18) {
            Bukkit.getLogger().warning("[MoonPillars] Player stats POST error: " + var18.getMessage());
            return null;
        }
    }
}

