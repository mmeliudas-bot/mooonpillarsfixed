/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.scheduler.BukkitRunnable
 */
package org.kloppie74.MoonPillars.PaperMC.WebEditor;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class MoonPillarsTracker
implements Listener {
    private static MoonPillarsTracker instance;
    private static final String API_BASE_URL = "https://moonstarstudios.xyz/db/moonpillars";
    private static final String API_KEY = "QvLJN8UR4ZCAjwqaunThKPcmzMFS7gBxDksEW3HYf5py26e9bX";
    private BukkitRunnable heartbeatTask;

    private MoonPillarsTracker() {
    }

    public static MoonPillarsTracker getInstance() {
        if (instance == null) {
            instance = new MoonPillarsTracker();
        }
        return instance;
    }

    public void AtStartUp() {
        Bukkit.getPluginManager().registerEvents((Listener)this, Bukkit.getPluginManager().getPlugins()[0]);
        for (Player p : Bukkit.getOnlinePlayers()) {
            this.sendPlayerJoin(p.getUniqueId(), p.getName());
        }
        this.heartbeatTask = new BukkitRunnable(){

            public void run() {
                MoonPillarsTracker.this.sendServerHeartbeat();
            }
        };
        this.heartbeatTask.runTaskTimerAsynchronously(Bukkit.getPluginManager().getPlugins()[0], 0L, 1200L);
    }

    public void AtServerStop() {
        if (this.heartbeatTask != null) {
            this.heartbeatTask.cancel();
        }
        for (Player p : Bukkit.getOnlinePlayers()) {
            this.sendPlayerQuit(p.getUniqueId());
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        this.sendPlayerJoin(event.getPlayer().getUniqueId(), event.getPlayer().getName());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        this.sendPlayerQuit(event.getPlayer().getUniqueId());
    }

    private void sendPlayerJoin(UUID uuid, String playerName) {
        if (uuid != null && playerName != null && !playerName.isEmpty()) {
            this.sendPostRequest("https://moonstarstudios.xyz/db/moonpillars/save-player", String.format("{\"uuid\":\"%s\",\"playername\":\"%s\"}", uuid, playerName));
            this.sendPostRequest("https://moonstarstudios.xyz/db/moonpillars/save-online-player", String.format("{\"uuid\":\"%s\"}", uuid));
        }
    }

    private void sendPlayerQuit(UUID uuid) {
        if (uuid != null) {
            this.sendDeleteRequest("https://moonstarstudios.xyz/db/moonpillars/remove-offline-player?uuid=" + String.valueOf(uuid));
        }
    }

    private void sendServerHeartbeat() {
        try {
            String serverID = SettingsManager.getInstance().getSettings().getString("WebSettings.ServerName");
            String serverIP = SettingsManager.getInstance().getSettings().getString("WebSettings.IP");
            String serverBannerURL = SettingsManager.getInstance().getSettings().getString("WebSettings.BannerURL");
            String serverSoftware = Bukkit.getName();
            String version = Bukkit.getVersion();
            int port = Bukkit.getPort();
            int onlinePlayers = Bukkit.getOnlinePlayers().size();
            String status = Bukkit.getOnlineMode() ? "online" : "unknown";
            String json = String.format("{\"serverID\":\"%s\",\"serverName\":\"%s\",\"serverIP\":\"%s\",\"serverPort\":%d,\"serverBannerURL\":\"%s\",\"onlinePlayers\":%d,\"serverStatus\":\"%s\",\"serverSoftware\":\"%s\",\"version\":\"%s\"}", serverID, serverID, serverIP, port, serverBannerURL == null ? "" : serverBannerURL, onlinePlayers, status, serverSoftware, version);
            this.sendPostRequest("https://moonstarstudios.xyz/db/moonpillars/register-server", json);
            this.sendPostRequest("https://moonstarstudios.xyz/db/moonpillars/save-online-server", String.format("{\"serverID\":\"%s\"}", serverID));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void sendPostRequest(String urlString, String json) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setConnectTimeout(500);
            conn.setReadTimeout(750);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("X-API-KEY", API_KEY);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream();){
                os.write(json.getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            if (code == 200) {
                conn.getInputStream().close();
            }
            conn.disconnect();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void sendDeleteRequest(String urlString) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setConnectTimeout(500);
            conn.setReadTimeout(750);
            conn.setRequestMethod("DELETE");
            conn.setRequestProperty("X-API-KEY", API_KEY);
            int code = conn.getResponseCode();
            if (code == 200) {
                conn.getInputStream().close();
            }
            conn.disconnect();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}

