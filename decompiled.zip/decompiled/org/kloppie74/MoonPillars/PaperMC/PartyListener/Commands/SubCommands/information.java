/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommand;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.PartyStaticClass;

public class information
extends SubCommand {
    @Override
    public String getName() {
        return "information";
    }

    @Override
    public String getDescription() {
        return "Information about your party!";
    }

    @Override
    public String getSyntax() {
        return "/party information";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("party.information")) {
            if (args.length >= 2) {
                Player playerTarget = Bukkit.getPlayer((String)args[1]);
                if (playerTarget != null) {
                    UUID partyOwnerUUID = PartyStaticClass.getPlayerPartyOwner(playerTarget);
                    if (partyOwnerUUID != null) {
                        this.sendPartyInfo(player, partyOwnerUUID);
                    } else {
                        MessageSender.SendMessage(player, "Party.Other-Player-Not-In-Party", "{player}", playerTarget.getName());
                    }
                } else {
                    MessageSender.SendMessage(player, "Party.Player-Not-Found", "", "");
                }
            } else {
                UUID partyOwnerUUID = PartyStaticClass.getPlayerPartyOwner(player);
                if (partyOwnerUUID != null) {
                    this.sendPartyInfo(player, partyOwnerUUID);
                } else {
                    MessageSender.SendMessage(player, "Party.Not-In-Party", "", "");
                }
            }
        } else {
            MessageSender.SendMessage(player, "Party.No-Partyinfo-Permission", "", "");
        }
    }

    private void sendPartyInfo(Player player, UUID partyOwnerUUID) {
        Map<UUID, List<Player>> partyMembersMap = PartyStaticClass.PartyMembers;
        Map<UUID, List<Player>> partyBannedPlayersMap = PartyStaticClass.PartyBannedPlayers;
        Map<UUID, Boolean> partyPublicMap = PartyStaticClass.PartyPublic;
        Map<UUID, Integer> partyMaxMembersMap = PartyStaticClass.PartyMaxMembers;
        if (partyMembersMap.containsKey(partyOwnerUUID) && partyPublicMap.containsKey(partyOwnerUUID) && partyMaxMembersMap.containsKey(partyOwnerUUID)) {
            List<Player> partyMembers = partyMembersMap.get(partyOwnerUUID);
            ArrayList<String> playerNames = new ArrayList<String>();
            for (Player partyPlayer : partyMembers) {
                playerNames.add(partyPlayer.getName());
            }
            List bannedPlayers = partyBannedPlayersMap.getOrDefault(partyOwnerUUID, new ArrayList());
            ArrayList<String> playerBannedNames = new ArrayList<String>();
            for (Player bannedPlayer : bannedPlayers) {
                playerBannedNames.add(bannedPlayer.getName());
            }
            Player partyOwner = Bukkit.getPlayer((UUID)partyOwnerUUID);
            if (partyOwner == null) {
                MessageSender.SendMessage(player, "Party.Owner-Not-Found", "", "");
                return;
            }
            String partyOwnerName = partyOwner.getName();
            boolean isPublic = partyPublicMap.get(partyOwnerUUID);
            int memberCount = partyMembers.size();
            int maxMembers = partyMaxMembersMap.get(partyOwnerUUID);
            List messages = SettingsManager.getInstance().getLang().getStringList("Party.Information");
            for (String message : messages) {
                message = message.replace("%partyowner%", partyOwnerName).replace("%ispublic%", String.valueOf(isPublic)).replace("%membercount%", String.valueOf(memberCount)).replace("%maxmembers%", String.valueOf(maxMembers)).replace("%members%", String.join((CharSequence)", ", playerNames)).replace("%banned%", String.join((CharSequence)", ", playerBannedNames));
                player.sendMessage(MSG.chatColors(message));
            }
        } else {
            MessageSender.SendMessage(player, "Party.Not-In-Party", "", "");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            completions.add("information");
        }
        Collections.sort(completions);
        return completions;
    }
}

