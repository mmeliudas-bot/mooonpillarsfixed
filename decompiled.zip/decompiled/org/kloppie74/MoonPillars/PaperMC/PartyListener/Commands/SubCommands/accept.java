/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommand;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.PartyStaticClass;

public class accept
extends SubCommand {
    @Override
    public String getName() {
        return "accept";
    }

    @Override
    public String getDescription() {
        return "Accept a Party invite!";
    }

    @Override
    public String getSyntax() {
        return "/party accept <player>";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("party.accept")) {
            if (args.length == 2) {
                Player targetPlayer = Bukkit.getPlayer((String)args[1]);
                if (targetPlayer == null) {
                    player.sendMessage(MSG.chatColors("&cPlayer not found."));
                    return;
                }
                if (!PartyStaticClass.PlayerPartyOwner.containsKey(targetPlayer.getUniqueId())) {
                    player.sendMessage(MSG.chatColors("&cThe player you specified is not in a party."));
                    return;
                }
                PartyStaticClass.acceptPartyInvite(player, targetPlayer);
            } else {
                player.sendMessage(MSG.chatColors("&cUsage: " + this.getSyntax()));
            }
        } else {
            MessageSender.SendMessage(player, "Party.No-Accept-Permission", "", "");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            completions.add("accept");
        }
        Collections.sort(completions);
        return completions;
    }
}

