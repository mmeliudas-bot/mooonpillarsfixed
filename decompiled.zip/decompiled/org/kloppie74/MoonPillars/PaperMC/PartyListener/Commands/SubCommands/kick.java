/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommand;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.PartyStaticClass;

public class kick
extends SubCommand {
    @Override
    public String getName() {
        return "kick";
    }

    @Override
    public String getDescription() {
        return "Kick a party member!";
    }

    @Override
    public String getSyntax() {
        return "/party kick <player>";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("party.kick")) {
            if (args.length == 2) {
                UUID partyOwnerUUID = PartyStaticClass.getPlayerPartyOwner(player);
                if (partyOwnerUUID == null) {
                    MessageSender.SendMessage(player, "Party.Not-In-Party", "", "");
                    return;
                }
                if (!player.getUniqueId().equals(partyOwnerUUID)) {
                    MessageSender.SendMessage(player, "Party.Not-Owner", "", "");
                    return;
                }
                Player targetPlayer = Bukkit.getPlayer((String)args[1]);
                if (targetPlayer == null) {
                    MessageSender.SendMessage(player, "Party.Player-Not-Found", "", "");
                    return;
                }
                PartyStaticClass.kickUser(player, targetPlayer);
            } else {
                MessageSender.SendMessage(player, "Party.kick-usage", "", "");
            }
        } else {
            MessageSender.SendMessage(player, "Party.No-Kick-Permission", "", "");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            completions.add("kick");
        }
        Collections.sort(completions);
        return completions;
    }
}

