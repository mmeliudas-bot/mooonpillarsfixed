/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommand;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.PartyStaticClass;

public class join
extends SubCommand {
    @Override
    public String getName() {
        return "join";
    }

    @Override
    public String getDescription() {
        return "Join a public party!";
    }

    @Override
    public String getSyntax() {
        return "/party join <player>";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("party.join")) {
            if (args.length == 2) {
                Player playerTarget = Bukkit.getPlayer((String)args[1]);
                if (playerTarget != null) {
                    UUID partyOwnerUUID = PartyStaticClass.getPlayerPartyOwner(playerTarget);
                    if (partyOwnerUUID != null) {
                        PartyStaticClass.joinPublicParty(player, partyOwnerUUID);
                    } else {
                        MessageSender.SendMessage(player, "Party.Not-In-Party", "", "");
                    }
                } else {
                    MessageSender.SendMessage(player, "Party.Player-Not-Found", "", "");
                }
            } else {
                MessageSender.SendMessage(player, "Party.join-usage", "", "");
            }
        } else {
            MessageSender.SendMessage(player, "Party.No-Join-Permission", "", "");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            completions.add("join");
        }
        Collections.sort(completions);
        return completions;
    }
}

