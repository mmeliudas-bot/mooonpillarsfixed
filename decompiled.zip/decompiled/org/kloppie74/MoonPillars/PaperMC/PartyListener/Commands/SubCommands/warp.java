/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommand;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.PartyStaticClass;

public class warp
extends SubCommand {
    @Override
    public String getName() {
        return "warp";
    }

    @Override
    public String getDescription() {
        return "Warp to the current-party game!";
    }

    @Override
    public String getSyntax() {
        return "/party warp";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("party.warp")) {
            PartyStaticClass.WarpPlayer(player);
        } else {
            MessageSender.SendMessage(player, "Party.No-Warp-Permission", "", "");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            completions.add("warp");
        }
        Collections.sort(completions);
        return completions;
    }
}

