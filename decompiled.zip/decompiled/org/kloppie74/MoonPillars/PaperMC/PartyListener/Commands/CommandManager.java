/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommand;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands.accept;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands.ban;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands.create;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands.disband;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands.information;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands.invite;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands.join;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands.kick;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands.leave;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands.setLeader;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands.setpublic;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands.unban;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands.warp;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.PartyStaticClass;

public class CommandManager
implements CommandExecutor,
TabCompleter {
    private final List<SubCommand> subcommands = new ArrayList<SubCommand>();

    public CommandManager() {
        this.subcommands.add(new create());
        this.subcommands.add(new invite());
        this.subcommands.add(new accept());
        this.subcommands.add(new ban());
        this.subcommands.add(new unban());
        this.subcommands.add(new information());
        this.subcommands.add(new setLeader());
        this.subcommands.add(new leave());
        this.subcommands.add(new kick());
        this.subcommands.add(new disband());
        this.subcommands.add(new setpublic());
        this.subcommands.add(new join());
        this.subcommands.add(new warp());
    }

    public SubCommand getSubCommand(String name) {
        SubCommand subCommand;
        Iterator<SubCommand> var2 = this.subcommands.iterator();
        do {
            if (var2.hasNext()) continue;
            return null;
        } while (!(subCommand = var2.next()).getName().equalsIgnoreCase(name));
        return subCommand;
    }

    public static void SendUsage(Player player) {
        List messages = SettingsManager.getInstance().getLang().getStringList("Party.Usage");
        for (String message : messages) {
            player.sendMessage(MSG.chatColors(message));
        }
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length > 0) {
                SubCommand subCommand = this.getSubCommand(args[0]);
                if (subCommand != null) {
                    subCommand.perform(player, args);
                    return true;
                }
                CommandManager.SendUsage(player);
                return true;
            }
            CommandManager.SendUsage(player);
            return true;
        }
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        Player player = (Player)sender;
        if (args.length == 1) {
            String currentArg = args[0].toLowerCase();
            for (SubCommand subCommand : this.subcommands) {
                String subCommandName = subCommand.getName().toLowerCase();
                if (!subCommandName.startsWith(currentArg)) continue;
                completions.add(subCommandName);
            }
        } else if (args.length == 2) {
            String currentArg = args[0].toLowerCase();
            String partialName = args[1].toLowerCase();
            int var17 = -1;
            switch (currentArg.hashCode()) {
                case -1423461112: {
                    if (!currentArg.equals("accept")) break;
                    var17 = 4;
                    break;
                }
                case -1183699191: {
                    if (!currentArg.equals("invite")) break;
                    var17 = 0;
                    break;
                }
                case 97295: {
                    if (!currentArg.equals("ban")) break;
                    var17 = 2;
                    break;
                }
                case 3267882: {
                    if (!currentArg.equals("join")) break;
                    var17 = 3;
                    break;
                }
                case 3291718: {
                    if (!currentArg.equals("kick")) break;
                    var17 = 1;
                    break;
                }
                case 111426262: {
                    if (!currentArg.equals("unban")) break;
                    var17 = 7;
                    break;
                }
                case 1290776555: {
                    if (!currentArg.equals("setleader")) break;
                    var17 = 6;
                    break;
                }
                case 1420107083: {
                    if (!currentArg.equals("setpublic")) break;
                    var17 = 8;
                    break;
                }
                case 1968600364: {
                    if (!currentArg.equals("information")) break;
                    var17 = 5;
                }
            }
            switch (var17) {
                case 0: 
                case 1: 
                case 2: 
                case 3: 
                case 4: 
                case 5: {
                    for (Player target : Bukkit.getOnlinePlayers()) {
                        if (!target.getName().toLowerCase().startsWith(partialName)) continue;
                        completions.add(target.getName());
                    }
                    break;
                }
                case 6: {
                    List<Player> partyMembers;
                    UUID partyOwnerUUID = PartyStaticClass.getPlayerPartyOwner(player);
                    if (partyOwnerUUID != null && (partyMembers = PartyStaticClass.PartyMembers.get(partyOwnerUUID)) != null) {
                        for (Player partyPlayer : partyMembers) {
                            if (!partyPlayer.getName().toLowerCase().startsWith(partialName)) continue;
                            completions.add(partyPlayer.getName());
                        }
                    }
                    break;
                }
                case 7: {
                    List<Player> bannedPlayers;
                    String gameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
                    if (gameID != null && (bannedPlayers = PartyStaticClass.PartyBannedPlayers.get(gameID)) != null) {
                        for (Player bannedPlayer : bannedPlayers) {
                            if (bannedPlayer == null || bannedPlayer.getName() == null) continue;
                            completions.add(bannedPlayer.getName());
                        }
                    }
                    break;
                }
                case 8: {
                    completions.add("true");
                    completions.add("false");
                }
            }
        }
        Collections.sort(completions);
        return completions;
    }
}

