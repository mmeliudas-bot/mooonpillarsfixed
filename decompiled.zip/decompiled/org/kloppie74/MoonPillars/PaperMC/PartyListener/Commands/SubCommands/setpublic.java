/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommand;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.PartyStaticClass;

public class setpublic
extends SubCommand {
    @Override
    public String getName() {
        return "setpublic";
    }

    @Override
    public String getDescription() {
        return "Set your party public!";
    }

    @Override
    public String getSyntax() {
        return "/party setpublic <true|false>";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("party.setpublic")) {
            if (args.length == 2) {
                PartyStaticClass.setPublic(player, Boolean.parseBoolean(args[1]));
            } else {
                MessageSender.SendMessage(player, "Party.setpublic-usage", "", "");
            }
        } else {
            MessageSender.SendMessage(player, "Party.No-SetPublic-Permission", "", "");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            completions.add("setpublic");
        }
        Collections.sort(completions);
        return completions;
    }
}

