/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommand;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.PartyStaticClass;

public class invite
extends SubCommand {
    @Override
    public String getName() {
        return "invite";
    }

    @Override
    public String getDescription() {
        return "Invite a player!";
    }

    @Override
    public String getSyntax() {
        return "/party invite <player>";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("party.invite")) {
            if (args.length == 2) {
                Player invitedPlayer = Bukkit.getPlayer((String)args[1]);
                if (invitedPlayer != null) {
                    PartyStaticClass.invitePlayer(player, invitedPlayer);
                } else {
                    MessageSender.SendMessage(player, "Party.Player-Not-Found", "", "");
                }
            } else {
                MessageSender.SendMessage(player, "Party.invite-usage", "", "");
            }
        } else {
            MessageSender.SendMessage(player, "Party.No-Invite-Permission", "", "");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            completions.add("invite");
        }
        Collections.sort(completions);
        return completions;
    }
}

