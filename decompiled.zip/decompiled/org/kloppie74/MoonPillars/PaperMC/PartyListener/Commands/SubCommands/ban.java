/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommand;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.PartyStaticClass;

public class ban
extends SubCommand {
    @Override
    public String getName() {
        return "ban";
    }

    @Override
    public String getDescription() {
        return "Ban a Party member!";
    }

    @Override
    public String getSyntax() {
        return "/party ban <player>";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("party.ban")) {
            if (args.length == 2) {
                UUID partyID = PartyStaticClass.getPlayerPartyOwner(player);
                if (partyID == null) {
                    MessageSender.SendMessage(player, "Party.Not-In-Party", "", "");
                    return;
                }
                if (!player.getUniqueId().equals(partyID)) {
                    MessageSender.SendMessage(player, "Party.Not-Owner", "", "");
                    return;
                }
                Player target = Bukkit.getPlayer((String)args[1]);
                if (target == null) {
                    MessageSender.SendMessage(player, "Party.Player-Not-Found", "", "");
                    return;
                }
                PartyStaticClass.banUser(player, target);
            } else {
                MessageSender.SendMessage(player, "Party.ban-usage", "", "");
            }
        } else {
            MessageSender.SendMessage(player, "Party.No-Ban-Permission", "", "");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            completions.add("ban");
        }
        Collections.sort(completions);
        return completions;
    }
}

