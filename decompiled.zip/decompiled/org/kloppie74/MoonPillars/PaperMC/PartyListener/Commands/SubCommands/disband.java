/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommands;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.Commands.SubCommand;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.PartyStaticClass;

public class disband
extends SubCommand {
    @Override
    public String getName() {
        return "disband";
    }

    @Override
    public String getDescription() {
        return "Disband a party!";
    }

    @Override
    public String getSyntax() {
        return "/party disband";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("party.disband")) {
            UUID partyOwnerUUID = PartyStaticClass.getPlayerPartyOwner(player);
            if (partyOwnerUUID == null) {
                MessageSender.SendMessage(player, "Party.Not-In-Party", "", "");
                return;
            }
            if (!player.getUniqueId().equals(partyOwnerUUID)) {
                MessageSender.SendMessage(player, "Party.Not-Owner", "", "");
                return;
            }
            PartyStaticClass.disbandParty(partyOwnerUUID);
        } else {
            MessageSender.SendMessage(player, "Party.No-Disband-Permission", "", "");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            completions.add("disband");
        }
        Collections.sort(completions);
        return completions;
    }
}

