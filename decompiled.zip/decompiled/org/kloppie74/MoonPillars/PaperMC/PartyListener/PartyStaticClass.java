/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.chat.BaseComponent
 *  net.md_5.bungee.api.chat.ClickEvent
 *  net.md_5.bungee.api.chat.ClickEvent$Action
 *  net.md_5.bungee.api.chat.ComponentBuilder
 *  net.md_5.bungee.api.chat.HoverEvent
 *  net.md_5.bungee.api.chat.HoverEvent$Action
 *  net.md_5.bungee.api.chat.TextComponent
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.PartyListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.Spectate;

public class PartyStaticClass {
    public static Map<UUID, UUID> PlayerPartyOwner = new HashMap<UUID, UUID>();
    public static Map<UUID, Boolean> PartyPublic = new HashMap<UUID, Boolean>();
    public static Map<UUID, Integer> PartyMaxMembers = new HashMap<UUID, Integer>();
    public static Map<UUID, List<Player>> PartyMembers = new HashMap<UUID, List<Player>>();
    public static Map<UUID, List<Player>> PartyBannedPlayers = new HashMap<UUID, List<Player>>();
    public static Map<UUID, UUID> PartyInvites = new HashMap<UUID, UUID>();
    public static List<UUID> PublicParties = new ArrayList<UUID>();

    public static UUID getPlayerPartyOwner(Player player) {
        return PlayerPartyOwner.get(player.getUniqueId());
    }

    public static void setPublic(Player player, boolean isPublic) {
        UUID partyOwner = PartyStaticClass.getPlayerPartyOwner(player);
        if (partyOwner == null) {
            MessageSender.SendMessage(player, "Party.Not-In-Party", "", "");
        } else if (!player.getUniqueId().equals(partyOwner)) {
            MessageSender.SendMessage(player, "Party.Not-Owner", "", "");
        } else {
            PartyPublic.put(partyOwner, isPublic);
            if (isPublic) {
                if (!PublicParties.contains(partyOwner)) {
                    PublicParties.add(partyOwner);
                }
                MessageSender.SendMessage(player, "Party.Set-To-Public", "", "");
            } else {
                PublicParties.remove(partyOwner);
                MessageSender.SendMessage(player, "Party.Set-To-Private", "", "");
            }
        }
    }

    public static void leaveParty(Player player) {
        UUID partyOwner = PartyStaticClass.getPlayerPartyOwner(player);
        if (partyOwner == null) {
            MessageSender.SendMessage(player, "Party.Not-In-Party", "", "");
        } else if (player.getUniqueId().equals(partyOwner)) {
            MessageSender.SendMessage(player, "Party.Cannot-Leave-Own-Party", "", "");
        } else {
            List<Player> partyMembers = PartyMembers.get(partyOwner);
            if (partyMembers != null && partyMembers.contains(player)) {
                partyMembers.remove(player);
                PlayerPartyOwner.remove(player.getUniqueId());
                MessageSender.SendMessage(player, "Party.Left-Party", "", "");
                for (Player partyPlayer : partyMembers) {
                    if (partyPlayer == null) continue;
                    MessageSender.SendMessage(partyPlayer, "Party.Member-Left-Party", "{player}", player.getName());
                }
            } else {
                MessageSender.SendMessage(player, "Party.Error-Occurred", "", "");
            }
        }
    }

    public static void WarpPlayer(Player player) {
        UUID partyOwner = PartyStaticClass.getPlayerPartyOwner(player);
        if (partyOwner == null) {
            MessageSender.SendMessage(player, "Party.Not-In-Party", "", "");
        } else {
            String PlayerGameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
            if (PlayerGameID != null) {
                MessageSender.SendMessage(player, "Party.In-Game-Cannot-Spectate", "", "");
            } else {
                String OwnerGameID = HashMapHandler.getPlayerGameID(partyOwner);
                if (OwnerGameID != null) {
                    Spectate.SpectateGameID(player, OwnerGameID);
                }
            }
        }
    }

    public static void banUser(Player player, Player target) {
        UUID partyOwner = PartyStaticClass.getPlayerPartyOwner(player);
        UUID targetUUID = target.getUniqueId();
        if (partyOwner == null) {
            MessageSender.SendMessage(player, "Party.Not-In-Party", "", "");
        } else if (targetUUID.equals(partyOwner)) {
            MessageSender.SendMessage(player, "Party.Cannot-Ban-Owner", "", "");
        } else {
            List<Player> partyMembers = PartyMembers.get(partyOwner);
            if (partyMembers != null && partyMembers.contains(target)) {
                partyMembers.remove(target);
                PlayerPartyOwner.remove(targetUUID);
            }
            PartyBannedPlayers.computeIfAbsent(partyOwner, k -> new ArrayList()).add(target);
            MessageSender.SendMessage(player, "Party.Banned-Player", "{target}", target.getName());
            MessageSender.SendMessage(target, "Party.Banned-By-Player", "{player}", player.getName());
        }
    }

    public static void kickUser(Player player, Player target) {
        UUID partyOwner = PartyStaticClass.getPlayerPartyOwner(player);
        UUID targetUUID = target.getUniqueId();
        if (partyOwner == null) {
            MessageSender.SendMessage(player, "Party.Not-In-Party", "", "");
        } else if (targetUUID.equals(partyOwner)) {
            MessageSender.SendMessage(player, "Party.Cannot-Kick-Owner", "", "");
        } else {
            List<Player> partyMembers = PartyMembers.get(partyOwner);
            if (partyMembers != null && partyMembers.contains(target)) {
                partyMembers.remove(target);
                PlayerPartyOwner.remove(targetUUID);
                MessageSender.SendMessage(player, "Party.Kicked-Player", "{target}", target.getName());
                MessageSender.SendMessage(target, "Party.Kicked-By-Player", "{player}", player.getName());
            }
        }
    }

    public static void disbandParty(UUID partyOwner) {
        List<Player> partyMembers = PartyMembers.get(partyOwner);
        if (partyMembers != null) {
            for (Player partyPlayer : partyMembers) {
                if (partyPlayer == null) continue;
                PlayerPartyOwner.remove(partyPlayer.getUniqueId());
                MessageSender.SendMessage(partyPlayer, "Party.Disbanded", "", "");
            }
        }
        PartyPublic.remove(partyOwner);
        PartyMaxMembers.remove(partyOwner);
        PartyMembers.remove(partyOwner);
        PartyBannedPlayers.remove(partyOwner);
        PublicParties.remove(partyOwner);
    }

    public static void onPlayerDisconnect(Player player) {
        UUID playerUUID = player.getUniqueId();
        UUID partyOwner = PartyStaticClass.getPlayerPartyOwner(player);
        if (partyOwner != null) {
            if (partyOwner.equals(playerUUID)) {
                List<Player> members = PartyMembers.get(partyOwner);
                if (members != null && members.size() > 1) {
                    PartyStaticClass.findNewPartyOwner(partyOwner);
                } else {
                    PartyStaticClass.disbandParty(partyOwner);
                }
            } else {
                PartyStaticClass.leaveParty(player);
            }
        }
        PartyInvites.remove(playerUUID);
    }

    public static void setPartyOwner(UUID oldOwner, Player newOwner) {
        List<Player> bannedPlayers;
        UUID newOwnerUUID = newOwner.getUniqueId();
        if (PartyMembers.containsKey(oldOwner)) {
            bannedPlayers = PartyMembers.remove(oldOwner);
            bannedPlayers.removeIf(p -> p == null || p.getUniqueId().equals(oldOwner));
            if (!bannedPlayers.contains(newOwner)) {
                bannedPlayers.add(newOwner);
            }
            PartyMembers.put(newOwnerUUID, bannedPlayers);
        }
        if (PartyBannedPlayers.containsKey(oldOwner)) {
            bannedPlayers = PartyBannedPlayers.remove(oldOwner);
            PartyBannedPlayers.put(newOwnerUUID, bannedPlayers);
        }
        if (PartyPublic.containsKey(oldOwner)) {
            boolean isPublic = PartyPublic.remove(oldOwner);
            PartyPublic.put(newOwnerUUID, isPublic);
            if (isPublic) {
                PublicParties.remove(oldOwner);
                if (!PublicParties.contains(newOwnerUUID)) {
                    PublicParties.add(newOwnerUUID);
                }
            }
        }
        if (PartyMaxMembers.containsKey(oldOwner)) {
            int maxMembers = PartyMaxMembers.remove(oldOwner);
            PartyMaxMembers.put(newOwnerUUID, maxMembers);
        }
        PartyInvites.replaceAll((k, v) -> v.equals(oldOwner) ? newOwnerUUID : v);
        for (Map.Entry<UUID, UUID> entry : new HashMap<UUID, UUID>(PlayerPartyOwner).entrySet()) {
            if (!entry.getValue().equals(oldOwner)) continue;
            PlayerPartyOwner.put(entry.getKey(), newOwnerUUID);
        }
        PlayerPartyOwner.put(newOwnerUUID, newOwnerUUID);
        PlayerPartyOwner.remove(oldOwner);
        Player oldOwnerPlayer = Bukkit.getPlayer((UUID)oldOwner);
        if (oldOwnerPlayer != null) {
            MessageSender.SendMessage(oldOwnerPlayer, "Party.Promoted-New-Leader", "{newOwner}", newOwner.getName());
        }
        MessageSender.SendMessage(newOwner, "Party.Promoted-To-Leader", "", "");
        List<Player> members = PartyMembers.get(newOwnerUUID);
        if (members != null) {
            for (Player member : members) {
                if (member == null || member.equals((Object)newOwner)) continue;
                MessageSender.SendMessage(member, "Party.New-Leader", "{newOwner}", newOwner.getName());
            }
        }
    }

    public static void findNewPartyOwner(UUID oldOwner) {
        List<Player> members = PartyMembers.get(oldOwner);
        if (members != null && !members.isEmpty()) {
            members.removeIf(p -> p == null || p.getUniqueId().equals(oldOwner));
            if (members.isEmpty()) {
                PartyStaticClass.disbandParty(oldOwner);
            } else {
                Player newOwner = null;
                for (Player member : members) {
                    if (member == null || !member.isOnline()) continue;
                    newOwner = member;
                    break;
                }
                if (newOwner == null) {
                    PartyStaticClass.disbandParty(oldOwner);
                } else {
                    PartyStaticClass.setPartyOwner(oldOwner, newOwner);
                }
            }
        } else {
            PartyStaticClass.disbandParty(oldOwner);
        }
    }

    public static void unbanUser(Player player, Player target) {
        UUID partyOwner = PartyStaticClass.getPlayerPartyOwner(player);
        if (partyOwner == null) {
            MessageSender.SendMessage(player, "Party.Not-In-Party", "", "");
        } else {
            List<Player> bannedPlayers = PartyBannedPlayers.get(partyOwner);
            if (bannedPlayers != null) {
                bannedPlayers.remove(target);
            }
            MessageSender.SendMessage(player, "Party.Unbanned-Player", "{target}", target.getName());
            MessageSender.SendMessage(target, "Party.Unbanned-By-Player", "{player}", player.getName());
        }
    }

    public static void invitePlayer(Player player, Player invitedPlayer) {
        UUID partyOwner = PartyStaticClass.getPlayerPartyOwner(player);
        if (partyOwner == null) {
            boolean isAutoPartyCreateOnInvite = SettingsManager.getInstance().getSettings().getBoolean("Party-Settings.Auto-Party-Create-On-Invite");
            if (!isAutoPartyCreateOnInvite) {
                MessageSender.SendMessage(player, "Party.Not-In-Party", "", "");
                return;
            }
            PartyStaticClass.createParty(player);
            partyOwner = player.getUniqueId();
        }
        if (!player.getUniqueId().equals(partyOwner)) {
            MessageSender.SendMessage(player, "Party.Not-Owner", "", "");
        } else if (PlayerPartyOwner.containsKey(invitedPlayer.getUniqueId())) {
            MessageSender.SendMessage(player, "Party.Invite-Already-In-Other-Party", "{invitedPlayer}", invitedPlayer.getName());
        } else {
            List<Player> bannedPlayers = PartyBannedPlayers.get(partyOwner);
            List<Player> partyMembers = PartyMembers.get(partyOwner);
            if (bannedPlayers != null && bannedPlayers.contains(invitedPlayer)) {
                MessageSender.SendMessage(player, "Party.Invite-Banned-Player", "{invitedPlayer}", invitedPlayer.getName());
            } else if (partyMembers != null && partyMembers.contains(invitedPlayer)) {
                MessageSender.SendMessage(player, "Party.Invite-Already-In-Party", "{invitedPlayer}", invitedPlayer.getName());
            } else if (invitedPlayer != null) {
                PartyInvites.put(invitedPlayer.getUniqueId(), partyOwner);
                boolean clickable = SettingsManager.getInstance().getSettings().getBoolean("Party-Settings.Click-Able-Invite-Message");
                if (clickable) {
                    String hoverText = SettingsManager.getInstance().getSettings().getString("Party-Settings.Click-Able-Invite-Message-Text", "&aClick to join the party!");
                    String hoverMessage = SettingsManager.getInstance().getLang().getString("Party.Invited-To-Party.Text").replace("{player}", player.getName());
                    TextComponent message = new TextComponent(hoverMessage);
                    TextComponent clickablePart = new TextComponent("[" + hoverText.replace("&", "\u00a7") + "]");
                    clickablePart.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder(hoverText.replace("&", "\u00a7")).create()));
                    clickablePart.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/party accept " + player.getName()));
                    message.addExtra((BaseComponent)clickablePart);
                    invitedPlayer.spigot().sendMessage((BaseComponent)message);
                } else {
                    MessageSender.SendMessage(invitedPlayer, "Party.Invited-To-Party", "{player}", player.getName());
                }
                MessageSender.SendMessage(player, "Party.Invited-Player", "{invitedPlayer}", invitedPlayer.getName());
            }
        }
    }

    public static void acceptPartyInvite(Player player, Player PartyOwner) {
        UUID playerUUID = player.getUniqueId();
        UUID partyOwnerUUID = PartyOwner.getUniqueId();
        if (partyOwnerUUID == null) {
            MessageSender.SendMessage(player, "Party.No-Pending-Invites", "", "");
        } else if (PartyInvites.containsKey(playerUUID) && PartyInvites.get(playerUUID).equals(partyOwnerUUID)) {
            if (PlayerPartyOwner.containsKey(playerUUID)) {
                MessageSender.SendMessage(player, "Party.Already-In-Party", "", "");
            } else {
                List<Player> partyMembers = PartyMembers.get(partyOwnerUUID);
                int maxMembers = PartyMaxMembers.getOrDefault(partyOwnerUUID, 8);
                if (partyMembers != null && partyMembers.size() >= maxMembers) {
                    MessageSender.SendMessage(player, "Party.Full", "", "");
                } else {
                    PartyInvites.remove(playerUUID);
                    if (partyMembers == null) {
                        partyMembers = new ArrayList<Player>();
                        PartyMembers.put(partyOwnerUUID, partyMembers);
                    }
                    for (Player partyPlayer : partyMembers) {
                        MessageSender.SendMessage(partyPlayer, "Party.Member-Joined-Party", "{player}", player.getName());
                    }
                    partyMembers.add(player);
                    PlayerPartyOwner.put(playerUUID, partyOwnerUUID);
                    MessageSender.SendMessage(player, "Party.Joined-Party", "{PartyOwner}", PartyOwner.getName());
                }
            }
        } else {
            MessageSender.SendMessage(player, "Party.Not-Invited", "", "");
        }
    }

    public static void joinPublicParty(Player player, UUID partyOwner) {
        if (!PublicParties.contains(partyOwner)) {
            MessageSender.SendMessage(player, "Party.Not-Public", "", "");
        } else if (PlayerPartyOwner.containsKey(player.getUniqueId())) {
            MessageSender.SendMessage(player, "Party.Already-In-Party", "", "");
        } else {
            List<Player> partyMembers = PartyMembers.get(partyOwner);
            int maxMembers = PartyMaxMembers.getOrDefault(partyOwner, 8);
            if (partyMembers != null && partyMembers.size() >= maxMembers) {
                MessageSender.SendMessage(player, "Party.Full", "", "");
            } else {
                List<Player> bannedPlayers = PartyBannedPlayers.get(partyOwner);
                if (bannedPlayers != null && bannedPlayers.contains(player)) {
                    MessageSender.SendMessage(player, "Party.Banned-From-Party", "", "");
                } else {
                    if (partyMembers == null) {
                        partyMembers = new ArrayList<Player>();
                        PartyMembers.put(partyOwner, partyMembers);
                    }
                    for (Player partyPlayer : partyMembers) {
                        MessageSender.SendMessage(partyPlayer, "Party.Member-Joined-Party", "{player}", player.getName());
                    }
                    partyMembers.add(player);
                    PlayerPartyOwner.put(player.getUniqueId(), partyOwner);
                    MessageSender.SendMessage(player, "Party.Joined-Public-Party", "", "");
                }
            }
        }
    }

    public static void createParty(Player player) {
        if (PlayerPartyOwner.containsKey(player.getUniqueId())) {
            MessageSender.SendMessage(player, "Party.Already-In-Party", "", "");
        } else {
            UUID partyOwner = player.getUniqueId();
            PlayerPartyOwner.put(partyOwner, partyOwner);
            PartyMaxMembers.put(partyOwner, PartyStaticClass.getMaxPartyMembersFromPermissions(player));
            PartyPublic.put(partyOwner, false);
            PartyBannedPlayers.put(partyOwner, new ArrayList());
            PartyMembers.put(partyOwner, new ArrayList<Player>(Collections.singletonList(player)));
            MessageSender.SendMessage(player, "Party.Created-New-Party", "", "");
        }
    }

    public static int getMaxPartyMembersFromPermissions(Player player) {
        int defaultMaxMembers = 8;
        for (int i = 50; i >= 1; --i) {
            if (!player.hasPermission("mpa.party.maxmembers." + i)) continue;
            return i;
        }
        return defaultMaxMembers;
    }
}

