/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.NamespacedKey
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataType
 */
package org.kloppie74.MoonPillars.PaperMC;

import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class ItemUtils {
    public static final NamespacedKey CUSTOM_TAG_KEY = new NamespacedKey("moonpillars", "custom_tag");

    public static String getCustomTag(ItemStack item) {
        if (item == null) {
            return null;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return null;
        }
        String value = (String)meta.getPersistentDataContainer().get(CUSTOM_TAG_KEY, PersistentDataType.STRING);
        return value;
    }
}

