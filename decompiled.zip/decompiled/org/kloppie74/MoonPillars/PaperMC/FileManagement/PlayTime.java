/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.Statistic
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.Statistic;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;

public class PlayTime
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            if (args.length == 0) {
                sender.sendMessage("Console can't check its own playtime. Use /playtime <player|uuid>");
                return true;
            }
            String targetIdentifier = args[0];
            OfflinePlayer targetPlayer = this.findPlayer(targetIdentifier);
            if (targetPlayer == null) {
                sender.sendMessage("Player not found: " + targetIdentifier);
                return true;
            }
            this.displayPlayerStats(sender, targetPlayer);
            return true;
        }
        Player player = (Player)sender;
        if (args.length == 0) {
            this.displayPlayerStats(sender, (OfflinePlayer)player);
            return true;
        }
        if (args.length == 1) {
            if (!player.hasPermission("playtime.others")) {
                MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
                return true;
            }
            String targetIdentifier = args[0];
            OfflinePlayer targetPlayer = this.findPlayer(targetIdentifier);
            if (targetPlayer == null) {
                MessageSender.SendMessage(player, "Commands.Invalid-Target", "{target}", targetIdentifier);
                return true;
            }
            this.displayPlayerStats(sender, targetPlayer);
            return true;
        }
        player.sendMessage(MSG.chatColors("&cUsage: /playtime [player|uuid]"));
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (args.length == 1 && sender.hasPermission("playtime.others")) {
            String input = args[0].toLowerCase();
            Stream<String> var10000 = Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(name -> name.toLowerCase().startsWith(input));
            Objects.requireNonNull(completions);
            completions.addAll(var10000.toList());
            if (input.contains("-") || input.length() > 8) {
                var10000 = Bukkit.getOnlinePlayers().stream().map(player -> player.getUniqueId().toString()).filter(uuid -> uuid.startsWith(input));
                Objects.requireNonNull(completions);
                completions.addAll(var10000.toList());
            }
        }
        return completions;
    }

    private OfflinePlayer findPlayer(String identifier) {
        Player onlinePlayer;
        if (this.isUUID(identifier)) {
            try {
                UUID uuid = UUID.fromString(identifier);
                return Bukkit.getOfflinePlayer((UUID)uuid);
            }
            catch (IllegalArgumentException uuid) {
                // empty catch block
            }
        }
        if ((onlinePlayer = Bukkit.getPlayer((String)identifier)) != null) {
            return onlinePlayer;
        }
        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((String)identifier);
        return offlinePlayer.hasPlayedBefore() ? offlinePlayer : null;
    }

    private boolean isUUID(String string) {
        try {
            UUID.fromString(string);
            return true;
        }
        catch (IllegalArgumentException var3) {
            return false;
        }
    }

    private void displayPlayerStats(CommandSender sender, OfflinePlayer target) {
        long playtimeTicks = target.getStatistic(Statistic.PLAY_ONE_MINUTE);
        long playtimeSeconds = playtimeTicks / 20L;
        String formattedTime = this.formatTime(playtimeSeconds);
        int timesJoined = target.getStatistic(Statistic.LEAVE_GAME) + 1;
        if (sender.equals((Object)target)) {
            sender.sendMessage(MSG.chatColors("&7&l&m-----==&r&7&l[ &6&lPlayer Statistics &7&l]&7&l&m==-----"));
            sender.sendMessage(MSG.chatColors("&7"));
            sender.sendMessage(MSG.chatColors("    &6&l\u2726 &7Playtime: &6" + formattedTime));
            sender.sendMessage(MSG.chatColors("    &c&l\u2726 &7Times Joined: &6" + timesJoined));
            sender.sendMessage(MSG.chatColors("    &9&l\u2726 &7UUID: &6" + String.valueOf(target.getUniqueId())));
            sender.sendMessage(MSG.chatColors("&7"));
            sender.sendMessage(MSG.chatColors("&7&l&m------------------------------------------"));
        } else {
            sender.sendMessage(MSG.chatColors("&7&l&m-----==&r&7&l[ &6&lPlayer Statistics &7&l]&7&l&m==-----"));
            sender.sendMessage(MSG.chatColors("&7"));
            sender.sendMessage(MSG.chatColors("    &6&l\u00bb &6" + target.getName() + "&7's Statistics:"));
            sender.sendMessage(MSG.chatColors("    &6&l\u2726 &7Playtime: &6" + formattedTime));
            sender.sendMessage(MSG.chatColors("    &c&l\u2726 &7Times Joined: &6" + timesJoined));
            sender.sendMessage(MSG.chatColors("    &9&l\u2726 &7UUID: &6" + String.valueOf(target.getUniqueId())));
            sender.sendMessage(MSG.chatColors("&7"));
            sender.sendMessage(MSG.chatColors("&7&l&m------------------------------------------"));
        }
    }

    private String formatTime(long seconds) {
        long months = TimeUnit.SECONDS.toDays(seconds) / 30L;
        long remainingDays = TimeUnit.SECONDS.toDays(seconds) % 30L;
        long weeks = remainingDays / 7L;
        remainingDays %= 7L;
        long hours = TimeUnit.SECONDS.toHours(seconds) % 24L;
        long minutes = TimeUnit.SECONDS.toMinutes(seconds) % 60L;
        long remainingSeconds = seconds % 60L;
        StringBuilder sb = new StringBuilder();
        if (months > 0L) {
            sb.append(months).append(months == 1L ? " month, " : " months, ");
        }
        if (weeks > 0L) {
            sb.append(weeks).append(weeks == 1L ? " week, " : " weeks, ");
        }
        if (remainingDays > 0L) {
            sb.append(remainingDays).append(remainingDays == 1L ? " day, " : " days, ");
        }
        if (hours > 0L) {
            sb.append(hours).append(hours == 1L ? " hour, " : " hours, ");
        }
        if (minutes > 0L) {
            sb.append(minutes).append(minutes == 1L ? " minute, " : " minutes, ");
        }
        sb.append(remainingSeconds).append(remainingSeconds == 1L ? " second" : " seconds");
        return sb.toString();
    }
}

