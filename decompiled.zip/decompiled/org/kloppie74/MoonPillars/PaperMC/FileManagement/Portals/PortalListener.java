/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.event.player.PlayerTeleportEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.Portals;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class PortalListener
implements Listener {
    private final Map<String, Portal> portals = new HashMap<String, Portal>();
    private final Map<UUID, Long> playerCooldowns = new HashMap<UUID, Long>();
    private final Set<UUID> teleportingPlayers = new HashSet<UUID>();
    private static final long COOLDOWN_TIME = 2000L;
    private final MoonLab plugin;
    private static PortalListener instance;
    private boolean isLoading = false;

    public PortalListener(MoonLab plugin) {
        this.plugin = plugin;
        instance = this;
        this.loadPortals();
    }

    public static PortalListener getInstance() {
        return instance;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void loadPortals() {
        if (this.isLoading) {
            Bukkit.getLogger().info("[MoonLab] Portal loading already in progress, skipping request");
        } else {
            this.isLoading = true;
            try {
                this.portals.clear();
                ConfigurationSection portalSection = SettingsManager.getInstance().getPortals().getConfigurationSection("Portals");
                if (portalSection == null) {
                    Bukkit.getLogger().warning("[MoonLab] No portals found in configuration!");
                    return;
                }
                for (String key : portalSection.getKeys(false)) {
                    try {
                        ConfigurationSection portal = portalSection.getConfigurationSection(key);
                        if (portal == null) continue;
                        String worldName = portal.getString("World");
                        if (worldName == null) {
                            Bukkit.getLogger().warning("[MoonLab] Portal " + key + " has no world specified");
                            continue;
                        }
                        World world = Bukkit.getWorld((String)worldName);
                        if (world == null) {
                            Bukkit.getLogger().warning("[MoonLab] Portal " + key + " references non-existent world: " + worldName);
                            continue;
                        }
                        double minX = portal.getDouble("Min.X");
                        double minY = portal.getDouble("Min.Y");
                        double minZ = portal.getDouble("Min.Z");
                        double maxX = portal.getDouble("Max.X");
                        double maxY = portal.getDouble("Max.Y");
                        double maxZ = portal.getDouble("Max.Z");
                        String action = portal.getString("Action", "COMMAND");
                        String executeAs = portal.getString("Execute_Action_As", "PLAYER");
                        String execute = portal.getString("Execute", "");
                        String message = portal.getString("Message", "");
                        this.portals.put(key, new Portal(world, minX, minY, minZ, maxX, maxY, maxZ, action, executeAs, execute, message));
                        Bukkit.getLogger().info("[MoonLab] Loaded portal " + key);
                    }
                    catch (Exception var27) {
                        Bukkit.getLogger().log(Level.WARNING, "[MoonLab] Error loading portal " + key, var27);
                    }
                }
                Bukkit.getLogger().info("[MoonLab] Loaded " + this.portals.size() + " portals");
            }
            catch (Exception var28) {
                Bukkit.getLogger().log(Level.SEVERE, "[MoonLab] Error loading portals", var28);
            }
            finally {
                this.isLoading = false;
            }
        }
    }

    @EventHandler(priority=EventPriority.NORMAL)
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player;
        UUID playerUUID;
        if (!(event.isCancelled() || this.portals.isEmpty() || event.getTo() == null || this.teleportingPlayers.contains(playerUUID = (player = event.getPlayer()).getUniqueId()))) {
            long lastTriggerTime;
            long currentTime = System.currentTimeMillis();
            if (this.playerCooldowns.containsKey(playerUUID) && currentTime - (lastTriggerTime = this.playerCooldowns.get(playerUUID).longValue()) < 2000L) {
                return;
            }
            Location playerLoc = player.getLocation();
            double playerMinX = playerLoc.getX() - 0.3;
            double playerMaxX = playerLoc.getX() + 0.3;
            double playerMinY = playerLoc.getY();
            double playerMaxY = playerLoc.getY() + 1.8;
            double playerMinZ = playerLoc.getZ() - 0.3;
            double playerMaxZ = playerLoc.getZ() + 0.3;
            for (Map.Entry<String, Portal> entry : this.portals.entrySet()) {
                boolean intersects;
                final Portal portal = entry.getValue();
                if (!playerLoc.getWorld().equals((Object)portal.getWorld()) || !(intersects = !(playerMaxX < portal.getMinX() || playerMinX > portal.getMaxX() || playerMaxY < portal.getMinY() || playerMinY > portal.getMaxY() || playerMaxZ < portal.getMinZ() || playerMinZ > portal.getMaxZ()))) continue;
                this.playerCooldowns.put(playerUUID, currentTime);
                new BukkitRunnable(){

                    public void run() {
                        PortalListener.this.triggerPortalAction(player, portal);
                    }
                }.runTask((Plugin)this.plugin);
                break;
            }
        }
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        UUID playerUUID;
        if (!event.isCancelled() && !this.teleportingPlayers.contains(playerUUID = event.getPlayer().getUniqueId())) {
            this.teleportingPlayers.add(playerUUID);
            new BukkitRunnable(){

                public void run() {
                    PortalListener.this.teleportingPlayers.remove(playerUUID);
                }
            }.runTaskLater((Plugin)this.plugin, 10L);
        }
    }

    private void triggerPortalAction(final Player player, Portal portal) {
        if (player.isOnline()) {
            if (!portal.getMessage().isEmpty()) {
                player.sendMessage(MSG.chatColors(portal.getMessage()));
            }
            try {
                switch (portal.getAction().toUpperCase()) {
                    case "COMMAND": {
                        String command = portal.getExecute().replace("%player%", player.getName());
                        if ("CONSOLE".equalsIgnoreCase(portal.getExecuteAs())) {
                            Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)command);
                            break;
                        }
                        if ("PLAYER".equalsIgnoreCase(portal.getExecuteAs())) {
                            player.performCommand(command);
                        }
                        break;
                    }
                    case "TELEPORT": {
                        try {
                            String[] coords = portal.getExecute().split(",");
                            if (coords.length < 4) {
                                Bukkit.getLogger().warning("[MoonLab] Invalid teleport format: " + portal.getExecute());
                                return;
                            }
                            final World world = Bukkit.getWorld((String)coords[0]);
                            if (world == null) {
                                Bukkit.getLogger().warning("[MoonLab] Teleport destination world not found: " + coords[0]);
                                return;
                            }
                            final double x = Double.parseDouble(coords[1]);
                            final double y = Double.parseDouble(coords[2]);
                            final double z = Double.parseDouble(coords[3]);
                            final float yaw = coords.length > 4 ? Float.parseFloat(coords[4]) : player.getLocation().getYaw();
                            final float pitch = coords.length > 5 ? Float.parseFloat(coords[5]) : player.getLocation().getPitch();
                            this.teleportingPlayers.add(player.getUniqueId());
                            new BukkitRunnable(){

                                public void run() {
                                    player.teleport(new Location(world, x, y, z, yaw, pitch));
                                    new BukkitRunnable(){

                                        public void run() {
                                            PortalListener.this.teleportingPlayers.remove(player.getUniqueId());
                                        }
                                    }.runTaskLater((Plugin)PortalListener.this.plugin, 10L);
                                }
                            }.runTask((Plugin)this.plugin);
                        }
                        catch (NumberFormatException var16) {
                            Bukkit.getLogger().warning("[MoonLab] Invalid teleport coordinates: " + portal.getExecute());
                        }
                        catch (Exception var17) {
                            Bukkit.getLogger().log(Level.WARNING, "[MoonLab] Error executing teleport", var17);
                        }
                        break;
                    }
                    default: {
                        Bukkit.getLogger().warning("[MoonLab] Unknown portal action type: " + portal.getAction());
                        break;
                    }
                }
            }
            catch (Exception var18) {
                Bukkit.getLogger().log(Level.WARNING, "[MoonLab] Error triggering portal action", var18);
            }
        }
    }

    public void reloadPortals() {
        this.loadPortals();
    }

    public Map<String, Portal> getPortals() {
        return new HashMap<String, Portal>(this.portals);
    }

    public static class Portal {
        private final World world;
        private final double minX;
        private final double minY;
        private final double minZ;
        private final double maxX;
        private final double maxY;
        private final double maxZ;
        private final String action;
        private final String executeAs;
        private final String execute;
        private final String message;

        public Portal(World world, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, String action, String executeAs, String execute, String message) {
            this.world = world;
            this.minX = Math.min(minX, maxX);
            this.minY = Math.min(minY, maxY);
            this.minZ = Math.min(minZ, maxZ);
            this.maxX = Math.max(minX, maxX);
            this.maxY = Math.max(minY, maxY);
            this.maxZ = Math.max(minZ, maxZ);
            this.action = action;
            this.executeAs = executeAs;
            this.execute = execute;
            this.message = message;
        }

        public World getWorld() {
            return this.world;
        }

        public double getMinX() {
            return this.minX;
        }

        public double getMinY() {
            return this.minY;
        }

        public double getMinZ() {
            return this.minZ;
        }

        public double getMaxX() {
            return this.maxX;
        }

        public double getMaxY() {
            return this.maxY;
        }

        public double getMaxZ() {
            return this.maxZ;
        }

        public String getAction() {
            return this.action;
        }

        public String getExecuteAs() {
            return this.executeAs;
        }

        public String getExecute() {
            return this.execute;
        }

        public String getMessage() {
            return this.message;
        }
    }
}

