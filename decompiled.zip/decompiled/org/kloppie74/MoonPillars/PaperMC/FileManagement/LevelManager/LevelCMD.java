/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Listener
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.LevelManager;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.LevelManager.AddPlayerXP;

public class LevelCMD
implements CommandExecutor,
TabCompleter,
Listener {
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        Player player;
        ArrayList<String> completions = new ArrayList<String>();
        if (sender instanceof Player && (player = (Player)sender).hasPermission("mpa.level.others") && args.length == 1) {
            String partialName = args[0].toLowerCase();
            for (Player playertab : Bukkit.getOnlinePlayers()) {
                if (!playertab.getName().toLowerCase().startsWith(partialName)) continue;
                completions.add(playertab.getName());
            }
        }
        return completions;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("This command can only be used by a player.");
            return true;
        }
        Player player = (Player)sender;
        if (args.length == 0) {
            if (!player.hasPermission("mpa.level")) {
                player.sendMessage(MSG.chatColors("&cYou don't have permission to use this command!"));
            }
            int level = AddPlayerXP.getLevel(player);
            int Newlevel = AddPlayerXP.getRequiredXP(++level) - AddPlayerXP.getXP(player);
            sender.sendMessage(MSG.chatColors("&3&l--- Level Statistics ---"));
            sender.sendMessage(MSG.chatColors("&f"));
            sender.sendMessage(MSG.chatColors("&bLevel: &f" + level));
            sender.sendMessage(MSG.chatColors("&bXP Required for next level: &f" + Newlevel));
            sender.sendMessage(MSG.chatColors("&3&l---------------------------"));
        } else if (args.length == 1) {
            Player target = Bukkit.getPlayer((String)args[0]);
            if (!player.hasPermission("mpa.level.others")) {
                player.sendMessage(MSG.chatColors("&cYou don't have permission to use this command!"));
            }
            if (target == null || !target.isOnline()) {
                sender.sendMessage(MSG.chatColors("&cPlayer not found or offline!"));
                return true;
            }
            int level = AddPlayerXP.getLevel(target);
            int Newlevel = level + 1;
            int finalXP = AddPlayerXP.getRequiredXP(Newlevel) - AddPlayerXP.getXP(target);
            sender.sendMessage(MSG.chatColors("&3&l--- " + target.getName() + "'s Level Statistics ---"));
            sender.sendMessage(MSG.chatColors("&f"));
            sender.sendMessage(MSG.chatColors("&bLevel: &f" + level));
            sender.sendMessage(MSG.chatColors("&bXP Required for next level: &f" + finalXP));
            sender.sendMessage(MSG.chatColors("&3&l---------------------------"));
        } else {
            sender.sendMessage("Too many arguments! Usage: /<command> <player>");
        }
        return true;
    }
}

