/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.PlaceholderAPI
 *  org.bukkit.Bukkit
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.LevelManager;

import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class AddPlayerXP {
    public static void AddXP(Player player, int xp) {
        int globalBooster = AddPlayerXP.getGlobalBooster();
        int levelBooster = AddPlayerXP.getLevelBooster(AddPlayerXP.getLevel(player));
        int permissionBooster = AddPlayerXP.getPermissionBoost(player);
        double multiplier = Math.max((double)globalBooster / 100.0, 1.0) * Math.max((double)levelBooster / 100.0, 1.0) * Math.max((double)permissionBooster / 100.0, 1.0);
        double boostedXP = (double)xp * multiplier;
        int currentXP = AddPlayerXP.getXP(player);
        int newXP = currentXP + (int)boostedXP;
        DatabaseManager.getInstance().updateSetting(player.getUniqueId(), "XP", newXP);
        AddPlayerXP.recalculateLevel(player);
    }

    public static int getXP(Player player) {
        try {
            return Integer.parseInt(DatabaseManager.getInstance().getSetting(player.getUniqueId(), "XP"));
        }
        catch (NumberFormatException var2) {
            return 0;
        }
    }

    public static void ResetPlayerXP(Player player) {
        DatabaseManager.getInstance().updateSetting(player.getUniqueId(), "XP", 0);
        player.sendMessage("Your XP has been reset upon leveling up.");
    }

    public static int getLevel(Player player) {
        try {
            return Integer.parseInt(DatabaseManager.getInstance().getSetting(player.getUniqueId(), "Level"));
        }
        catch (NumberFormatException var2) {
            return 1;
        }
    }

    public static void recalculateLevel(Player player) {
        int oldLevel;
        int displayLevel;
        int xp = AddPlayerXP.getXP(player);
        int max = AddPlayerXP.getMaxConfiguredLevel();
        int reached = 0;
        int minutes = -1;
        int lvl = 1;
        while (lvl <= max && AddPlayerXP.isLevelConfigured(lvl) && xp >= AddPlayerXP.getRequiredXP(lvl)) {
            int reqTime = AddPlayerXP.getRequiredTime(lvl);
            if (reqTime > 0) {
                if (minutes < 0) {
                    minutes = AddPlayerXP.getPlayedMinutes(player);
                }
                if (minutes < reqTime) break;
            }
            reached = lvl++;
        }
        if ((displayLevel = Math.max(reached, 1)) != (oldLevel = AddPlayerXP.getLevel(player))) {
            DatabaseManager.getInstance().updateSetting(player.getUniqueId(), "Level", displayLevel);
            if (displayLevel > oldLevel) {
                String msg = SettingsManager.getInstance().getLevelMenu().getString("Menu.Messages.LevelUp", "&a\u0412\u044b \u0434\u043e\u0441\u0442\u0438\u0433\u043b\u0438 \u0443\u0440\u043e\u0432\u043d\u044f &e%level%&a! \u0417\u0430\u0431\u0435\u0440\u0438\u0442\u0435 \u043d\u0430\u0433\u0440\u0430\u0434\u0443: &e/levelrewards");
                player.sendMessage(MSG.chatColors(msg.replace("%level%", String.valueOf(displayLevel))));
            }
        }
    }

    private static ConfigurationSection getLevelSection(int level) {
        ConfigurationSection section;
        FileConfiguration menu = SettingsManager.getInstance().getLevelMenu();
        ConfigurationSection configurationSection = section = menu != null ? menu.getConfigurationSection("Menu.Levels." + level) : null;
        if (section != null) {
            return section;
        }
        FileConfiguration legacy = SettingsManager.getInstance().getLevelSettings();
        return legacy != null ? legacy.getConfigurationSection("Rewards.Level." + level) : null;
    }

    public static boolean isLevelConfigured(int level) {
        return AddPlayerXP.getLevelSection(level) != null;
    }

    public static int getMaxConfiguredLevel() {
        ConfigurationSection levels;
        int max = 0;
        FileConfiguration menu = SettingsManager.getInstance().getLevelMenu();
        if (menu != null && (levels = menu.getConfigurationSection("Menu.Levels")) != null) {
            for (String key : levels.getKeys(false)) {
                try {
                    max = Math.max(max, Integer.parseInt(key));
                }
                catch (NumberFormatException numberFormatException) {}
            }
        }
        return max > 0 ? max : 15;
    }

    public static int getRequiredXP(int level) {
        ConfigurationSection section = AddPlayerXP.getLevelSection(level);
        if (section == null) {
            return Integer.MAX_VALUE;
        }
        try {
            return Integer.parseInt(String.valueOf(section.get("RequiredXP", (Object)0)));
        }
        catch (NumberFormatException var3) {
            return Integer.MAX_VALUE;
        }
    }

    public static int getRequiredTime(int level) {
        ConfigurationSection section = AddPlayerXP.getLevelSection(level);
        return section == null ? 0 : section.getInt("RequiredTime", 0);
    }

    public static boolean isLevelUnlocked(Player player, int level) {
        if (!AddPlayerXP.isLevelConfigured(level)) {
            return false;
        }
        if (AddPlayerXP.getXP(player) < AddPlayerXP.getRequiredXP(level)) {
            return false;
        }
        int reqTime = AddPlayerXP.getRequiredTime(level);
        if (reqTime <= 0) {
            return true;
        }
        return AddPlayerXP.getPlayedMinutes(player) >= reqTime;
    }

    public static int getPlayedMinutes(Player player) {
        FileConfiguration menu = SettingsManager.getInstance().getLevelMenu();
        if (menu == null) {
            return 0;
        }
        if (!Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            return 0;
        }
        String placeholder = menu.getString("Menu.Time.Placeholder", "%statistic_time_played%");
        String unit = menu.getString("Menu.Time.Unit", "TICKS").toUpperCase();
        String raw = PlaceholderAPI.setPlaceholders((Player)player, (String)placeholder);
        long value = AddPlayerXP.parseFirstNumber(raw);
        switch (unit) {
            case "TICKS": {
                return (int)(value / 1200L);
            }
            case "SECONDS": {
                return (int)(value / 60L);
            }
            case "HOURS": {
                return (int)(value * 60L);
            }
        }
        return (int)value;
    }

    private static long parseFirstNumber(String input) {
        if (input == null) {
            return 0L;
        }
        StringBuilder digits = new StringBuilder();
        boolean started = false;
        for (int i = 0; i < input.length(); ++i) {
            char c = input.charAt(i);
            if (c >= '0' && c <= '9') {
                digits.append(c);
                started = true;
                continue;
            }
            if (started) break;
        }
        if (digits.length() == 0) {
            return 0L;
        }
        try {
            return Long.parseLong(digits.toString());
        }
        catch (NumberFormatException var5) {
            return 0L;
        }
    }

    public static String getLevelName(int level) {
        ConfigurationSection section = AddPlayerXP.getLevelSection(level);
        return section != null ? section.getString("Name", "N/A") : "N/A";
    }

    public static int getGlobalBooster() {
        return SettingsManager.getInstance().getLevelSettings().getInt("settings.Booster", 100);
    }

    public static int getLevelBooster(int level) {
        String path = "Rewards.Level." + level + ".Booster";
        return SettingsManager.getInstance().getLevelSettings().getInt(path, 100);
    }

    public static int getPermissionBoost(Player player) {
        int highestBoost = 100;
        for (int boost = 100; boost <= 500; boost += 25) {
            String permission = "mpa.level.boost." + boost;
            if (!player.hasPermission(permission) || boost <= highestBoost) continue;
            highestBoost = boost;
        }
        return highestBoost;
    }
}

