/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.PlaceholderAPI
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.LevelManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.LevelManager.AddPlayerXP;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class LevelMenuManager
implements Listener {
    private static final String STATE_LOCKED = "Locked";
    private static final String STATE_UNCLAIMED = "Unclaimed";
    private static final String STATE_CLAIMED = "Claimed";

    public static void registerEvents() {
        MoonLab.getInstance().getServer().getPluginManager().registerEvents((Listener)new LevelMenuManager(), (Plugin)MoonLab.getInstance());
    }

    public static void open(Player player) {
        FileConfiguration menu = SettingsManager.getInstance().getLevelMenu();
        if (menu == null) {
            player.sendMessage(MSG.chatColors("&cThe level menu is not configured."));
        } else {
            int rawSize = menu.getInt("Menu.Size", 54);
            int size = Math.min(54, Math.max(9, (int)Math.ceil((double)rawSize / 9.0) * 9));
            String title = LevelMenuManager.applyColorsAndPapi(player, menu.getString("Menu.Title", "&8Level Rewards"));
            if (title.length() > 32) {
                title = title.substring(0, 32);
            }
            LevelMenuHolder holder = new LevelMenuHolder();
            Inventory inventory = Bukkit.createInventory((InventoryHolder)holder, (int)size, (String)title);
            holder.setInventory(inventory);
            if (menu.getBoolean("Menu.Filler.Enabled", true)) {
                ItemStack filler = LevelMenuManager.buildBasicItem(menu.getString("Menu.Filler.Material", "GRAY_STAINED_GLASS_PANE"), menu.getString("Menu.Filler.Name", " "), menu.getInt("Menu.Filler.CustomModelData", 0));
                for (int i = 0; i < size; ++i) {
                    inventory.setItem(i, filler);
                }
            }
            int xp = AddPlayerXP.getXP(player);
            int minutes = AddPlayerXP.getPlayedMinutes(player);
            Set<Integer> claimed = LevelMenuManager.getClaimedLevels(player);
            ConfigurationSection levels = menu.getConfigurationSection("Menu.Levels");
            if (levels != null) {
                for (String key : levels.getKeys(false)) {
                    int slot;
                    int level;
                    try {
                        level = Integer.parseInt(key);
                    }
                    catch (NumberFormatException var18) {
                        continue;
                    }
                    ConfigurationSection levelSection = levels.getConfigurationSection(key);
                    if (levelSection == null || (slot = levelSection.getInt("Slot", -1)) < 0 || slot >= size) continue;
                    int requiredXP = AddPlayerXP.getRequiredXP(level);
                    int requiredTime = AddPlayerXP.getRequiredTime(level);
                    boolean unlocked = xp >= requiredXP && minutes >= requiredTime;
                    boolean isClaimed = claimed.contains(level);
                    String state = !unlocked ? STATE_LOCKED : (isClaimed ? STATE_CLAIMED : STATE_UNCLAIMED);
                    ItemStack item = LevelMenuManager.buildLevelItem(player, menu, levelSection, level, state, xp, requiredXP, minutes, requiredTime);
                    inventory.setItem(slot, item);
                    holder.mapSlot(slot, level);
                }
            }
            player.openInventory(inventory);
            LevelMenuManager.playSound(player, menu.getString("Menu.OpenSound", ""));
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getInventory().getHolder() instanceof LevelMenuHolder) {
            event.setCancelled(true);
            if (event.getWhoClicked() instanceof Player) {
                Integer level;
                Player player = (Player)event.getWhoClicked();
                LevelMenuHolder holder = (LevelMenuHolder)event.getInventory().getHolder();
                if (event.getClickedInventory() != null && event.getClickedInventory().equals((Object)holder.getInventory()) && (level = holder.getLevel(event.getRawSlot())) != null) {
                    FileConfiguration menu = SettingsManager.getInstance().getLevelMenu();
                    if (!AddPlayerXP.isLevelUnlocked(player, level)) {
                        String msg = menu.getString("Menu.Messages.NotUnlocked", "&c\u0412\u044b \u0435\u0449\u0451 \u043d\u0435 \u0432\u044b\u043f\u043e\u043b\u043d\u0438\u043b\u0438 \u0443\u0441\u043b\u043e\u0432\u0438\u044f \u044d\u0442\u043e\u0433\u043e \u0443\u0440\u043e\u0432\u043d\u044f.");
                        player.sendMessage(MSG.chatColors(msg));
                    } else if (LevelMenuManager.getClaimedLevels(player).contains(level)) {
                        String msg = menu.getString("Menu.Messages.AlreadyClaimed", "&c\u041d\u0430\u0433\u0440\u0430\u0434\u0430 \u0437\u0430 \u044d\u0442\u043e\u0442 \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u0443\u0436\u0435 \u0437\u0430\u0431\u0440\u0430\u043d\u0430.");
                        player.sendMessage(MSG.chatColors(msg));
                    } else {
                        LevelMenuManager.giveReward(player, menu, level);
                        LevelMenuManager.markClaimed(player, level);
                        String msg = menu.getString("Menu.Messages.Claimed", "&a\u041d\u0430\u0433\u0440\u0430\u0434\u0430 \u0437\u0430 &e\u0443\u0440\u043e\u0432\u0435\u043d\u044c %level% &a\u043f\u043e\u043b\u0443\u0447\u0435\u043d\u0430!");
                        player.sendMessage(MSG.chatColors(msg.replace("%level%", String.valueOf(level))));
                        LevelMenuManager.playSound(player, menu.getString("Menu.ClaimSound", ""));
                        LevelMenuManager.open(player);
                    }
                }
            }
        }
    }

    private static List<String> getRewardCommands(FileConfiguration menu, int level) {
        List raw = menu.getList("Menu.Levels." + level + ".Rewards");
        ArrayList<String> commands = new ArrayList<String>();
        if (raw == null || raw.isEmpty()) {
            return SettingsManager.getInstance().getLevelSettings().getStringList("Rewards.Level." + level + ".Commands");
        }
        for (Object entry : raw) {
            Object cmd;
            if (entry instanceof String) {
                commands.add((String)entry);
                continue;
            }
            if (!(entry instanceof Map) || (cmd = ((Map)entry).get("command")) == null) continue;
            commands.add(cmd.toString());
        }
        return commands;
    }

    private static List<String> getRewardDescriptions(FileConfiguration menu, int level) {
        List raw = menu.getList("Menu.Levels." + level + ".Rewards");
        ArrayList<String> descs = new ArrayList<String>();
        if (raw == null) {
            return descs;
        }
        for (Object entry : raw) {
            Object desc;
            if (!(entry instanceof Map) || (desc = ((Map)entry).get("description")) == null) continue;
            descs.add(desc.toString());
        }
        return descs;
    }

    private static void giveReward(Player player, FileConfiguration menu, int level) {
        for (String command : LevelMenuManager.getRewardCommands(menu, level)) {
            command = command.replace("%player%", player.getName());
            if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
                command = PlaceholderAPI.setPlaceholders((Player)player, (String)command);
            }
            if (command.startsWith("/")) {
                command = command.substring(1);
            }
            Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)command);
        }
    }

    private static ItemStack buildLevelItem(Player player, FileConfiguration menu, ConfigurationSection levelSection, int level, String state, int xpNow, int xpRequired, int timeNow, int timeRequired) {
        String material = LevelMenuManager.resolveString(levelSection, menu, state, "Material", "PAPER");
        int customModelData = LevelMenuManager.resolveInt(levelSection, menu, state, "CustomModelData", 0);
        boolean glow = LevelMenuManager.resolveBool(levelSection, menu, state, "Glow", false);
        String name = levelSection.getString("Name", "&aLevel " + level);
        List<String> loreTemplate = LevelMenuManager.resolveLore(levelSection, menu, state);
        List<String> rewardDescs = LevelMenuManager.getRewardDescriptions(menu, level);
        ItemStack item = LevelMenuManager.buildBasicItem(material, null, customModelData);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(LevelMenuManager.replacePlaceholders(player, name, level, xpNow, xpRequired, timeNow, timeRequired));
            ArrayList<String> lore = new ArrayList<String>();
            for (String line : loreTemplate) {
                if (line.contains("%rewards%")) {
                    if (rewardDescs.isEmpty()) {
                        lore.add(LevelMenuManager.replacePlaceholders(player, line.replace("%rewards%", "&7\u2014"), level, xpNow, xpRequired, timeNow, timeRequired));
                        continue;
                    }
                    for (String desc : rewardDescs) {
                        lore.add(LevelMenuManager.replacePlaceholders(player, line.replace("%rewards%", desc), level, xpNow, xpRequired, timeNow, timeRequired));
                    }
                    continue;
                }
                lore.add(LevelMenuManager.replacePlaceholders(player, line, level, xpNow, xpRequired, timeNow, timeRequired));
            }
            meta.setLore(lore);
            if (glow) {
                meta.addEnchant(Enchantment.LURE, 1, true);
                meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    private static ItemStack buildBasicItem(String materialName, String name, int customModelData) {
        ItemStack item;
        ItemMeta meta;
        Material material = Material.matchMaterial((String)(materialName != null ? materialName.toUpperCase() : ""));
        if (material == null) {
            material = Material.PAPER;
        }
        if ((meta = (item = new ItemStack(material)).getItemMeta()) != null) {
            if (name != null) {
                meta.setDisplayName(MSG.chatColors(name));
            }
            if (customModelData > 0) {
                meta.setCustomModelData(Integer.valueOf(customModelData));
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    private static String replacePlaceholders(Player player, String text, int level, int xpNow, int xpRequired, int timeNow, int timeRequired) {
        if (text == null) {
            return "";
        }
        text = text.replace("%level%", String.valueOf(level)).replace("%player%", player.getName()).replace("%xp_now%", String.valueOf(xpNow)).replace("%xp_required%", String.valueOf(xpRequired)).replace("%time_now%", String.valueOf(timeNow)).replace("%time_required%", String.valueOf(timeRequired));
        return LevelMenuManager.applyColorsAndPapi(player, text);
    }

    private static String applyColorsAndPapi(Player player, String text) {
        if (text == null) {
            return "";
        }
        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            text = PlaceholderAPI.setPlaceholders((Player)player, (String)text);
        }
        return MSG.chatColors(text);
    }

    private static String resolveString(ConfigurationSection levelSection, FileConfiguration menu, String state, String key, String def) {
        ConfigurationSection override = levelSection.getConfigurationSection(state);
        if (override != null && override.contains(key)) {
            return override.getString(key, def);
        }
        return menu.getString("Menu.States." + state + "." + key, def);
    }

    private static int resolveInt(ConfigurationSection levelSection, FileConfiguration menu, String state, String key, int def) {
        ConfigurationSection override = levelSection.getConfigurationSection(state);
        if (override != null && override.contains(key)) {
            return override.getInt(key, def);
        }
        return menu.getInt("Menu.States." + state + "." + key, def);
    }

    private static boolean resolveBool(ConfigurationSection levelSection, FileConfiguration menu, String state, String key, boolean def) {
        ConfigurationSection override = levelSection.getConfigurationSection(state);
        if (override != null && override.contains(key)) {
            return override.getBoolean(key, def);
        }
        return menu.getBoolean("Menu.States." + state + "." + key, def);
    }

    private static List<String> resolveLore(ConfigurationSection levelSection, FileConfiguration menu, String state) {
        ConfigurationSection override = levelSection.getConfigurationSection(state);
        if (override != null && override.isList("Lore")) {
            return override.getStringList("Lore");
        }
        return menu.getStringList("Menu.States." + state + ".Lore");
    }

    private static void playSound(Player player, String soundName) {
        if (soundName != null && !soundName.isEmpty()) {
            try {
                Sound sound = Sound.valueOf((String)soundName.toUpperCase());
                player.playSound(player.getLocation(), sound, 1.0f, 1.0f);
            }
            catch (IllegalArgumentException illegalArgumentException) {
                // empty catch block
            }
        }
    }

    public static Set<Integer> getClaimedLevels(Player player) {
        HashSet<Integer> claimed = new HashSet<Integer>();
        String raw = DatabaseManager.getInstance().getSetting(player.getUniqueId(), "claimed_levels");
        if (raw != null && !raw.isEmpty()) {
            for (String part : raw.split(",")) {
                try {
                    claimed.add(Integer.parseInt(part.trim()));
                }
                catch (NumberFormatException numberFormatException) {
                    // empty catch block
                }
            }
        }
        return claimed;
    }

    private static void markClaimed(Player player, int level) {
        Set<Integer> claimed = LevelMenuManager.getClaimedLevels(player);
        if (claimed.add(level)) {
            String csv = claimed.stream().sorted().map(String::valueOf).collect(Collectors.joining(","));
            DatabaseManager.getInstance().updateSetting(player.getUniqueId(), "claimed_levels", csv);
        }
    }

    public static class LevelMenuHolder
    implements InventoryHolder {
        private Inventory inventory;
        private final Map<Integer, Integer> slotToLevel = new HashMap<Integer, Integer>();

        public void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }

        public Inventory getInventory() {
            return this.inventory;
        }

        public void mapSlot(int slot, int level) {
            this.slotToLevel.put(slot, level);
        }

        public Integer getLevel(int slot) {
            return this.slotToLevel.get(slot);
        }
    }
}

