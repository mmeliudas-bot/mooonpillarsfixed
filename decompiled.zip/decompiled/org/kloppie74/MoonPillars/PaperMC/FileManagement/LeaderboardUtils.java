/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement;

import java.util.List;
import java.util.UUID;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class LeaderboardUtils {
    public static boolean isPlayerIncludedInLeaderboards(String playerUuid) {
        FileConfiguration config = SettingsManager.getInstance().getSettings();
        List excludedPlayers = config.getStringList("Leaderboards.ExcludedPlayers");
        if (excludedPlayers == null) {
            return true;
        }
        return !excludedPlayers.contains(playerUuid);
    }

    public static boolean isPlayerIncludedInLeaderboards(Player player) {
        return LeaderboardUtils.isPlayerIncludedInLeaderboards(player.getUniqueId().toString());
    }

    public static boolean isPlayerIncludedInLeaderboards(UUID uuid) {
        return LeaderboardUtils.isPlayerIncludedInLeaderboards(uuid.toString());
    }
}

