/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.ChatManagerFunctions;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.ChatManagerFunctions.KeyFilter;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class SpamFilter {
    private final boolean enabled = SettingsManager.getInstance().getSettings().getBoolean("Chat-Format.Anti-Spam-Enabled", true);
    private final double similarityThreshold = SettingsManager.getInstance().getSettings().getDouble("Chat-Format.Anti-Spam-Percent", 80.0) / 100.0;
    private final KeyFilter keyFilter = new KeyFilter();
    private final Map<UUID, String> lastMessages = new HashMap<UUID, String>();

    public boolean isSpam(Player player, String message) {
        String lastMessage;
        double similarity;
        if (!this.enabled) {
            return false;
        }
        if (this.keyFilter.containsKeySpam(message)) {
            return true;
        }
        UUID playerUUID = player.getUniqueId();
        if (this.lastMessages.containsKey(playerUUID) && (similarity = this.calculateSimilarity(lastMessage = this.lastMessages.get(playerUUID), message)) >= this.similarityThreshold) {
            return true;
        }
        this.lastMessages.put(playerUUID, message);
        return false;
    }

    private double calculateSimilarity(String str1, String str2) {
        if (!str1.isEmpty() && !str2.isEmpty()) {
            int[][] distance = new int[str1.length() + 1][str2.length() + 1];
            int i = 0;
            while (i <= str1.length()) {
                distance[i][0] = i++;
            }
            i = 0;
            while (i <= str2.length()) {
                distance[0][i] = i++;
            }
            for (i = 1; i <= str1.length(); ++i) {
                for (int j = 1; j <= str2.length(); ++j) {
                    int cost = str1.charAt(i - 1) == str2.charAt(j - 1) ? 0 : 1;
                    distance[i][j] = Math.min(Math.min(distance[i - 1][j] + 1, distance[i][j - 1] + 1), distance[i - 1][j - 1] + cost);
                }
            }
            i = Math.max(str1.length(), str2.length());
            double levenshteinSimilarity = 1.0 - (double)distance[str1.length()][str2.length()] / (double)i;
            return levenshteinSimilarity;
        }
        return 0.0;
    }

    public void clearLastMessage(Player player) {
        this.lastMessages.remove(player.getUniqueId());
    }

    public boolean handleChatMessage(Player player, String message) {
        return !this.isSpam(player, message);
    }
}

