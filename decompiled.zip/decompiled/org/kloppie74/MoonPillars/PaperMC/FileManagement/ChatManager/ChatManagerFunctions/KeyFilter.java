/*
 * Decompiled with CFR 0.152.
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.ChatManagerFunctions;

import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class KeyFilter {
    private final boolean enabled = SettingsManager.getInstance().getSettings().getBoolean("Chat-Format.Block-Key-Spam", true);
    private final int keySpamAmount = SettingsManager.getInstance().getSettings().getInt("Chat-Format.Key-Spam-Amount", 5);

    public boolean containsKeySpam(String message) {
        if (!this.enabled) {
            return false;
        }
        if (message.length() < this.keySpamAmount) {
            return false;
        }
        if (this.hasRepeatedCharacters(message)) {
            return true;
        }
        return this.hasRepeatedPatterns(message);
    }

    private boolean hasRepeatedCharacters(String message) {
        char[] chars = message.toLowerCase().toCharArray();
        int count = 1;
        for (int i = 1; i < chars.length; ++i) {
            if (chars[i] == chars[i - 1]) {
                if (++count < this.keySpamAmount) continue;
                return true;
            }
            count = 1;
        }
        return false;
    }

    private boolean hasRepeatedPatterns(String message) {
        String lowercaseMessage = message.toLowerCase();
        for (int patternLength = 2; patternLength <= 4; ++patternLength) {
            if (lowercaseMessage.length() < patternLength * this.keySpamAmount) continue;
            for (int i = 0; i <= lowercaseMessage.length() - patternLength * 2; ++i) {
                String pattern = lowercaseMessage.substring(i, i + patternLength);
                int repetitions = this.countPatternRepetitions(lowercaseMessage, pattern, i);
                if (repetitions < this.keySpamAmount) continue;
                return true;
            }
        }
        return false;
    }

    private int countPatternRepetitions(String message, String pattern, int startIndex) {
        String nextChunk;
        int repetitions = 1;
        int patternLength = pattern.length();
        int position = startIndex + patternLength;
        while (position + patternLength <= message.length() && (nextChunk = message.substring(position, position + patternLength)).equals(pattern)) {
            ++repetitions;
            position += patternLength;
        }
        return repetitions;
    }
}

