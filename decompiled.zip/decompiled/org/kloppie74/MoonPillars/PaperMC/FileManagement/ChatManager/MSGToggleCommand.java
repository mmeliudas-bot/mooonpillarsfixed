/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;

public class MSGToggleCommand
implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            boolean var6 = DatabaseManager.getInstance().getMsgToggle(player.getUniqueId());
            boolean newState = !var6;
            DatabaseManager.getInstance().setMsgToggle(player.getUniqueId(), newState);
            if (newState) {
                player.sendMessage(MSG.chatColors("&aYou will now receive messages."));
            } else {
                player.sendMessage(MSG.chatColors("&cYou will no longer receive messages."));
            }
            return true;
        }
        sender.sendMessage("This command can only be used by a player.");
        return true;
    }
}

