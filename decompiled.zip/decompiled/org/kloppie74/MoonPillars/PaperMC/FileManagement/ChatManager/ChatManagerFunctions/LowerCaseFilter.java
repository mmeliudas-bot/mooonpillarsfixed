/*
 * Decompiled with CFR 0.152.
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.ChatManagerFunctions;

import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class LowerCaseFilter {
    private final boolean enabled = SettingsManager.getInstance().getSettings().getBoolean("Chat-Format.Fix-Uppercase", true);
    private final int minLength = SettingsManager.getInstance().getSettings().getInt("Chat-Format.Min-Length-For-Uppercase-Check", 5);
    private final double upperCaseThreshold = SettingsManager.getInstance().getSettings().getDouble("Chat-Format.Uppercase-Threshold", 0.8);

    public String processMessage(String message) {
        if (this.enabled && message.length() >= this.minLength) {
            double uppercaseRatio = this.calculateUppercaseRatio(message);
            return uppercaseRatio >= this.upperCaseThreshold ? this.capitalizeFirstLetter(message.toLowerCase()) : message;
        }
        return message;
    }

    private double calculateUppercaseRatio(String message) {
        int letterCount = 0;
        int uppercaseCount = 0;
        for (char c : message.toCharArray()) {
            if (!Character.isLetter(c)) continue;
            ++letterCount;
            if (!Character.isUpperCase(c)) continue;
            ++uppercaseCount;
        }
        return letterCount > 0 ? (double)uppercaseCount / (double)letterCount : 0.0;
    }

    private String capitalizeFirstLetter(String message) {
        if (message != null && !message.isEmpty()) {
            for (int i = 0; i < message.length(); ++i) {
                if (!Character.isLetter(message.charAt(i))) continue;
                String var10000 = message.substring(0, i);
                return var10000 + Character.toUpperCase(message.charAt(i)) + message.substring(i + 1);
            }
            return message;
        }
        return message;
    }
}

