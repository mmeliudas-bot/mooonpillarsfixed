/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerCommandPreprocessEvent
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;

public class SpyCommand
implements CommandExecutor,
Listener {
    private static final Set<UUID> spyingPlayers = new HashSet<UUID>();

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("\u00a7cOnly players can use this command!");
            return true;
        }
        Player player = (Player)sender;
        if (!player.hasPermission("mpa.spycommand")) {
            player.sendMessage("\u00a7cYou don't have permission to use this command!");
            return true;
        }
        UUID uuid = player.getUniqueId();
        if (spyingPlayers.contains(uuid)) {
            spyingPlayers.remove(uuid);
            player.sendMessage("\u00a7eSpy mode disabled.");
        } else {
            spyingPlayers.add(uuid);
            player.sendMessage("\u00a7aSpy mode enabled. You will now see all executed commands.");
        }
        return true;
    }

    public static void notifySpies(String message) {
        for (UUID uuid : spyingPlayers) {
            Player player = Bukkit.getPlayer((UUID)uuid);
            if (player == null) continue;
            player.sendMessage(MSG.chatColors("&7[&6SpyCommand&7] " + message));
        }
    }

    @EventHandler
    public void onCommandExecute(PlayerCommandPreprocessEvent event) {
        String command = event.getMessage();
        String playerName = event.getPlayer().getName();
        SpyCommand.notifySpies("\u00a7c" + playerName + " \u00a77executed: \u00a7e" + command);
    }
}

