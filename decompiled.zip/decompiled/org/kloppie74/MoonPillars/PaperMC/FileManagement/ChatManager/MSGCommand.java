/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  litebans.api.Database
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;
import litebans.api.Database;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class MSGCommand
implements CommandExecutor,
TabCompleter {
    private static final Map<UUID, UUID> lastMessageSender = new HashMap<UUID, UUID>();

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (!player.hasPermission("mpa.msg")) {
                player.sendMessage(MSG.chatColors("&cYou don't have permission to use this command!"));
                return true;
            }
            if (args.length < 2) {
                player.sendMessage(MSG.chatColors("&cUsage: /msg <player> <message>"));
                return true;
            }
            if (Bukkit.getPluginManager().isPluginEnabled("LiteBans")) {
                Bukkit.getScheduler().runTaskAsynchronously((Plugin)MoonLab.getInstance(), () -> {
                    try {
                        boolean isMuted = Database.get().isPlayerMuted(player.getUniqueId(), (String)null);
                        Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> {
                            if (isMuted) {
                                player.sendMessage(MSG.chatColors("&cYou cannot send messages while muted!"));
                            } else {
                                this.processMessage(player, args);
                            }
                        });
                    }
                    catch (Exception var4) {
                        Logger var10000 = Bukkit.getLogger();
                        String var10001 = player.getName();
                        var10000.warning("Error checking mute status for " + var10001 + ": " + var4.getMessage());
                        Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> this.processMessage(player, args));
                    }
                });
                return true;
            }
            this.processMessage(player, args);
            return true;
        }
        sender.sendMessage("This command can only be used by a player.");
        return true;
    }

    private void processMessage(Player player, String[] args) {
        Player target = Bukkit.getPlayer((String)args[0]);
        if (target == null) {
            player.sendMessage(MSG.chatColors("&cPlayer not found."));
        } else if (player.equals((Object)target)) {
            player.sendMessage(MSG.chatColors("&cYou can't message yourself."));
        } else {
            boolean targetMsgToggle = DatabaseManager.getInstance().getMsgToggle(target.getUniqueId());
            if (!targetMsgToggle) {
                player.sendMessage(MSG.chatColors("&cThis player has messages disabled."));
            } else if (Bukkit.getPluginManager().isPluginEnabled("LiteBans")) {
                Bukkit.getScheduler().runTaskAsynchronously((Plugin)MoonLab.getInstance(), () -> {
                    try {
                        boolean isTargetMuted = Database.get().isPlayerMuted(target.getUniqueId(), (String)null);
                        Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> {
                            if (isTargetMuted) {
                                player.sendMessage(MSG.chatColors("&cYou cannot message this player as they are currently muted."));
                            } else {
                                this.sendMessage(player, target, args);
                            }
                        });
                    }
                    catch (Exception var5) {
                        Logger var10000 = Bukkit.getLogger();
                        String var10001 = target.getName();
                        var10000.warning("Error checking mute status for target " + var10001 + ": " + var5.getMessage());
                        Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> this.sendMessage(player, target, args));
                    }
                });
            } else {
                this.sendMessage(player, target, args);
            }
        }
    }

    private void sendMessage(Player player, Player target, String[] args) {
        String message = String.join((CharSequence)" ", Arrays.copyOfRange(args, 1, args.length));
        FileConfiguration config = SettingsManager.getInstance().getSettings();
        String senderFormat = config.getString("Chat-Format.msg.format.sender", "&7[You -> %receiver%]: %message%");
        String receiverFormat = config.getString("Chat-Format.msg.format.receiver", "&7[%sender% -> You]: %message%");
        senderFormat = senderFormat.replace("%receiver%", target.getName()).replace("%message%", message);
        receiverFormat = receiverFormat.replace("%sender%", player.getName()).replace("%message%", message);
        player.sendMessage(MSG.chatColors(senderFormat));
        target.sendMessage(MSG.chatColors(receiverFormat));
        Bukkit.getLogger().info(senderFormat);
        Bukkit.getLogger().info(receiverFormat);
        lastMessageSender.put(target.getUniqueId(), player.getUniqueId());
        Iterator var8 = Bukkit.getOnlinePlayers().iterator();
        while (var8.hasNext()) {
            Player onlinePlayer = (Player)var8.next();
            if (onlinePlayer.equals((Object)player) || onlinePlayer.equals((Object)target)) continue;
            boolean hasSpyPermission = onlinePlayer.hasPermission("mpa.spymsg");
            int spyChatLevel = 0;
            try {
                spyChatLevel = Integer.parseInt(DatabaseManager.getInstance().getSetting(onlinePlayer.getUniqueId(), "SpyChat"));
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
            if (!hasSpyPermission && spyChatLevel < 1) continue;
            String spyPrefix = "&7[&aSpyMSG&7] &7";
            String spyFormat = "&7[&6%sender% &7-> &6%receiver%&7]: %message%";
            String spyMessage = spyFormat.replace("%sender%", player.getName()).replace("%receiver%", target.getName()).replace("%message%", message);
            onlinePlayer.sendMessage(MSG.chatColors(spyPrefix + spyMessage));
        }
        return;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            ArrayList<String> playerNames = new ArrayList<String>();
            String partialName = args[0].toLowerCase();
            for (Player playertab : Bukkit.getOnlinePlayers()) {
                if (!playertab.getName().toLowerCase().startsWith(partialName)) continue;
                playerNames.add(playertab.getName());
            }
            return playerNames;
        }
        return null;
    }

    public static UUID getLastMessageSender(UUID playerUUID) {
        return lastMessageSender.get(playerUUID);
    }

    public static void setLastMessageSender(UUID playerUUID, UUID lastSenderUUID) {
        lastMessageSender.put(playerUUID, lastSenderUUID);
    }
}

