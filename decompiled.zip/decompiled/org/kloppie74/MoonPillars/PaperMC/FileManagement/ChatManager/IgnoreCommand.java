/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;

public class IgnoreCommand
implements CommandExecutor,
TabCompleter {
    private static Map<UUID, Set<UUID>> ignoredPlayers = new HashMap<UUID, Set<UUID>>();

    public IgnoreCommand() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            IgnoreCommand.loadIgnoredPlayers(player.getUniqueId());
        }
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(MSG.chatColors("&cThis command can only be used by players."));
            return true;
        }
        Player player = (Player)sender;
        if (args.length == 0) {
            this.showHelp(player);
            return true;
        }
        if (args[0].equalsIgnoreCase("list")) {
            this.showIgnoredList(player);
            return true;
        }
        if (args[0].equalsIgnoreCase("clear")) {
            this.clearAllIgnored(player);
            return true;
        }
        Player target = Bukkit.getPlayer((String)args[0]);
        if (target == null) {
            player.sendMessage(MSG.chatColors("&cPlayer not found or not online."));
            return true;
        }
        if (target.getUniqueId().equals(player.getUniqueId())) {
            player.sendMessage(MSG.chatColors("&cYou cannot ignore yourself."));
            return true;
        }
        if (target.hasPermission("mpa.ignore.bypass") && !player.hasPermission("mpa.ignore.admin")) {
            player.sendMessage(MSG.chatColors("&cYou cannot ignore this player."));
            return true;
        }
        Set ignored = ignoredPlayers.computeIfAbsent(player.getUniqueId(), k -> new HashSet());
        if (ignored.contains(target.getUniqueId())) {
            ignored.remove(target.getUniqueId());
            player.sendMessage(MSG.chatColors("&aYou are no longer ignoring " + target.getName() + "."));
            IgnoreCommand.saveIgnoredPlayers(player.getUniqueId());
        } else {
            ignored.add(target.getUniqueId());
            player.sendMessage(MSG.chatColors("&aYou are now ignoring " + target.getName() + "."));
            IgnoreCommand.saveIgnoredPlayers(player.getUniqueId());
        }
        return true;
    }

    private void showHelp(Player player) {
        player.sendMessage(MSG.chatColors("&6=== Ignore Command Help ==="));
        player.sendMessage(MSG.chatColors("&e/ignore <player> &7- Toggle ignoring a player"));
        player.sendMessage(MSG.chatColors("&e/ignore list &7- Show all players you're ignoring"));
        player.sendMessage(MSG.chatColors("&e/ignore clear &7- Remove all players from your ignore list"));
    }

    private void showIgnoredList(Player player) {
        Set ignored = ignoredPlayers.getOrDefault(player.getUniqueId(), new HashSet());
        if (ignored.isEmpty()) {
            player.sendMessage(MSG.chatColors("&aYou are not ignoring any players."));
        } else {
            player.sendMessage(MSG.chatColors("&6=== Players You Are Ignoring ==="));
            for (UUID uuid : ignored) {
                String name = Bukkit.getOfflinePlayer((UUID)uuid).getName();
                if (name == null) continue;
                player.sendMessage(MSG.chatColors("&e- " + name));
            }
        }
    }

    private void clearAllIgnored(Player player) {
        ignoredPlayers.put(player.getUniqueId(), new HashSet());
        IgnoreCommand.saveIgnoredPlayers(player.getUniqueId());
        player.sendMessage(MSG.chatColors("&aYou are no longer ignoring any players."));
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof Player)) {
            return Collections.emptyList();
        }
        if (args.length == 1) {
            ArrayList<String> completions = new ArrayList<String>();
            completions.add("list");
            completions.add("clear");
            completions.addAll(Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList()));
            return completions.stream().filter(s -> s.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

    public static boolean isIgnoring(UUID player, UUID target) {
        Set ignored = ignoredPlayers.getOrDefault(player, Collections.emptySet());
        return ignored.contains(target);
    }

    public static void loadIgnoredPlayers(UUID playerId) {
        String ignoredData = DatabaseManager.getInstance().getSetting(playerId, "IgnoredPlayers");
        HashSet<UUID> ignored = new HashSet<UUID>();
        if (ignoredData != null && !ignoredData.isEmpty()) {
            String[] uuidStrings;
            String[] var4 = uuidStrings = ignoredData.split(",");
            int var5 = uuidStrings.length;
            for (int var6 = 0; var6 < var5; ++var6) {
                String uuidStr = var4[var6];
                try {
                    UUID uuid = UUID.fromString(uuidStr.trim());
                    ignored.add(uuid);
                    continue;
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    // empty catch block
                }
            }
        }
        ignoredPlayers.put(playerId, ignored);
    }

    public static void saveIgnoredPlayers(UUID playerId) {
        Set ignored = ignoredPlayers.getOrDefault(playerId, Collections.emptySet());
        if (ignored.isEmpty()) {
            DatabaseManager.getInstance().updateIgnoredPlayersSetting(playerId, "");
        } else {
            String ignoredData = ignored.stream().map(UUID::toString).collect(Collectors.joining(","));
            DatabaseManager.getInstance().updateIgnoredPlayersSetting(playerId, ignoredData);
        }
    }
}

