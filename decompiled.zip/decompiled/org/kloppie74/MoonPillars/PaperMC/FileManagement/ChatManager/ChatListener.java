/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  litebans.api.Database
 *  me.clip.placeholderapi.PlaceholderAPI
 *  net.kyori.adventure.text.BuildableComponent
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.TextComponent
 *  net.kyori.adventure.text.TextComponent$Builder
 *  net.kyori.adventure.text.event.ClickEvent
 *  net.kyori.adventure.text.event.HoverEvent
 *  net.kyori.adventure.text.event.HoverEventSource
 *  net.kyori.adventure.text.format.NamedTextColor
 *  net.kyori.adventure.text.format.TextColor
 *  net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
 *  org.bukkit.Bukkit
 *  org.bukkit.World
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;
import litebans.api.Database;
import me.clip.placeholderapi.PlaceholderAPI;
import net.kyori.adventure.text.BuildableComponent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.event.HoverEventSource;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.EditorMenu;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.ChatManagerFunctions.KeyFilter;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.ChatManagerFunctions.LowerCaseFilter;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.ChatManagerFunctions.SpamFilter;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.ChatManagerFunctions.SwearFilter;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.IgnoreCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;
import org.kloppie74.MoonPillars.PaperMC.PartyListener.PartyStaticClass;

public class ChatListener
implements Listener {
    private static ChatListener instance;
    private final SpamFilter spamFilter;
    private final KeyFilter keyFilter;
    private final LowerCaseFilter lowerCaseFilter;
    private Map<String, List<String>> chatReplyTriggers;
    private final HashMap<UUID, Integer> warningMap;
    private File logFile;
    private FileWriter fileWriter;
    private SimpleDateFormat dateFormat;
    private static final String LOG_DIRECTORY = "Logs/ChatLogs";

    public static ChatListener getInstance() {
        return instance;
    }

    public ChatListener() {
        instance = this;
        this.spamFilter = new SpamFilter();
        this.keyFilter = new KeyFilter();
        this.lowerCaseFilter = new LowerCaseFilter();
        this.warningMap = new HashMap();
        this.loadChatReplySettings();
        this.setupLogger();
    }

    @EventHandler(priority=EventPriority.NORMAL)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        String message = event.getMessage();
        Plugin placeholderAPIPlugin = Bukkit.getPluginManager().getPlugin("PlaceholderAPI");
        if (Bukkit.getPluginManager().isPluginEnabled("LiteBans")) {
            Bukkit.getScheduler().runTaskAsynchronously((Plugin)MoonLab.getInstance(), () -> {
                try {
                    boolean isMuted = Database.get().isPlayerMuted(player.getUniqueId(), null);
                    if (isMuted) {
                        Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> {
                            event.setCancelled(true);
                            player.sendMessage(MSG.chatColors("&cYou cannot chat while muted!"));
                        });
                    }
                }
                catch (Exception var3) {
                    Logger var10000 = Bukkit.getLogger();
                    String var10001 = player.getName();
                    var10000.warning("Error checking mute status for " + var10001 + ": " + var3.getMessage());
                }
            });
        }
        if (EditorMenu.AdminEditCache.containsKey(player.getUniqueId())) {
            event.setCancelled(true);
        } else if (!this.applyFilters(player, message, event)) {
            this.checkAndSendChatReply(player, message);
            FileConfiguration config = SettingsManager.getInstance().getSettings();
            if (!config.getBoolean("Chat-Format.Enabled")) {
                String var10001 = player.getWorld().getName();
                this.logChat("[" + var10001 + "] " + player.getName() + ": " + message);
            } else {
                event.setCancelled(true);
                boolean perWorldChat = config.getBoolean("Chat-Format.Per-World-Chat");
                String chatChannel = DatabaseManager.getInstance().getChatChannel(player.getUniqueId());
                if (chatChannel.equalsIgnoreCase("party")) {
                    UUID partyID = PartyStaticClass.getPlayerPartyOwner(player);
                    if (partyID != null) {
                        this.handlePartyChat(event, player, message, perWorldChat, placeholderAPIPlugin);
                    } else {
                        DatabaseManager.getInstance().setChatChannel(player.getUniqueId(), "global");
                        player.sendMessage(MSG.chatColors("&cYou're not in a party. &7Your chat has been switched to &6global&7."));
                        this.handleWorldOrGlobalChat(event, player, message, perWorldChat, placeholderAPIPlugin);
                    }
                } else {
                    this.handleWorldOrGlobalChat(event, player, message, perWorldChat, placeholderAPIPlugin);
                }
                this.validateSpyChat(player);
            }
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        this.spamFilter.clearLastMessage(event.getPlayer());
    }

    private boolean applyFilters(Player player, String message, AsyncPlayerChatEvent event) {
        if (!player.hasPermission("mpa.chat.bypass.spam") && !this.spamFilter.handleChatMessage(player, message)) {
            event.setCancelled(true);
            String var10001 = player.getName();
            this.logChat("[Spam Detection] " + var10001 + " (UUID: " + String.valueOf(player.getUniqueId()) + "): " + message);
            player.sendMessage(MSG.chatColors("&c&lMessage Blocked: &fSpam Detection"));
            player.sendMessage(MSG.chatColors("&fYour message was flagged as spam by our filter system."));
            player.sendMessage(MSG.chatColors("&cPlease wait before sending another message."));
            player.sendMessage(MSG.chatColors(""));
            this.notifyStaff(player, message, "spam");
            return true;
        }
        if (!player.hasPermission("mpa.chat.bypass.swear") && SwearFilter.checkSwearingFunction(message)) {
            event.setCancelled(true);
            String var10001 = player.getName();
            this.logChat("[Blocked Word] " + var10001 + " (UUID: " + String.valueOf(player.getUniqueId()) + "): " + message);
            player.sendMessage(MSG.chatColors("&c&lMessage Blocked: &fInappropriate Content"));
            player.sendMessage(MSG.chatColors("&fYour message contains prohibited language or phrases."));
            player.sendMessage(MSG.chatColors("&cPlease be respectful in our community."));
            player.sendMessage(MSG.chatColors(""));
            this.notifyStaff(player, message, "swear");
            return true;
        }
        if (!player.hasPermission("mpa.chat.bypass.keyspam") && this.keyFilter.containsKeySpam(message)) {
            event.setCancelled(true);
            String var10001 = player.getName();
            this.logChat("[Key Spam] " + var10001 + " (UUID: " + String.valueOf(player.getUniqueId()) + "): " + message);
            player.sendMessage(MSG.chatColors("&c&lMessage Blocked: &fPattern Detection"));
            player.sendMessage(MSG.chatColors("&fYour message contains too many repeated characters or patterns."));
            player.sendMessage(MSG.chatColors("&cPlease compose a more natural message."));
            player.sendMessage(MSG.chatColors(""));
            this.notifyStaff(player, message, "keyspam");
            return true;
        }
        if (!player.hasPermission("mpa.chat.bypass.uppercase")) {
            message = this.lowerCaseFilter.processMessage(message);
            event.setMessage(message);
        }
        return false;
    }

    private void notifyStaff(Player player, String message, String filterType) {
        int var6 = -1;
        switch (filterType.hashCode()) {
            case -814526936: {
                if (!filterType.equals("keyspam")) break;
                var6 = 2;
                break;
            }
            case 3536713: {
                if (!filterType.equals("spam")) break;
                var6 = 0;
                break;
            }
            case 109850226: {
                if (!filterType.equals("swear")) break;
                var6 = 1;
            }
        }
        Object typeText = switch (var6) {
            case 0 -> "tried to spam";
            case 1 -> "used blocked word in";
            case 2 -> "tried to key spam";
            default -> "was flagged for " + filterType + " in";
        };
        BuildableComponent baseMessage = ((TextComponent.Builder)((TextComponent.Builder)((TextComponent.Builder)((TextComponent.Builder)((TextComponent.Builder)((TextComponent.Builder)Component.text().content("[").color((TextColor)NamedTextColor.DARK_GRAY)).append((Component)Component.text((String)"SpyChat", (TextColor)NamedTextColor.DARK_RED))).append((Component)Component.text((String)"] ", (TextColor)NamedTextColor.DARK_GRAY))).append((Component)Component.text((String)player.getName(), (TextColor)NamedTextColor.RED))).append((Component)Component.text((String)(" " + (String)typeText + ": "), (TextColor)NamedTextColor.GRAY))).append((Component)Component.text((String)message, (TextColor)NamedTextColor.WHITE))).build();
        if (filterType.equals("swear")) {
            baseMessage = baseMessage.hoverEvent((HoverEventSource)HoverEvent.showText((Component)Component.text((String)"Click to show whitelist options", (TextColor)NamedTextColor.YELLOW)));
            String messageId = UUID.randomUUID().toString().substring(0, 8);
            baseMessage = baseMessage.clickEvent(ClickEvent.callback(viewer -> {
                Player staffPlayer;
                if (viewer instanceof Player && (staffPlayer = (Player)viewer).hasPermission("mpa.chat.whitelist")) {
                    this.showWhitelistOptions(staffPlayer, message);
                }
            }));
        }
        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            int targetSpyChatLVL;
            if (player.equals((Object)onlinePlayer) || (targetSpyChatLVL = Integer.parseInt(DatabaseManager.getInstance().getSetting(onlinePlayer.getUniqueId(), "SpyChat"))) < 1 || !onlinePlayer.hasPermission("mpa.chat.notify")) continue;
            onlinePlayer.sendMessage((Component)baseMessage);
        }
    }

    private void showWhitelistOptions(Player staffPlayer, String message) {
        String[] words;
        if (staffPlayer.hasPermission("mpa.chat.whitelist") && (words = message.split("\\s+")).length != 0) {
            staffPlayer.sendMessage((Component)Component.text((String)"Choose a word to whitelist:", (TextColor)NamedTextColor.YELLOW));
            String[] var4 = words;
            int var5 = words.length;
            for (int var6 = 0; var6 < var5; ++var6) {
                String wordToAdd;
                String word = var4[var6];
                if (word.length() < 3 || (wordToAdd = word.toLowerCase().replaceAll("[^a-z0-9]", "")).isEmpty()) continue;
                Component wordComponent = ((TextComponent)((TextComponent)Component.text((String)"  \u27a4 ", (TextColor)NamedTextColor.GRAY).append((Component)Component.text((String)word, (TextColor)NamedTextColor.WHITE))).hoverEvent((HoverEventSource)HoverEvent.showText((Component)Component.text((String)("Click to show whitelist options for: " + word))))).clickEvent(ClickEvent.callback(viewer -> {
                    Player player;
                    if (viewer instanceof Player && (player = (Player)viewer).hasPermission("mpa.chat.whitelist")) {
                        this.showConfirmation(player, wordToAdd);
                    }
                }));
                staffPlayer.sendMessage(wordComponent);
            }
        }
    }

    private void showConfirmation(Player staffPlayer, String word) {
        if (staffPlayer.hasPermission("mpa.chat.whitelist")) {
            List whitelistedWords = SettingsManager.getInstance().getSettings().getStringList("Chat-Format.WhitelistedWords");
            if (whitelistedWords.contains(word)) {
                staffPlayer.sendMessage(MSG.chatColors("&6The word \"" + word + "\" is already whitelisted."));
            } else {
                staffPlayer.sendMessage((Component)Component.text((String)("Add \"" + word + "\" to the whitelist?"), (TextColor)NamedTextColor.YELLOW));
                Component confirmButton = ((TextComponent)Component.text((String)"[CONFIRM]", (TextColor)NamedTextColor.GREEN).hoverEvent((HoverEventSource)HoverEvent.showText((Component)Component.text((String)("Click to add \"" + word + "\" to the whitelist"))))).clickEvent(ClickEvent.callback(viewer -> {
                    Player player;
                    if (viewer instanceof Player && (player = (Player)viewer).hasPermission("mpa.chat.whitelist")) {
                        this.addToWhitelist(player, word);
                    }
                }));
                Component declineButton = ((TextComponent)Component.text((String)"[DECLINE]", (TextColor)NamedTextColor.RED).hoverEvent((HoverEventSource)HoverEvent.showText((Component)Component.text((String)"Cancel this action")))).clickEvent(ClickEvent.callback(viewer -> {
                    if (viewer instanceof Player) {
                        Player player = (Player)viewer;
                        player.sendMessage(MSG.chatColors("&7Whitelist action cancelled."));
                    }
                }));
                staffPlayer.sendMessage(((TextComponent)((TextComponent)Component.empty().append(confirmButton)).append((Component)Component.text((String)"  "))).append(declineButton));
            }
        }
    }

    private void addToWhitelist(Player staffPlayer, String word) {
        if (!staffPlayer.hasPermission("mpa.chat.whitelist")) {
            staffPlayer.sendMessage(MSG.chatColors("&cYou don't have permission to modify the whitelist."));
        } else {
            List whitelistedWords = SettingsManager.getInstance().getSettings().getStringList("Chat-Format.WhitelistedWords");
            if (whitelistedWords.contains(word)) {
                staffPlayer.sendMessage(MSG.chatColors("&6The word \"" + word + "\" is already whitelisted."));
            } else {
                ArrayList<String> updatedWhitelist = new ArrayList<String>(whitelistedWords);
                updatedWhitelist.add(word);
                SettingsManager.getInstance().getSettings().set("Chat-Format.WhitelistedWords", updatedWhitelist);
                SettingsManager.getInstance();
                SettingsManager.saveSettings("Settings");
                staffPlayer.sendMessage(MSG.chatColors("&aAdded \"" + word + "\" to the whitelist."));
                Logger var10000 = Bukkit.getLogger();
                String var10001 = staffPlayer.getName();
                var10000.info("[MoonPillars] " + var10001 + " added word \"" + word + "\" to chat filter whitelist");
                for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
                    if (onlinePlayer.equals((Object)staffPlayer) || !onlinePlayer.hasPermission("mpa.chat.notify")) continue;
                    var10001 = staffPlayer.getName();
                    onlinePlayer.sendMessage(MSG.chatColors("&7[&aSpyChat&7] &e" + var10001 + " &7added word \"&e" + word + "&7\" to the whitelist."));
                }
            }
        }
    }

    private ChatMessageComponent createChatComponent(Player player, String message, Plugin placeholderAPI) {
        FileConfiguration config = SettingsManager.getInstance().getSettings();
        boolean useHover = config.getBoolean("Chat-Format.Hover-Event.Enabled", true);
        String format = config.getString("Chat-Format.Prefix", "%player%: %message%");
        format = format.replace("%player%", player.getName());
        format = format.replace("%message%", "");
        if (placeholderAPI != null && placeholderAPI.isEnabled()) {
            format = PlaceholderAPI.setPlaceholders((Player)player, (String)format);
        }
        String processedMessage = this.formatPlayerMessage(player, message);
        String var10000 = MSG.chatColors(format);
        String plainText = var10000 + processedMessage;
        if (!useHover) {
            return new ChatMessageComponent(plainText, null, null);
        }
        List hoverLines = config.getStringList("Chat-Format.Hover-Event.Lines");
        if (hoverLines.isEmpty()) {
            return new ChatMessageComponent(plainText, null, null);
        }
        StringBuilder hoverText = new StringBuilder();
        for (int i = 0; i < hoverLines.size(); ++i) {
            String line = (String)hoverLines.get(i);
            line = line.replace("%player%", player.getName());
            if (placeholderAPI != null && placeholderAPI.isEnabled()) {
                line = PlaceholderAPI.setPlaceholders((Player)player, (String)line);
            }
            hoverText.append(line);
            if (i >= hoverLines.size() - 1) continue;
            hoverText.append("\n");
        }
        String clickCommand = config.getString("Chat-Format.Hover-Event.Click-Command", "/msg %player% ");
        clickCommand = clickCommand.replace("%player%", player.getName());
        return new ChatMessageComponent(plainText, hoverText.toString(), clickCommand);
    }

    private String formatPlayerMessage(Player player, String message) {
        if (!player.hasPermission("mpa.chat.colors")) {
            return message;
        }
        StringBuilder result = new StringBuilder();
        boolean inCode = false;
        for (int i = 0; i < message.length(); ++i) {
            char c = message.charAt(i);
            if (inCode) {
                if ("0123456789abcdefklmnorx".indexOf(Character.toLowerCase(c)) >= 0) {
                    result.append('\u00a7').append(c);
                } else {
                    result.append('&').append(c);
                }
                inCode = false;
                continue;
            }
            if (c == '&') {
                inCode = true;
                continue;
            }
            result.append(c);
        }
        if (inCode) {
            result.append('&');
        }
        return result.toString();
    }

    private void handlePartyChat(AsyncPlayerChatEvent event, Player player, String message, boolean perWorldChat, Plugin placeholderAPIPlugin) {
        UUID partyID = PartyStaticClass.getPlayerPartyOwner(player);
        if (partyID == null) {
            this.handleWorldOrGlobalChat(event, player, message, perWorldChat, placeholderAPIPlugin);
        } else {
            List<Player> partyMembers = PartyStaticClass.PartyMembers.get(partyID);
            if (partyMembers != null && !partyMembers.isEmpty()) {
                String var10001;
                ChatMessageComponent component = this.createChatComponent(player, message, placeholderAPIPlugin);
                HashSet<Player> notifiedPlayers = new HashSet<Player>();
                for (Player onlinePlayer : partyMembers) {
                    if (this.isPlayerIgnored(player, onlinePlayer)) continue;
                    TextComponent partyPrefix = LegacyComponentSerializer.legacySection().deserialize(MSG.chatColors("&6[Party]&f "));
                    if (component.hoverText != null) {
                        onlinePlayer.sendMessage(partyPrefix.append(component.toComponent()));
                    } else {
                        var10001 = MSG.chatColors("&6[Party]&f ");
                        onlinePlayer.sendMessage(var10001 + component.text);
                    }
                    notifiedPlayers.add(onlinePlayer);
                }
                for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
                    int spyChatLevel;
                    if (notifiedPlayers.contains(onlinePlayer) || (spyChatLevel = Integer.parseInt(DatabaseManager.getInstance().getSetting(onlinePlayer.getUniqueId(), "SpyChat"))) < 1 || !onlinePlayer.hasPermission("mpa.spychat") || this.isPlayerIgnored(player, onlinePlayer)) continue;
                    TextComponent spyPrefix = LegacyComponentSerializer.legacySection().deserialize(MSG.chatColors("&7[&aSpyChat&7] &6[Party] "));
                    if (component.hoverText != null) {
                        onlinePlayer.sendMessage(spyPrefix.append(component.toComponent()));
                        continue;
                    }
                    var10001 = MSG.chatColors("&7[&aSpyChat&7] &6[Party] ");
                    onlinePlayer.sendMessage(var10001 + component.text);
                }
                var10001 = player.getName();
                this.logChat("[Party Chat] " + var10001 + " (UUID: " + String.valueOf(player.getUniqueId()) + ") (Party: " + String.valueOf(partyID) + "): " + message);
            } else {
                this.handleWorldOrGlobalChat(event, player, message, perWorldChat, placeholderAPIPlugin);
            }
        }
    }

    private void handleWorldOrGlobalChat(AsyncPlayerChatEvent event, Player player, String message, boolean perWorldChat, Plugin placeholderAPIPlugin) {
        boolean messageStartsWithExclamation = message.startsWith("!");
        String originalMessage = message;
        if (messageStartsWithExclamation) {
            message = message.substring(1).trim();
        }
        String senderGameID = this.getPlayerGameID(player);
        String worldName = player.getWorld().getName();
        boolean senderInGameWorld = worldName.startsWith("Areas/");
        boolean senderIsSpectator = senderInGameWorld && senderGameID == null;
        boolean spectatorUsingGlobalChat = senderIsSpectator && player.hasPermission("mpa.chat.global") && messageStartsWithExclamation;
        ChatMessageComponent component = this.createChatComponent(player, message, placeholderAPIPlugin);
        if (senderIsSpectator && !spectatorUsingGlobalChat) {
            String spectatorPrefix = MSG.chatColors("&3[Spectator]&r ");
            if (component.hoverText != null) {
                TextComponent prefixComp = LegacyComponentSerializer.legacySection().deserialize(spectatorPrefix);
                Component originalComp = component.toComponent();
                component = new ChatMessageComponent(spectatorPrefix + component.text, component.hoverText, component.clickCommand);
            } else {
                component = new ChatMessageComponent(spectatorPrefix + component.text, null, null);
            }
        }
        HashSet<Player> notifiedPlayers = new HashSet<Player>();
        boolean perGameChat = SettingsManager.getInstance().getSettings().getBoolean("Chat-Format.Per-Game-Chat", true);
        if (perWorldChat) {
            this.sendWorldChat(player, component, senderGameID, senderIsSpectator, spectatorUsingGlobalChat, perGameChat, notifiedPlayers);
        } else {
            this.sendGlobalChat(player, component, senderGameID, senderIsSpectator, spectatorUsingGlobalChat, perGameChat, notifiedPlayers);
        }
        this.sendSpyChat(player, component, notifiedPlayers);
        String chatType = spectatorUsingGlobalChat ? " (Spectator-Global)" : (senderIsSpectator ? " (Spectator)" : (senderGameID != null ? " (Game: " + senderGameID + ")" : " (Regular)"));
        String logPrefix = perWorldChat ? "[World Chat]" : "[Global Chat]";
        this.logChat(logPrefix + chatType + " " + player.getName() + " (UUID: " + String.valueOf(player.getUniqueId()) + (String)(perWorldChat ? " (World: " + player.getWorld().getName() + ")" : "") + ": " + originalMessage);
    }

    private void sendWorldChat(Player sender, ChatMessageComponent component, String senderGameID, boolean senderIsSpectator, boolean spectatorUsingGlobalChat, boolean perGameChat, Set<Player> notifiedPlayers) {
        World world = sender.getWorld();
        Iterator var9 = world.getPlayers().iterator();
        while (var9.hasNext()) {
            Player worldPlayer = (Player)var9.next();
            if (this.isPlayerIgnored(sender, worldPlayer)) continue;
            if (!spectatorUsingGlobalChat && perGameChat) {
                boolean receiverIsSpectator;
                String receiverGameID = this.getPlayerGameID(worldPlayer);
                boolean receiverInGameWorld = worldPlayer.getWorld().getName().startsWith("Areas/");
                boolean bl = receiverIsSpectator = receiverInGameWorld && receiverGameID == null;
                if (!(this.senderInGameWorld(sender) && senderGameID != null ? receiverGameID != null && receiverGameID.equals(senderGameID) || receiverIsSpectator : !senderIsSpectator || receiverIsSpectator)) continue;
            }
            if (component.hoverText != null) {
                worldPlayer.sendMessage(component.toComponent());
            } else {
                worldPlayer.sendMessage(component.text);
            }
            notifiedPlayers.add(worldPlayer);
        }
        return;
    }

    private void sendGlobalChat(Player sender, ChatMessageComponent component, String senderGameID, boolean senderIsSpectator, boolean spectatorUsingGlobalChat, boolean perGameChat, Set<Player> notifiedPlayers) {
        String worldName = sender.getWorld().getName();
        Iterator var9 = Bukkit.getOnlinePlayers().iterator();
        while (var9.hasNext()) {
            Player onlinePlayer = (Player)var9.next();
            if (this.isPlayerIgnored(sender, onlinePlayer)) continue;
            if (spectatorUsingGlobalChat) {
                if (!worldName.equals(onlinePlayer.getWorld().getName())) {
                    continue;
                }
            } else if (perGameChat) {
                boolean receiverIsSpectator;
                String receiverGameID = this.getPlayerGameID(onlinePlayer);
                boolean receiverInGameWorld = onlinePlayer.getWorld().getName().startsWith("Areas/");
                boolean bl = receiverIsSpectator = receiverInGameWorld && receiverGameID == null;
                if (!(this.senderInGameWorld(sender) && senderGameID != null ? receiverGameID != null && receiverGameID.equals(senderGameID) || receiverIsSpectator : !senderIsSpectator || receiverIsSpectator)) continue;
            }
            if (component.hoverText != null) {
                onlinePlayer.sendMessage(component.toComponent());
            } else {
                onlinePlayer.sendMessage(component.text);
            }
            notifiedPlayers.add(onlinePlayer);
        }
        return;
    }

    private void sendSpyChat(Player sender, ChatMessageComponent component, Set<Player> notifiedPlayers) {
        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            int spyChatLevel;
            if (notifiedPlayers.contains(onlinePlayer) || (spyChatLevel = Integer.parseInt(DatabaseManager.getInstance().getSetting(onlinePlayer.getUniqueId(), "SpyChat"))) < 1 || !onlinePlayer.hasPermission("mpa.spychat") || this.isPlayerIgnored(sender, onlinePlayer)) continue;
            TextComponent spyPrefix = LegacyComponentSerializer.legacySection().deserialize(MSG.chatColors("&7[&aSpyChat&7] &7"));
            if (component.hoverText != null) {
                onlinePlayer.sendMessage(spyPrefix.append(component.toComponent()));
                continue;
            }
            String var10001 = MSG.chatColors("&7[&aSpyChat&7] &7");
            onlinePlayer.sendMessage(var10001 + component.text);
        }
    }

    private boolean isPlayerIgnored(Player sender, Player recipient) {
        return IgnoreCommand.isIgnoring(recipient.getUniqueId(), sender.getUniqueId());
    }

    private boolean senderInGameWorld(Player player) {
        return player.getWorld().getName().startsWith("Areas/");
    }

    private String getPlayerGameID(Player player) {
        if (player != null && player.isOnline()) {
            String worldName = player.getWorld().getName();
            return !worldName.startsWith("Areas/") ? null : HashMapHandler.getPlayerGameID(player.getUniqueId());
        }
        return null;
    }

    private void validateSpyChat(Player player) {
        int spyChatLVL = Integer.parseInt(DatabaseManager.getInstance().getSetting(player.getUniqueId(), "SpyChat"));
        if (spyChatLVL > 0 && !player.hasPermission("mpa.spychat")) {
            DatabaseManager.getInstance().updateSetting(player.getUniqueId(), "SpyChat", 0);
            player.sendMessage(MSG.chatColors("&cSpyChat has been disabled because you don't have permission!"));
        }
    }

    private void loadChatReplySettings() {
        FileConfiguration config = SettingsManager.getInstance().getChatReplySettings();
        this.chatReplyTriggers = new HashMap<String, List<String>>();
        if (config == null) {
            Bukkit.getLogger().warning("[MoonPillars] Chat reply settings configuration is null.");
        } else {
            if (config.contains("ChatReplies")) {
                for (String key : config.getConfigurationSection("ChatReplies").getKeys(false)) {
                    List triggers = config.getStringList("ChatReplies." + key + ".Triggers");
                    List messages = config.getStringList("ChatReplies." + key + ".Message");
                    if (triggers.isEmpty() || messages.isEmpty()) continue;
                    for (String trigger : triggers) {
                        this.chatReplyTriggers.put(trigger.toLowerCase(), messages);
                    }
                }
            }
            Bukkit.getLogger().info("[MoonPillars] Loaded " + this.chatReplyTriggers.size() + " chat reply triggers");
        }
    }

    private void checkAndSendChatReply(Player player, String message) {
        if (!this.chatReplyTriggers.isEmpty()) {
            String lowerMessage = message.toLowerCase();
            for (Map.Entry<String, List<String>> entry : this.chatReplyTriggers.entrySet()) {
                List<String> replies;
                String trigger = entry.getKey();
                if (!lowerMessage.contains(trigger) || (replies = entry.getValue()).isEmpty()) continue;
                for (String reply : replies) {
                    player.sendMessage(MSG.chatColors(reply));
                }
                String var10001 = player.getName();
                this.logChat("[Auto-Reply] Sent to " + var10001 + " for trigger '" + trigger + "'");
                return;
            }
        }
    }

    public void reloadChatFilter() {
        this.loadChatReplySettings();
        Bukkit.getLogger().info("[MoonPillars] Chat filter has been reloaded");
    }

    private void setupLogger() {
        try {
            this.dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            File directory = new File(MoonLab.getInstance().getDataFolder(), LOG_DIRECTORY);
            if (!directory.exists()) {
                directory.mkdirs();
            }
            SimpleDateFormat fileNameFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
            String var10000 = fileNameFormat.format(new Date());
            String fileName = "chat_" + var10000 + ".log";
            this.logFile = new File(directory, fileName);
            if (!this.logFile.exists()) {
                this.logFile.createNewFile();
            }
            this.fileWriter = new FileWriter(this.logFile, true);
            String timestamp = this.dateFormat.format(new Date());
            this.fileWriter.write("[" + timestamp + "] === SERVER STARTED === New chat log initiated ===" + System.lineSeparator());
            this.fileWriter.flush();
            Bukkit.getLogger().info("Chat logging started. Log file: " + this.logFile.getName());
        }
        catch (IOException var5) {
            Bukkit.getLogger().severe("Failed to setup chat logger: " + var5.getMessage());
        }
    }

    private void logChat(String message) {
        try {
            if (this.fileWriter == null) {
                this.setupLogger();
            }
            String timestamp = this.dateFormat.format(new Date());
            this.fileWriter.write("[" + timestamp + "] " + message + System.lineSeparator());
            this.fileWriter.flush();
        }
        catch (IOException var3) {
            Bukkit.getLogger().severe("Failed to log chat message: " + var3.getMessage());
        }
    }

    public void closeLogger() {
        try {
            if (this.fileWriter != null) {
                String timestamp = this.dateFormat.format(new Date());
                this.fileWriter.write("[" + timestamp + "] === SERVER STOPPED === Chat log closed ===" + System.lineSeparator());
                this.fileWriter.flush();
                this.fileWriter.close();
                Bukkit.getLogger().info("Chat logger closed successfully.");
            }
        }
        catch (IOException var2) {
            Bukkit.getLogger().severe("Failed to close chat logger: " + var2.getMessage());
        }
    }

    private record ChatMessageComponent(String text, String hoverText, String clickCommand) {
        Component toComponent() {
            TextComponent component = LegacyComponentSerializer.legacySection().deserialize(this.text);
            if (this.hoverText != null && !this.hoverText.isEmpty()) {
                component = component.hoverEvent((HoverEventSource)HoverEvent.showText((Component)LegacyComponentSerializer.legacySection().deserialize(MSG.chatColors(this.hoverText))));
            }
            if (this.clickCommand != null && !this.clickCommand.isEmpty()) {
                component = component.clickEvent(ClickEvent.suggestCommand((String)this.clickCommand));
            }
            return component;
        }
    }
}

