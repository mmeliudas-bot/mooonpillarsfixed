/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class ClearChatCMD
implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("mpa.clearchat")) {
            sender.sendMessage(MSG.chatColors("&cYou don't have permission to use this command!"));
            return true;
        }
        FileConfiguration config = MoonLab.getInstance().getConfig();
        boolean enabled = config.getBoolean("Chat-Format.ClearChat.Enabled", true);
        int lines = config.getInt("Chat-Format.ClearChat.Amount", 500);
        String bypassPermission = config.getString("Chat-Format.ClearChat.Bypass-Permission", "mpa.admin.clearchat");
        if (!enabled) {
            sender.sendMessage(MSG.chatColors("&cChat clearing is disabled in the configuration."));
            return true;
        }
        String message = config.getString("Chat-Format.ClearChat.Message", "&8[&e&lMPA&8] &7Chat has been cleared by %player%!");
        String senderName = sender instanceof Player ? sender.getName() : "Console";
        message = message.replace("%player%", senderName);
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!player.hasPermission(bypassPermission)) {
                for (int i = 0; i < lines; ++i) {
                    player.sendMessage(" ");
                }
                player.sendMessage(MSG.chatColors(message));
                continue;
            }
            player.sendMessage(MSG.chatColors("&7Chat has been cleared for players without bypass permission."));
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage(MSG.chatColors("&aChat has been cleared for all players without bypass permission."));
        }
        return true;
    }
}

