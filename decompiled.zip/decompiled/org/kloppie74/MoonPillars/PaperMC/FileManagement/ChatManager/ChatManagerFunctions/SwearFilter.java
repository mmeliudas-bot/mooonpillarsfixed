/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.ChatManagerFunctions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.bukkit.ChatColor;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class SwearFilter {
    private static final Map<Character, String> SIMILAR_CHARS = new HashMap<Character, String>();

    private static List<String> getSafeWords() {
        ArrayList<String> safeWords = new ArrayList<String>();
        try {
            List configWords = SettingsManager.getInstance().getSettings().getStringList("Chat-Format.WhitelistedWords");
            if (configWords != null) {
                for (String word : configWords) {
                    safeWords.add(word.toLowerCase());
                }
            }
        }
        catch (Exception var4) {
            var4.printStackTrace();
        }
        return safeWords;
    }

    public static boolean checkSwearingFunction(String message) {
        List blockedWords = SettingsManager.getInstance().getSettings().getStringList("Chat-Format.BlockedWords");
        if (blockedWords != null && !blockedWords.isEmpty()) {
            String word;
            String normalizedMessage = SwearFilter.normalizeText(message);
            HashSet<String> messageWords = new HashSet<String>(Arrays.asList(normalizedMessage.split("\\s+")));
            List<String> safeWords = SwearFilter.getSafeWords();
            HashSet<String> safeWordsSet = new HashSet<String>(safeWords);
            List filteredBlockedWords = blockedWords.stream().filter(wordx -> wordx.length() >= 4).collect(Collectors.toList());
            Iterator var7 = messageWords.iterator();
            do {
                if (var7.hasNext()) continue;
                List blockedPatterns = filteredBlockedWords.stream().map(SwearFilter::createBypassPattern).collect(Collectors.toList());
                for (Pattern pattern : blockedPatterns) {
                    String match;
                    if (!pattern.matcher(normalizedMessage).find() || (match = SwearFilter.findMatchingSubstring(normalizedMessage, pattern)) == null || SwearFilter.isPartOfSafeWord(match, safeWords)) continue;
                    return true;
                }
                return false;
            } while (!blockedWords.contains((word = (String)var7.next()).toLowerCase()) || safeWordsSet.contains(word.toLowerCase()));
            return true;
        }
        return false;
    }

    private static String findMatchingSubstring(String text, Pattern pattern) {
        Matcher matcher = pattern.matcher(text);
        return matcher.find() ? matcher.group() : null;
    }

    private static boolean isPartOfSafeWord(String word, List<String> safeWords) {
        String safeWord;
        Iterator<String> var2 = safeWords.iterator();
        do {
            if (var2.hasNext()) continue;
            return false;
        } while (!(safeWord = var2.next()).contains(word));
        return true;
    }

    private static Pattern createBypassPattern(String word) {
        String normalized = SwearFilter.normalizeText(word);
        if (normalized.length() < 4) {
            return Pattern.compile("\\b" + Pattern.quote(normalized) + "\\b", 2);
        }
        StringBuilder patternBuilder = new StringBuilder("\\b");
        for (int i = 0; i < normalized.length(); ++i) {
            char c = normalized.charAt(i);
            if (i != 0 && i != normalized.length() - 1) {
                patternBuilder.append(SwearFilter.getCharacterPattern(c));
                patternBuilder.append("{1,2}");
                continue;
            }
            patternBuilder.append(SwearFilter.getSimpleCharacterPattern(c));
        }
        patternBuilder.append("\\b");
        return Pattern.compile(patternBuilder.toString(), 2);
    }

    private static String getSimpleCharacterPattern(char c) {
        return switch (c) {
            case 'a' -> "[aA@4]";
            case 'e' -> "[eE3]";
            case 'i' -> "[iI!1|]";
            case 'o' -> "[oO0]";
            case 's' -> "[sS$5]";
            default -> String.valueOf(c);
        };
    }

    private static String getCharacterPattern(char c) {
        return switch (c) {
            case 'a' -> "[aA@4]";
            case 'b' -> "[bB8]";
            case 'c' -> "[cC]";
            default -> String.valueOf(c);
            case 'e' -> "[eE3]";
            case 'i' -> "[iI!1|]";
            case 'l' -> "[lL1|]";
            case 'o' -> "[oO0]";
            case 's' -> "[sS$5]";
            case 't' -> "[tT7]";
            case 'z' -> "[zZ2]";
        };
    }

    private static String normalizeText(String text) {
        if (text == null) {
            return "";
        }
        String normalized = text.toLowerCase();
        normalized = ChatColor.stripColor((String)normalized);
        normalized = normalized.replaceAll("[.,\\-_'\"!?*()\\[\\]{}:;/<>]", " ");
        normalized = normalized.replaceAll("\\s+", " ").trim();
        return normalized;
    }

    static {
        SIMILAR_CHARS.put(Character.valueOf('a'), "a4@");
        SIMILAR_CHARS.put(Character.valueOf('b'), "b8");
        SIMILAR_CHARS.put(Character.valueOf('c'), "ck");
        SIMILAR_CHARS.put(Character.valueOf('e'), "e3");
        SIMILAR_CHARS.put(Character.valueOf('g'), "gq");
        SIMILAR_CHARS.put(Character.valueOf('h'), "hn");
        SIMILAR_CHARS.put(Character.valueOf('i'), "i1!");
        SIMILAR_CHARS.put(Character.valueOf('l'), "l1|");
        SIMILAR_CHARS.put(Character.valueOf('o'), "o0");
        SIMILAR_CHARS.put(Character.valueOf('s'), "s5$");
        SIMILAR_CHARS.put(Character.valueOf('t'), "t7");
        SIMILAR_CHARS.put(Character.valueOf('z'), "z2");
    }
}

