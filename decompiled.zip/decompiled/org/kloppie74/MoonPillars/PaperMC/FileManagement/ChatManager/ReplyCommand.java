/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  litebans.api.Database
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager;

import java.util.Arrays;
import java.util.Iterator;
import java.util.UUID;
import java.util.logging.Logger;
import litebans.api.Database;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.MSGCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class ReplyCommand
implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (!player.hasPermission("mpa.reply")) {
                player.sendMessage(MSG.chatColors("&cYou don't have permission to use this command!"));
                return true;
            }
            if (args.length < 1) {
                player.sendMessage(MSG.chatColors("&cUsage: /reply <message>"));
                return true;
            }
            if (Bukkit.getPluginManager().isPluginEnabled("LiteBans")) {
                Bukkit.getScheduler().runTaskAsynchronously((Plugin)MoonLab.getInstance(), () -> {
                    try {
                        boolean isMuted = Database.get().isPlayerMuted(player.getUniqueId(), (String)null);
                        Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> {
                            if (isMuted) {
                                player.sendMessage(MSG.chatColors("&cYou cannot send messages while muted!"));
                            } else {
                                this.processReply(player, args);
                            }
                        });
                    }
                    catch (Exception var4) {
                        Logger var10000 = Bukkit.getLogger();
                        String var10001 = player.getName();
                        var10000.warning("Error checking mute status for " + var10001 + ": " + var4.getMessage());
                        Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> this.processReply(player, args));
                    }
                });
                return true;
            }
            this.processReply(player, args);
            return true;
        }
        sender.sendMessage("This command can only be used by a player.");
        return true;
    }

    private void processReply(Player player, String[] args) {
        UUID lastSenderUUID = MSGCommand.getLastMessageSender(player.getUniqueId());
        if (lastSenderUUID == null) {
            player.sendMessage(MSG.chatColors("&cNo one to reply to."));
        } else {
            Player target = Bukkit.getPlayer((UUID)lastSenderUUID);
            if (target == null) {
                player.sendMessage(MSG.chatColors("&cPlayer not found."));
            } else {
                boolean targetMsgToggle = DatabaseManager.getInstance().getMsgToggle(target.getUniqueId());
                if (!targetMsgToggle) {
                    player.sendMessage(MSG.chatColors("&cThis player has messages disabled."));
                } else {
                    String message = String.join((CharSequence)" ", Arrays.copyOfRange(args, 0, args.length));
                    FileConfiguration config = SettingsManager.getInstance().getSettings();
                    String senderFormat = config.getString("Chat-Format.msg.format.sender", "&7[You -> %receiver%]: %message%");
                    String receiverFormat = config.getString("Chat-Format.msg.format.receiver", "&7[%sender% -> You]: %message%");
                    senderFormat = senderFormat.replace("%receiver%", target.getName()).replace("%message%", message);
                    receiverFormat = receiverFormat.replace("%sender%", player.getName()).replace("%message%", message);
                    player.sendMessage(MSG.chatColors(senderFormat));
                    target.sendMessage(MSG.chatColors(receiverFormat));
                    Bukkit.getLogger().info(senderFormat);
                    Bukkit.getLogger().info(receiverFormat);
                    MSGCommand.setLastMessageSender(target.getUniqueId(), player.getUniqueId());
                    Iterator var10 = Bukkit.getOnlinePlayers().iterator();
                    while (true) {
                        if (!var10.hasNext()) {
                            return;
                        }
                        Player onlinePlayer = (Player)var10.next();
                        if (onlinePlayer.equals((Object)player) || onlinePlayer.equals((Object)target)) continue;
                        boolean hasSpyPermission = onlinePlayer.hasPermission("mpa.spymsg");
                        int spyChatLevel = 0;
                        try {
                            spyChatLevel = Integer.parseInt(DatabaseManager.getInstance().getSetting(onlinePlayer.getUniqueId(), "SpyChat"));
                        }
                        catch (NumberFormatException numberFormatException) {
                            // empty catch block
                        }
                        if (!hasSpyPermission && spyChatLevel < 1) continue;
                        String spyPrefix = "&7[&aSpyMSG&7] &7";
                        String spyFormat = "&7[&6%sender% &7-> &6%receiver%&7]: %message%";
                        String spyMessage = spyFormat.replace("%sender%", player.getName()).replace("%receiver%", target.getName()).replace("%message%", message);
                        onlinePlayer.sendMessage(MSG.chatColors(spyPrefix + spyMessage));
                    }
                }
            }
        }
    }
}

