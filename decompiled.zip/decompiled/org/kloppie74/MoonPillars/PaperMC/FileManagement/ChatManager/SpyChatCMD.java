/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;

public class SpyChatCMD
implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length == 0) {
                if (!player.hasPermission("mpa.spychat")) {
                    player.sendMessage(MSG.chatColors("&cYou don't have permission to use this command!"));
                    return true;
                }
                int SpyChatLVL = Integer.parseInt(DatabaseManager.getInstance().getSetting(player.getUniqueId(), "SpyChat"));
                if (SpyChatLVL == 0) {
                    DatabaseManager.getInstance().updateSetting(player.getUniqueId(), "SpyChat", 1);
                    player.sendMessage(MSG.chatColors("&aSpyChat has been enabled!"));
                } else {
                    DatabaseManager.getInstance().updateSetting(player.getUniqueId(), "SpyChat", 0);
                    player.sendMessage(MSG.chatColors("&cSpyChat has been disabled!"));
                }
            }
            return true;
        }
        sender.sendMessage("This command can only be used by a player.");
        return true;
    }
}

