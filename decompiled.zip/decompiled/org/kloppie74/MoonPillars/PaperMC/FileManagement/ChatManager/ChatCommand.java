/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;

public class ChatCommand
implements CommandExecutor,
TabCompleter {
    private final List<String> VALID_CHANNELS = Arrays.asList("global", "party");

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }
        Player player = (Player)sender;
        if (args.length == 0) {
            String channelArg = DatabaseManager.getInstance().getChatChannel(player.getUniqueId());
            player.sendMessage(MSG.chatColors("&7&l&m-----==&r&7&l[ &6&lChat Channels &7&l]&7&l&m==-----"));
            player.sendMessage(MSG.chatColors("&7"));
            player.sendMessage(MSG.chatColors("    &6&lCurrent channel: &6" + channelArg));
            player.sendMessage(MSG.chatColors("    &7Use &6/chat <global|party> &7to change channels"));
            player.sendMessage(MSG.chatColors("&7"));
            player.sendMessage(MSG.chatColors("&7&l&m------------------------------------------"));
            return true;
        }
        if (args.length == 1) {
            String channelArg = args[0].toLowerCase();
            if (!this.VALID_CHANNELS.contains(channelArg)) {
                player.sendMessage(MSG.chatColors("&cInvalid channel! Use: global, party"));
                return true;
            }
            DatabaseManager.getInstance().setChatChannel(player.getUniqueId(), channelArg);
            player.sendMessage(MSG.chatColors("&aChat channel changed to: &6" + channelArg));
            return true;
        }
        player.sendMessage(MSG.chatColors("&cUsage: /chat [global|party]"));
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<String>();
        if (args.length == 1) {
            String input = args[0].toLowerCase();
            completions = this.VALID_CHANNELS.stream().filter(channel -> channel.startsWith(input)).collect(Collectors.toList());
        }
        return completions;
    }
}

