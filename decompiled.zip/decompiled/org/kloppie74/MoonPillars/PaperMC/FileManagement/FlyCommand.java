/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerCommandPreprocessEvent
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class FlyCommand
implements CommandExecutor,
TabCompleter,
Listener {
    public FlyCommand() {
        MoonLab.getInstance().getServer().getPluginManager().registerEvents((Listener)this, (Plugin)MoonLab.getInstance());
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onCommandPreprocess(PlayerCommandPreprocessEvent event) {
        String command = event.getMessage().split(" ")[0].toLowerCase();
        if (command.equals("/fly")) {
            event.setCancelled(true);
            this.handleFlyCommand(event.getPlayer());
        }
    }

    private void handleFlyCommand(Player player) {
        String worldName = player.getWorld().getName().toLowerCase();
        if (!player.hasPermission("mpa.fly.*") && !player.hasPermission("mpa.fly.world." + worldName)) {
            player.sendMessage(MSG.chatColors("&cYou don't have permission to fly in this world."));
        } else {
            boolean newFlightState = !player.getAllowFlight();
            player.setAllowFlight(newFlightState);
            if (!newFlightState && player.isFlying()) {
                player.setFlying(false);
            }
            if (newFlightState) {
                player.sendMessage(MSG.chatColors("&aFlight mode &eenabled&a."));
            } else {
                player.sendMessage(MSG.chatColors("&aFlight mode &edisabled&a."));
            }
        }
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(String.valueOf(ChatColor.RED) + "This command can only be used by players.");
            return true;
        }
        Player player = (Player)sender;
        this.handleFlyCommand(player);
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return new ArrayList<String>();
    }
}

