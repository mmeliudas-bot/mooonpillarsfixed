/*
 * Decompiled with CFR 0.152.
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LogManager {
    private static final String LOG_DIRECTORY = "./plugins/MoonPillars/Logs/";

    public static void LogMessage(String logMessage) {
        try {
            LogManager.createLogFile();
            FileWriter fw = new FileWriter("./plugins/MoonPillars/Logs/Latest-Log.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            String var10001 = LogManager.getCurrentTimestamp();
            bw.write(var10001 + " - " + logMessage);
            bw.newLine();
            bw.close();
        }
        catch (IOException var3) {
            var3.printStackTrace();
        }
    }

    private static void createLogFile() {
        File latestLog;
        File logDirectory = new File(LOG_DIRECTORY);
        if (!logDirectory.exists()) {
            logDirectory.mkdirs();
        }
        if ((latestLog = new File("./plugins/MoonPillars/Logs/Latest-Log.txt")).exists()) {
            String newFileName = "Log-" + LogManager.getCurrentDate() + ".txt";
            File oldFile = new File("./plugins/MoonPillars/Logs/Latest-Log.txt");
            File newFile = new File(LOG_DIRECTORY + newFileName);
            oldFile.renameTo(newFile);
        }
        try {
            if (!latestLog.exists()) {
                latestLog.createNewFile();
            }
        }
        catch (IOException var5) {
            var5.printStackTrace();
        }
    }

    private static String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(new Date());
    }

    private static String getCurrentTimestamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new Date());
    }
}

