/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.ConsoleCommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.PlayerVisibilityListener;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;

public class ShowOthersCommand
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length == 0) {
                player.sendMessage(MSG.chatColors("&cUsage: /showothers <playername>"));
                return true;
            }
            if (args.length == 2 && player.hasPermission("mpa.showothers.others")) {
                String operatorName = args[0];
                String targetName = args[1];
                Player operator = Bukkit.getPlayer((String)operatorName);
                if (operator == null) {
                    player.sendMessage(MSG.chatColors("&cOperator player not found."));
                    return true;
                }
                String operatorGameID = HashMapHandler.getPlayerGameID(operator.getUniqueId());
                if (operatorGameID != null) {
                    player.sendMessage(MSG.chatColors("&cThat player is currently in a game and cannot use showothers."));
                    return true;
                }
                UUID operatorUUID = operator.getUniqueId();
                PlayerVisibilityListener.VisibilityState operatorState = PlayerVisibilityListener.getPlayerVisibilityState(operatorUUID);
                if (operatorState == null) {
                    player.sendMessage(MSG.chatColors("&cError retrieving operator's visibility state. Please try again."));
                    return true;
                }
                if (!operatorState.isHideOthers()) {
                    player.sendMessage(MSG.chatColors("&cThat player doesn't have hideothers enabled, so can't use showothers."));
                    return true;
                }
                Player target = Bukkit.getPlayer((String)targetName);
                if (target == null) {
                    player.sendMessage(MSG.chatColors("&cTarget player not found."));
                    return true;
                }
                this.toggleShowOthers(operator, target, player);
                return true;
            }
            UUID playerUUID = player.getUniqueId();
            String targetName = HashMapHandler.getPlayerGameID(playerUUID);
            if (targetName != null) {
                player.sendMessage(MSG.chatColors("&cYou cannot use this command while in a game."));
                return true;
            }
            try {
                PlayerVisibilityListener.VisibilityState state = PlayerVisibilityListener.getPlayerVisibilityState(playerUUID);
                if (state == null) {
                    player.sendMessage(MSG.chatColors("&cError retrieving visibility state. Please try again."));
                    return true;
                }
                if (!state.isHideOthers()) {
                    player.sendMessage(MSG.chatColors("&cYou cannot use this command because hideothers is disabled."));
                    return true;
                }
                Player target = Bukkit.getPlayer((String)args[0]);
                if (target == null) {
                    player.sendMessage(MSG.chatColors("&cPlayer not found."));
                    return true;
                }
                this.toggleShowOthers(player, target, null);
            }
            catch (Exception var13) {
                player.sendMessage(MSG.chatColors("&cAn error occurred while processing your request."));
                ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
                String var10001 = player.getName();
                var10000.sendMessage(MSG.chatColors("&7[ChatLog] [ShowOthers] Error for " + var10001 + ": " + var13.getMessage()));
                var13.printStackTrace();
            }
            return true;
        }
        sender.sendMessage(MSG.chatColors("&cThis command can only be used by a player."));
        return true;
    }

    private void toggleShowOthers(Player operator, Player target, Player executor) {
        block18: {
            UUID operatorUUID = operator.getUniqueId();
            UUID targetUUID = target.getUniqueId();
            try {
                String var10001;
                PlayerVisibilityListener.VisibilityState operatorState = PlayerVisibilityListener.getPlayerVisibilityState(operatorUUID);
                if (operatorState == null) {
                    if (executor != null) {
                        executor.sendMessage(MSG.chatColors("&cError retrieving visibility state. Please try again."));
                    } else {
                        operator.sendMessage(MSG.chatColors("&cError retrieving visibility state. Please try again."));
                    }
                    break block18;
                }
                PlayerVisibilityListener.VisibilityState targetState = PlayerVisibilityListener.getPlayerVisibilityState(targetUUID);
                if (targetState == null) {
                    if (executor != null) {
                        executor.sendMessage(MSG.chatColors("&cCannot get player state. Please try again."));
                    } else {
                        operator.sendMessage(MSG.chatColors("&cCannot get player state. Please try again."));
                    }
                    break block18;
                }
                if (targetState.isVanished() && !operator.hasPermission("mpa.vanish.seeothers") && executor == null) {
                    operator.sendMessage(MSG.chatColors("&cPlayer not found."));
                    ConsoleCommandSender var14 = Bukkit.getConsoleSender();
                    String var100012 = operator.getName();
                    var14.sendMessage(MSG.chatColors("&7[ChatLog] [ShowOthers] " + var100012 + " attempted to showothers vanished player " + target.getName()));
                    break block18;
                }
                HashSet<UUID> showOthers = new HashSet<UUID>(operatorState.getShowOthers());
                if (showOthers.contains(targetUUID)) {
                    String var100013;
                    showOthers.remove(targetUUID);
                    PlayerVisibilityListener.updateCacheValue(operatorUUID, "showOthers", showOthers);
                    operator.sendMessage(MSG.chatColors("&cYou can no longer see " + target.getName() + "."));
                    if (executor != null && !executor.equals((Object)operator)) {
                        var100013 = operator.getName();
                        executor.sendMessage(MSG.chatColors("&c" + var100013 + " can no longer see " + target.getName() + "."));
                    }
                    String executorInfo = executor != null && !executor.equals((Object)operator) ? " by " + executor.getName() : "";
                    String var10000 = operator.getName();
                    String logMessage = var10000 + " removed " + target.getName() + " from ShowOthers" + executorInfo;
                    Bukkit.getConsoleSender().sendMessage(MSG.chatColors("&7[ChatLog] [ShowOthers] " + logMessage));
                    Iterator var11 = Bukkit.getOnlinePlayers().iterator();
                    while (true) {
                        if (!var11.hasNext()) {
                            return;
                        }
                        Player admin = (Player)var11.next();
                        if (admin.equals((Object)operator) || admin.equals((Object)executor) || !admin.hasPermission("mpa.notify.admin")) continue;
                        var100013 = operator.getName();
                        admin.sendMessage(MSG.chatColors("&7[&aShowOthers&7] &a" + var100013 + " &7can no longer see &a" + target.getName() + (String)(executor != null && !executor.equals((Object)operator) ? " &7(set by &a" + executor.getName() + "&7)" : "")));
                    }
                }
                showOthers.add(targetUUID);
                PlayerVisibilityListener.updateCacheValue(operatorUUID, "showOthers", showOthers);
                operator.sendMessage(MSG.chatColors("&aYou can now see " + target.getName() + "."));
                if (executor != null && !executor.equals((Object)operator)) {
                    var10001 = operator.getName();
                    executor.sendMessage(MSG.chatColors("&a" + var10001 + " can now see " + target.getName() + "."));
                }
                String executorInfo = executor != null && !executor.equals((Object)operator) ? " by " + executor.getName() : "";
                String var10000 = operator.getName();
                String logMessage = var10000 + " added " + target.getName() + " to ShowOthers" + executorInfo;
                Bukkit.getConsoleSender().sendMessage(MSG.chatColors("&7[ChatLog] [ShowOthers] " + logMessage));
                Iterator var11 = Bukkit.getOnlinePlayers().iterator();
                while (true) {
                    if (!var11.hasNext()) {
                        return;
                    }
                    Player admin = (Player)var11.next();
                    if (admin.equals((Object)operator) || admin.equals((Object)executor) || !admin.hasPermission("mpa.notify.admin")) continue;
                    var10001 = operator.getName();
                    admin.sendMessage(MSG.chatColors("&7[&aShowOthers&7] &a" + var10001 + " &7can now see &a" + target.getName() + (String)(executor != null && !executor.equals((Object)operator) ? " &7(set by &a" + executor.getName() + "&7)" : "")));
                }
            }
            catch (Exception var13) {
                if (executor != null) {
                    executor.sendMessage(MSG.chatColors("&cAn error occurred while processing your request."));
                } else {
                    operator.sendMessage(MSG.chatColors("&cAn error occurred while processing your request."));
                }
                Bukkit.getConsoleSender().sendMessage(MSG.chatColors("&7[ChatLog] [ShowOthers] Error: " + var13.getMessage()));
                var13.printStackTrace();
            }
        }
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length == 1) {
                String partialName = args[0].toLowerCase();
                boolean canSeeVanished = player.hasPermission("mpa.vanish.seeothers");
                boolean canControlOthers = player.hasPermission("mpa.showothers.others");
                return canControlOthers ? Bukkit.getOnlinePlayers().stream().filter(p -> p.getName().toLowerCase().startsWith(partialName)).map(Player::getName).collect(Collectors.toList()) : Bukkit.getOnlinePlayers().stream().filter(onlinePlayer -> {
                    UUID targetUUID;
                    PlayerVisibilityListener.VisibilityState state;
                    if (!canSeeVanished && (state = PlayerVisibilityListener.getPlayerVisibilityState(targetUUID = onlinePlayer.getUniqueId())) != null && state.isVanished()) {
                        return false;
                    }
                    return onlinePlayer.getName().toLowerCase().startsWith(partialName);
                }).map(Player::getName).collect(Collectors.toList());
            }
            if (args.length == 2 && player.hasPermission("mpa.showothers.others")) {
                String partialName = args[1].toLowerCase();
                boolean canSeeVanished = player.hasPermission("mpa.vanish.seeothers");
                return Bukkit.getOnlinePlayers().stream().filter(onlinePlayer -> {
                    UUID targetUUID;
                    PlayerVisibilityListener.VisibilityState state;
                    if (!canSeeVanished && (state = PlayerVisibilityListener.getPlayerVisibilityState(targetUUID = onlinePlayer.getUniqueId())) != null && state.isVanished()) {
                        return false;
                    }
                    return onlinePlayer.getName().toLowerCase().startsWith(partialName);
                }).map(Player::getName).collect(Collectors.toList());
            }
            return new ArrayList<String>();
        }
        return new ArrayList<String>();
    }
}

