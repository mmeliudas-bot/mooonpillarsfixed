/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.ConsoleCommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem;

import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.PlayerVisibilityListener;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;

public class HideOthersCommand
implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length > 0) {
                if (!player.hasPermission("mpa.hideothers.others")) {
                    player.sendMessage(MSG.chatColors("&cYou don't have permission to toggle hideothers for other players."));
                    return true;
                }
                Player targetPlayer = Bukkit.getPlayer((String)args[0]);
                if (targetPlayer == null) {
                    player.sendMessage(MSG.chatColors("&cPlayer not found or not online."));
                    return true;
                }
                String gameID = HashMapHandler.getPlayerGameID(targetPlayer.getUniqueId());
                if (gameID != null) {
                    player.sendMessage(MSG.chatColors("&cThat player is currently in a game and cannot toggle hideothers."));
                    return true;
                }
                this.toggleHideOthersState(targetPlayer, player);
                return true;
            }
            String gameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
            if (gameID != null) {
                player.sendMessage(MSG.chatColors("&cYou cannot use this command while in a game."));
                return true;
            }
            this.toggleHideOthersState(player, null);
            return true;
        }
        sender.sendMessage(MSG.chatColors("&cThis command can only be used by a player."));
        return true;
    }

    private void toggleHideOthersState(Player targetPlayer, Player executor) {
        UUID playerUUID = targetPlayer.getUniqueId();
        boolean currentHideOthersState = false;
        try {
            PlayerVisibilityListener.VisibilityState state = PlayerVisibilityListener.getPlayerVisibilityState(playerUUID);
            if (state != null) {
                currentHideOthersState = state.isHideOthers();
            }
        }
        catch (Exception var9) {
            if (executor != null) {
                executor.sendMessage(MSG.chatColors("&cError checking HideOthers state. Please try again."));
            } else {
                targetPlayer.sendMessage(MSG.chatColors("&cError checking HideOthers state. Please try again."));
            }
            ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
            String var10001 = targetPlayer.getName();
            var10000.sendMessage(MSG.chatColors("&7[ChatLog] [HideOthers] Error checking state for " + var10001 + ": " + var9.getMessage()));
            return;
        }
        boolean newHideOthersState = !currentHideOthersState;
        try {
            PlayerVisibilityListener.updateCacheValue(playerUUID, "hideOthers", newHideOthersState);
            if (newHideOthersState) {
                targetPlayer.sendMessage(MSG.chatColors("&aYou are now hiding others in this world."));
                if (executor != null && !executor.equals((Object)targetPlayer)) {
                    executor.sendMessage(MSG.chatColors("&aYou have enabled hide others for &e" + targetPlayer.getName() + "&a."));
                }
                for (Player admin : Bukkit.getOnlinePlayers()) {
                    if (admin.equals((Object)targetPlayer) || !admin.hasPermission("mpa.notify.admin")) continue;
                    admin.sendMessage(MSG.chatColors("&7[&aHideOthers&7] &a" + targetPlayer.getName() + " &7is now hiding other players."));
                }
                ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
                String var10001 = targetPlayer.getName();
                var10000.sendMessage(MSG.chatColors("&7[ChatLog] [HideOthers] " + var10001 + " enabled HideOthers" + (String)(executor != null && !executor.equals((Object)targetPlayer) ? " by " + executor.getName() : "")));
            } else {
                targetPlayer.sendMessage(MSG.chatColors("&cYou are no longer hiding others in this world."));
                if (executor != null && !executor.equals((Object)targetPlayer)) {
                    executor.sendMessage(MSG.chatColors("&cYou have disabled hide others for &e" + targetPlayer.getName() + "&c."));
                }
                for (Player admin : Bukkit.getOnlinePlayers()) {
                    if (admin.equals((Object)targetPlayer) || !admin.hasPermission("mpa.notify.admin")) continue;
                    admin.sendMessage(MSG.chatColors("&7[&aHideOthers&7] &a" + targetPlayer.getName() + " &7is no longer hiding other players."));
                }
                ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
                String var10001 = targetPlayer.getName();
                var10000.sendMessage(MSG.chatColors("&7[ChatLog] [HideOthers] " + var10001 + " disabled HideOthers" + (String)(executor != null && !executor.equals((Object)targetPlayer) ? " by " + executor.getName() : "")));
            }
        }
        catch (Exception var8) {
            if (executor != null) {
                executor.sendMessage(MSG.chatColors("&cError updating HideOthers state. Please try again."));
            } else {
                targetPlayer.sendMessage(MSG.chatColors("&cError updating HideOthers state. Please try again."));
            }
            ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
            String var10001 = targetPlayer.getName();
            var10000.sendMessage(MSG.chatColors("&7[ChatLog] [HideOthers] Error updating state for " + var10001 + ": " + var8.getMessage()));
        }
    }
}

