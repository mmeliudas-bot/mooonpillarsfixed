/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.ChatMessageType
 *  net.md_5.bungee.api.chat.TextComponent
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerChangedWorldEvent
 *  org.bukkit.event.player.PlayerGameModeChangeEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.player.PlayerRespawnEvent
 *  org.bukkit.event.player.PlayerTeleportEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class PlayerVisibilityListener
implements Listener {
    private static final Map<UUID, VisibilityState> visibilityCache = new ConcurrentHashMap<UUID, VisibilityState>();
    private static BukkitTask mainTask = null;
    private static final Set<UUID> playersNeedingUpdate = Collections.newSetFromMap(new ConcurrentHashMap());
    private static final Set<UUID> vanishedPlayers = Collections.newSetFromMap(new ConcurrentHashMap());
    private static final int PLAYERS_PER_TICK = 10;

    public static void startVisibilityTask() {
        if (mainTask == null) {
            mainTask = Bukkit.getScheduler().runTaskTimer((Plugin)MoonLab.getInstance(), () -> {
                PlayerVisibilityListener.processQueuedUpdates();
                PlayerVisibilityListener.updateVanishedPlayers();
            }, 1L, 2L);
        }
    }

    public static void stopVisibilityTask() {
        if (mainTask != null) {
            mainTask.cancel();
            mainTask = null;
        }
    }

    public static void shutdown() {
        PlayerVisibilityListener.stopVisibilityTask();
        visibilityCache.clear();
        playersNeedingUpdate.clear();
        vanishedPlayers.clear();
    }

    private static void processQueuedUpdates() {
        if (!playersNeedingUpdate.isEmpty()) {
            ArrayList<UUID> toProcess = new ArrayList<UUID>(playersNeedingUpdate);
            int count = 0;
            for (UUID playerUUID : toProcess) {
                if (count++ >= 10) break;
                Player player = Bukkit.getPlayer((UUID)playerUUID);
                if (player != null && player.isOnline()) {
                    PlayerVisibilityListener.updatePlayerVisibility(player);
                    playersNeedingUpdate.remove(playerUUID);
                    continue;
                }
                PlayerVisibilityListener.clearPlayerFromCache(playerUUID);
                playersNeedingUpdate.remove(playerUUID);
            }
        }
    }

    private static void updateVanishedPlayers() {
        if (!vanishedPlayers.isEmpty()) {
            for (UUID uuid : vanishedPlayers) {
                Player player = Bukkit.getPlayer((UUID)uuid);
                if (player != null && player.isOnline()) {
                    PlayerVisibilityListener.applyVanishEffects(player);
                    if (Bukkit.getCurrentTick() % 20 != 0) continue;
                    PlayerVisibilityListener.sendVisibilityActionBar(player);
                    continue;
                }
                vanishedPlayers.remove(uuid);
            }
            return;
        }
    }

    private static void updatePlayerVisibility(Player player) {
        UUID playerUUID = player.getUniqueId();
        VisibilityState playerState = visibilityCache.get(playerUUID);
        if (playerState != null) {
            if (playerState.vanished && !vanishedPlayers.contains(playerUUID)) {
                vanishedPlayers.add(playerUUID);
            } else if (!playerState.vanished && vanishedPlayers.contains(playerUUID)) {
                vanishedPlayers.remove(playerUUID);
            }
            PlayerVisibilityListener.sendVisibilityActionBar(player);
            for (Player otherPlayer : Bukkit.getOnlinePlayers()) {
                UUID otherUUID;
                VisibilityState otherState;
                if (otherPlayer.equals((Object)player) || (otherState = visibilityCache.get(otherUUID = otherPlayer.getUniqueId())) == null) continue;
                PlayerVisibilityListener.updateVisibilityBetweenPlayers(player, playerState, otherPlayer, otherState);
            }
        }
    }

    private static void updateVisibilityBetweenPlayers(Player player, VisibilityState playerState, Player other, VisibilityState otherState) {
        UUID playerUUID = player.getUniqueId();
        UUID otherUUID = other.getUniqueId();
        boolean canSeeOther = !otherState.vanished || player.hasPermission("mpa.vanish.seeothers");
        boolean showHiddenPlayers = player.hasPermission("mpa.hideme.seeothers");
        if (otherState.hideMe && !showHiddenPlayers && !otherState.showOthers.contains(playerUUID)) {
            canSeeOther = false;
        }
        if (playerState.hideOthers && !playerState.showOthers.contains(otherUUID)) {
            canSeeOther = false;
        }
        boolean otherCanSeePlayer = !playerState.vanished || other.hasPermission("mpa.vanish.seeothers");
        boolean otherShowHiddenPlayers = other.hasPermission("mpa.hideme.seeothers");
        if (playerState.hideMe && !otherShowHiddenPlayers && !playerState.showOthers.contains(otherUUID)) {
            otherCanSeePlayer = false;
        }
        if (otherState.hideOthers && !otherState.showOthers.contains(playerUUID)) {
            otherCanSeePlayer = false;
        }
        if (canSeeOther != player.canSee(other)) {
            if (canSeeOther) {
                player.showPlayer(other);
            } else {
                player.hidePlayer(other);
            }
        }
        if (otherCanSeePlayer != other.canSee(player)) {
            if (otherCanSeePlayer) {
                other.showPlayer(player);
            } else {
                other.hidePlayer(player);
            }
        }
    }

    public static void loadPlayerVisibilityState(UUID playerUUID) {
        DatabaseManager dbManager = DatabaseManager.getInstance();
        boolean vanished = dbManager.getVanishState(playerUUID);
        boolean hideMe = dbManager.getHideMeState(playerUUID);
        boolean hideOthers = dbManager.getHideOthersState(playerUUID);
        Set<UUID> showOthers = dbManager.getShowOthersState(playerUUID);
        visibilityCache.put(playerUUID, new VisibilityState(vanished, hideMe, hideOthers, new HashSet<UUID>(showOthers)));
        if (vanished) {
            vanishedPlayers.add(playerUUID);
        }
        PlayerVisibilityListener.queueForVisibilityUpdate(playerUUID);
    }

    private static void queueForVisibilityUpdate(UUID playerUUID) {
        playersNeedingUpdate.add(playerUUID);
    }

    public static void clearPlayerFromCache(UUID playerUUID) {
        VisibilityState state = visibilityCache.remove(playerUUID);
        playersNeedingUpdate.remove(playerUUID);
        vanishedPlayers.remove(playerUUID);
        if (state != null) {
            DatabaseManager dbManager = DatabaseManager.getInstance();
            dbManager.setVanishState(playerUUID, state.vanished);
            dbManager.setHideMeState(playerUUID, state.hideMe);
            dbManager.setHideOthersState(playerUUID, state.hideOthers);
        }
    }

    public static void updateCacheValue(UUID playerUUID, String type, Object value) {
        VisibilityState state = visibilityCache.get(playerUUID);
        if (state == null) {
            PlayerVisibilityListener.loadPlayerVisibilityState(playerUUID);
            state = visibilityCache.get(playerUUID);
            if (state == null) {
                return;
            }
        }
        int var5 = -1;
        switch (type.hashCode()) {
            case -1217487238: {
                if (!type.equals("hideMe")) break;
                var5 = 1;
                break;
            }
            case -823764357: {
                if (!type.equals("vanish")) break;
                var5 = 0;
                break;
            }
            case 236237637: {
                if (!type.equals("hideOthers")) break;
                var5 = 2;
                break;
            }
            case 668285120: {
                if (!type.equals("showOthers")) break;
                var5 = 3;
            }
        }
        switch (var5) {
            case 0: {
                boolean newVanishState = (Boolean)value;
                if (state.vanished == newVanishState) break;
                state.vanished = newVanishState;
                DatabaseManager.getInstance().setVanishState(playerUUID, state.vanished);
                if (newVanishState) {
                    vanishedPlayers.add(playerUUID);
                    break;
                }
                vanishedPlayers.remove(playerUUID);
                break;
            }
            case 1: {
                state.hideMe = (Boolean)value;
                DatabaseManager.getInstance().setHideMeState(playerUUID, state.hideMe);
                break;
            }
            case 2: {
                state.hideOthers = (Boolean)value;
                DatabaseManager.getInstance().setHideOthersState(playerUUID, state.hideOthers);
                break;
            }
            case 3: {
                state.showOthers = new HashSet<UUID>((Set)value);
                for (UUID targetUUID : state.showOthers) {
                    DatabaseManager.getInstance().addShowOthersState(playerUUID, targetUUID);
                }
                break;
            }
        }
        PlayerVisibilityListener.queueForVisibilityUpdate(playerUUID);
        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            PlayerVisibilityListener.queueForVisibilityUpdate(onlinePlayer.getUniqueId());
        }
    }

    private static void sendVisibilityActionBar(Player player) {
        UUID playerUUID;
        VisibilityState state;
        if (player != null && player.isOnline() && (state = visibilityCache.get(playerUUID = player.getUniqueId())) != null) {
            StringBuilder message = new StringBuilder();
            if (state.vanished) {
                message.append("\u00a7c\u00a7lYou're vanished");
            }
            if (state.hideMe) {
                if (message.length() > 0) {
                    message.append(" \u00a78| ");
                }
                message.append("\u00a7e\u00a7lYou are hidden from other players");
            }
            if (state.hideOthers) {
                if (message.length() > 0) {
                    message.append(" \u00a78| ");
                }
                message.append("\u00a76\u00a7lYou're hiding other players");
            }
            if (message.length() > 0) {
                player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText((String)message.toString()));
            }
        }
    }

    public static void applyVanishEffects(Player player) {
        if (player.isOnline()) {
            for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
                if (onlinePlayer.equals((Object)player) || onlinePlayer.hasPermission("mpa.vanish.seeothers")) continue;
                onlinePlayer.hidePlayer(player);
            }
        }
    }

    public static boolean isVanished(UUID playerUUID) {
        VisibilityState state = visibilityCache.get(playerUUID);
        if (state == null) {
            PlayerVisibilityListener.loadPlayerVisibilityState(playerUUID);
            state = visibilityCache.get(playerUUID);
        }
        return state != null && state.vanished;
    }

    public static VisibilityState getPlayerVisibilityState(UUID playerUUID) {
        VisibilityState state = visibilityCache.get(playerUUID);
        if (state == null) {
            PlayerVisibilityListener.loadPlayerVisibilityState(playerUUID);
            state = visibilityCache.get(playerUUID);
        }
        return state;
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID playerUUID = player.getUniqueId();
        PlayerVisibilityListener.loadPlayerVisibilityState(playerUUID);
        VisibilityState state = visibilityCache.get(playerUUID);
        if (state != null && state.vanished) {
            Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> PlayerVisibilityListener.applyVanishEffects(player));
        }
        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            PlayerVisibilityListener.queueForVisibilityUpdate(onlinePlayer.getUniqueId());
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPlayerQuit(PlayerQuitEvent event) {
        UUID playerUUID = event.getPlayer().getUniqueId();
        PlayerVisibilityListener.clearPlayerFromCache(playerUUID);
        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            if (onlinePlayer.getUniqueId().equals(playerUUID)) continue;
            PlayerVisibilityListener.queueForVisibilityUpdate(onlinePlayer.getUniqueId());
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPlayerChangedWorld(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        UUID playerUUID = player.getUniqueId();
        PlayerVisibilityListener.queueForVisibilityUpdate(playerUUID);
        VisibilityState state = visibilityCache.get(playerUUID);
        if (state != null && state.vanished) {
            Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> PlayerVisibilityListener.applyVanishEffects(player));
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        if (!event.getFrom().getWorld().equals((Object)event.getTo().getWorld())) {
            Player player = event.getPlayer();
            PlayerVisibilityListener.queueForVisibilityUpdate(player.getUniqueId());
            VisibilityState state = visibilityCache.get(player.getUniqueId());
            if (state != null && state.vanished) {
                Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> PlayerVisibilityListener.applyVanishEffects(player), 1L);
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPlayerGameModeChange(PlayerGameModeChangeEvent event) {
        PlayerVisibilityListener.queueForVisibilityUpdate(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        PlayerVisibilityListener.queueForVisibilityUpdate(player.getUniqueId());
        VisibilityState state = visibilityCache.get(player.getUniqueId());
        if (state != null && state.vanished) {
            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> PlayerVisibilityListener.applyVanishEffects(player), 1L);
        }
    }

    public static class VisibilityState {
        boolean vanished;
        boolean hideMe;
        boolean hideOthers;
        Set<UUID> showOthers;

        VisibilityState(boolean vanished, boolean hideMe, boolean hideOthers, Set<UUID> showOthers) {
            this.vanished = vanished;
            this.hideMe = hideMe;
            this.hideOthers = hideOthers;
            this.showOthers = showOthers;
        }

        public boolean isVanished() {
            return this.vanished;
        }

        public boolean isHideMe() {
            return this.hideMe;
        }

        public boolean isHideOthers() {
            return this.hideOthers;
        }

        public Set<UUID> getShowOthers() {
            return new HashSet<UUID>(this.showOthers);
        }
    }
}

