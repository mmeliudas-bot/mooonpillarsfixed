/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.ConsoleCommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerChangedWorldEvent
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem;

import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.PlayerVisibilityListener;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class VanishCommand
implements CommandExecutor,
Listener {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length > 0) {
                if (!player.hasPermission("mpa.vanish.others")) {
                    player.sendMessage(MSG.chatColors("&cYou don't have permission to vanish other players."));
                    return true;
                }
                Player targetPlayer = Bukkit.getPlayer((String)args[0]);
                if (targetPlayer == null) {
                    player.sendMessage(MSG.chatColors("&cPlayer not found or not online."));
                    return true;
                }
                this.toggleVanishState(targetPlayer, player);
                return true;
            }
            this.toggleVanishState(player, null);
            return true;
        }
        sender.sendMessage(MSG.chatColors("&cThis command can only be used by a player."));
        return true;
    }

    private void toggleVanishState(Player targetPlayer, Player executor) {
        UUID playerUUID = targetPlayer.getUniqueId();
        boolean currentVanishState = false;
        try {
            currentVanishState = PlayerVisibilityListener.isVanished(playerUUID);
        }
        catch (Exception var8) {
            if (executor != null) {
                executor.sendMessage(MSG.chatColors("&cError checking vanish state. Please try again."));
            } else {
                targetPlayer.sendMessage(MSG.chatColors("&cError checking vanish state. Please try again."));
            }
            ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
            String var10001 = targetPlayer.getName();
            var10000.sendMessage(MSG.chatColors("&7[ChatLog] [Vanish] Error checking state for " + var10001 + ": " + var8.getMessage()));
            return;
        }
        boolean newVanishState = !currentVanishState;
        try {
            PlayerVisibilityListener.updateCacheValue(playerUUID, "vanish", newVanishState);
            if (newVanishState) {
                targetPlayer.sendMessage(MSG.chatColors("&aYou are now vanished."));
                if (executor != null && !executor.equals((Object)targetPlayer)) {
                    executor.sendMessage(MSG.chatColors("&aYou have vanished &e" + targetPlayer.getName() + "&a."));
                }
                for (Player admin : Bukkit.getOnlinePlayers()) {
                    if (admin.equals((Object)targetPlayer) || !admin.hasPermission("mpa.notify.admin")) continue;
                    admin.sendMessage(MSG.chatColors("&7[&aVanish&7] &a" + targetPlayer.getName() + " &7is now vanished."));
                }
                ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
                String var10001 = targetPlayer.getName();
                var10000.sendMessage(MSG.chatColors("&7[ChatLog] [Vanish] " + var10001 + " enabled vanish" + (String)(executor != null && !executor.equals((Object)targetPlayer) ? " by " + executor.getName() : "")));
            } else {
                targetPlayer.sendMessage(MSG.chatColors("&cYou are no longer vanished."));
                if (executor != null && !executor.equals((Object)targetPlayer)) {
                    executor.sendMessage(MSG.chatColors("&cYou have made &e" + targetPlayer.getName() + " &cvisible again."));
                }
                for (Player admin : Bukkit.getOnlinePlayers()) {
                    if (admin.equals((Object)targetPlayer) || !admin.hasPermission("mpa.notify.admin")) continue;
                    admin.sendMessage(MSG.chatColors("&7[&aVanish&7] &a" + targetPlayer.getName() + " &7is no longer vanished."));
                }
                ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
                String var10001 = targetPlayer.getName();
                var10000.sendMessage(MSG.chatColors("&7[ChatLog] [Vanish] " + var10001 + " disabled vanish" + (String)(executor != null && !executor.equals((Object)targetPlayer) ? " by " + executor.getName() : "")));
            }
        }
        catch (Exception var9) {
            if (executor != null) {
                executor.sendMessage(MSG.chatColors("&cError updating vanish state. Please try again."));
            } else {
                targetPlayer.sendMessage(MSG.chatColors("&cError updating vanish state. Please try again."));
            }
            ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
            String var10001 = targetPlayer.getName();
            var10000.sendMessage(MSG.chatColors("&7[ChatLog] [Vanish] Error updating state for " + var10001 + ": " + var9.getMessage()));
            return;
        }
        this.updateFlightStatus(targetPlayer, newVanishState);
    }

    private void updateFlightStatus(Player player, boolean isVanished) {
        try {
            if (isVanished) {
                player.setAllowFlight(true);
                player.setFlying(true);
            } else if (!player.getGameMode().toString().equals("CREATIVE") && !player.getGameMode().toString().equals("SPECTATOR")) {
                player.setAllowFlight(false);
                player.setFlying(false);
            }
        }
        catch (Exception var4) {
            ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
            String var10001 = player.getName();
            var10000.sendMessage(MSG.chatColors("&7[ChatLog] [Vanish] Error updating flight for " + var10001 + ": " + var4.getMessage()));
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPlayerChangedWorld(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        UUID playerUUID = player.getUniqueId();
        if (PlayerVisibilityListener.isVanished(playerUUID)) {
            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> {
                if (player.isOnline() && PlayerVisibilityListener.isVanished(playerUUID)) {
                    player.setAllowFlight(true);
                    player.setFlying(true);
                    Bukkit.getConsoleSender().sendMessage(MSG.chatColors("&7[ChatLog] [Vanish] Restored flight for " + player.getName() + " after world change"));
                }
            }, 2L);
        }
    }
}

