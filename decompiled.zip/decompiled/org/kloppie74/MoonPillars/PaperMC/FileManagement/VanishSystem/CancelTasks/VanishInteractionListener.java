/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.destroystokyo.paper.event.player.PlayerPickupExperienceEvent
 *  org.bukkit.Material
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityPickupItemEvent
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.util.Vector
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.CancelTasks;

import com.destroystokyo.paper.event.player.PlayerPickupExperienceEvent;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.util.Vector;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.PlayerVisibilityListener;

public class VanishInteractionListener
implements Listener {
    @EventHandler(priority=EventPriority.HIGHEST)
    public void onItemPickup(EntityPickupItemEvent event) {
        Player player;
        if (SettingsManager.getInstance().getSettings().getBoolean("VanishSettings.BlockItemPickup", true) && event.getEntity() instanceof Player && PlayerVisibilityListener.isVanished((player = (Player)event.getEntity()).getUniqueId())) {
            event.setCancelled(true);
            if (SettingsManager.getInstance().getSettings().getBoolean("VanishSettings.ShowPickupNotification", false)) {
                player.sendMessage(MSG.chatColors("&cYou cannot pick up items while vanished."));
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onItemDrop(PlayerDropItemEvent event) {
        Player player;
        if (SettingsManager.getInstance().getSettings().getBoolean("VanishSettings.BlockItemDrop", true) && PlayerVisibilityListener.isVanished((player = event.getPlayer()).getUniqueId())) {
            event.setCancelled(true);
            if (SettingsManager.getInstance().getSettings().getBoolean("VanishSettings.ShowDropNotification", true)) {
                player.sendMessage(MSG.chatColors("&cYou cannot drop items while vanished."));
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (SettingsManager.getInstance().getSettings().getBoolean("VanishSettings.BlockDamageDealing", true)) {
            Player victim;
            if (event.getDamager() instanceof Player && PlayerVisibilityListener.isVanished((victim = (Player)event.getDamager()).getUniqueId())) {
                event.setCancelled(true);
                if (SettingsManager.getInstance().getSettings().getBoolean("VanishSettings.ShowDamageNotification", true)) {
                    victim.sendMessage(MSG.chatColors("&cYou cannot deal damage while vanished."));
                }
                return;
            }
            if (SettingsManager.getInstance().getSettings().getBoolean("VanishSettings.BlockDamageReceiving", true) && event.getEntity() instanceof Player && PlayerVisibilityListener.isVanished((victim = (Player)event.getEntity()).getUniqueId())) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onEntityDamage(EntityDamageEvent event) {
        Player player;
        if (SettingsManager.getInstance().getSettings().getBoolean("VanishSettings.BlockEnvironmentalDamage", true) && event.getEntity() instanceof Player && PlayerVisibilityListener.isVanished((player = (Player)event.getEntity()).getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPlayerInteractWithPressurePlate(PlayerInteractEvent event) {
        Block block;
        Player player;
        if (SettingsManager.getInstance().getSettings().getBoolean("VanishSettings.BlockPressurePlates", true) && PlayerVisibilityListener.isVanished((player = event.getPlayer()).getUniqueId()) && event.getAction() == Action.PHYSICAL && (block = event.getClickedBlock()) != null && this.isPressurePlate(block.getType())) {
            event.setCancelled(true);
        }
    }

    private boolean isPressurePlate(Material material) {
        return material.name().endsWith("_PRESSURE_PLATE");
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPlayerPickupExperience(PlayerPickupExperienceEvent event) {
        Player player;
        if (SettingsManager.getInstance().getSettings().getBoolean("VanishSettings.BlockExpPickup", true) && PlayerVisibilityListener.isVanished((player = event.getPlayer()).getUniqueId())) {
            event.setCancelled(true);
            event.getExperienceOrb().setVelocity(new Vector(0, 0, 0));
        }
    }
}

