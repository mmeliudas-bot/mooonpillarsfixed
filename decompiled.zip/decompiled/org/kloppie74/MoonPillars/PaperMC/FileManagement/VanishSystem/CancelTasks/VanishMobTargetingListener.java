/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.ExperienceOrb
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Mob
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.EntityTargetEvent
 *  org.bukkit.event.entity.EntityTargetLivingEntityEvent
 *  org.bukkit.event.world.EntitiesLoadEvent
 *  org.bukkit.util.Vector
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.CancelTasks;

import org.bukkit.entity.Entity;
import org.bukkit.entity.ExperienceOrb;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.util.Vector;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.PlayerVisibilityListener;

public class VanishMobTargetingListener
implements Listener {
    @EventHandler(priority=EventPriority.HIGHEST)
    public void onEntityTarget(EntityTargetLivingEntityEvent event) {
        Player player;
        if (SettingsManager.getInstance().getSettings().getBoolean("VanishSettings.BlockMobTargeting", true) && event.getTarget() instanceof Player && PlayerVisibilityListener.isVanished((player = (Player)event.getTarget()).getUniqueId())) {
            event.setCancelled(true);
            event.setTarget((Entity)null);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onEntityTargetSimple(EntityTargetEvent event) {
        Player player;
        if (SettingsManager.getInstance().getSettings().getBoolean("VanishSettings.BlockMobTargeting", true) && event.getTarget() instanceof Player && PlayerVisibilityListener.isVanished((player = (Player)event.getTarget()).getUniqueId())) {
            event.setCancelled(true);
            event.setTarget((Entity)null);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onEntitiesLoad(EntitiesLoadEvent event) {
        boolean blockMobTargeting = SettingsManager.getInstance().getSettings().getBoolean("VanishSettings.BlockMobTargeting", true);
        boolean blockXpAttraction = SettingsManager.getInstance().getSettings().getBoolean("VanishSettings.BlockXpAttraction", true);
        if (blockMobTargeting || blockXpAttraction) {
            for (Entity entity : event.getEntities()) {
                if (entity instanceof Mob && blockMobTargeting) {
                    Player target;
                    Mob mob = (Mob)entity;
                    if (!(mob.getTarget() instanceof Player) || !PlayerVisibilityListener.isVanished((target = (Player)mob.getTarget()).getUniqueId())) continue;
                    mob.setTarget((LivingEntity)null);
                    continue;
                }
                if (!(entity instanceof ExperienceOrb) || !blockXpAttraction) continue;
                ExperienceOrb orb = (ExperienceOrb)entity;
                double searchRadius = SettingsManager.getInstance().getSettings().getDouble("VanishSettings.XpAttractionRadius", 5.0);
                for (Entity nearbyEntity : orb.getNearbyEntities(searchRadius, searchRadius, searchRadius)) {
                    Player player;
                    if (!(nearbyEntity instanceof Player) || !PlayerVisibilityListener.isVanished((player = (Player)nearbyEntity).getUniqueId())) continue;
                    orb.setVelocity(new Vector(0, 0, 0));
                }
            }
            return;
        }
    }
}

