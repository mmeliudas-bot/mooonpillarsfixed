/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.ConsoleCommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem;

import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.PlayerVisibilityListener;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;

public class HideMeCommand
implements CommandExecutor {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length > 0) {
                if (!player.hasPermission("mpa.hideme.others")) {
                    player.sendMessage(MSG.chatColors("&cYou don't have permission to hide other players."));
                    return true;
                }
                Player targetPlayer = Bukkit.getPlayer((String)args[0]);
                if (targetPlayer == null) {
                    player.sendMessage(MSG.chatColors("&cPlayer not found or not online."));
                    return true;
                }
                String gameID = HashMapHandler.getPlayerGameID(targetPlayer.getUniqueId());
                if (gameID != null) {
                    player.sendMessage(MSG.chatColors("&cThat player is currently in a game and cannot be hidden."));
                    return true;
                }
                this.toggleHideMeState(targetPlayer, player);
                return true;
            }
            String gameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
            if (gameID != null) {
                player.sendMessage(MSG.chatColors("&cYou cannot use this command while in a game."));
                return true;
            }
            this.toggleHideMeState(player, null);
            return true;
        }
        sender.sendMessage(MSG.chatColors("&cThis command can only be used by a player."));
        return true;
    }

    private void toggleHideMeState(Player targetPlayer, Player executor) {
        UUID playerUUID = targetPlayer.getUniqueId();
        boolean currentHideMeState = false;
        try {
            PlayerVisibilityListener.VisibilityState state = PlayerVisibilityListener.getPlayerVisibilityState(playerUUID);
            if (state != null) {
                currentHideMeState = state.hideMe;
            }
        }
        catch (Exception var9) {
            if (executor != null) {
                executor.sendMessage(MSG.chatColors("&cError checking HideMe state. Please try again."));
            } else {
                targetPlayer.sendMessage(MSG.chatColors("&cError checking HideMe state. Please try again."));
            }
            ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
            String var10001 = targetPlayer.getName();
            var10000.sendMessage(MSG.chatColors("&7[ChatLog] [HideMe] Error checking state for " + var10001 + ": " + var9.getMessage()));
            return;
        }
        boolean newHideMeState = !currentHideMeState;
        try {
            PlayerVisibilityListener.updateCacheValue(playerUUID, "hideMe", newHideMeState);
            if (newHideMeState) {
                targetPlayer.sendMessage(MSG.chatColors("&aYou are now hidden from other players."));
                if (executor != null && !executor.equals((Object)targetPlayer)) {
                    executor.sendMessage(MSG.chatColors("&aYou have hidden &e" + targetPlayer.getName() + "&a from other players."));
                }
                for (Player admin : Bukkit.getOnlinePlayers()) {
                    if (admin.equals((Object)targetPlayer) || !admin.hasPermission("mpa.notify.admin")) continue;
                    admin.sendMessage(MSG.chatColors("&7[&aHideMe&7] &a" + targetPlayer.getName() + " &7is now hidden from other players."));
                }
                ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
                String var10001 = targetPlayer.getName();
                var10000.sendMessage(MSG.chatColors("&7[ChatLog] [HideMe] " + var10001 + " enabled HideMe" + (String)(executor != null && !executor.equals((Object)targetPlayer) ? " by " + executor.getName() : "")));
            } else {
                targetPlayer.sendMessage(MSG.chatColors("&cYou are no longer hidden from other players."));
                if (executor != null && !executor.equals((Object)targetPlayer)) {
                    executor.sendMessage(MSG.chatColors("&cYou have made &e" + targetPlayer.getName() + "&c visible to other players again."));
                }
                for (Player admin : Bukkit.getOnlinePlayers()) {
                    if (admin.equals((Object)targetPlayer) || !admin.hasPermission("mpa.notify.admin")) continue;
                    admin.sendMessage(MSG.chatColors("&7[&aHideMe&7] &a" + targetPlayer.getName() + " &7is no longer hidden from other players."));
                }
                ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
                String var10001 = targetPlayer.getName();
                var10000.sendMessage(MSG.chatColors("&7[ChatLog] [HideMe] " + var10001 + " disabled HideMe" + (String)(executor != null && !executor.equals((Object)targetPlayer) ? " by " + executor.getName() : "")));
            }
        }
        catch (Exception var8) {
            if (executor != null) {
                executor.sendMessage(MSG.chatColors("&cError updating HideMe state. Please try again."));
            } else {
                targetPlayer.sendMessage(MSG.chatColors("&cError updating HideMe state. Please try again."));
            }
            ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
            String var10001 = targetPlayer.getName();
            var10000.sendMessage(MSG.chatColors("&7[ChatLog] [HideMe] Error updating state for " + var10001 + ": " + var8.getMessage()));
        }
    }
}

