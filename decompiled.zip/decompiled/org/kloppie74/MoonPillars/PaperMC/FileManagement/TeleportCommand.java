/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 *  org.bukkit.generator.WorldInfo
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.generator.WorldInfo;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.LeaveGameManager;

public class TeleportCommand
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player) && args.length < 2) {
            sender.sendMessage(String.valueOf(ChatColor.RED) + "This command can only be used by players or with 2 player arguments from console.");
            return true;
        }
        if (!sender.hasPermission("mpa.command.teleport")) {
            sender.sendMessage(MSG.chatColors("&cYou don't have permission to use this command."));
            return true;
        }
        switch (args.length) {
            case 0: {
                sender.sendMessage(MSG.chatColors("&cUsage: /tp <player|x> [y] [z] [target]"));
                break;
            }
            case 1: {
                if (!(sender instanceof Player)) {
                    sender.sendMessage(String.valueOf(ChatColor.RED) + "Console must specify both players: /tp <player> <target>");
                    return true;
                }
                Player player = (Player)sender;
                Player target = Bukkit.getPlayer((String)args[0]);
                if (target == null) {
                    sender.sendMessage(MSG.chatColors("&cPlayer &e" + args[0] + " &cis not online."));
                    return true;
                }
                LeaveGameManager.onTeleportLeave(player);
                player.teleport(target.getLocation());
                player.sendMessage(MSG.chatColors("&aTeleported to &e" + target.getName() + "&a."));
                break;
            }
            case 2: {
                Player playerToMove = Bukkit.getPlayer((String)args[0]);
                Player playerDestination = Bukkit.getPlayer((String)args[1]);
                if (playerToMove == null) {
                    sender.sendMessage(MSG.chatColors("&cPlayer &e" + args[0] + " &cis not online."));
                    return true;
                }
                if (playerDestination == null) {
                    sender.sendMessage(MSG.chatColors("&cPlayer &e" + args[1] + " &cis not online."));
                    return true;
                }
                LeaveGameManager.onTeleportLeave(playerToMove);
                playerToMove.teleport(playerDestination.getLocation());
                String var10001 = playerToMove.getName();
                sender.sendMessage(MSG.chatColors("&aTeleported &e" + var10001 + " &ato &e" + playerDestination.getName() + "&a."));
                if (sender.equals((Object)playerToMove)) break;
                playerToMove.sendMessage(MSG.chatColors("&aYou were teleported to &e" + playerDestination.getName() + "&a."));
                break;
            }
            case 3: {
                if (!(sender instanceof Player)) {
                    sender.sendMessage(String.valueOf(ChatColor.RED) + "Console cannot teleport to coordinates without specifying a player.");
                    return true;
                }
                Player commandSender = (Player)sender;
                try {
                    double x = Double.parseDouble(args[0]);
                    double y = Double.parseDouble(args[1]);
                    double z = Double.parseDouble(args[2]);
                    LeaveGameManager.onTeleportLeave(commandSender);
                    Location location = new Location(commandSender.getWorld(), x, y, z, commandSender.getLocation().getYaw(), commandSender.getLocation().getPitch());
                    commandSender.teleport(location);
                    commandSender.sendMessage(MSG.chatColors("&aTeleported to &e" + x + ", " + y + ", " + z + "&a."));
                }
                catch (NumberFormatException var24) {
                    commandSender.sendMessage(MSG.chatColors("&cInvalid coordinates. Use numbers for x, y, and z."));
                }
                break;
            }
            case 4: {
                Player targetPlayer = Bukkit.getPlayer((String)args[0]);
                if (targetPlayer != null) {
                    try {
                        double x = Double.parseDouble(args[1]);
                        double y = Double.parseDouble(args[2]);
                        double z = Double.parseDouble(args[3]);
                        LeaveGameManager.onTeleportLeave(targetPlayer);
                        Location location = new Location(targetPlayer.getWorld(), x, y, z, targetPlayer.getLocation().getYaw(), targetPlayer.getLocation().getPitch());
                        targetPlayer.teleport(location);
                        sender.sendMessage(MSG.chatColors("&aTeleported &e" + targetPlayer.getName() + "&a to &e" + x + ", " + y + ", " + z + "&a."));
                        if (sender.equals((Object)targetPlayer)) break;
                        targetPlayer.sendMessage(MSG.chatColors("&aYou were teleported to &e" + x + ", " + y + ", " + z + "&a."));
                    }
                    catch (NumberFormatException var23) {
                        sender.sendMessage(MSG.chatColors("&cInvalid coordinates. Use numbers for x, y, and z."));
                    }
                    break;
                }
                if (sender instanceof Player) {
                    try {
                        double x = Double.parseDouble(args[0]);
                        double y = Double.parseDouble(args[1]);
                        double z = Double.parseDouble(args[2]);
                        String worldName = args[3];
                        World world = Bukkit.getWorld((String)worldName);
                        if (world == null) {
                            sender.sendMessage(MSG.chatColors("&cWorld &e" + worldName + " &cdoes not exist."));
                            return true;
                        }
                        Player playerSender = (Player)sender;
                        LeaveGameManager.onTeleportLeave(playerSender);
                        Location location = new Location(world, x, y, z, playerSender.getLocation().getYaw(), playerSender.getLocation().getPitch());
                        playerSender.teleport(location);
                        playerSender.sendMessage(MSG.chatColors("&aTeleported to &e" + x + ", " + y + ", " + z + " &ain world &e" + worldName + "&a."));
                    }
                    catch (NumberFormatException var22) {
                        sender.sendMessage(MSG.chatColors("&cInvalid coordinates. Use numbers for x, y, and z."));
                    }
                    break;
                }
                sender.sendMessage(String.valueOf(ChatColor.RED) + "Invalid command usage. Console must specify player for teleportation.");
                break;
            }
            case 5: {
                Player targetPlayer = Bukkit.getPlayer((String)args[0]);
                if (targetPlayer == null) {
                    sender.sendMessage(MSG.chatColors("&cPlayer &e" + args[0] + " &cis not online."));
                    return true;
                }
                try {
                    double x = Double.parseDouble(args[1]);
                    double y = Double.parseDouble(args[2]);
                    double z = Double.parseDouble(args[3]);
                    String worldName = args[4];
                    World world = Bukkit.getWorld((String)worldName);
                    if (world == null) {
                        sender.sendMessage(MSG.chatColors("&cWorld &e" + worldName + " &cdoes not exist."));
                        return true;
                    }
                    LeaveGameManager.onTeleportLeave(targetPlayer);
                    Location location = new Location(world, x, y, z, targetPlayer.getLocation().getYaw(), targetPlayer.getLocation().getPitch());
                    targetPlayer.teleport(location);
                    sender.sendMessage(MSG.chatColors("&aTeleported &e" + targetPlayer.getName() + "&a to &e" + x + ", " + y + ", " + z + " &ain world &e" + worldName + "&a."));
                    if (sender.equals((Object)targetPlayer)) break;
                    targetPlayer.sendMessage(MSG.chatColors("&aYou were teleported to &e" + x + ", " + y + ", " + z + " &ain world &e" + worldName + "&a."));
                }
                catch (NumberFormatException var21) {
                    sender.sendMessage(MSG.chatColors("&cInvalid coordinates. Use numbers for x, y, and z."));
                }
                break;
            }
            default: {
                sender.sendMessage(MSG.chatColors("&cToo many arguments. Usage: /tp <player|x> [y] [z] [world|target]"));
            }
        }
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions;
        block9: {
            List worldNames;
            block12: {
                block10: {
                    block11: {
                        List playerNames;
                        block8: {
                            completions = new ArrayList<String>();
                            if (!sender.hasPermission("mpa.command.teleport")) {
                                return completions;
                            }
                            playerNames = Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList());
                            worldNames = Bukkit.getWorlds().stream().map(WorldInfo::getName).collect(Collectors.toList());
                            if (args.length != 1) break block8;
                            String partialName = args[0].toLowerCase();
                            for (String name : playerNames) {
                                if (!name.toLowerCase().startsWith(partialName)) continue;
                                completions.add(name);
                            }
                            if (!"~".startsWith(partialName) && !"".equals(partialName)) break block9;
                            completions.add("~");
                            break block9;
                        }
                        if (args.length != 2) break block10;
                        if (Bukkit.getPlayer((String)args[0]) == null) break block11;
                        String partialName = args[1].toLowerCase();
                        for (String name : playerNames) {
                            if (!name.toLowerCase().startsWith(partialName)) continue;
                            completions.add(name);
                        }
                        if (!"~".startsWith(partialName) && !"".equals(partialName)) break block9;
                        completions.add("~");
                        break block9;
                    }
                    if (!"~".startsWith(args[1]) && !"".equals(args[1])) break block9;
                    completions.add("~");
                    break block9;
                }
                if (args.length != 3) break block12;
                if (!"~".startsWith(args[2]) && !"".equals(args[2])) break block9;
                completions.add("~");
                break block9;
            }
            if (args.length == 4) {
                String partialName = args[3].toLowerCase();
                for (String name : worldNames) {
                    if (!name.toLowerCase().startsWith(partialName)) continue;
                    completions.add(name);
                }
            } else if (args.length == 5) {
                String partialName = args[4].toLowerCase();
                for (String name : worldNames) {
                    if (!name.toLowerCase().startsWith(partialName)) continue;
                    completions.add(name);
                }
            }
        }
        return completions;
    }
}

