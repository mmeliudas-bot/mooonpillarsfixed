/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class CosmeticHandler {
    private static CosmeticHandler instance;
    private final String dbName = String.valueOf(MoonLab.getInstance().getDataFolder()) + "/Storage/Player-Cosmetics.db";

    private CosmeticHandler() {
        this.createTable();
    }

    public static synchronized CosmeticHandler getInstance() {
        if (instance == null) {
            instance = new CosmeticHandler();
        }
        return instance;
    }

    private Connection connect() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
        }
        catch (ClassNotFoundException var2) {
            var2.printStackTrace();
        }
        return DriverManager.getConnection("jdbc:sqlite:" + this.dbName);
    }

    public void createTable() {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS cosmetics (uuid VARCHAR(36) PRIMARY KEY,Cage_Particle VARCHAR(255) DEFAULT NULL,Pillar_Particle VARCHAR(255) DEFAULT NULL,Bow_Particle VARCHAR(255) DEFAULT NULL,Win_Particle VARCHAR(255) DEFAULT NULL,Kill_Particle VARCHAR(255) DEFAULT NULL,Death_Particle VARCHAR(255) DEFAULT NULL,Kill_Message_Particle VARCHAR(255) DEFAULT NULL);";
        try (Connection connection = this.connect();
             Statement statement = connection.createStatement();){
            statement.executeUpdate(createTableSQL);
            this.addColumnIfNotExists(connection, "cosmetics", "Cage_Particle", "VARCHAR(255) DEFAULT NULL");
            this.addColumnIfNotExists(connection, "cosmetics", "Pillar_Particle", "VARCHAR(255) DEFAULT NULL");
            this.addColumnIfNotExists(connection, "cosmetics", "Bow_Particle", "VARCHAR(255) DEFAULT NULL");
            this.addColumnIfNotExists(connection, "cosmetics", "Win_Particle", "VARCHAR(255) DEFAULT NULL");
            this.addColumnIfNotExists(connection, "cosmetics", "Kill_Particle", "VARCHAR(255) DEFAULT NULL");
            this.addColumnIfNotExists(connection, "cosmetics", "Death_Particle", "VARCHAR(255) DEFAULT NULL");
            this.addColumnIfNotExists(connection, "cosmetics", "Elytra_Particle", "VARCHAR(255) DEFAULT NULL");
            this.addColumnIfNotExists(connection, "cosmetics", "Kill_Message_Particle", "VARCHAR(255) DEFAULT NULL");
            this.migrateColumn(connection, "Death_Message_Particle", "Kill_Message_Particle");
        }
        catch (SQLException var10) {
            var10.printStackTrace();
        }
    }

    private void addColumnIfNotExists(Connection connection, String tableName, String columnName, String columnDefinition) throws SQLException {
        block12: {
            DatabaseMetaData meta = connection.getMetaData();
            try (ResultSet resultSet = meta.getColumns(null, null, tableName, columnName);){
                if (resultSet.next()) break block12;
                try (Statement statement = connection.createStatement();){
                    String alterTableSQL = "ALTER TABLE " + tableName + " ADD COLUMN " + columnName + " " + columnDefinition + ";";
                    statement.executeUpdate(alterTableSQL);
                }
            }
        }
    }

    private void migrateColumn(Connection connection, String oldColumn, String newColumn) throws SQLException {
        DatabaseMetaData meta = connection.getMetaData();
        boolean oldColumnExists = false;
        boolean newColumnExists = false;
        try (ResultSet newResultSet = meta.getColumns(null, null, "cosmetics", oldColumn);){
            oldColumnExists = newResultSet.next();
        }
        newResultSet = meta.getColumns(null, null, "cosmetics", newColumn);
        try {
            newColumnExists = newResultSet.next();
        }
        finally {
            if (newResultSet != null) {
                newResultSet.close();
            }
        }
        if (oldColumnExists && newColumnExists) {
            try (Statement statement = connection.createStatement();){
                String updateSQL = "UPDATE cosmetics SET " + newColumn + " = " + oldColumn + " WHERE " + oldColumn + " IS NOT NULL AND " + newColumn + " IS NULL;";
                statement.executeUpdate(updateSQL);
            }
        }
    }

    public boolean hasCosmetic(UUID uuid, String section, String cosmeticID) {
        String path = this.getConfigPath(section, cosmeticID);
        Player player = Bukkit.getPlayer((UUID)uuid);
        String permission = SettingsManager.getInstance().getCosmetics().getString(path);
        assert (player != null);
        assert (permission != null);
        return player.hasPermission(permission);
    }

    private String getConfigPath(String section, String cosmeticID) {
        return switch (section.toLowerCase()) {
            case "cages" -> "Cages." + cosmeticID + ".Permission";
            case "pillars" -> "Pillars." + cosmeticID + ".Permission";
            case "bow" -> "Particles.Bow." + cosmeticID + ".Permission";
            case "kill" -> "Particles.Kill." + cosmeticID + ".Permission";
            case "win" -> "Particles.Win." + cosmeticID + ".Permission";
            case "death" -> "Particles.Death." + cosmeticID + ".Permission";
            case "killmessage" -> "Particles.KillMessage." + cosmeticID + ".Permission";
            default -> throw new IllegalArgumentException("Invalid section: " + section);
        };
    }

    public String getSelectedCosmetic(UUID uuid, String cosmeticName) {
        String selectSQL = "SELECT " + cosmeticName + " FROM cosmetics WHERE uuid = ?;";
        try {
            String var7;
            block21: {
                block20: {
                    try (Connection connection = this.connect();
                         PreparedStatement preparedStatement = connection.prepareStatement(selectSQL);){
                        preparedStatement.setString(1, uuid.toString());
                        try (ResultSet resultSet = preparedStatement.executeQuery();){
                            if (!resultSet.next()) break block20;
                            var7 = resultSet.getString(cosmeticName);
                            break block21;
                        }
                    }
                }
                return null;
            }
            return var7;
        }
        catch (SQLException var15) {
            var15.printStackTrace();
            return null;
        }
    }

    public void updateSelectedCosmetic(UUID uuid, String cosmeticName, String value) {
        String updateSQL = "UPDATE cosmetics SET " + cosmeticName + " = ? WHERE uuid = ?;";
        try (Connection connection = this.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(updateSQL);){
            preparedStatement.setString(1, value);
            preparedStatement.setString(2, uuid.toString());
            preparedStatement.executeUpdate();
        }
        catch (SQLException var13) {
            var13.printStackTrace();
        }
    }

    public void clearCosmetic(UUID uuid, String cosmeticName) {
        String updateSQL = "UPDATE cosmetics SET " + cosmeticName + " = NULL WHERE uuid = ?;";
        try (Connection connection = this.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(updateSQL);){
            preparedStatement.setString(1, uuid.toString());
            preparedStatement.executeUpdate();
        }
        catch (SQLException var12) {
            var12.printStackTrace();
        }
    }

    public void saveNewPlayerWithCosmetics(UUID uuid) {
        String insertSQL = "INSERT INTO cosmetics (uuid, Cage_Particle, Pillar_Particle, Bow_Particle, Win_Particle, Kill_Particle, Death_Particle, Kill_Message_Particle) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
        try (Connection connection = this.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(insertSQL);){
            preparedStatement.setString(1, uuid.toString());
            preparedStatement.setString(2, null);
            preparedStatement.setString(3, null);
            preparedStatement.setString(4, null);
            preparedStatement.setString(5, null);
            preparedStatement.setString(6, null);
            preparedStatement.setString(7, null);
            preparedStatement.setString(8, null);
            preparedStatement.executeUpdate();
        }
        catch (SQLException var11) {
            var11.printStackTrace();
        }
    }

    public boolean playerExists(UUID uuid) {
        String query = "SELECT COUNT(*) FROM cosmetics WHERE uuid = ?";
        try {
            boolean var7;
            try (Connection connection = this.connect();
                 PreparedStatement preparedStatement = connection.prepareStatement(query);){
                preparedStatement.setString(1, uuid.toString());
                try (ResultSet resultSet = preparedStatement.executeQuery();){
                    resultSet.next();
                    int count = resultSet.getInt(1);
                    var7 = count > 0;
                }
            }
            return var7;
        }
        catch (SQLException var14) {
            var14.printStackTrace();
            return false;
        }
    }
}

