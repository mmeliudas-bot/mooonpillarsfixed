/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler.CosmeticHandler;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class CosmeticGui
implements Listener {
    public static final HashMap<Integer, String> cosmeticID = new HashMap();
    public static final HashMap<UUID, String> cosmeticPath = new HashMap();
    public static final HashMap<UUID, String> cosmeticGUI = new HashMap();

    public static void openCosmeticGUI(Player player, String path) {
        ItemStack item;
        Inventory gui = Bukkit.createInventory((InventoryHolder)null, (int)54, (String)"Select a Cosmetic");
        FileConfiguration config = SettingsManager.getInstance().getCosmetics();
        switch (path.toLowerCase()) {
            case "cages": {
                cosmeticPath.put(player.getUniqueId(), "Settings.Cages");
                cosmeticGUI.put(player.getUniqueId(), "Cage_Particle");
                CosmeticGui.addItemsFromConfig(player, gui, config, "Settings.Cages");
                break;
            }
            case "pillars": {
                cosmeticPath.put(player.getUniqueId(), "Settings.Pillars");
                cosmeticGUI.put(player.getUniqueId(), "Pillar_Particle");
                CosmeticGui.addItemsFromConfig(player, gui, config, "Settings.Pillars");
                break;
            }
            case "bow": {
                cosmeticPath.put(player.getUniqueId(), "Settings.Particles.Bow");
                cosmeticGUI.put(player.getUniqueId(), "Bow_Particle");
                CosmeticGui.addItemsFromConfig(player, gui, config, "Settings.Particles.Bow");
                break;
            }
            case "kill": {
                cosmeticPath.put(player.getUniqueId(), "Settings.Particles.Kill");
                cosmeticGUI.put(player.getUniqueId(), "Kill_Particle");
                CosmeticGui.addItemsFromConfig(player, gui, config, "Settings.Particles.Kill");
                break;
            }
            case "win": {
                cosmeticPath.put(player.getUniqueId(), "Settings.Particles.Win");
                cosmeticGUI.put(player.getUniqueId(), "Win_Particle");
                CosmeticGui.addItemsFromConfig(player, gui, config, "Settings.Particles.Win");
                break;
            }
            case "death": {
                cosmeticPath.put(player.getUniqueId(), "Settings.Particles.Death");
                cosmeticGUI.put(player.getUniqueId(), "Death_Particle");
                CosmeticGui.addItemsFromConfig(player, gui, config, "Settings.Particles.Death");
                break;
            }
            case "killmessage": {
                cosmeticPath.put(player.getUniqueId(), "Settings.Particles.KillMessage");
                cosmeticGUI.put(player.getUniqueId(), "Kill_Message_Particle");
                CosmeticGui.addItemsFromConfig(player, gui, config, "Settings.Particles.KillMessage");
                break;
            }
            default: {
                player.sendMessage("Invalid path specified.");
                return;
            }
        }
        for (int i = 36; i <= 44; ++i) {
            ItemStack glassPane = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
            ItemMeta meta = glassPane.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(" ");
                glassPane.setItemMeta(meta);
            }
            gui.setItem(i, glassPane);
        }
        String section = cosmeticGUI.get(player.getUniqueId());
        String cosmetic = CosmeticHandler.getInstance().getSelectedCosmetic(player.getUniqueId(), section);
        String CurrentPath = cosmeticPath.get(player.getUniqueId());
        String CosmeticName = CurrentPath + "." + cosmetic + ".Displayname";
        String FinalName = SettingsManager.getInstance().getCosmetics().getString(CosmeticName);
        if (cosmetic != null) {
            item = new ItemStack(Material.ANVIL);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName("\u00a7eUnselect your cosmetic!");
                ArrayList<Object> lore = new ArrayList<Object>();
                lore.add("\u00a77Selected cosmetic: " + MSG.chatColors(FinalName));
                lore.add("\u00a77Click to remove your selection.");
                meta.setLore(lore);
                item.setItemMeta(meta);
            }
        } else {
            item = new ItemStack(Material.BARRIER);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName("\u00a7cYou do not have any cosmetic selected!");
                ArrayList<String> lore = new ArrayList<String>();
                lore.add("\u00a77Select a cosmetic in the menu.");
                meta.setLore(lore);
                item.setItemMeta(meta);
            }
        }
        gui.setItem(49, item);
        ItemStack barrier = new ItemStack(Material.FLOWER_BANNER_PATTERN);
        ItemMeta barrierMeta = barrier.getItemMeta();
        if (barrierMeta != null) {
            barrierMeta.setDisplayName("\u00a7f");
            barrier.setItemMeta(barrierMeta);
        }
        gui.setItem(48, barrier);
        gui.setItem(50, barrier);
        player.openInventory(gui);
        MoonLab.PlayerMenu.put(player.getUniqueId(), "SelectCosmetic-37bc82m-398dm-dj39");
    }

    private static void addItemsFromConfig(Player player, Inventory gui, FileConfiguration config, String configPath) {
        int slot = 0;
        Iterator var5 = config.getConfigurationSection(configPath).getKeys(false).iterator();
        while (var5.hasNext()) {
            String ID2;
            String key = (String)var5.next();
            String permission = config.getString(configPath + "." + key + ".Permission");
            if (!player.hasPermission(permission)) continue;
            String displayName = config.getString(configPath + "." + key + ".Displayname");
            Material itemMaterial = Material.valueOf((String)config.getString(configPath + "." + key + ".Item"));
            ArrayList<String> lore = new ArrayList<String>();
            for (String ID2 : config.getStringList(configPath + "." + key + ".Lore")) {
                lore.add(MSG.chatColors(ID2));
            }
            String DBCosmetic = cosmeticGUI.get(player.getUniqueId());
            ID2 = CosmeticHandler.getInstance().getSelectedCosmetic(player.getUniqueId(), DBCosmetic);
            ItemStack item = new ItemStack(itemMaterial);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(MSG.chatColors(displayName));
                meta.setLore(lore);
                if (key.equalsIgnoreCase(ID2)) {
                    meta.addEnchant(Enchantment.SILK_TOUCH, 1, true);
                    meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
                    ArrayList<String> lore2 = new ArrayList<String>();
                    lore2.add(MSG.chatColors("&aThis cosmetic is currently equipped!"));
                    meta.setLore(lore2);
                }
                item.setItemMeta(meta);
            }
            gui.setItem(slot, item);
            cosmeticID.put(slot, key);
            ++slot;
        }
        return;
    }

    @EventHandler
    public void onPlayerClickCosmeticItem(InventoryClickEvent event) {
        Player player = (Player)event.getWhoClicked();
        Inventory inventory = event.getClickedInventory();
        if (inventory != null) {
            String CurrentGUI = MoonLab.PlayerMenu.get(player.getUniqueId());
            String CurrentPath = cosmeticPath.get(player.getUniqueId());
            String section = cosmeticGUI.get(player.getUniqueId());
            if (CurrentGUI != null && CurrentGUI.equalsIgnoreCase("SelectCosmetic-37bc82m-398dm-dj39") && event.getView().getTitle().equalsIgnoreCase("Select a Cosmetic")) {
                event.setCancelled(true);
                int slot = event.getSlot();
                String cosmeticIDValue = cosmeticID.get(slot);
                ItemStack clickedItem = inventory.getItem(slot);
                if (slot == 49) {
                    if (clickedItem != null && clickedItem.getType().equals((Object)Material.ANVIL)) {
                        player.sendMessage(MSG.chatColors("&eYou have deselected your current cosmetic!"));
                        CosmeticHandler.getInstance().clearCosmetic(player.getUniqueId(), section);
                        player.closeInventory();
                        MoonLab.PlayerMenu.put(player.getUniqueId(), "YourCustomKeyHere");
                    }
                    return;
                }
                if (cosmeticIDValue != null && clickedItem != null && clickedItem.getType() != Material.AIR) {
                    CosmeticHandler.getInstance().updateSelectedCosmetic(player.getUniqueId(), section, cosmeticIDValue);
                    String CosmeticName = CurrentPath + "." + cosmeticIDValue + ".Displayname";
                    String FinalName = SettingsManager.getInstance().getCosmetics().getString(CosmeticName);
                    player.sendMessage(MSG.chatColors("&eYou have selected a new cosmetic! &7(" + FinalName + "&7)"));
                    player.closeInventory();
                    MoonLab.PlayerMenu.put(player.getUniqueId(), "YourCustomKeyHere");
                }
            }
        }
    }
}

