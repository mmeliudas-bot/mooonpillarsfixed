/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerJoinEvent
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler.CosmeticHandler;

public class JoinHandler
implements Listener {
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (!CosmeticHandler.getInstance().playerExists(player.getUniqueId())) {
            CosmeticHandler.getInstance().saveNewPlayerWithCosmetics(player.getUniqueId());
        }
    }
}

