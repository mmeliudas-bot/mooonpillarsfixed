/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler.CosmeticHandler;

public class SelectCosmeticCMD
implements CommandExecutor,
TabCompleter {
    private String getColumnName(String section) {
        return switch (section.toLowerCase()) {
            case "cages" -> "Cage_Particle";
            case "pillar" -> "Pillar_Particle";
            case "bow" -> "Bow_Particle";
            case "kill" -> "Kill_Particle";
            case "win" -> "Win_Particle";
            case "death" -> "Death_Particle";
            case "killmessage" -> "Kill_Message_Particle";
            default -> throw new IllegalArgumentException("Invalid section: " + section);
        };
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (args.length == 2) {
                String type = args[0];
                String id = args[1];
                try {
                    String columnName = this.getColumnName(type);
                    CosmeticHandler.getInstance().updateSelectedCosmetic(player.getUniqueId(), columnName, id);
                }
                catch (IllegalArgumentException var11) {
                    player.sendMessage(MSG.chatColors("&cInvalid cosmetic type!"));
                }
            } else {
                player.sendMessage(MSG.chatColors("&cUsage: /selectcosmetic <type> <id>"));
            }
            return true;
        }
        if (args.length == 3) {
            String type = args[0];
            String id = args[1];
            String columnName = args[2];
            Player targetPlayer = Bukkit.getPlayer((String)columnName);
            if (targetPlayer != null) {
                try {
                    columnName = this.getColumnName(type);
                    CosmeticHandler.getInstance().updateSelectedCosmetic(targetPlayer.getUniqueId(), columnName, id);
                }
                catch (IllegalArgumentException var12) {
                    sender.sendMessage("&cInvalid cosmetic type!");
                }
            } else {
                sender.sendMessage("&cPlayer not found!");
            }
        } else {
            sender.sendMessage(MSG.chatColors("&cUsage: /selectcosmetic <type> <id> <player>"));
        }
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        ArrayList<String> suggestions = new ArrayList<String>();
        if (sender instanceof Player && args.length == 1) {
            String arg = args[0].toLowerCase();
            suggestions.add("pillar");
            suggestions.add("cages");
            suggestions.add("win");
            suggestions.add("bow");
            suggestions.add("kill");
            suggestions.add("death");
            suggestions.add("killmessage");
            for (String suggestion : suggestions) {
                if (!suggestion.startsWith(arg)) continue;
                completions.add(suggestion);
            }
        }
        return completions;
    }
}

