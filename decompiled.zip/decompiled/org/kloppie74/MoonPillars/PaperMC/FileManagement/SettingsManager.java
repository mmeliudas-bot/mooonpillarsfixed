/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.configuration.InvalidConfigurationException
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.HashMap;
import org.bukkit.Bukkit;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.FileCopy;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class SettingsManager {
    static SettingsManager instance = new SettingsManager();
    static FileConfiguration Scoreboard;
    static File Scoreboardfile;
    static FileConfiguration ChatReplySettings;
    static File ChatReplySettingsfile;
    static FileConfiguration Settings;
    static File Settingsfile;
    static FileConfiguration LevelSettings;
    static File LevelSettingsfile;
    static FileConfiguration LevelMenu;
    static File LevelMenufile;
    static FileConfiguration Cosmetics;
    static File Cosmeticsfile;
    static FileConfiguration commands;
    static File commandsfile;
    static FileConfiguration items;
    static File itemsfile;
    static FileConfiguration Lang;
    static File Langfile;
    static FileConfiguration ClickAbleSigns;
    static File ClickAbleSignsfile;
    static FileConfiguration Portals;
    static File Portalsfile;
    private static HashMap<File, Long> lastModifiedTimes;
    private static final long MESSAGE_COOLDOWN = 5000L;
    private static HashMap<String, Long> lastMessageTime;

    public static SettingsManager getInstance() {
        return instance;
    }

    public FileConfiguration getSettings() {
        return Settings;
    }

    public FileConfiguration getLevelSettings() {
        return LevelSettings;
    }

    public FileConfiguration getLevelMenu() {
        return LevelMenu;
    }

    public FileConfiguration getCosmetics() {
        return Cosmetics;
    }

    public FileConfiguration getItems() {
        return items;
    }

    public FileConfiguration getLang() {
        return Lang;
    }

    public FileConfiguration getScoreboard() {
        return Scoreboard;
    }

    public FileConfiguration getCommands() {
        return commands;
    }

    public FileConfiguration getClickableSigns() {
        return ClickAbleSigns;
    }

    public FileConfiguration getChatReplySettings() {
        return ChatReplySettings;
    }

    public FileConfiguration getPortals() {
        return Portals;
    }

    public static boolean SetupFolders(Plugin p) {
        File PillarFolder;
        File LangFolder;
        File MenuFolder;
        File StorageFolder;
        File GameSettingsFolder;
        if (!p.getDataFolder().exists()) {
            p.getDataFolder().mkdir();
        }
        if (!(GameSettingsFolder = new File(p.getDataFolder(), "Games")).exists()) {
            GameSettingsFolder.mkdirs();
        }
        if (!(StorageFolder = new File(p.getDataFolder(), "Storage")).exists()) {
            StorageFolder.mkdirs();
        }
        if (!(MenuFolder = new File(p.getDataFolder(), "Menus")).exists()) {
            MenuFolder.mkdirs();
        }
        if (!(LangFolder = new File(p.getDataFolder(), "LangFiles")).exists()) {
            LangFolder.mkdirs();
        }
        if (!(PillarFolder = new File(p.getDataFolder(), "Pillars")).exists()) {
            PillarFolder.mkdirs();
        }
        return true;
    }

    public static boolean setup(Plugin p) {
        SettingsManager.SetupFolders((Plugin)MoonLab.getInstance());
        Scoreboardfile = new File(p.getDataFolder(), "ScoreBoards.yml");
        if (!Scoreboardfile.exists()) {
            new FileCopy().copy(p.getResource("ScoreBoards.yml"), Scoreboardfile);
        }
        Scoreboard = YamlConfiguration.loadConfiguration((File)Scoreboardfile);
        Settingsfile = new File(p.getDataFolder(), "Settings.yml");
        if (!Settingsfile.exists()) {
            new FileCopy().copy(p.getResource("Settings.yml"), Settingsfile);
        }
        Settings = YamlConfiguration.loadConfiguration((File)Settingsfile);
        LevelSettingsfile = new File(p.getDataFolder(), "LevelRewards.yml");
        if (!LevelSettingsfile.exists()) {
            new FileCopy().copy(p.getResource("LevelRewards.yml"), LevelSettingsfile);
        }
        LevelSettings = YamlConfiguration.loadConfiguration((File)LevelSettingsfile);
        LevelMenufile = new File(p.getDataFolder(), "LevelMenu.yml");
        if (!LevelMenufile.exists()) {
            new FileCopy().copy(p.getResource("LevelMenu.yml"), LevelMenufile);
        }
        LevelMenu = YamlConfiguration.loadConfiguration((File)LevelMenufile);
        Cosmeticsfile = new File(p.getDataFolder(), "Cosmetics.yml");
        if (!Cosmeticsfile.exists()) {
            new FileCopy().copy(p.getResource("Cosmetics.yml"), Cosmeticsfile);
        }
        Cosmetics = YamlConfiguration.loadConfiguration((File)Cosmeticsfile);
        commandsfile = new File(p.getDataFolder(), "Commands.yml");
        if (!commandsfile.exists()) {
            new FileCopy().copy(p.getResource("Commands.yml"), commandsfile);
        }
        commands = YamlConfiguration.loadConfiguration((File)commandsfile);
        itemsfile = new File(p.getDataFolder(), "Items.yml");
        if (!itemsfile.exists()) {
            new FileCopy().copy(p.getResource("Items.yml"), itemsfile);
        }
        items = YamlConfiguration.loadConfiguration((File)itemsfile);
        Langfile = new File(p.getDataFolder(), "LangFiles/en.yml");
        if (!Langfile.exists()) {
            new FileCopy().copy(p.getResource("LangFiles/en.yml"), Langfile);
        }
        Lang = YamlConfiguration.loadConfiguration((File)Langfile);
        ClickAbleSignsfile = new File(p.getDataFolder(), "ClickAbleSigns.yml");
        if (!ClickAbleSignsfile.exists()) {
            new FileCopy().copy(p.getResource("ClickAbleSigns.yml"), ClickAbleSignsfile);
        }
        ClickAbleSigns = YamlConfiguration.loadConfiguration((File)ClickAbleSignsfile);
        ChatReplySettingsfile = new File(p.getDataFolder(), "ChatReply.yml");
        if (!ChatReplySettingsfile.exists()) {
            new FileCopy().copy(p.getResource("ChatReply.yml"), ChatReplySettingsfile);
        }
        ChatReplySettings = YamlConfiguration.loadConfiguration((File)ChatReplySettingsfile);
        Portalsfile = new File(p.getDataFolder(), "Portals.yml");
        if (!Portalsfile.exists()) {
            new FileCopy().copy(p.getResource("Portals.yml"), Portalsfile);
        }
        Portals = YamlConfiguration.loadConfiguration((File)Portalsfile);
        MessageSender.init(Lang);
        SettingsManager.ensureSectionsExist(Scoreboard);
        return true;
    }

    public static void saveSettings(String Setting) {
        if (Setting.equalsIgnoreCase("Cosmetics")) {
            try {
                Cosmetics.save(Cosmeticsfile);
            }
            catch (IOException var7) {
                throw new RuntimeException(var7);
            }
        }
        if (Setting.equalsIgnoreCase("Settings")) {
            try {
                Settings.save(Settingsfile);
            }
            catch (IOException var6) {
                throw new RuntimeException(var6);
            }
        }
        if (Setting.equalsIgnoreCase("LangFile")) {
            try {
                Lang.save(Langfile);
            }
            catch (IOException var5) {
                throw new RuntimeException(var5);
            }
        }
        if (Setting.equalsIgnoreCase("Scoreboard")) {
            try {
                Scoreboard.save(Scoreboardfile);
            }
            catch (IOException var4) {
                throw new RuntimeException(var4);
            }
        }
        if (Setting.equalsIgnoreCase("ClickAbleSigns")) {
            try {
                ClickAbleSigns.save(ClickAbleSignsfile);
            }
            catch (IOException var3) {
                throw new RuntimeException(var3);
            }
        }
        if (Setting.equalsIgnoreCase("Portals")) {
            try {
                Portals.save(Portalsfile);
            }
            catch (IOException var2) {
                throw new RuntimeException(var2);
            }
        }
    }

    private static void sendConsoleMessage(String fileName, String message) {
        long currentTime = System.currentTimeMillis();
        if (!lastMessageTime.containsKey(fileName) || currentTime - lastMessageTime.get(fileName) > 5000L) {
            Bukkit.getConsoleSender().sendMessage(message);
            lastMessageTime.put(fileName, currentTime);
        }
    }

    public static void registerFileChangeListeners() {
        SettingsManager.registerListener(Settingsfile, () -> SettingsManager.reloadFile(Settingsfile, Settings, "Settings"));
        SettingsManager.registerListener(Cosmeticsfile, () -> SettingsManager.reloadFile(Cosmeticsfile, Cosmetics, "Cosmetics"));
        SettingsManager.registerListener(itemsfile, () -> SettingsManager.reloadFile(itemsfile, items, "Items"));
        SettingsManager.registerListener(Scoreboardfile, () -> SettingsManager.reloadFile(Scoreboardfile, Scoreboard, "Scoreboard"));
        SettingsManager.registerListener(commandsfile, () -> SettingsManager.reloadFile(commandsfile, commands, "Commands"));
        SettingsManager.registerListener(Langfile, () -> SettingsManager.reloadFile(Langfile, Lang, "LangFiles/en.yml"));
        SettingsManager.registerListener(LevelMenufile, () -> SettingsManager.reloadFile(LevelMenufile, LevelMenu, "LevelMenu"));
        SettingsManager.registerListener(ClickAbleSignsfile, () -> SettingsManager.reloadFile(ClickAbleSignsfile, ClickAbleSigns, "ClickAbleSigns"));
        SettingsManager.registerListener(Portalsfile, () -> SettingsManager.reloadFile(Portalsfile, Portals, "Portals"));
    }

    private static void reloadFile(File file, FileConfiguration config, String fileName) {
        try {
            long currentLastModified = file.lastModified();
            Long lastModified = lastModifiedTimes.get(file);
            if (lastModified == null || currentLastModified > lastModified) {
                config.load(file);
                SettingsManager.sendConsoleMessage(fileName, "\u00a77[\u00a7bMoonPillars\u00a77] \u00a7f- \u00a7aFound save in \u00a7e" + fileName + ".yml, \u00a7aReloading file automatic!");
                lastModifiedTimes.put(file, currentLastModified);
            }
        }
        catch (IOException | InvalidConfigurationException var6) {
            var6.printStackTrace();
        }
    }

    public static void registerListener(File file, Runnable onChange) {
        Path path = file.toPath();
        try {
            WatchService watchService = FileSystems.getDefault().newWatchService();
            path.getParent().register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);
            new Thread(() -> {
                while (true) {
                    try {
                        while (true) {
                            WatchKey watchKey = watchService.take();
                            for (WatchEvent<?> event : watchKey.pollEvents()) {
                                if (!event.context().equals(path.getFileName())) continue;
                                onChange.run();
                            }
                            watchKey.reset();
                        }
                    }
                    catch (InterruptedException var6) {
                        var6.printStackTrace();
                        continue;
                    }
                    break;
                }
            }).start();
        }
        catch (Exception var4) {
            var4.printStackTrace();
        }
    }

    public static void ensureSectionsExist(FileConfiguration config) {
        String[] sections;
        String[] var2 = sections = new String[]{"Game_ended", "Game", "Game_spectate", "Game_Lobby", "Lobby"};
        int var3 = sections.length;
        for (int var4 = 0; var4 < var3; ++var4) {
            String section = var2[var4];
            if (config.contains("ScoreBoards." + section)) continue;
            SettingsManager.addDefaultSection(config, section);
        }
        SettingsManager.saveSettings("Scoreboard");
    }

    private static void addDefaultSection(FileConfiguration config, String section) {
        int var3 = -1;
        switch (section.hashCode()) {
            case -1373755347: {
                if (!section.equals("Game_Ended")) break;
                var3 = 0;
                break;
            }
            case -1367262903: {
                if (!section.equals("Game_Lobby")) break;
                var3 = 3;
                break;
            }
            case 2211858: {
                if (!section.equals("Game")) break;
                var3 = 1;
                break;
            }
            case 73591734: {
                if (!section.equals("Lobby")) break;
                var3 = 4;
                break;
            }
            case 1629725062: {
                if (!section.equals("Game_Spectate")) break;
                var3 = 2;
            }
        }
        switch (var3) {
            case 0: {
                config.set("ScoreBoards.Game_ended.Enabled", (Object)true);
                config.set("ScoreBoards.Game_ended.Title", (Object)"&b&lGame Ended!");
                config.set("ScoreBoards.Game_ended.Lines.8", (Object)"&b");
                config.set("ScoreBoards.Game_ended.Lines.7", (Object)"&bPlayer: &f%player_name%");
                config.set("ScoreBoards.Game_ended.Lines.6", (Object)"&bGameID: &f%mpa_game_id%");
                config.set("ScoreBoards.Game_ended.Lines.5", (Object)"&bGameName: &f%mpa_game_displayname%");
                config.set("ScoreBoards.Game_ended.Lines.4", (Object)"&b");
                config.set("ScoreBoards.Game_ended.Lines.3", (Object)"&bGame Timer: &f%mpa_game_timer%");
                config.set("ScoreBoards.Game_ended.Lines.2", (Object)"&bItem Timer: &f%mpa_item_timer%");
                config.set("ScoreBoards.Game_ended.Lines.1", (Object)"");
                break;
            }
            case 1: {
                config.set("ScoreBoards.Game.Enabled", (Object)true);
                config.set("ScoreBoards.Game.Title", (Object)"&b&lGame ");
                config.set("ScoreBoards.Game.Lines.8", (Object)"&b");
                config.set("ScoreBoards.Game.Lines.7", (Object)"&bPlayer: &f%player_name%");
                config.set("ScoreBoards.Game.Lines.6", (Object)"&bGameID: &f%mpa_game_id%");
                config.set("ScoreBoards.Game.Lines.5", (Object)"&bGameName: &f%mpa_game_displayname%");
                config.set("ScoreBoards.Game.Lines.4", (Object)"&b");
                config.set("ScoreBoards.Game.Lines.3", (Object)"&bGame Timer: &f%mpa_game_timer%");
                config.set("ScoreBoards.Game.Lines.2", (Object)"&bItem Timer: &f%mpa_item_timer%");
                config.set("ScoreBoards.Game.Lines.1", (Object)"");
                break;
            }
            case 2: {
                config.set("ScoreBoards.Game_spectate.Enabled", (Object)true);
                config.set("ScoreBoards.Game_spectate.Title", (Object)"&b&lGame Spectator ");
                config.set("ScoreBoards.Game_spectate.Lines.8", (Object)"&b");
                config.set("ScoreBoards.Game_spectate.Lines.7", (Object)"&bPlayer: &f%player_name%");
                config.set("ScoreBoards.Game_spectate.Lines.6", (Object)"&bGameID: &f%mpa_game_id%");
                config.set("ScoreBoards.Game_spectate.Lines.5", (Object)"&bGameName: &f%mpa_game_displayname%");
                config.set("ScoreBoards.Game_spectate.Lines.4", (Object)"&b");
                config.set("ScoreBoards.Game_spectate.Lines.3", (Object)"&bGame Timer: &f%mpa_game_timer%");
                config.set("ScoreBoards.Game_spectate.Lines.2", (Object)"&bItem Timer: &f%mpa_item_timer%");
                config.set("ScoreBoards.Game_spectate.Lines.1", (Object)"");
                break;
            }
            case 3: {
                config.set("ScoreBoards.Game_Lobby.Enabled", (Object)true);
                config.set("ScoreBoards.Game_Lobby.Title", (Object)"&b&lGame Lobby");
                config.set("ScoreBoards.Game_Lobby.Lines.9", (Object)"&b");
                config.set("ScoreBoards.Game_Lobby.Lines.8", (Object)"&bPlayer: &f%player_name%");
                config.set("ScoreBoards.Game_Lobby.Lines.7", (Object)"&blevel: &f%mpa_level%");
                config.set("ScoreBoards.Game_Lobby.Lines.6", (Object)"&bShards: &f%mpa_shards%");
                config.set("ScoreBoards.Game_Lobby.Lines.5", (Object)"&bXP: &f%mpa_level_xp%#BDD3D5/&f%mpa_level_xp_needed%");
                config.set("ScoreBoards.Game_Lobby.Lines.4", (Object)"&bWins: &f%mpa_wins%");
                config.set("ScoreBoards.Game_Lobby.Lines.3", (Object)"&b");
                config.set("ScoreBoards.Game_Lobby.Lines.2", (Object)"&bAdmin: &f%mpa_player_isadmin%");
                config.set("ScoreBoards.Game_Lobby.Lines.1", (Object)"");
                break;
            }
            case 4: {
                config.set("ScoreBoards.Lobby.Enabled", (Object)true);
                config.set("ScoreBoards.Lobby.Title", (Object)"#87C8CE&lLobby");
                config.set("ScoreBoards.Lobby.Lines.9", (Object)"&b");
                config.set("ScoreBoards.Lobby.Lines.8", (Object)"&bPlayer: &f%player_name% ");
                config.set("ScoreBoards.Lobby.Lines.7", (Object)"&blevel: &f%mpa_level%");
                config.set("ScoreBoards.Lobby.Lines.6", (Object)"&bShards: &f%mpa_shards%");
                config.set("ScoreBoards.Lobby.Lines.5", (Object)"&bXP: &f%mpa_level_xp%#BDD3D5/&f%mpa_level_xp_needed%");
                config.set("ScoreBoards.Lobby.Lines.4", (Object)"&bWins: &f%mpa_wins%");
                config.set("ScoreBoards.Lobby.Lines.3", (Object)"&b");
                config.set("ScoreBoards.Lobby.Lines.2", (Object)"&bAdmin: &f%mpa_player_isadmin%");
                config.set("ScoreBoards.Lobby.Lines.1", (Object)"");
            }
        }
    }

    public boolean reloadFiles(Player player) {
        try {
            MoonLab plugin = MoonLab.getInstance();
            Scoreboard = YamlConfiguration.loadConfiguration((File)Scoreboardfile);
            Settings = YamlConfiguration.loadConfiguration((File)Settingsfile);
            LevelSettings = YamlConfiguration.loadConfiguration((File)LevelSettingsfile);
            LevelMenu = YamlConfiguration.loadConfiguration((File)LevelMenufile);
            Cosmetics = YamlConfiguration.loadConfiguration((File)Cosmeticsfile);
            commands = YamlConfiguration.loadConfiguration((File)commandsfile);
            items = YamlConfiguration.loadConfiguration((File)itemsfile);
            Lang = YamlConfiguration.loadConfiguration((File)Langfile);
            ClickAbleSigns = YamlConfiguration.loadConfiguration((File)ClickAbleSignsfile);
            Portals = YamlConfiguration.loadConfiguration((File)Portalsfile);
            lastModifiedTimes.put(Settingsfile, Settingsfile.lastModified());
            lastModifiedTimes.put(Cosmeticsfile, Cosmeticsfile.lastModified());
            lastModifiedTimes.put(itemsfile, itemsfile.lastModified());
            lastModifiedTimes.put(Scoreboardfile, Scoreboardfile.lastModified());
            lastModifiedTimes.put(commandsfile, commandsfile.lastModified());
            lastModifiedTimes.put(Langfile, Langfile.lastModified());
            lastModifiedTimes.put(LevelMenufile, LevelMenufile.lastModified());
            lastModifiedTimes.put(ClickAbleSignsfile, ClickAbleSignsfile.lastModified());
            lastModifiedTimes.put(Portalsfile, Portalsfile.lastModified());
            SettingsManager.ensureSectionsExist(Scoreboard);
            Bukkit.getConsoleSender().sendMessage("\u00a77[\u00a7bMoonPillars\u00a77] \u00a7f- \u00a7aAll configuration files have been reloaded!");
            player.sendMessage(MSG.chatColors("\u00a7aAll configuration files have been reloaded!"));
            return true;
        }
        catch (Exception var3) {
            Bukkit.getConsoleSender().sendMessage("\u00a77[\u00a7bMoonPillars\u00a77] \u00a7f- \u00a7cError reloading configuration files: " + var3.getMessage());
            player.sendMessage(MSG.chatColors("\u00a7cError reloading configuration files! Check the console for details."));
            var3.printStackTrace();
            return false;
        }
    }

    static {
        lastModifiedTimes = new HashMap();
        lastMessageTime = new HashMap();
    }
}

