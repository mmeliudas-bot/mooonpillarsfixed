/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.server.PluginDisableEvent
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class DatabaseManager
implements Listener {
    private static DatabaseManager instance;
    private final String dbName = String.valueOf(MoonLab.getInstance().getDataFolder()) + "/Storage/Player-Data.db";
    private final AtomicReference<Connection> connectionRef = new AtomicReference();
    private final ReentrantLock connectionLock = new ReentrantLock();
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread thread = new Thread(r, "MoonPillars-DatabaseThread");
        thread.setDaemon(true);
        return thread;
    });
    private static final int CONNECTION_REFRESH_MINUTES = 30;
    private static final int BACKUP_INTERVAL_MINUTES = 15;

    public DatabaseManager() {
        try {
            this.initializeDatabase();
        }
        catch (SQLException var2) {
            Bukkit.getLogger().severe("[MoonPillars] Failed to initialize database: " + var2.getMessage());
            var2.printStackTrace();
        }
        this.scheduler.scheduleAtFixedRate(this::refreshConnection, 30L, 30L, TimeUnit.MINUTES);
        MoonLab.getInstance().getServer().getPluginManager().registerEvents((Listener)this, (Plugin)MoonLab.getInstance());
    }

    public static synchronized DatabaseManager getInstance() {
        if (instance == null) {
            instance = new DatabaseManager();
        }
        return instance;
    }

    private void initializeDatabase() throws SQLException {
        Connection connection = this.getConnection();
        this.createTables(connection);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void createTables(Connection connection) throws SQLException {
        String createPlayerDataTableSQL = "CREATE TABLE IF NOT EXISTS player_data (uuid VARCHAR(36) PRIMARY KEY,Level INTEGER DEFAULT 1,XP INTEGER DEFAULT 0,Kills INTEGER DEFAULT 0,Shards INTEGER DEFAULT 0,name VARCHAR(255) NOT NULL,wins INTEGER DEFAULT 0,total_played_games INTEGER DEFAULT 0,winstreak INTEGER DEFAULT 0,total_winstreak INTEGER DEFAULT 0,SpyChat INTEGER DEFAULT 0,msg_toggle BOOLEAN DEFAULT TRUE,vanish BOOLEAN DEFAULT FALSE,hide_me BOOLEAN DEFAULT FALSE,hide_others BOOLEAN DEFAULT FALSE,IgnoredPlayers TEXT DEFAULT '',client_notifs_disabled BOOLEAN DEFAULT FALSE,chat_channel TEXT DEFAULT 'global');";
        String createShowOthersTableSQL = "CREATE TABLE IF NOT EXISTS show_others (player_uuid VARCHAR(36),target_uuid VARCHAR(36),PRIMARY KEY (player_uuid, target_uuid));";
        try (Statement statement = null;){
            statement = connection.createStatement();
            statement.executeUpdate(createPlayerDataTableSQL);
            statement.executeUpdate(createShowOthersTableSQL);
            this.addColumnIfNotExists(connection, "total_played_games", "INTEGER DEFAULT 0");
            this.addColumnIfNotExists(connection, "winstreak", "INTEGER DEFAULT 0");
            this.addColumnIfNotExists(connection, "total_winstreak", "INTEGER DEFAULT 0");
            this.addColumnIfNotExists(connection, "Level", "INTEGER DEFAULT 1");
            this.addColumnIfNotExists(connection, "XP", "INTEGER DEFAULT 0");
            this.addColumnIfNotExists(connection, "Kills", "INTEGER DEFAULT 0");
            this.addColumnIfNotExists(connection, "Shards", "INTEGER DEFAULT 0");
            this.addColumnIfNotExists(connection, "name", "VARCHAR(255) NOT NULL");
            this.addColumnIfNotExists(connection, "wins", "INTEGER DEFAULT 0");
            this.addColumnIfNotExists(connection, "msg_toggle", "BOOLEAN DEFAULT TRUE");
            this.addColumnIfNotExists(connection, "vanish", "BOOLEAN DEFAULT FALSE");
            this.addColumnIfNotExists(connection, "hide_me", "BOOLEAN DEFAULT FALSE");
            this.addColumnIfNotExists(connection, "hide_others", "BOOLEAN DEFAULT FALSE");
            this.addColumnIfNotExists(connection, "IgnoredPlayers", "TEXT DEFAULT ''");
            this.addColumnIfNotExists(connection, "client_notifs_disabled", "BOOLEAN DEFAULT FALSE");
            this.addColumnIfNotExists(connection, "chat_channel", "TEXT DEFAULT 'global'");
            this.addColumnIfNotExists(connection, "claimed_levels", "TEXT DEFAULT ''");
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void addColumnIfNotExists(Connection connection, String columnName, String columnDefinition) throws SQLException {
        String checkColumnSQL = "PRAGMA table_info(player_data);";
        boolean columnExists = false;
        Statement statement = null;
        ResultSet resultSet = null;
        try {
            Object addColumnSQL;
            statement = connection.createStatement();
            resultSet = statement.executeQuery(checkColumnSQL);
            while (resultSet.next()) {
                addColumnSQL = resultSet.getString("name");
                if (!((String)addColumnSQL).equals(columnName)) continue;
                columnExists = true;
                break;
            }
            if (!columnExists) {
                addColumnSQL = "ALTER TABLE player_data ADD COLUMN " + columnName + " " + columnDefinition + ";";
                statement.executeUpdate((String)addColumnSQL);
                Bukkit.getLogger().info("[MoonPillars] Added column " + columnName + " to player_data table");
            }
        }
        finally {
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private Connection getConnection() throws SQLException {
        Connection var18;
        this.connectionLock.lock();
        try {
            Connection connection = this.connectionRef.get();
            if (connection == null || connection.isClosed()) {
                try {
                    Class.forName("org.sqlite.JDBC");
                }
                catch (ClassNotFoundException var14) {
                    throw new SQLException("SQLite JDBC driver not found", var14);
                }
                File dbFile = new File(this.dbName);
                dbFile.getParentFile().mkdirs();
                connection = DriverManager.getConnection("jdbc:sqlite:" + this.dbName);
                try (Statement stmt = null;){
                    stmt = connection.createStatement();
                    stmt.execute("PRAGMA busy_timeout = 10000;");
                    stmt.execute("PRAGMA journal_mode = WAL;");
                    stmt.execute("PRAGMA synchronous = NORMAL;");
                }
                this.connectionRef.set(connection);
                Bukkit.getLogger().info("[MoonPillars] Established new database connection");
            }
            var18 = connection;
        }
        catch (SQLException var16) {
            Bukkit.getLogger().severe("[MoonPillars] Failed to get database connection: " + var16.getMessage());
            throw var16;
        }
        finally {
            this.connectionLock.unlock();
        }
        return var18;
    }

    private void refreshConnection() {
        this.connectionLock.lock();
        try {
            Connection oldConnection = this.connectionRef.get();
            if (oldConnection != null) {
                try {
                    oldConnection.close();
                }
                catch (SQLException var8) {
                    Bukkit.getLogger().warning("[MoonPillars] Error closing old database connection: " + var8.getMessage());
                }
            }
            this.connectionRef.set(null);
            try {
                this.getConnection();
                Bukkit.getLogger().info("[MoonPillars] Database connection refreshed successfully");
            }
            catch (SQLException var7) {
                Bukkit.getLogger().severe("[MoonPillars] Failed to refresh database connection: " + var7.getMessage());
                var7.printStackTrace();
            }
        }
        finally {
            this.connectionLock.unlock();
        }
    }

    private void closeConnection() {
        this.connectionLock.lock();
        try {
            Connection connection = this.connectionRef.get();
            if (connection != null) {
                try {
                    connection.close();
                    this.connectionRef.set(null);
                    Bukkit.getLogger().info("[MoonPillars] Database connection closed");
                }
                catch (SQLException var6) {
                    Bukkit.getLogger().warning("[MoonPillars] Error closing database connection: " + var6.getMessage());
                }
            }
        }
        finally {
            this.connectionLock.unlock();
        }
    }

    @EventHandler(priority=EventPriority.NORMAL)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        String name = player.getName();
        this.updatePlayerName(uuid, name);
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerQuit(PlayerQuitEvent event) {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void updatePlayerName(UUID uuid, String name) {
        Statement stmt = null;
        try {
            boolean exists;
            Connection connection = this.connectionRef.get();
            if (connection == null || connection.isClosed()) {
                connection = this.getConnection();
            }
            if (exists = this.playerExists(uuid)) {
                stmt = connection.prepareStatement("UPDATE player_data SET name = ? WHERE uuid = ?");
                stmt.setString(1, name);
                stmt.setString(2, uuid.toString());
                stmt.executeUpdate();
            } else {
                stmt = connection.prepareStatement("INSERT INTO player_data (uuid, name) VALUES (?, ?)");
                stmt.setString(1, uuid.toString());
                stmt.setString(2, name);
                stmt.executeUpdate();
            }
        }
        catch (SQLException var14) {
            Bukkit.getLogger().severe("[MoonPillars] Error updating player name for " + name + ": " + var14.getMessage());
            var14.printStackTrace();
        }
        finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var13) {
                Bukkit.getLogger().warning("[MoonPillars] Error closing statement: " + var13.getMessage());
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private boolean playerExists(UUID uuid) throws SQLException {
        boolean var5;
        Connection connection = this.connectionRef.get();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = connection.prepareStatement("SELECT 1 FROM player_data WHERE uuid = ?");
            stmt.setString(1, uuid.toString());
            rs = stmt.executeQuery();
            var5 = rs.next();
        }
        finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
        return var5;
    }

    private void createDatabaseBackup() {
        try {
            File sourceDB = new File(this.dbName);
            if (!sourceDB.exists()) {
                return;
            }
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
            String timestamp = dateFormat.format(new Date());
            File backupDir = new File(MoonLab.getInstance().getDataFolder(), "backups");
            if (!backupDir.exists()) {
                backupDir.mkdirs();
            }
            File backupFile = new File(backupDir, "Player-Data_" + timestamp + ".db");
            this.closeConnection();
            Files.copy(sourceDB.toPath(), backupFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            Bukkit.getConsoleSender().sendMessage("[MoonPillars] Database backup created: " + backupFile.getName());
            this.cleanupOldBackups(backupDir, 20);
            this.getConnection();
        }
        catch (IOException | SQLException var6) {
            Bukkit.getLogger().severe("[MoonPillars] Failed to create database backup: " + var6.getMessage());
            var6.printStackTrace();
        }
    }

    private void cleanupOldBackups(File backupDir, int keepCount) {
        File[] backupFiles = backupDir.listFiles((dir, name) -> name.startsWith("Player-Data_") && name.endsWith(".db"));
        if (backupFiles != null && backupFiles.length > keepCount) {
            Arrays.sort(backupFiles, Comparator.comparingLong(File::lastModified));
            for (int i = 0; i < backupFiles.length - keepCount; ++i) {
                if (!backupFiles[i].delete()) continue;
                Bukkit.getConsoleSender().sendMessage("[MoonPillars] Deleted old backup: " + backupFiles[i].getName());
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public String getSetting(UUID uuid, String setting) {
        String var6;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Connection connection = this.connectionRef.get();
            if (connection == null || connection.isClosed()) {
                connection = this.getConnection();
            }
            stmt = connection.prepareStatement("SELECT " + setting + " FROM player_data WHERE uuid = ?");
            stmt.setString(1, uuid.toString());
            rs = stmt.executeQuery();
            if (!rs.next()) {
                String string = null;
                return string;
            }
            var6 = rs.getString(setting);
        }
        catch (SQLException var17) {
            Bukkit.getLogger().severe("[MoonPillars] Error getting setting " + setting + " for player " + String.valueOf(uuid) + ": " + var17.getMessage());
            var17.printStackTrace();
            String string = null;
            return string;
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var16) {
                Bukkit.getLogger().severe("[MoonPillars] Error closing resources: " + var16.getMessage());
            }
        }
        return var6;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void updateSetting(UUID uuid, String setting, Object value) {
        Statement stmt = null;
        try {
            Connection connection = this.connectionRef.get();
            if (connection == null || connection.isClosed()) {
                connection = this.getConnection();
            }
            stmt = connection.prepareStatement("UPDATE player_data SET " + setting + " = ? WHERE uuid = ?");
            if (value instanceof Integer) {
                stmt.setInt(1, (Integer)value);
            } else if (value instanceof Boolean) {
                stmt.setBoolean(1, (Boolean)value);
            } else if (value instanceof String) {
                stmt.setString(1, (String)value);
            } else {
                stmt.setString(1, value.toString());
            }
            stmt.setString(2, uuid.toString());
            stmt.executeUpdate();
        }
        catch (SQLException var14) {
            Bukkit.getLogger().severe("[MoonPillars] Error updating setting " + setting + " for player " + String.valueOf(uuid) + ": " + var14.getMessage());
            var14.printStackTrace();
        }
        finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var13) {
                Bukkit.getLogger().severe("[MoonPillars] Error closing resources: " + var13.getMessage());
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public boolean getMsgToggle(UUID uuid) {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Connection connection = this.connectionRef.get();
            if (connection == null || connection.isClosed()) {
                connection = this.getConnection();
            }
            stmt = connection.prepareStatement("SELECT msg_toggle FROM player_data WHERE uuid = ?");
            stmt.setString(1, uuid.toString());
            rs = stmt.executeQuery();
            if (rs.next()) {
                boolean var5;
                boolean bl = var5 = rs.getBoolean("msg_toggle");
                return bl;
            }
        }
        catch (SQLException var16) {
            Logger var10000 = Bukkit.getLogger();
            String var10001 = String.valueOf(uuid);
            var10000.severe("[MoonPillars] Error getting msg_toggle for player " + var10001 + ": " + var16.getMessage());
            var16.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var15) {
                Bukkit.getLogger().severe("[MoonPillars] Error closing resources: " + var15.getMessage());
            }
        }
        return true;
    }

    public void setMsgToggle(UUID uuid, boolean enabled) {
        this.updateSetting(uuid, "msg_toggle", enabled);
    }

    public void updateIgnoredPlayersSetting(UUID uuid, String value) {
        this.updateSetting(uuid, "IgnoredPlayers", value);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public boolean getVanishState(UUID uuid) {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Connection connection = this.connectionRef.get();
            if (connection == null || connection.isClosed()) {
                connection = this.getConnection();
            }
            stmt = connection.prepareStatement("SELECT vanish FROM player_data WHERE uuid = ?");
            stmt.setString(1, uuid.toString());
            rs = stmt.executeQuery();
            if (rs.next()) {
                boolean var5;
                boolean bl = var5 = rs.getBoolean("vanish");
                return bl;
            }
        }
        catch (SQLException var16) {
            Logger var10000 = Bukkit.getLogger();
            String var10001 = String.valueOf(uuid);
            var10000.severe("[MoonPillars] Error getting vanish state for player " + var10001 + ": " + var16.getMessage());
            var16.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var15) {
                Bukkit.getLogger().severe("[MoonPillars] Error closing resources: " + var15.getMessage());
            }
        }
        return false;
    }

    public void setVanishState(UUID uuid, boolean state) {
        this.updateSetting(uuid, "vanish", state);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public boolean getHideMeState(UUID uuid) {
        boolean var5;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Connection connection = this.connectionRef.get();
            if (connection == null || connection.isClosed()) {
                connection = this.getConnection();
            }
            stmt = connection.prepareStatement("SELECT hide_me FROM player_data WHERE uuid = ?");
            stmt.setString(1, uuid.toString());
            rs = stmt.executeQuery();
            if (!rs.next()) {
                boolean bl = false;
                return bl;
            }
            var5 = rs.getBoolean("hide_me");
        }
        catch (SQLException var16) {
            Logger var10000 = Bukkit.getLogger();
            String var10001 = String.valueOf(uuid);
            var10000.severe("[MoonPillars] Error getting hide_me state for player " + var10001 + ": " + var16.getMessage());
            var16.printStackTrace();
            boolean bl = false;
            return bl;
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var15) {
                Bukkit.getLogger().severe("[MoonPillars] Error closing resources: " + var15.getMessage());
            }
        }
        return var5;
    }

    public void setHideMeState(UUID uuid, boolean state) {
        this.updateSetting(uuid, "hide_me", state);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public boolean getHideOthersState(UUID uuid) {
        boolean var5;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Connection connection = this.connectionRef.get();
            if (connection == null || connection.isClosed()) {
                connection = this.getConnection();
            }
            stmt = connection.prepareStatement("SELECT hide_others FROM player_data WHERE uuid = ?");
            stmt.setString(1, uuid.toString());
            rs = stmt.executeQuery();
            if (!rs.next()) {
                boolean bl = false;
                return bl;
            }
            var5 = rs.getBoolean("hide_others");
        }
        catch (SQLException var16) {
            Logger var10000 = Bukkit.getLogger();
            String var10001 = String.valueOf(uuid);
            var10000.severe("[MoonPillars] Error getting hide_others state for player " + var10001 + ": " + var16.getMessage());
            var16.printStackTrace();
            boolean bl = false;
            return bl;
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var15) {
                Bukkit.getLogger().severe("[MoonPillars] Error closing resources: " + var15.getMessage());
            }
        }
        return var5;
    }

    public void setHideOthersState(UUID uuid, boolean state) {
        this.updateSetting(uuid, "hide_others", state);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public Set<UUID> getShowOthersState(UUID uuid) {
        HashSet<UUID> showOthers = new HashSet<UUID>();
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Connection connection = this.connectionRef.get();
            if (connection == null || connection.isClosed()) {
                connection = this.getConnection();
            }
            stmt = connection.prepareStatement("SELECT target_uuid FROM show_others WHERE player_uuid = ?");
            stmt.setString(1, uuid.toString());
            rs = stmt.executeQuery();
            while (rs.next()) {
                showOthers.add(UUID.fromString(rs.getString("target_uuid")));
            }
        }
        catch (SQLException var14) {
            Logger var10000 = Bukkit.getLogger();
            String var10001 = String.valueOf(uuid);
            var10000.severe("[MoonPillars] Error getting show_others state for player " + var10001 + ": " + var14.getMessage());
            var14.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var13) {
                Bukkit.getLogger().severe("[MoonPillars] Error closing resources: " + var13.getMessage());
            }
        }
        return showOthers;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void addShowOthersState(UUID playerUUID, UUID targetUUID) {
        Statement stmt = null;
        try {
            Connection connection = this.connectionRef.get();
            if (connection == null || connection.isClosed()) {
                connection = this.getConnection();
            }
            stmt = connection.prepareStatement("INSERT OR IGNORE INTO show_others (player_uuid, target_uuid) VALUES (?, ?)");
            stmt.setString(1, playerUUID.toString());
            stmt.setString(2, targetUUID.toString());
            stmt.executeUpdate();
        }
        catch (SQLException var13) {
            Logger var10000 = Bukkit.getLogger();
            String var10001 = String.valueOf(playerUUID);
            var10000.severe("[MoonPillars] Error adding show_others state for player " + var10001 + ": " + var13.getMessage());
            var13.printStackTrace();
        }
        finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var12) {
                Bukkit.getLogger().severe("[MoonPillars] Error closing resources: " + var12.getMessage());
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void removeShowOthersState(UUID playerUUID, UUID targetUUID) {
        Statement stmt = null;
        try {
            Connection connection = this.connectionRef.get();
            if (connection == null || connection.isClosed()) {
                connection = this.getConnection();
            }
            stmt = connection.prepareStatement("DELETE FROM show_others WHERE player_uuid = ? AND target_uuid = ?");
            stmt.setString(1, playerUUID.toString());
            stmt.setString(2, targetUUID.toString());
            stmt.executeUpdate();
        }
        catch (SQLException var13) {
            Logger var10000 = Bukkit.getLogger();
            String var10001 = String.valueOf(playerUUID);
            var10000.severe("[MoonPillars] Error removing show_others state for player " + var10001 + ": " + var13.getMessage());
            var13.printStackTrace();
        }
        finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var12) {
                Bukkit.getLogger().severe("[MoonPillars] Error closing resources: " + var12.getMessage());
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public boolean hasShowOthersState(UUID playerUUID, UUID targetUUID) {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            boolean var6;
            Connection connection = this.connectionRef.get();
            if (connection == null || connection.isClosed()) {
                connection = this.getConnection();
            }
            stmt = connection.prepareStatement("SELECT 1 FROM show_others WHERE player_uuid = ? AND target_uuid = ?");
            stmt.setString(1, playerUUID.toString());
            stmt.setString(2, targetUUID.toString());
            rs = stmt.executeQuery();
            boolean bl = var6 = rs.next();
            return bl;
        }
        catch (SQLException var16) {
            Logger var10000 = Bukkit.getLogger();
            String var10001 = String.valueOf(playerUUID);
            var10000.severe("[MoonPillars] Error checking show_others state for player " + var10001 + ": " + var16.getMessage());
            var16.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var15) {
                Bukkit.getLogger().severe("[MoonPillars] Error closing resources: " + var15.getMessage());
            }
        }
        return false;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public boolean getClientNotificationsDisabled(UUID uuid) {
        boolean var5;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Connection connection = this.connectionRef.get();
            if (connection == null || connection.isClosed()) {
                connection = this.getConnection();
            }
            stmt = connection.prepareStatement("SELECT client_notifs_disabled FROM player_data WHERE uuid = ?");
            stmt.setString(1, uuid.toString());
            rs = stmt.executeQuery();
            if (!rs.next()) {
                boolean bl = false;
                return bl;
            }
            var5 = rs.getBoolean("client_notifs_disabled");
        }
        catch (SQLException var16) {
            Logger var10000 = Bukkit.getLogger();
            String var10001 = String.valueOf(uuid);
            var10000.severe("[MoonPillars] Error getting client_notifs_disabled for player " + var10001 + ": " + var16.getMessage());
            var16.printStackTrace();
            boolean bl = false;
            return bl;
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var15) {
                Bukkit.getLogger().severe("[MoonPillars] Error closing resources: " + var15.getMessage());
            }
        }
        return var5;
    }

    public void setClientNotificationsDisabled(UUID uuid, boolean disabled) {
        this.updateSetting(uuid, "client_notifs_disabled", disabled);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public String getChatChannel(UUID uuid) {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            Connection connection = this.connectionRef.get();
            if (connection == null || connection.isClosed()) {
                connection = this.getConnection();
            }
            stmt = connection.prepareStatement("SELECT chat_channel FROM player_data WHERE uuid = ?");
            stmt.setString(1, uuid.toString());
            rs = stmt.executeQuery();
            if (rs.next()) {
                String var6;
                String channel = rs.getString("chat_channel");
                String string = var6 = channel != null ? channel : "global";
                return string;
            }
        }
        catch (SQLException var17) {
            Logger var10000 = Bukkit.getLogger();
            String var10001 = String.valueOf(uuid);
            var10000.severe("[MoonPillars] Error getting chat_channel for player " + var10001 + ": " + var17.getMessage());
            var17.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var16) {
                Bukkit.getLogger().severe("[MoonPillars] Error closing resources: " + var16.getMessage());
            }
        }
        return "global";
    }

    public void setChatChannel(UUID uuid, String channel) {
        this.updateSetting(uuid, "chat_channel", channel);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public List<LeaderboardEntry> getLeaderboard(String statName, int limit) {
        ArrayList<LeaderboardEntry> leaderboard = new ArrayList<LeaderboardEntry>();
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (this.connectionRef.get() == null || this.connectionRef.get().isClosed()) {
                this.getConnection();
            }
            stmt = this.connectionRef.get().prepareStatement("SELECT name, " + statName + " FROM player_data ORDER BY " + statName + " DESC LIMIT ?");
            stmt.setInt(1, limit);
            rs = stmt.executeQuery();
            while (rs.next()) {
                leaderboard.add(new LeaderboardEntry(rs.getString("name"), rs.getInt(statName)));
            }
        }
        catch (SQLException var15) {
            Bukkit.getLogger().severe("[MoonPillars] Error getting leaderboard for " + statName + ": " + var15.getMessage());
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var14) {
                Bukkit.getLogger().severe("[MoonPillars] Error closing resources: " + var14.getMessage());
            }
        }
        return leaderboard;
    }

    public String getLeaderboardWinsValue(int position) {
        if (position < 1) {
            return null;
        }
        List<LeaderboardEntry> leaderboard = this.getLeaderboard("wins", position);
        return position <= leaderboard.size() ? String.valueOf(leaderboard.get(position - 1).getValue()) : null;
    }

    public String getLeaderboardWinsName(int position) {
        if (position < 1) {
            return null;
        }
        List<LeaderboardEntry> leaderboard = this.getLeaderboard("wins", position);
        return position <= leaderboard.size() ? leaderboard.get(position - 1).getPlayerName() : null;
    }

    public String getLeaderboardWinstreakValue(int position) {
        if (position < 1) {
            return null;
        }
        List<LeaderboardEntry> leaderboard = this.getLeaderboard("winstreak", position);
        return position <= leaderboard.size() ? String.valueOf(leaderboard.get(position - 1).getValue()) : null;
    }

    public String getLeaderboardWinstreakName(int position) {
        if (position < 1) {
            return null;
        }
        List<LeaderboardEntry> leaderboard = this.getLeaderboard("winstreak", position);
        return position <= leaderboard.size() ? leaderboard.get(position - 1).getPlayerName() : null;
    }

    public int getLeaderboardYourPosition(UUID uuid, String statName) {
        return this.getPlayerLeaderboardRank(uuid, statName);
    }

    public boolean isPlayerExcludedFromLeaderboards(UUID uuid) {
        List excludedPlayers = SettingsManager.getInstance().getSettings().getStringList("Leaderboards.ExcludedPlayers");
        String uuidString = uuid.toString();
        return excludedPlayers.contains(uuidString);
    }

    public void setPlayerExcludedFromLeaderboards(UUID uuid, boolean excluded) {
        this.updateSetting(uuid, "ExcludeFromLeaderboards", excluded ? 1 : 0);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private String getPlayerName(UUID uuid) {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (this.connectionRef.get() == null || this.connectionRef.get().isClosed()) {
                this.getConnection();
            }
            stmt = this.connectionRef.get().prepareStatement("SELECT name FROM player_data WHERE uuid = ?");
            stmt.setString(1, uuid.toString());
            rs = stmt.executeQuery();
            if (rs.next()) {
                String var4;
                String string = var4 = rs.getString("name");
                return string;
            }
        }
        catch (SQLException var15) {
            Bukkit.getLogger().severe("[MoonPillars] Failed to get player name: " + var15.getMessage());
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var14) {
                Bukkit.getLogger().severe("[MoonPillars] Error closing resources: " + var14.getMessage());
            }
        }
        return null;
    }

    public boolean getSpyChat(UUID uuid) {
        String result = this.getSetting(uuid, "SpyChat");
        if (result != null) {
            try {
                return Integer.parseInt(result) == 1;
            }
            catch (NumberFormatException var4) {
                return false;
            }
        }
        return false;
    }

    public void setSpyChat(UUID uuid, boolean enabled) {
        this.updateSetting(uuid, "SpyChat", enabled ? 1 : 0);
    }

    public List<UUID> getIgnoredPlayers(UUID uuid) {
        ArrayList<UUID> ignoredList = new ArrayList<UUID>();
        String ignoredString = this.getSetting(uuid, "IgnoredPlayers");
        if (ignoredString != null && !ignoredString.isEmpty()) {
            for (String ignored : ignoredString.split(",")) {
                try {
                    ignoredList.add(UUID.fromString(ignored));
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    // empty catch block
                }
            }
        }
        return ignoredList;
    }

    public void addIgnoredPlayer(UUID playerUuid, UUID ignoredUuid) {
        List<UUID> ignoredPlayers = this.getIgnoredPlayers(playerUuid);
        if (!ignoredPlayers.contains(ignoredUuid)) {
            ignoredPlayers.add(ignoredUuid);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < ignoredPlayers.size(); ++i) {
                sb.append(ignoredPlayers.get(i).toString());
                if (i >= ignoredPlayers.size() - 1) continue;
                sb.append(",");
            }
            this.updateIgnoredPlayersSetting(playerUuid, sb.toString());
        }
    }

    public void removeIgnoredPlayer(UUID playerUuid, UUID ignoredUuid) {
        List<UUID> ignoredPlayers = this.getIgnoredPlayers(playerUuid);
        if (ignoredPlayers.remove(ignoredUuid)) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < ignoredPlayers.size(); ++i) {
                sb.append(ignoredPlayers.get(i).toString());
                if (i >= ignoredPlayers.size() - 1) continue;
                sb.append(",");
            }
            this.updateIgnoredPlayersSetting(playerUuid, sb.toString());
        }
    }

    public boolean isIgnoring(UUID playerUuid, UUID targetUuid) {
        return this.getIgnoredPlayers(playerUuid).contains(targetUuid);
    }

    public String getLeaderboardXPValue(int position) {
        if (position < 1) {
            return null;
        }
        List<LeaderboardEntry> leaderboard = this.getLeaderboard("XP", position);
        return position <= leaderboard.size() ? String.valueOf(leaderboard.get(position - 1).getValue()) : null;
    }

    public String getLeaderboardXPName(int position) {
        if (position < 1) {
            return null;
        }
        List<LeaderboardEntry> leaderboard = this.getLeaderboard("XP", position);
        return position <= leaderboard.size() ? leaderboard.get(position - 1).getPlayerName() : null;
    }

    public String getLeaderboardKillsValue(int position) {
        if (position < 1) {
            return null;
        }
        List<LeaderboardEntry> leaderboard = this.getLeaderboard("Kills", position);
        return position <= leaderboard.size() ? String.valueOf(leaderboard.get(position - 1).getValue()) : null;
    }

    public String getLeaderboardKillsName(int position) {
        if (position < 1) {
            return null;
        }
        List<LeaderboardEntry> leaderboard = this.getLeaderboard("Kills", position);
        return position <= leaderboard.size() ? leaderboard.get(position - 1).getPlayerName() : null;
    }

    public String getLeaderboardLevelValue(int position) {
        if (position < 1) {
            return null;
        }
        List<LeaderboardEntry> leaderboard = this.getLeaderboard("Level", position);
        return position <= leaderboard.size() ? String.valueOf(leaderboard.get(position - 1).getValue()) : null;
    }

    public String getLeaderboardLevelName(int position) {
        if (position < 1) {
            return null;
        }
        List<LeaderboardEntry> leaderboard = this.getLeaderboard("Level", position);
        return position <= leaderboard.size() ? leaderboard.get(position - 1).getPlayerName() : null;
    }

    @EventHandler
    public void onPluginDisable(PluginDisableEvent event) {
        if (event.getPlugin().getName().equals("MoonLab")) {
            this.createDatabaseBackup();
            this.scheduler.shutdown();
            try {
                this.scheduler.awaitTermination(5L, TimeUnit.SECONDS);
            }
            catch (InterruptedException var3) {
                Thread.currentThread().interrupt();
            }
            this.closeConnection();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public int getPlayerLeaderboardRank(UUID uuid, String statName) {
        if (this.isPlayerExcludedFromLeaderboards(uuid)) {
            return 0;
        }
        Statement stmt = null;
        ResultSet rs = null;
        try {
            if (this.connectionRef.get() == null || this.connectionRef.get().isClosed()) {
                this.getConnection();
            }
            stmt = this.connectionRef.get().prepareStatement("SELECT uuid, name, " + statName + " FROM player_data ORDER BY " + statName + " DESC");
            rs = stmt.executeQuery();
            List excludedPlayers = MoonLab.getInstance().getConfig().getStringList("Leaderboards.ExcludedPlayers");
            String playerUuidStr = uuid.toString();
            int position = 1;
            while (rs.next()) {
                String currentUuidStr = rs.getString("uuid");
                String currentName = rs.getString("name");
                boolean excluded = false;
                for (String excludedName : excludedPlayers) {
                    if (!currentName.equalsIgnoreCase(excludedName)) continue;
                    excluded = true;
                    break;
                }
                if (excluded) continue;
                if (currentUuidStr.equals(playerUuidStr)) {
                    int var24;
                    int n = var24 = position;
                    return n;
                }
                ++position;
            }
        }
        catch (SQLException var22) {
            Bukkit.getLogger().severe("[MoonPillars] Error getting player rank for " + statName + ": " + var22.getMessage());
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
            }
            catch (SQLException var21) {
                Bukkit.getLogger().severe("[MoonPillars] Error closing resources: " + var21.getMessage());
            }
        }
        return 0;
    }

    private static class LeaderboardEntry {
        private final String playerName;
        private final int value;

        public LeaderboardEntry(String playerName, int value) {
            this.playerName = playerName;
            this.value = value;
        }

        public String getPlayerName() {
            return this.playerName;
        }

        public int getValue() {
            return this.value;
        }
    }
}

