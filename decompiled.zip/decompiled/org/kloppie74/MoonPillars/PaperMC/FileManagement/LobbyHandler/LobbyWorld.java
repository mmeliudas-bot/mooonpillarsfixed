/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.LobbyHandler;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class LobbyWorld {
    public static final String lobbyWorldName;
    private static Location lobbySpawn;

    public static Location getLobbySpawn() {
        World world;
        if (lobbySpawn == null && (world = Bukkit.getWorld((String)lobbyWorldName)) != null) {
            double x = SettingsManager.getInstance().getSettings().getDouble("LobbySettings.Spawn.X", 0.0);
            double y = SettingsManager.getInstance().getSettings().getDouble("LobbySettings.Spawn.Y", 100.0);
            double z = SettingsManager.getInstance().getSettings().getDouble("LobbySettings.Spawn.Z", 0.0);
            lobbySpawn = new Location(world, x, y, z);
        }
        return lobbySpawn;
    }

    public static void teleportToLobby(Player player) {
        Location spawn = LobbyWorld.getLobbySpawn();
        if (spawn != null) {
            player.teleport(spawn);
        }
    }

    public static boolean isLobbyWorld(String worldName) {
        return lobbyWorldName.equals(worldName);
    }

    static {
        String configWorldName;
        lobbyWorldName = configWorldName = SettingsManager.getInstance().getSettings().getString("LobbySettings.World", "world");
        double x = SettingsManager.getInstance().getSettings().getDouble("LobbySettings.Spawn.X", 0.0);
        double y = SettingsManager.getInstance().getSettings().getDouble("LobbySettings.Spawn.Y", 100.0);
        double z = SettingsManager.getInstance().getSettings().getDouble("LobbySettings.Spawn.Z", 0.0);
        World world = Bukkit.getWorld((String)lobbyWorldName);
        if (world != null) {
            lobbySpawn = new Location(world, x, y, z);
        }
    }
}

