/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.Material
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Projectile
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockBurnEvent
 *  org.bukkit.event.block.BlockFadeEvent
 *  org.bukkit.event.block.BlockGrowEvent
 *  org.bukkit.event.block.BlockIgniteEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.event.block.BlockSpreadEvent
 *  org.bukkit.event.block.EntityBlockFormEvent
 *  org.bukkit.event.block.LeavesDecayEvent
 *  org.bukkit.event.block.SignChangeEvent
 *  org.bukkit.event.entity.CreatureSpawnEvent
 *  org.bukkit.event.entity.CreatureSpawnEvent$SpawnReason
 *  org.bukkit.event.entity.EntityChangeBlockEvent
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 *  org.bukkit.event.entity.EntityPickupItemEvent
 *  org.bukkit.event.entity.ExplosionPrimeEvent
 *  org.bukkit.event.entity.FoodLevelChangeEvent
 *  org.bukkit.event.hanging.HangingBreakByEntityEvent
 *  org.bukkit.event.hanging.HangingPlaceEvent
 *  org.bukkit.event.player.PlayerBucketEmptyEvent
 *  org.bukkit.event.player.PlayerBucketFillEvent
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerTeleportEvent
 *  org.bukkit.event.player.PlayerTeleportEvent$TeleportCause
 *  org.bukkit.event.vehicle.VehicleDamageEvent
 *  org.bukkit.event.weather.WeatherChangeEvent
 *  org.bukkit.projectiles.ProjectileSource
 */
package org.kloppie74.MoonPillars.PaperMC.FileManagement.LobbyHandler;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockFadeEvent;
import org.bukkit.event.block.BlockGrowEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.block.EntityBlockFormEvent;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.ExplosionPrimeEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.vehicle.VehicleDamageEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.projectiles.ProjectileSource;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.LobbyHandler.LobbyWorld;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class LobbyProtectionListener
implements Listener {
    private boolean canBypass(Player player) {
        return player.getGameMode() == GameMode.CREATIVE && player.hasPermission("mpa.world.manage");
    }

    private boolean isInLobby(Player player) {
        return player.getWorld().getName().equals(LobbyWorld.lobbyWorldName);
    }

    private boolean isInLobby(Entity entity) {
        return entity.getWorld().getName().equals(LobbyWorld.lobbyWorldName);
    }

    private boolean isEventEnabled(String eventName) {
        return SettingsManager.getInstance().getSettings().getBoolean("LobbySettings.Events." + eventName, true);
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onSignChange(SignChangeEvent event) {
        Player player;
        if (this.isEventEnabled("onSignChange") && this.isInLobby(player = event.getPlayer()) && !this.canBypass(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player;
        if (this.isEventEnabled("onBlockBreak") && this.isInLobby(player = event.getPlayer()) && !this.canBypass(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player;
        if (this.isEventEnabled("onBlockPlace") && this.isInLobby(player = event.getPlayer()) && !this.canBypass(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        Player player;
        if (this.isEventEnabled("onPlayerDropItem") && this.isInLobby(player = event.getPlayer()) && !this.canBypass(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPlayerPickupItem(EntityPickupItemEvent event) {
        Player player;
        LivingEntity var3;
        if (this.isEventEnabled("onPlayerPickupItem") && (var3 = event.getEntity()) instanceof Player && this.isInLobby(player = (Player)var3) && !this.canBypass(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onBucketEmpty(PlayerBucketEmptyEvent event) {
        Player player;
        if (this.isEventEnabled("onBucketEmpty") && this.isInLobby(player = event.getPlayer()) && !this.canBypass(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onBucketFill(PlayerBucketFillEvent event) {
        Player player;
        if (this.isEventEnabled("onBucketFill") && this.isInLobby(player = event.getPlayer()) && !this.canBypass(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onEntityDamage(EntityDamageEvent event) {
        if (this.isEventEnabled("onEntityDamage") && this.isInLobby(event.getEntity())) {
            Entity var3 = event.getEntity();
            if (var3 instanceof Player) {
                Player player = (Player)var3;
                if (event.getCause() == EntityDamageEvent.DamageCause.VOID) {
                    return;
                }
                if (this.canBypass(player)) {
                    return;
                }
            }
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (this.isEventEnabled("onEntityDamageByEntity")) {
            Entity damager = event.getDamager();
            if (this.isInLobby(event.getEntity())) {
                Player player;
                Projectile projectile;
                ProjectileSource var6;
                Player player2;
                if (damager instanceof Player ? this.canBypass(player2 = (Player)damager) : damager instanceof Projectile && (var6 = (projectile = (Projectile)damager).getShooter()) instanceof Player && this.canBypass(player = (Player)var6)) {
                    return;
                }
                event.setCancelled(true);
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onFoodLevelChange(FoodLevelChangeEvent event) {
        Player player;
        HumanEntity var3;
        if (this.isEventEnabled("onFoodLevelChange") && (var3 = event.getEntity()) instanceof Player && this.isInLobby(player = (Player)var3)) {
            event.setCancelled(true);
            player.setFoodLevel(20);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onBlockBurn(BlockBurnEvent event) {
        if (this.isEventEnabled("onBlockBurn") && event.getBlock().getWorld().getName().equals(LobbyWorld.lobbyWorldName)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onBlockFade(BlockFadeEvent event) {
        if (this.isEventEnabled("onBlockFade") && event.getBlock().getWorld().getName().equals(LobbyWorld.lobbyWorldName)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onBlockGrow(BlockGrowEvent event) {
        if (this.isEventEnabled("onBlockGrow") && event.getBlock().getWorld().getName().equals(LobbyWorld.lobbyWorldName)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onBlockSpread(BlockSpreadEvent event) {
        if (this.isEventEnabled("onBlockSpread") && event.getBlock().getWorld().getName().equals(LobbyWorld.lobbyWorldName)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onEntityBlockForm(EntityBlockFormEvent event) {
        if (this.isEventEnabled("onEntityBlockForm") && event.getBlock().getWorld().getName().equals(LobbyWorld.lobbyWorldName)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onLeafDecay(LeavesDecayEvent event) {
        if (this.isEventEnabled("onLeafDecay") && event.getBlock().getWorld().getName().equals(LobbyWorld.lobbyWorldName)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onEntityChangeBlock(EntityChangeBlockEvent event) {
        if (this.isEventEnabled("onEntityChangeBlock") && this.isInLobby(event.getEntity())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onHangingBreakByEntity(HangingBreakByEntityEvent event) {
        Player player;
        Entity var3;
        if (this.isEventEnabled("onHangingBreakByEntity") && (var3 = event.getRemover()) instanceof Player && this.isInLobby(player = (Player)var3) && !this.canBypass(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onHangingPlace(HangingPlaceEvent event) {
        Player player;
        if (this.isEventEnabled("onHangingPlace") && (player = event.getPlayer()) != null && this.isInLobby(player) && !this.canBypass(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onVehicleDamage(VehicleDamageEvent event) {
        Player player;
        Entity var3;
        if (this.isEventEnabled("onVehicleDamage") && (var3 = event.getAttacker()) instanceof Player && this.isInLobby(player = (Player)var3) && !this.canBypass(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onWeatherChange(WeatherChangeEvent event) {
        if (this.isEventEnabled("onWeatherChange") && event.getWorld().getName().equals(LobbyWorld.lobbyWorldName) && event.toWeatherState()) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        if (this.isEventEnabled("onPlayerTeleport")) {
            Player player = event.getPlayer();
            if (event.getCause() == PlayerTeleportEvent.TeleportCause.ENDER_PEARL && this.isInLobby(player) && !this.canBypass(player)) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onExplosionPrime(ExplosionPrimeEvent event) {
        if (this.isEventEnabled("onExplosionPrime") && this.isInLobby(event.getEntity())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onBlockIgnite(BlockIgniteEvent event) {
        if (this.isEventEnabled("onBlockIgnite") && event.getBlock().getWorld().getName().equals(LobbyWorld.lobbyWorldName)) {
            if (event.getPlayer() != null && this.canBypass(event.getPlayer())) {
                return;
            }
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onCreatureSpawn(CreatureSpawnEvent event) {
        if (this.isEventEnabled("onCreatureSpawn") && event.getEntity().getWorld().getName().equals(LobbyWorld.lobbyWorldName) && event.getSpawnReason() != CreatureSpawnEvent.SpawnReason.CUSTOM && event.getSpawnReason() != CreatureSpawnEvent.SpawnReason.COMMAND) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onDoorInteract(PlayerInteractEvent event) {
        Material material;
        Player player;
        if (this.isEventEnabled("onDoorInteract") && this.isInLobby(player = event.getPlayer()) && !this.canBypass(player) && event.hasBlock() && event.getAction() == Action.RIGHT_CLICK_BLOCK && ((material = event.getClickedBlock().getType()).name().contains("DOOR") || material.name().contains("TRAPDOOR") || material.name().contains("GATE"))) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onFurnitureInteract(PlayerInteractEvent event) {
        Material material;
        Player player;
        if (this.isEventEnabled("onFurnitureInteract") && this.isInLobby(player = event.getPlayer()) && !this.canBypass(player) && event.hasBlock() && event.getAction() == Action.RIGHT_CLICK_BLOCK && ((material = event.getClickedBlock().getType()).name().contains("CHEST") || material.name().contains("HOPPER") || material.name().contains("SHULKER") || material.name().contains("BARREL") || material == Material.FURNACE || material == Material.BLAST_FURNACE || material == Material.SMOKER || material == Material.BREWING_STAND || material == Material.DISPENSER || material == Material.DROPPER)) {
            event.setCancelled(true);
        }
    }
}

