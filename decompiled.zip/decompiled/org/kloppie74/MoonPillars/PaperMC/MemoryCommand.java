/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.World
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.jetbrains.annotations.NotNull
 */
package org.kloppie74.MoonPillars.PaperMC;

import com.sun.management.OperatingSystemMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class MemoryCommand
implements CommandExecutor,
TabCompleter {
    private long lastCpuTime = 0L;
    private long lastSystemTime = 0L;
    private double cpuUsage = 0.0;
    private static int joinsSinceRestart = 0;

    public MemoryCommand() {
        this.updateCpuUsage();
        new BukkitRunnable(){

            public void run() {
                MemoryCommand.this.updateCpuUsage();
            }
        }.runTaskTimerAsynchronously((Plugin)MoonLab.getInstance(), 20L, 20L);
    }

    private void updateCpuUsage() {
        java.lang.management.OperatingSystemMXBean osBean = ManagementFactory.getOperatingSystemMXBean();
        if (osBean instanceof OperatingSystemMXBean) {
            OperatingSystemMXBean sunOsBean = (OperatingSystemMXBean)osBean;
            long currentCpuTime = sunOsBean.getProcessCpuTime();
            long currentSystemTime = System.nanoTime();
            if (this.lastSystemTime > 0L && this.lastCpuTime > 0L) {
                long cpuTimeDiff = currentCpuTime - this.lastCpuTime;
                long systemTimeDiff = currentSystemTime - this.lastSystemTime;
                this.cpuUsage = (double)cpuTimeDiff / (double)systemTimeDiff / (double)osBean.getAvailableProcessors() * 100.0;
            }
            this.lastCpuTime = currentCpuTime;
            this.lastSystemTime = currentSystemTime;
        } else {
            this.cpuUsage = -1.0;
        }
    }

    public boolean onCommand(CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
        if (!sender.hasPermission("mpa.memory.info")) {
            sender.sendMessage(MSG.chatColors("&cYou don't have permission to use this command."));
        } else {
            String threadName;
            int i;
            MemoryMXBean memoryBean = ManagementFactory.getMemoryMXBean();
            MemoryUsage heapUsage = memoryBean.getHeapMemoryUsage();
            MemoryUsage nonHeapUsage = memoryBean.getNonHeapMemoryUsage();
            ThreadMXBean threadBean = ManagementFactory.getThreadMXBean();
            int threadCount = threadBean.getThreadCount();
            int daemonThreadCount = threadBean.getDaemonThreadCount();
            int peakThreadCount = threadBean.getPeakThreadCount();
            long totalStartedThreadCount = threadBean.getTotalStartedThreadCount();
            long heapUsedMB = heapUsage.getUsed() / 0x100000L;
            long heapMaxMB = heapUsage.getMax() / 0x100000L;
            long nonHeapUsedMB = nonHeapUsage.getUsed() / 0x100000L;
            int usagePercent = (int)(heapUsage.getUsed() * 100L / heapUsage.getMax());
            StringBuilder memoryBar = new StringBuilder("&8[");
            int barLength = 20;
            int filledBars = Math.max(1, usagePercent * barLength / 100);
            String barColor = "&a";
            if (usagePercent >= 70 && usagePercent < 85) {
                barColor = "&e";
            } else if (usagePercent >= 85) {
                barColor = "&c";
            }
            memoryBar.append(barColor);
            for (i = 0; i < filledBars; ++i) {
                memoryBar.append("\u2588");
            }
            memoryBar.append("&8");
            for (i = filledBars; i < barLength; ++i) {
                memoryBar.append("\u2588");
            }
            memoryBar.append("&8]");
            Map<String, Long> threadMemory = this.getThreadMemoryUsage();
            List topThreads = threadMemory.entrySet().stream().sorted((e1, e2) -> ((Long)e2.getValue()).compareTo((Long)e1.getValue())).limit(5L).toList();
            List<WorldData> worldDataList = this.getWorldData();
            sender.sendMessage(MSG.chatColors("&8&m-------------------------------------"));
            sender.sendMessage(MSG.chatColors("&f&lServer Performance Information"));
            sender.sendMessage(MSG.chatColors("&8&m-------------------------------------"));
            sender.sendMessage(MSG.chatColors("&7&lMemory Usage:"));
            String var10001 = memoryBar.toString();
            sender.sendMessage(MSG.chatColors("  " + var10001 + " &7(" + usagePercent + "%)"));
            sender.sendMessage(MSG.chatColors("  &8\u2022 &7Heap: &f" + heapUsedMB + " MB &7/ &f" + heapMaxMB + " MB"));
            sender.sendMessage(MSG.chatColors("  &8\u2022 &7Non-Heap: &f" + nonHeapUsedMB + " MB"));
            sender.sendMessage(MSG.chatColors("&7&lCPU Information:"));
            if (this.cpuUsage >= 0.0) {
                int iii;
                StringBuilder cpuBar = new StringBuilder("&8[");
                int ii = (int)Math.min(100.0, this.cpuUsage);
                int cpuFilledBars = Math.max(1, ii * barLength / 100);
                threadName = "&a";
                if (ii >= 50 && ii < 80) {
                    threadName = "&e";
                } else if (ii >= 80) {
                    threadName = "&c";
                }
                cpuBar.append(threadName);
                for (iii = 0; iii < cpuFilledBars; ++iii) {
                    cpuBar.append("\u2588");
                }
                cpuBar.append("&8");
                for (iii = cpuFilledBars; iii < barLength; ++iii) {
                    cpuBar.append("\u2588");
                }
                cpuBar.append("&8]");
                var10001 = cpuBar.toString();
                sender.sendMessage(MSG.chatColors("  " + var10001 + " &7(" + String.format("%.2f", this.cpuUsage) + "%)"));
            } else {
                sender.sendMessage(MSG.chatColors("  &8\u2022 &7CPU usage monitoring not available"));
            }
            sender.sendMessage(MSG.chatColors("  &8\u2022 &7Available Processors: &f" + ManagementFactory.getOperatingSystemMXBean().getAvailableProcessors()));
            sender.sendMessage(MSG.chatColors("  &8\u2022 &7System Load Average: &f" + String.format("%.2f", ManagementFactory.getOperatingSystemMXBean().getSystemLoadAverage())));
            sender.sendMessage(MSG.chatColors("&7&lThread Information:"));
            sender.sendMessage(MSG.chatColors("  &8\u2022 &7Active Threads: &f" + threadCount + " &7(&f" + daemonThreadCount + " &7daemon)"));
            sender.sendMessage(MSG.chatColors("  &8\u2022 &7Peak Thread Count: &f" + peakThreadCount));
            sender.sendMessage(MSG.chatColors("  &8\u2022 &7Total Started Threads: &f" + totalStartedThreadCount));
            sender.sendMessage(MSG.chatColors("&7&lWorld Information:"));
            sender.sendMessage(MSG.chatColors("  &8\u2022 &7Total Loaded Worlds: &f" + worldDataList.size()));
            sender.sendMessage(MSG.chatColors("&7&lTop 5 Worlds by Memory Usage:"));
            worldDataList.sort((w1, w2) -> Double.compare((double)w2.getEntities() * 0.7 + (double)w2.getChunks() * 0.3, (double)w1.getEntities() * 0.7 + (double)w1.getChunks() * 0.3));
            int worldCount = Math.min(5, worldDataList.size());
            for (i = 0; i < worldCount; ++i) {
                WorldData world = worldDataList.get(i);
                sender.sendMessage(MSG.chatColors("  &8\u2022 &f" + (i + 1) + ". &7" + world.getName() + ": &f" + world.getEntities() + " &7entities, &f" + world.getChunks() + " &7chunks"));
            }
            sender.sendMessage(MSG.chatColors("&7&lTop 5 Memory Consumers:"));
            if (topThreads.isEmpty()) {
                sender.sendMessage(MSG.chatColors("  &8\u2022 &7Unable to gather memory usage by thread"));
            } else {
                for (i = 0; i < topThreads.size(); ++i) {
                    Map.Entry entry = (Map.Entry)topThreads.get(i);
                    threadName = (String)entry.getKey();
                    long memoryUsageMB = (Long)entry.getValue() / 0x100000L;
                    sender.sendMessage(MSG.chatColors("  &8\u2022 &f" + (i + 1) + ". &7" + threadName + ": &f" + memoryUsageMB + " MB"));
                }
            }
            long uptime = ManagementFactory.getRuntimeMXBean().getUptime();
            long uptimeHours = uptime / 3600000L;
            long uptimeMinutes = uptime / 60000L % 60L;
            long uptimeDays = TimeUnit.MILLISECONDS.toDays(uptime);
            uptimeHours %= 24L;
            StringBuilder uptimeStr = new StringBuilder();
            if (uptimeDays > 0L) {
                uptimeStr.append(uptimeDays).append("d ");
            }
            uptimeStr.append(uptimeHours).append("h ").append(uptimeMinutes).append("m");
            sender.sendMessage(MSG.chatColors("&7&lRuntime Information:"));
            sender.sendMessage(MSG.chatColors("  &8\u2022 &7Server Uptime: &f" + String.valueOf(uptimeStr)));
            sender.sendMessage(MSG.chatColors("  &8\u2022 &7Java Version: &f" + System.getProperty("java.version")));
            var10001 = System.getProperty("os.name");
            sender.sendMessage(MSG.chatColors("  &8\u2022 &7OS: &f" + var10001 + " " + System.getProperty("os.arch")));
            int onlinePlayers = Bukkit.getOnlinePlayers().size();
            int joinsAfterRestart = MemoryCommand.getJoinsSinceRestart();
            sender.sendMessage(MSG.chatColors("&7&lPlayer Statistics:"));
            sender.sendMessage(MSG.chatColors("  &8\u2022 &7Online Players: &f" + onlinePlayers));
            sender.sendMessage(MSG.chatColors("  &8\u2022 &7Joins Since Restart: &f" + joinsAfterRestart));
            sender.sendMessage(MSG.chatColors("&8&m-------------------------------------"));
        }
        return true;
    }

    public static void incrementJoins() {
        ++joinsSinceRestart;
    }

    public static int getJoinsSinceRestart() {
        return joinsSinceRestart;
    }

    private List<WorldData> getWorldData() {
        ArrayList<WorldData> result = new ArrayList<WorldData>();
        for (World world : Bukkit.getWorlds()) {
            String worldName = world.getName();
            int entityCount = world.getEntities().size();
            int chunkCount = world.getLoadedChunks().length;
            result.add(new WorldData(worldName, entityCount, chunkCount));
        }
        return result;
    }

    private Map<String, Long> getThreadMemoryUsage() {
        HashMap<String, Long> result = new HashMap<String, Long>();
        try {
            ThreadMXBean threadBean = ManagementFactory.getThreadMXBean();
            long[] threadIds = threadBean.getAllThreadIds();
            HashMap<String, Integer> classOccurrences = new HashMap<String, Integer>();
            for (long threadId : threadIds) {
                StackTraceElement[] stack;
                ThreadInfo threadInfo = threadBean.getThreadInfo(threadId, 20);
                if (threadInfo == null) continue;
                for (StackTraceElement element : stack = threadInfo.getStackTrace()) {
                    String className = element.getClassName();
                    if (className.isEmpty()) continue;
                    Object displayName = className;
                    if (className.startsWith("org.kloppie74.MoonPillars")) {
                        displayName = "MoonPillars: " + className;
                    }
                    classOccurrences.merge((String)displayName, 1, Integer::sum);
                }
            }
            MemoryMXBean memBean = ManagementFactory.getMemoryMXBean();
            long totalUsedMemory = memBean.getHeapMemoryUsage().getUsed();
            int totalOccurrences = classOccurrences.values().stream().mapToInt(Integer::intValue).sum();
            if (totalOccurrences > 0) {
                for (Map.Entry stringIntegerEntry : classOccurrences.entrySet()) {
                    long estimatedMemory = (long)((double)((Integer)stringIntegerEntry.getValue()).intValue() / (double)totalOccurrences * (double)totalUsedMemory);
                    result.put((String)stringIntegerEntry.getKey(), estimatedMemory);
                }
            }
        }
        catch (Exception var18) {
            MoonLab.getInstance().getLogger().warning("Failed to gather thread memory usage: " + var18.getMessage());
        }
        return result;
    }

    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, String[] args) {
        return new ArrayList<String>();
    }

    private static class WorldData {
        private final String name;
        private final int entities;
        private final int chunks;

        public WorldData(String name, int entities, int chunks) {
            this.name = name;
            this.entities = entities;
            this.chunks = chunks;
        }

        public String getName() {
            return this.name;
        }

        public int getEntities() {
            return this.entities;
        }

        public int getChunks() {
            return this.chunks;
        }
    }
}

