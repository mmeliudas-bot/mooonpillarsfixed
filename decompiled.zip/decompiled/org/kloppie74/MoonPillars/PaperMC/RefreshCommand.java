/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 */
package org.kloppie74.MoonPillars.PaperMC;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class RefreshCommand
implements CommandExecutor,
TabCompleter {
    private final MoonLab plugin;

    public RefreshCommand(MoonLab plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("moonpillars.admin.refresh")) {
            sender.sendMessage(MSG.chatColors("&cYou don't have permission to use this command."));
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(MSG.chatColors("&cUsage: /refresh <component>"));
            sender.sendMessage(MSG.chatColors("&cAvailable components: vanishcommands, corecommands, gamecommands, admincommands, chatcommands, cosmeticcommands, eastereggscommands, settings, corelisteners, adminlisteners, gamelisteners, cosmeticlisteners, vanishlisteners, luckyblocklisteners, all"));
            return true;
        }
        String component = args[0].toLowerCase();
        try {
            boolean success = this.refreshComponent(component);
            if (success) {
                sender.sendMessage(MSG.chatColors("&aSuccessfully refreshed component: &e" + component));
            } else {
                sender.sendMessage(MSG.chatColors("&cFailed to refresh component: &e" + component));
            }
        }
        catch (Exception var7) {
            sender.sendMessage(MSG.chatColors("&cError refreshing component: &e" + var7.getMessage()));
            var7.printStackTrace();
        }
        return true;
    }

    private boolean refreshComponent(String component) throws Exception {
        int var3 = -1;
        switch (component.hashCode()) {
            case -1979232553: {
                if (!component.equals("admincommands")) break;
                var3 = 3;
                break;
            }
            case -1398363353: {
                if (!component.equals("corecommands")) break;
                var3 = 1;
                break;
            }
            case -1327252989: {
                if (!component.equals("vanishcommands")) break;
                var3 = 0;
                break;
            }
            case -946661424: {
                if (!component.equals("adminlisteners")) break;
                var3 = 8;
                break;
            }
            case -511949702: {
                if (!component.equals("gamecommands")) break;
                var3 = 2;
                break;
            }
            case -119585408: {
                if (!component.equals("corelisteners")) break;
                var3 = 7;
                break;
            }
            case 96673: {
                if (!component.equals("all")) break;
                var3 = 14;
                break;
            }
            case 294110688: {
                if (!component.equals("chatcommands")) break;
                var3 = 4;
                break;
            }
            case 458936919: {
                if (!component.equals("cosmeticcommands")) break;
                var3 = 5;
                break;
            }
            case 775040000: {
                if (!component.equals("eastereggscommands")) break;
                var3 = 6;
                break;
            }
            case 1434631203: {
                if (!component.equals("settings")) break;
                var3 = 13;
                break;
            }
            case 1589433997: {
                if (!component.equals("gamelisteners")) break;
                var3 = 9;
                break;
            }
            case 1604272442: {
                if (!component.equals("luckyblocklisteners")) break;
                var3 = 12;
                break;
            }
            case 1622148176: {
                if (!component.equals("cosmeticlisteners")) break;
                var3 = 10;
                break;
            }
            case 2084835876: {
                if (!component.equals("vanishlisteners")) break;
                var3 = 11;
            }
        }
        switch (var3) {
            case 0: {
                this.invokeMethod("registerVanishCommands");
                return true;
            }
            case 1: {
                this.invokeMethod("registerCoreCommands");
                return true;
            }
            case 2: {
                this.invokeMethod("registerGameCommands");
                return true;
            }
            case 3: {
                this.invokeMethod("registerAdminCommands");
                return true;
            }
            case 4: {
                this.invokeMethod("registerChatCommands");
                return true;
            }
            case 5: {
                this.invokeMethod("registerCosmeticCommands");
                return true;
            }
            case 6: {
                this.invokeMethod("registerEasterEggCommands");
                return true;
            }
            case 7: {
                this.invokeMethod("registerCoreListeners");
                return true;
            }
            case 8: {
                this.invokeMethod("registerAdminListeners");
                return true;
            }
            case 9: {
                this.invokeMethod("registerGameListeners");
                return true;
            }
            case 10: {
                this.invokeMethod("registerCosmeticListeners");
                return true;
            }
            case 11: {
                this.invokeMethod("registerVanishListeners");
                return true;
            }
            case 12: {
                this.invokeMethod("registerLuckyBlockListeners");
                return true;
            }
            case 13: {
                this.plugin.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Reloading settings...");
                MoonLab.CheckUpdateSettings();
                return true;
            }
            case 14: {
                this.plugin.getLogger().info("\u00a7e[MoonPillars] \u00a7f- Refreshing all components...");
                this.invokeMethod("registerVanishCommands");
                this.invokeMethod("registerCoreCommands");
                this.invokeMethod("registerGameCommands");
                this.invokeMethod("registerAdminCommands");
                this.invokeMethod("registerChatCommands");
                this.invokeMethod("registerCosmeticCommands");
                this.invokeMethod("registerEasterEggCommands");
                this.invokeMethod("registerCoreListeners");
                this.invokeMethod("registerAdminListeners");
                this.invokeMethod("registerGameListeners");
                this.invokeMethod("registerCosmeticListeners");
                this.invokeMethod("registerVanishListeners");
                this.invokeMethod("registerLuckyBlockListeners");
                MoonLab.CheckUpdateSettings();
                return true;
            }
        }
        return false;
    }

    private void invokeMethod(String methodName) throws Exception {
        Method method = ((Object)((Object)this.plugin)).getClass().getDeclaredMethod(methodName, new Class[0]);
        method.setAccessible(true);
        method.invoke((Object)this.plugin, new Object[0]);
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("moonpillars.admin.refresh")) {
            return new ArrayList<String>();
        }
        if (args.length == 1) {
            List<String> components = Arrays.asList("vanishcommands", "corecommands", "gamecommands", "admincommands", "chatcommands", "cosmeticcommands", "eastereggscommands", "settings", "corelisteners", "adminlisteners", "gamelisteners", "cosmeticlisteners", "vanishlisteners", "luckyblocklisteners", "all");
            return components.stream().filter(comp -> comp.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        return new ArrayList<String>();
    }
}

