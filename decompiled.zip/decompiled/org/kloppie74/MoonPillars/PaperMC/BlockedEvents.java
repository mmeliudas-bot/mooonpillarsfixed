/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.destroystokyo.paper.profile.PlayerProfile
 *  com.destroystokyo.paper.profile.ProfileProperty
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Particle
 *  org.bukkit.Sound
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Chicken
 *  org.bukkit.entity.Damageable
 *  org.bukkit.entity.Egg
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Projectile
 *  org.bukkit.entity.SmallFireball
 *  org.bukkit.entity.Snowball
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.HandlerList
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.block.BlockIgniteEvent
 *  org.bukkit.event.entity.EntityExplodeEvent
 *  org.bukkit.event.entity.ProjectileHitEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.projectiles.ProjectileSource
 *  org.bukkit.scheduler.BukkitScheduler
 *  org.bukkit.scheduler.BukkitTask
 *  org.bukkit.util.Vector
 */
package org.kloppie74.MoonPillars.PaperMC;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Chicken;
import org.bukkit.entity.Damageable;
import org.bukkit.entity.Egg;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.SmallFireball;
import org.bukkit.entity.Snowball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class BlockedEvents
implements Listener {
    @EventHandler
    public void onSnowballHit(ProjectileHitEvent event) {
        if (SettingsManager.getInstance().getSettings().getBoolean("Settings.EnableDamageSnowballs", true) && event.getEntity() instanceof Snowball && event.getHitEntity() instanceof Player) {
            Player hitPlayer = (Player)event.getHitEntity();
            double damage = SettingsManager.getInstance().getSettings().getDouble("Settings.SnowballDamage", 2.0);
            hitPlayer.damage(damage);
            hitPlayer.getWorld().playSound(hitPlayer.getLocation(), Sound.ENTITY_PLAYER_HURT, 1.0f, 1.0f);
            hitPlayer.getWorld().spawnParticle(Particle.SNOWBALL, hitPlayer.getLocation().add(0.0, 1.0, 0.0), 10);
            if (event.getEntity().getShooter() instanceof Player) {
                Player shooter = (Player)event.getEntity().getShooter();
                shooter.playSound(shooter.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.0f);
            }
        }
    }

    @EventHandler
    public void onPlayerInteractWithFireCharge(PlayerInteractEvent event) {
        if (SettingsManager.getInstance().getSettings().getBoolean("Settings.EnableFireChargeProjectiles", true)) {
            final Player player = event.getPlayer();
            if ((event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) && event.getItem() != null && event.getItem().getType() == Material.FIRE_CHARGE) {
                event.setCancelled(true);
                if (player.getGameMode() != GameMode.CREATIVE) {
                    ItemStack fireCharge = event.getItem();
                    if (fireCharge.getAmount() > 1) {
                        fireCharge.setAmount(fireCharge.getAmount() - 1);
                    } else {
                        player.getInventory().setItemInMainHand((ItemStack)null);
                    }
                }
                final SmallFireball fireball = (SmallFireball)player.launchProjectile(SmallFireball.class);
                fireball.setShooter((ProjectileSource)player);
                float yield = (float)SettingsManager.getInstance().getSettings().getDouble("Settings.FireChargeYield", 1.0);
                boolean isIncendiary = SettingsManager.getInstance().getSettings().getBoolean("Settings.FireChargeIncendiary", false);
                fireball.setYield(yield);
                fireball.setIsIncendiary(isIncendiary);
                double velocityMultiplier = SettingsManager.getInstance().getSettings().getDouble("Settings.FireChargeVelocity", 1.5);
                fireball.setVelocity(player.getEyeLocation().getDirection().multiply(velocityMultiplier));
                player.getWorld().playSound(player.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1.0f, 1.0f);
                Bukkit.getPluginManager().registerEvents(new Listener(){

                    @EventHandler
                    public void onFireballHit(ProjectileHitEvent e) {
                        if (e.getEntity() == fireball) {
                            Location loc = fireball.getLocation();
                            fireball.remove();
                            loc.getWorld().createExplosion(loc, 0.0f, false, false, (Entity)player);
                            loc.getWorld().spawnParticle(Particle.EXPLOSION_HUGE, loc, 1);
                            loc.getWorld().spawnParticle(Particle.FLAME, loc, 20, 0.5, 0.5, 0.5, 0.1);
                            loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.0f);
                            double maxDamage = SettingsManager.getInstance().getSettings().getDouble("Settings.FireChargeMaxDamage", 6.0);
                            double radius = SettingsManager.getInstance().getSettings().getDouble("Settings.FireChargeRadius", 2.0);
                            loc.getWorld().getNearbyEntities(loc, radius, radius, radius).forEach(entity -> {
                                double distance;
                                double damage;
                                if (entity != player && entity instanceof Damageable && (damage = maxDamage * (1.0 - (distance = entity.getLocation().distance(loc)) / radius)) > 0.0) {
                                    ((Damageable)entity).damage(damage, (Entity)player);
                                }
                            });
                            HandlerList.unregisterAll((Listener)this);
                        }
                    }
                }, (Plugin)MoonLab.getInstance());
            }
        }
    }

    @EventHandler
    public void onEggHit(ProjectileHitEvent event) {
        Player player;
        Egg egg;
        ProjectileSource var5;
        Projectile var4;
        boolean easterEgg = SettingsManager.getInstance().getSettings().getBoolean("Settings.EasterEgg", false);
        if (easterEgg && (var4 = event.getEntity()) instanceof Egg && (var5 = (egg = (Egg)var4).getShooter()) instanceof Player && (player = (Player)var5).hasPermission("mpa.easterevent")) {
            Location location = event.getEntity().getLocation();
            event.setCancelled(true);
            Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> {
                Bukkit.getLogger().info("[MoonPillars] Attempting to spawn Easter chicken");
                try {
                    Chicken chicken = (Chicken)location.getWorld().spawnEntity(location, EntityType.CHICKEN);
                    chicken.setCustomName(MSG.chatColors("&6&lHappy Easter!"));
                    chicken.setCustomNameVisible(true);
                    chicken.setRemoveWhenFarAway(false);
                    Bukkit.getLogger().info("[MoonPillars] Easter chicken spawned successfully!");
                    List<String> headTextures = List.of("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvODYyMWE1MjY5ODY5ODQ3NTMxMDE1NjYzMDBhMzU2YjVmMzBkNjk3NWExZWZlNjI5YWJmMjY5NDc2NWQ5NmNjIn19fQ==", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNDdjZDY5NjBlMTYwYzZlYzQ4OTZmNzc0ZmYyMzY0Y2IwN2YxMTk5ZjFmOWJlMzQ4MTY5MjFjYzE3NzViNWU4MiJ9fX0=", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOWY1NWM1MDVkN2YwMDEzNWI1ZjUyMjViNzVjZDkyZWQxMjIwMWNjOTVjNDFkZWVkOGE3N2RhOGZkNmI3Yjk2MyJ9fX0=", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZDdmODUxOWNjNWE2MjQzZDg1ODk0OWE2YzU3MzlkY2U4NWE3NjE5YWQwZTcxYzUzNzAxYzgwZDQ3NjA0NmEwMCJ9fX0=", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMmM3MDQwNmU3NTM5NDIxMzU0MjRiYjk5NjkyYjc0NGM5YTAzNDVkM2YzYzgxOTNlOWQ4ZTMwZDU0NDEyMThlMyJ9fX0=", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzM3NDZhZWMyNTg4NzQ4MGVlZDE3MzMwYzQzZWFiY2M1NDljMmJiOGNlNGYxNWJhM2M2NGE1MmIwNzE2NmVmIn19fQ==", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYmFhNGYxNjY2Y2FlNzk3YmFiMWU1ZjI0ZjZmNmQxZDY3YzVlYjNlODViOTYwNDQ1ZTFiNjQ1MWRlODAzYSJ9fX0=", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZTJkMzE3ZTFhMTI4M2FiMmY2NDc0ZjNhN2UxODI1OWU2MGE0NzkxYjYxMzMxOWVmZWRhN2ViZGFiODk5MzQifX19", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzQzYjFjNDM2NzRmZDgyMTZhNjMwYzQ2MjQ3NzMzZjNkZDViMTYxZDA2MWEwZmM2NGRkZjA3ZTViM2ZmZWMifX19", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNWZmZWQ3YWMxNWQ2N2VjNWE0Y2I5MjM2N2Y5ZDc1NDMyZWIxNjEwNWFmZjJjMjkxYzg4OTQ2Yzc0NzhmY2I1In19fQ==", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOWZiZWIwYWE2ODhlOTdlNDYzYjUxOGQ0YzBjOGY1YmE4MjJhNzM4NmE0NmRlM2NhMjZjZTJjNWIzMTM3OTg1YyJ9fX0=", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNGViNWFiYjEyMzUyN2E3YTFmNWM5NTg5NzE1OTY0YjU5Zjc2ODI0OTI2ZDNiOTgyZmE4NDExZDQ2MDZjNzkifX19", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZDM2ZmU4M2M0MmM2Y2U3Mzg2Y2YyMzMzYTFjNTk1ZDBiNDMzZGE3YmM1NTkyYjg2ODY2ODU1MWQ2OWI5YjAifX19", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMjY0NDMwZTQ5M2ZlYjVlYWExNDU1ODJlNTRlNzYxYTg2MDNmYjE2Y2MwZmYxMjY4YTVkMWU4NjRlNmY0NzlmNiJ9fX0=");
                    int eggCount = SettingsManager.getInstance().getSettings().getInt("Settings.EasterEggCount", 60);
                    int eggFrequency = SettingsManager.getInstance().getSettings().getInt("Settings.EasterEggFrequency", 5);
                    AtomicInteger headCount = new AtomicInteger(0);
                    BukkitTask headTask = Bukkit.getScheduler().runTaskTimer((Plugin)MoonLab.getInstance(), () -> {
                        if (headCount.get() >= eggCount) {
                            chicken.remove();
                            Bukkit.getLogger().info("[MoonPillars] Easter event complete - chicken removed");
                        } else {
                            double angle = Math.random() * 1.0;
                            double radius = Math.random() * 5.0;
                            double x = chicken.getLocation().getX() + radius * Math.cos(angle);
                            double y = chicken.getLocation().getY();
                            double z = chicken.getLocation().getZ() + radius * Math.sin(angle);
                            Location headLoc = new Location(chicken.getWorld(), x, y, z);
                            String texture = (String)headTextures.get(headCount.get() % headTextures.size());
                            ItemStack head = BlockedEvents.getHeadFrom64(texture);
                            Item item = chicken.getWorld().dropItem(headLoc, head);
                            item.setPickupDelay(Integer.MAX_VALUE);
                            item.setCustomName(MSG.chatColors("&e&lEaster Egg"));
                            item.setCustomNameVisible(true);
                            double horizontalSpeed = 0.3;
                            double verticalSpeed = 0.8;
                            double randomAngle = Math.random() * 2.0 * Math.PI;
                            double vx = horizontalSpeed * Math.cos(randomAngle);
                            double vz = horizontalSpeed * Math.sin(randomAngle);
                            item.setVelocity(new Vector(vx, verticalSpeed, vz));
                            int displayTime = SettingsManager.getInstance().getSettings().getInt("Settings.EasterEggDisplayTime", 100);
                            BukkitScheduler var10000 = Bukkit.getScheduler();
                            MoonLab var10001 = MoonLab.getInstance();
                            Objects.requireNonNull(item);
                            var10000.runTaskLater((Plugin)var10001, () -> ((Item)item).remove(), (long)displayTime);
                            headCount.incrementAndGet();
                        }
                    }, 0L, (long)eggFrequency);
                    BukkitScheduler var10000 = Bukkit.getScheduler();
                    MoonLab var10001 = MoonLab.getInstance();
                    Objects.requireNonNull(headTask);
                    var10000.runTaskLater((Plugin)var10001, () -> ((BukkitTask)headTask).cancel(), (long)(eggFrequency * eggCount + 20));
                }
                catch (Exception var7) {
                    Bukkit.getLogger().severe("[MoonPillars] Failed to spawn chicken: " + var7.getMessage());
                    var7.printStackTrace();
                }
            });
        }
    }

    public static ItemStack getHeadFrom64(String value) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD, 1);
        SkullMeta meta = (SkullMeta)head.getItemMeta();
        PlayerProfile profile = Bukkit.createProfile((UUID)UUID.randomUUID());
        profile.setProperty(new ProfileProperty("textures", value));
        meta.setPlayerProfile(profile);
        head.setItemMeta((ItemMeta)meta);
        return head;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player;
        if (SettingsManager.getInstance().getSettings().getBoolean("Settings.RestrictEnderChest", true) && event.getAction() == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock() != null && event.getClickedBlock().getType() == Material.ENDER_CHEST && !(player = event.getPlayer()).hasPermission("mpa.enderchest")) {
            event.setCancelled(true);
            ItemStack itemInHand = player.getInventory().getItemInMainHand();
            if (itemInHand.getType().isBlock() && itemInHand.getType().isSolid()) {
                event.setCancelled(true);
                Block clickedBlock = event.getClickedBlock();
                BlockFace clickedFace = event.getBlockFace();
                Block placementBlock = clickedBlock.getRelative(clickedFace);
                if (placementBlock.isEmpty() || placementBlock.isReplaceable()) {
                    placementBlock.setType(itemInHand.getType());
                    if (player.getGameMode() != GameMode.CREATIVE) {
                        if (itemInHand.getAmount() > 1) {
                            itemInHand.setAmount(itemInHand.getAmount() - 1);
                        } else {
                            player.getInventory().setItemInMainHand((ItemStack)null);
                        }
                    }
                    player.getWorld().playSound(placementBlock.getLocation(), Sound.BLOCK_STONE_PLACE, 1.0f, 1.0f);
                }
            }
        }
    }

    @EventHandler
    public void onExplosion(EntityExplodeEvent event) {
        if (SettingsManager.getInstance().getSettings().getBoolean("Settings.ProtectWorldFromExplosions", true)) {
            ArrayList<Block> blocksToRemove = new ArrayList<Block>();
            String gameName = event.getLocation().getWorld().getName().replace("Areas/", "");
            FileConfiguration config = HashMapHandler.getConfigGameID(gameName);
            if (config != null) {
                for (Block block : event.blockList()) {
                    if (block.getType().name().contains("BED")) {
                        blocksToRemove.add(block);
                        continue;
                    }
                    boolean tntMode = config.getBoolean("Settings.TnTMode", false);
                    if (tntMode) continue;
                    String blockKey = this.getBlockKey(block);
                    Set<String> placedBlocks = HashMapHandler.getGamePlacedBlocks(gameName);
                    if (placedBlocks != null && placedBlocks.contains(blockKey)) continue;
                    blocksToRemove.add(block);
                }
                event.blockList().removeAll(blocksToRemove);
                return;
            }
        }
    }

    @EventHandler
    public void onBlockIgnite(BlockIgniteEvent event) {
        if (SettingsManager.getInstance().getSettings().getBoolean("Settings.ProtectWorldFromFire", true)) {
            Block block = event.getBlock();
            String gameName = block.getWorld().getName().replace("Areas/", "");
            String blockKey = this.getBlockKey(block);
            Set<String> placedBlocks = HashMapHandler.getGamePlacedBlocks(gameName);
            if (placedBlocks == null || !placedBlocks.contains(blockKey)) {
                event.setCancelled(true);
            }
        }
    }

    private String getBlockKey(Block block) {
        String var10000 = block.getWorld().getName();
        return var10000 + ":" + block.getX() + "," + block.getY() + "," + block.getZ();
    }
}

