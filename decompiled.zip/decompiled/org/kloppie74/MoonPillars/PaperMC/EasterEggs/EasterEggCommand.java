/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.block.Block
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.EasterEggs;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.EasterEggs.EasterEggManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class EasterEggCommand
implements CommandExecutor,
TabCompleter {
    private static final String EGG_PREFIX = "\u00a7e\u00a7lEaster Egg \u00a7f#";
    private static final NamespacedKey EGG_KEY = new NamespacedKey((Plugin)MoonLab.getInstance(), "easter_egg");
    private static File eggFile;
    private static FileConfiguration eggConfig;
    private static int totalEggs;

    public static void setup() {
        eggFile = new File(MoonLab.getInstance().getDataFolder(), "eastereggs.yml");
        if (!eggFile.exists()) {
            try {
                eggFile.createNewFile();
            }
            catch (IOException var1) {
                Bukkit.getLogger().severe("Could not create eastereggs.yml");
                var1.printStackTrace();
            }
        }
        if ((eggConfig = YamlConfiguration.loadConfiguration((File)eggFile)).contains("settings.totalEggs")) {
            totalEggs = eggConfig.getInt("settings.totalEggs");
        } else {
            eggConfig.set("settings.totalEggs", (Object)totalEggs);
            EasterEggCommand.saveConfig();
        }
    }

    private static void saveConfig() {
        try {
            eggConfig.save(eggFile);
        }
        catch (IOException var1) {
            Bukkit.getLogger().severe("Could not save eastereggs.yml");
            var1.printStackTrace();
        }
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            if (!player.hasPermission("moonpillars.admin")) {
                player.sendMessage(MSG.chatColors("&cYou don't have permission to use this command."));
                return true;
            }
            if (args.length == 0) {
                this.sendHelp(player);
                return true;
            }
            switch (args[0].toLowerCase()) {
                case "findamount": {
                    if (args.length < 2) {
                        player.sendMessage(MSG.chatColors("&cUsage: /eastereggfindamount <amount>"));
                        return true;
                    }
                    try {
                        int amount = Integer.parseInt(args[1]);
                        if (amount <= 0) {
                            player.sendMessage(MSG.chatColors("&cAmount must be greater than 0."));
                            return true;
                        }
                        totalEggs = amount;
                        eggConfig.set("settings.totalEggs", (Object)amount);
                        EasterEggCommand.saveConfig();
                        player.sendMessage(MSG.chatColors("&aSet total eggs to find to " + amount));
                    }
                    catch (NumberFormatException var17) {
                        player.sendMessage(MSG.chatColors("&cInvalid number: " + args[1]));
                    }
                    break;
                }
                case "reward": {
                    if (args.length < 3) {
                        player.sendMessage(MSG.chatColors("&cUsage: /eastereggreward {console} <command>"));
                        return true;
                    }
                    StringBuilder commandBuilder = new StringBuilder();
                    for (int ii = 2; ii < args.length; ++ii) {
                        commandBuilder.append(args[ii]).append(" ");
                    }
                    String commandStr = commandBuilder.toString().trim();
                    List rewards = eggConfig.getStringList("settings.rewards");
                    rewards.add(commandStr);
                    eggConfig.set("settings.rewards", (Object)rewards);
                    EasterEggCommand.saveConfig();
                    player.sendMessage(MSG.chatColors("&aAdded reward command: &e" + commandStr));
                    break;
                }
                case "rewards": {
                    List rewardsList = eggConfig.getStringList("settings.rewards");
                    if (rewardsList.isEmpty()) {
                        player.sendMessage(MSG.chatColors("&cNo reward commands have been set."));
                        return true;
                    }
                    player.sendMessage(MSG.chatColors("&e=== Easter Egg Rewards ==="));
                    for (int i = 0; i < rewardsList.size(); ++i) {
                        player.sendMessage(MSG.chatColors("&f" + (i + 1) + ". &e" + (String)rewardsList.get(i)));
                    }
                    return true;
                }
                case "clearrewards": {
                    eggConfig.set("settings.rewards", null);
                    EasterEggCommand.saveConfig();
                    player.sendMessage(MSG.chatColors("&aCleared all reward commands."));
                    break;
                }
                case "list": {
                    this.listEggs(player);
                    break;
                }
                case "remove": {
                    if (args.length < 2) {
                        player.sendMessage(MSG.chatColors("&cUsage: /eastereggremove <id>"));
                        return true;
                    }
                    try {
                        int i = Integer.parseInt(args[1]);
                        this.removeEgg(player, i);
                    }
                    catch (NumberFormatException var16) {
                        player.sendMessage(MSG.chatColors("&cInvalid egg ID: " + args[1]));
                    }
                    break;
                }
                case "removeall": {
                    this.removeAllEggs(player);
                    break;
                }
                case "tp": {
                    if (args.length < 2) {
                        player.sendMessage(MSG.chatColors("&cUsage: /eastereggtp <id>"));
                        return true;
                    }
                    try {
                        int i = Integer.parseInt(args[1]);
                        this.teleportToEgg(player, i);
                    }
                    catch (NumberFormatException var15) {
                        player.sendMessage(MSG.chatColors("&cInvalid egg ID: " + args[1]));
                    }
                    break;
                }
                case "enable": {
                    EasterEggManager.setEggsEnabled(true);
                    player.sendMessage(MSG.chatColors("&aEaster egg finding has been enabled."));
                    break;
                }
                case "disable": {
                    EasterEggManager.setEggsEnabled(false);
                    player.sendMessage(MSG.chatColors("&cEaster egg finding has been disabled."));
                    break;
                }
                case "status": {
                    boolean enabled = EasterEggManager.areEggsEnabled();
                    player.sendMessage(MSG.chatColors(enabled ? "&aEaster egg finding is currently enabled." : "&cEaster egg finding is currently disabled."));
                    break;
                }
                default: {
                    try {
                        int id = Integer.parseInt(args[0]);
                        this.placeEgg(player, id);
                        break;
                    }
                    catch (NumberFormatException var14) {
                        player.sendMessage(MSG.chatColors("&cInvalid egg ID or command: " + args[0]));
                        this.sendHelp(player);
                    }
                }
            }
            return true;
        }
        sender.sendMessage(MSG.chatColors("&cOnly players can use this command."));
        return true;
    }

    private void sendHelp(Player player) {
        player.sendMessage(MSG.chatColors("&e=== Easter Egg Commands ==="));
        player.sendMessage(MSG.chatColors("&f/easteregg<id> - Place Easter Egg at target block"));
        player.sendMessage(MSG.chatColors("&f/easteregg findamount <amount> - Set total eggs to find"));
        player.sendMessage(MSG.chatColors("&f/easteregg reward {console} <command> - Add reward command"));
        player.sendMessage(MSG.chatColors("&f/easteregg rewards - List all reward commands"));
        player.sendMessage(MSG.chatColors("&f/easteregg clearrewards - Clear all reward commands"));
        player.sendMessage(MSG.chatColors("&f/easteregg list - List all placed Easter Eggs"));
        player.sendMessage(MSG.chatColors("&f/easteregg remove <id> - Remove Easter Egg"));
        player.sendMessage(MSG.chatColors("&f/easteregg removeall - Remove all Easter Eggs"));
        player.sendMessage(MSG.chatColors("&f/easteregg tp <id> - Teleport to Easter Egg"));
        player.sendMessage(MSG.chatColors("&f/easteregg enable - Enable egg finding"));
        player.sendMessage(MSG.chatColors("&f/easteregg disable - Disable egg finding"));
        player.sendMessage(MSG.chatColors("&f/easteregg status - Check if egg finding is enabled"));
    }

    private void placeEgg(Player player, int id) {
        if (id > 0 && id <= totalEggs) {
            Block targetBlock = player.getTargetBlock((Set)null, 5);
            if (targetBlock != null && targetBlock.getType() != Material.AIR) {
                Location location = targetBlock.getLocation();
                String path = "eggs." + id;
                eggConfig.set(path + ".world", (Object)location.getWorld().getName());
                eggConfig.set(path + ".x", (Object)location.getX());
                eggConfig.set(path + ".y", (Object)location.getY());
                eggConfig.set(path + ".z", (Object)location.getZ());
                EasterEggCommand.saveConfig();
                this.placeEasterEggHead(location, id);
                player.sendMessage(MSG.chatColors("&aPlaced Easter Egg #" + id + " at your target block."));
            } else {
                player.sendMessage(MSG.chatColors("&cYou must be looking at a block."));
            }
        } else {
            player.sendMessage(MSG.chatColors("&cInvalid egg ID. Must be between 1 and " + totalEggs));
        }
    }

    private void placeEasterEggHead(Location location, int id) {
        EasterEggManager.createEasterEgg(location, id);
    }

    private void listEggs(Player player) {
        ConfigurationSection eggsSection = eggConfig.getConfigurationSection("eggs");
        if (eggsSection != null && !eggsSection.getKeys(false).isEmpty()) {
            player.sendMessage(MSG.chatColors("&e=== Placed Easter Eggs ==="));
            for (String key : eggsSection.getKeys(false)) {
                ConfigurationSection eggSection = eggsSection.getConfigurationSection(key);
                if (eggSection == null) continue;
                String world = eggSection.getString("world");
                int x = eggSection.getInt("x");
                int y = eggSection.getInt("y");
                int z = eggSection.getInt("z");
                player.sendMessage(MSG.chatColors("&fEgg #" + key + ": &e" + world + " at " + x + ", " + y + ", " + z));
            }
        } else {
            player.sendMessage(MSG.chatColors("&cNo Easter Eggs have been placed yet."));
        }
    }

    private void removeEgg(Player player, int id) {
        String path = "eggs." + id;
        if (!eggConfig.contains(path)) {
            player.sendMessage(MSG.chatColors("&cEaster Egg #" + id + " doesn't exist."));
        } else {
            String world = eggConfig.getString(path + ".world");
            int x = eggConfig.getInt(path + ".x");
            int y = eggConfig.getInt(path + ".y");
            int z = eggConfig.getInt(path + ".z");
            if (world != null) {
                Location loc = new Location(Bukkit.getWorld((String)world), (double)x, (double)y, (double)z);
                EasterEggManager.removeEasterEgg(loc);
            }
            eggConfig.set(path, null);
            EasterEggCommand.saveConfig();
            player.sendMessage(MSG.chatColors("&aRemoved Easter Egg #" + id));
        }
    }

    private void removeAllEggs(Player player) {
        ConfigurationSection eggsSection = eggConfig.getConfigurationSection("eggs");
        if (eggsSection != null && !eggsSection.getKeys(false).isEmpty()) {
            for (String key : eggsSection.getKeys(false)) {
                ConfigurationSection eggSection = eggsSection.getConfigurationSection(key);
                if (eggSection == null) continue;
                String world = eggSection.getString("world");
                int x = eggSection.getInt("x");
                int y = eggSection.getInt("y");
                int z = eggSection.getInt("z");
                if (world == null) continue;
                Location loc = new Location(Bukkit.getWorld((String)world), (double)x, (double)y, (double)z);
                EasterEggManager.removeEasterEgg(loc);
            }
            eggConfig.set("eggs", null);
            EasterEggCommand.saveConfig();
            player.sendMessage(MSG.chatColors("&aRemoved all Easter Eggs."));
        } else {
            player.sendMessage(MSG.chatColors("&cNo Easter Eggs to remove."));
        }
    }

    private void teleportToEgg(Player player, int id) {
        String path = "eggs." + id;
        if (!eggConfig.contains(path)) {
            player.sendMessage(MSG.chatColors("&cEaster Egg #" + id + " doesn't exist."));
        } else {
            String worldName = eggConfig.getString(path + ".world");
            double x = eggConfig.getDouble(path + ".x");
            double y = eggConfig.getDouble(path + ".y");
            double z = eggConfig.getDouble(path + ".z");
            if (worldName != null) {
                Location loc = new Location(Bukkit.getWorld((String)worldName), x, y + 1.0, z);
                player.teleport(loc);
                player.sendMessage(MSG.chatColors("&aTeleported to Easter Egg #" + id));
            } else {
                player.sendMessage(MSG.chatColors("&cInvalid world for Easter Egg #" + id));
            }
        }
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            ArrayList<String> completions = new ArrayList<String>(Arrays.asList("findamount", "reward", "rewards", "clearrewards", "list", "remove", "removeall", "tp", "enable", "disable", "status"));
            for (int i = 1; i <= totalEggs; ++i) {
                completions.add(String.valueOf(i));
            }
            return this.filterCompletions(completions, args[0]);
        }
        if (args.length == 2) {
            if (args[0].equalsIgnoreCase("findamount")) {
                return Arrays.asList("10", "25", "50", "100");
            }
            if (!args[0].equalsIgnoreCase("remove") && !args[0].equalsIgnoreCase("tp")) {
                if (args[0].equalsIgnoreCase("reward")) {
                    return Collections.singletonList("console");
                }
            } else {
                ConfigurationSection eggsSection = eggConfig.getConfigurationSection("eggs");
                if (eggsSection != null) {
                    return this.filterCompletions(new ArrayList<String>(eggsSection.getKeys(false)), args[1]);
                }
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("reward") && args[1].equalsIgnoreCase("console")) {
            return Arrays.asList("give %player% diamond", "eco give %player%", "broadcast");
        }
        return Collections.emptyList();
    }

    private List<String> filterCompletions(List<String> completions, String partial) {
        String lowerPartial = partial.toLowerCase();
        return completions.stream().filter(s -> s.toLowerCase().startsWith(lowerPartial)).toList();
    }

    public static int getTotalEggs() {
        return totalEggs;
    }

    public static FileConfiguration getEggConfig() {
        return eggConfig;
    }

    public static void saveEggConfig() {
        EasterEggCommand.saveConfig();
    }

    static {
        totalEggs = 25;
    }
}

