/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 */
package org.kloppie74.MoonPillars.PaperMC.EasterEggs;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.EasterEggs.EasterEggManager;

public class EasterEggListener
implements Listener {
    private final Map<UUID, Long> cooldowns = new HashMap<UUID, Long>();
    private static final long COOLDOWN_TIME = 1000L;

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Block block;
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK && (block = event.getClickedBlock()) != null && (block.getType() == Material.PLAYER_HEAD || block.getType() == Material.PLAYER_WALL_HEAD)) {
            Player player = event.getPlayer();
            UUID playerUUID = player.getUniqueId();
            if (EasterEggManager.isEasterEgg(block)) {
                long lastInteraction;
                event.setCancelled(true);
                long currentTime = System.currentTimeMillis();
                if (this.cooldowns.containsKey(playerUUID) && currentTime - (lastInteraction = this.cooldowns.get(playerUUID).longValue()) < 1000L) {
                    return;
                }
                this.cooldowns.put(playerUUID, currentTime);
                int eggId = EasterEggManager.findEggIdAtLocation(block.getLocation());
                if (eggId == -1) {
                    return;
                }
                if (EasterEggManager.hasPlayerFoundEgg(player, eggId)) {
                    player.sendMessage(MSG.chatColors("&cYou've already found Easter Egg #" + eggId + "!"));
                    return;
                }
                EasterEggManager.markEggAsFound(player, eggId);
            }
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        EasterEggManager.loadPlayerFoundEggs(event.getPlayer());
    }
}

