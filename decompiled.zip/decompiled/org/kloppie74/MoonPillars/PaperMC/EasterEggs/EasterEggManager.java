/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Particle
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.block.BlockState
 *  org.bukkit.block.Skull
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 */
package org.kloppie74.MoonPillars.PaperMC.EasterEggs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.Skull;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.EasterEggs.EasterEggCommand;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class EasterEggManager {
    private static final Map<UUID, Set<Integer>> playerFoundEggs = new HashMap<UUID, Set<Integer>>();
    private static final Map<Location, Integer> activeEggs = new HashMap<Location, Integer>();
    private static boolean eggsEnabled = true;
    private static int particleTaskId = -1;

    public static void initialize() {
        EasterEggManager.loadAllEggs();
        EasterEggManager.loadAllPlayerData();
        EasterEggManager.startParticleEffects();
    }

    public static void shutdown() {
        EasterEggManager.stopParticleEffects();
        EasterEggManager.saveAllPlayerData();
        activeEggs.clear();
        playerFoundEggs.clear();
    }

    public static void reload() {
        EasterEggManager.shutdown();
        EasterEggManager.initialize();
    }

    public static void setEggsEnabled(boolean enabled) {
        eggsEnabled = enabled;
        if (enabled) {
            EasterEggManager.startParticleEffects();
        } else {
            EasterEggManager.stopParticleEffects();
        }
    }

    public static boolean areEggsEnabled() {
        return eggsEnabled;
    }

    private static void loadAllPlayerData() {
        FileConfiguration eggConfig = EasterEggCommand.getEggConfig();
        ConfigurationSection playersSection = eggConfig.getConfigurationSection("players");
        if (playersSection != null) {
            for (String uuidString : playersSection.getKeys(false)) {
                try {
                    UUID playerId = UUID.fromString(uuidString);
                    List foundEggs = eggConfig.getIntegerList("players." + uuidString + ".foundEggs");
                    if (foundEggs == null || foundEggs.isEmpty()) continue;
                    playerFoundEggs.put(playerId, new HashSet(foundEggs));
                }
                catch (IllegalArgumentException var6) {
                    Bukkit.getLogger().warning("Invalid UUID in Easter Egg config: " + uuidString);
                }
            }
        }
    }

    private static void saveAllPlayerData() {
        FileConfiguration eggConfig = EasterEggCommand.getEggConfig();
        for (Map.Entry<UUID, Set<Integer>> entry : playerFoundEggs.entrySet()) {
            UUID playerId = entry.getKey();
            Set<Integer> foundEggs = entry.getValue();
            ArrayList<Integer> eggList = new ArrayList<Integer>(foundEggs);
            String playerName = Bukkit.getPlayer((UUID)playerId) != null ? Bukkit.getPlayer((UUID)playerId).getName() : eggConfig.getString("players." + String.valueOf(playerId) + ".name", "Unknown");
            eggConfig.set("players." + String.valueOf(playerId) + ".name", (Object)playerName);
            eggConfig.set("players." + String.valueOf(playerId) + ".foundEggs", eggList);
        }
        EasterEggCommand.saveEggConfig();
    }

    private static void loadAllEggs() {
        FileConfiguration eggConfig = EasterEggCommand.getEggConfig();
        ConfigurationSection eggsSection = eggConfig.getConfigurationSection("eggs");
        if (eggsSection != null) {
            for (String key : eggsSection.getKeys(false)) {
                String path = "eggs." + key;
                String worldName = eggConfig.getString(path + ".world");
                int x = eggConfig.getInt(path + ".x");
                int y = eggConfig.getInt(path + ".y");
                int z = eggConfig.getInt(path + ".z");
                if (worldName == null) continue;
                Location loc = new Location(Bukkit.getWorld((String)worldName), (double)x, (double)y, (double)z);
                int eggId = Integer.parseInt(key);
                activeEggs.put(loc, eggId);
            }
        }
    }

    private static void startParticleEffects() {
        if (particleTaskId == -1) {
            particleTaskId = new BukkitRunnable(){

                /*
                 * Unable to fully structure code
                 */
                public void run() {
                    if (EasterEggManager.eggsEnabled) {
                        var1 = EasterEggManager.activeEggs.keySet().iterator();
                        block0: while (true) {
                            if (!var1.hasNext()) {
                                return;
                            }
                            loc = var1.next();
                            if (!loc.getWorld().isChunkLoaded(loc.getBlockX() >> 4, loc.getBlockZ() >> 4)) continue;
                            eggId = EasterEggManager.activeEggs.get(loc);
                            var4 = loc.getWorld().getPlayers().iterator();
                            while (true) {
                                if (var4.hasNext()) ** break;
                                continue block0;
                                player = (Player)var4.next();
                                if (!(player.getLocation().distanceSquared(loc) <= 2500.0) || EasterEggManager.hasPlayerFoundEgg(player, eggId)) continue;
                                player.spawnParticle(Particle.VILLAGER_HAPPY, loc.clone().add(0.5, 0.5, 0.5), 5, 0.3, 0.3, 0.3, 0.01);
                            }
                            break;
                        }
                    }
                }
            }.runTaskTimer((Plugin)MoonLab.getInstance(), 20L, 20L).getTaskId();
        }
    }

    private static void stopParticleEffects() {
        if (particleTaskId != -1) {
            Bukkit.getScheduler().cancelTask(particleTaskId);
            particleTaskId = -1;
        }
    }

    public static void createEasterEgg(Location location, int eggId) {
        Block block = location.getBlock();
        if (block.getType() != Material.PLAYER_HEAD && block.getType() != Material.PLAYER_WALL_HEAD) {
            block.setType(Material.PLAYER_HEAD);
            BlockState var4 = block.getState();
            if (var4 instanceof Skull) {
                Skull skull = (Skull)var4;
                BlockFace[] faces = new BlockFace[]{BlockFace.NORTH, BlockFace.EAST, BlockFace.SOUTH, BlockFace.WEST};
                skull.setRotation(faces[new Random().nextInt(faces.length)]);
                skull.update();
            }
        }
        activeEggs.put(location, eggId);
    }

    public static void removeEasterEgg(Location location) {
        activeEggs.remove(location);
        location.getBlock().setType(Material.AIR);
    }

    public static boolean isEasterEgg(Block block) {
        return block.getType() != Material.PLAYER_HEAD && block.getType() != Material.PLAYER_WALL_HEAD ? false : activeEggs.containsKey(block.getLocation());
    }

    private static boolean isLocationAnEgg(Location location) {
        return activeEggs.containsKey(location);
    }

    public static int findEggIdAtLocation(Location location) {
        return activeEggs.getOrDefault(location, -1);
    }

    public static void markEggAsFound(Player player, int eggId) {
        if (!eggsEnabled) {
            player.sendMessage(MSG.chatColors("&cEaster eggs are currently disabled!"));
        } else {
            UUID playerId = player.getUniqueId();
            playerFoundEggs.computeIfAbsent(playerId, k -> new HashSet());
            playerFoundEggs.get(playerId).add(eggId);
            EasterEggManager.savePlayerFoundEggs(player);
            int found = playerFoundEggs.get(playerId).size();
            int total = EasterEggCommand.getTotalEggs();
            player.sendMessage(MSG.chatColors("&a&lEASTER EGG FOUND! &f#" + eggId));
            player.sendMessage(MSG.chatColors("&eYou have found &6" + found + "&e/&6" + total + " &eeggs!"));
            if (found >= total) {
                EasterEggManager.giveRewards(player);
            }
        }
    }

    private static void giveRewards(Player player) {
        player.sendMessage(MSG.chatColors("&a&l\u2713 CONGRATULATIONS! &eYou have found all Easter Eggs!"));
        player.sendMessage(MSG.chatColors("&6&lREWARD RECEIVED!"));
        FileConfiguration eggConfig = EasterEggCommand.getEggConfig();
        List<String> rewardCommands = eggConfig.getStringList("settings.rewards");
        if (rewardCommands == null || rewardCommands.isEmpty()) {
            rewardCommands = Arrays.asList("give %player% diamond 64", "eco give %player% 1000");
        }
        for (String cmd : rewardCommands) {
            cmd = cmd.replace("%player%", player.getName());
            Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)cmd);
        }
    }

    private static void savePlayerFoundEggs(Player player) {
        UUID playerId = player.getUniqueId();
        Set foundEggs = playerFoundEggs.getOrDefault(playerId, new HashSet());
        ArrayList eggList = new ArrayList(foundEggs);
        FileConfiguration eggConfig = EasterEggCommand.getEggConfig();
        eggConfig.set("players." + String.valueOf(playerId) + ".name", (Object)player.getName());
        eggConfig.set("players." + String.valueOf(playerId) + ".foundEggs", eggList);
        EasterEggCommand.saveEggConfig();
    }

    public static void loadPlayerFoundEggs(Player player) {
        UUID playerId = player.getUniqueId();
        if (!playerFoundEggs.containsKey(playerId)) {
            FileConfiguration eggConfig = EasterEggCommand.getEggConfig();
            List foundEggs = eggConfig.getIntegerList("players." + String.valueOf(playerId) + ".foundEggs");
            if (foundEggs != null && !foundEggs.isEmpty()) {
                playerFoundEggs.put(playerId, new HashSet(foundEggs));
            }
            if (playerFoundEggs.containsKey(playerId)) {
                eggConfig.set("players." + String.valueOf(playerId) + ".name", (Object)player.getName());
                EasterEggCommand.saveEggConfig();
            }
        }
    }

    public static boolean hasPlayerFoundEgg(Player player, int eggId) {
        UUID playerId = player.getUniqueId();
        Set foundEggs = playerFoundEggs.getOrDefault(playerId, new HashSet());
        return foundEggs.contains(eggId);
    }

    public static Set<Integer> getPlayerFoundEggs(Player player) {
        return playerFoundEggs.getOrDefault(player.getUniqueId(), new HashSet());
    }
}

