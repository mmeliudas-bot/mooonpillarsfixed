/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.expansion.PlaceholderExpansion
 *  org.bukkit.Bukkit
 *  org.bukkit.GameMode
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.Statistic
 *  org.bukkit.World
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.jetbrains.annotations.NotNull
 */
package org.kloppie74.MoonPillars.PaperMC;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.OfflinePlayer;
import org.bukkit.Statistic;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.LevelManager.AddPlayerXP;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.VanishSystem.PlayerVisibilityListener;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.FindGames;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.LocalCache;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.TeamManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class PlaceHolder
extends PlaceholderExpansion {
    private static List<PlaytimeEntry> cachedPlaytimeLeaderboard = new ArrayList<PlaytimeEntry>();
    private static long lastLeaderboardUpdate = 0L;
    private static final long LEADERBOARD_CACHE_TIME = 300000L;

    @NotNull
    public String getAuthor() {
        return "Kloppie74";
    }

    @NotNull
    public String getIdentifier() {
        return "mpa";
    }

    public boolean persist() {
        return true;
    }

    @NotNull
    public String getVersion() {
        return "5.0.0";
    }

    public String onRequest(OfflinePlayer p, @NotNull String params) {
        UUID playerUUID;
        int position;
        String[] parts;
        World world;
        String value;
        if (params == null) {
            PlaceHolder.$$$reportNull$$$0(0);
        }
        if (params.equalsIgnoreCase("level")) {
            return String.valueOf(AddPlayerXP.getLevel(p.getPlayer()));
        }
        if (params.equalsIgnoreCase("level_name")) {
            int position2 = AddPlayerXP.getLevel(p.getPlayer());
            return AddPlayerXP.getLevelName(position2);
        }
        if (params.equalsIgnoreCase("level_xp")) {
            return String.valueOf(AddPlayerXP.getXP(p.getPlayer()));
        }
        if (params.equalsIgnoreCase("level_xp_needed")) {
            int position3 = AddPlayerXP.getLevel(p.getPlayer()) + 1;
            return String.valueOf(AddPlayerXP.getRequiredXP(position3));
        }
        if (params.startsWith("game_current_waiting_")) {
            Object value2 = params.substring("game_current_waiting_".length());
            if (((String)value2).endsWith("_amount")) {
                value2 = ((String)value2).substring(0, ((String)value2).length() - 7);
            }
            if (!((String)value2).startsWith("Mini-")) {
                value2 = "Mini-" + (String)value2;
            }
            if (!((String)value2).matches(".*-\\d+$")) {
                value2 = (String)value2 + "-1";
            }
            int position4 = 0;
            for (Player player : Bukkit.getOnlinePlayers()) {
                String teamColor = HashMapHandler.getPlayerWaitingGameID(player.getUniqueId());
                if (teamColor == null || !teamColor.equals(value2)) continue;
                ++position4;
            }
            return String.valueOf(position4);
        }
        if (params.startsWith("game_totalwaiting_")) {
            String value3 = params.substring("game_totalwaiting_".length());
            if (value3.endsWith("_amount")) {
                value3 = value3.substring(0, value3.length() - 7);
            }
            int maxCount = 5;
            int kills = 0;
            for (int games = 1; games <= maxCount; ++games) {
                String teamColor = "Mini-" + value3 + "-" + games;
                for (Player pl : Bukkit.getOnlinePlayers()) {
                    String gameName = HashMapHandler.getPlayerWaitingGameID(pl.getUniqueId());
                    if (gameName == null || !gameName.equals(teamColor)) continue;
                    ++kills;
                }
            }
            return String.valueOf(kills);
        }
        if (params.startsWith("game_playercount")) {
            List<Player> members;
            String value4 = params.substring("game_playercount_".length());
            if (value4.endsWith("_amount")) {
                value4 = value4.substring(0, value4.length() - 7);
            }
            if ((members = HashMapHandler.getMembersGameID(value4)) == null) {
                return "0";
            }
            int kills = members.size();
            return String.valueOf(kills);
        }
        if (params.startsWith("gameslist_playertotalcount")) {
            String value5 = params.substring("mpa_games_playertotalcount_".length());
            if (value5.endsWith("_amount")) {
                value5 = value5.substring(0, value5.length() - 7);
            }
            value5 = value5.replace("{", "").replace("}", "");
            String[] parts2 = value5.split(",");
            int maxCount = 5;
            int games = 0;
            String[] var62 = parts2;
            int livingTeammates = parts2.length;
            for (int var58 = 0; var58 < livingTeammates; ++var58) {
                String gameName = var62[var58];
                for (int i = 1; i <= maxCount; ++i) {
                    String modifiedGameName = "Mini-" + gameName + "-" + i;
                    List<Player> playersInGame = HashMapHandler.getMembersGameID(modifiedGameName);
                    if (playersInGame == null) continue;
                    games += playersInGame.size();
                }
            }
            return String.valueOf(games);
        }
        if (params.startsWith("game_totalplayercount")) {
            String value6 = params.substring("game_totalplayercount_".length());
            if (value6.endsWith("_amount")) {
                value6 = value6.substring(0, value6.length() - 7);
            }
            int maxCount = 5;
            int kills = 0;
            for (int games = 1; games <= maxCount; ++games) {
                String teamColor = "Mini-" + value6 + "-" + games;
                List<Player> teamPlayers = HashMapHandler.getMembersGameID(teamColor);
                if (teamPlayers == null) continue;
                kills += teamPlayers.size();
            }
            return String.valueOf(kills);
        }
        if (params.equalsIgnoreCase("game_players_left")) {
            String value7 = HashMapHandler.getPlayerGameID(p.getUniqueId());
            if (value7 == null && p.getPlayer() != null) {
                value7 = p.getPlayer().getWorld().getName().replace("Areas/", "");
            }
            if (value7 != null) {
                List<Player> members = HashMapHandler.getMembersGameID(value7);
                return String.valueOf(members.size());
            }
            return "0";
        }
        if (params.startsWith("teams_") && params.endsWith("_teamname")) {
            FileConfiguration config;
            String value8 = params.substring("teams_".length(), params.length() - "_teamname".length());
            String gamesStr = HashMapHandler.getPlayerGameID(p.getUniqueId());
            if (gamesStr == null && p.getPlayer() != null) {
                gamesStr = p.getPlayer().getWorld().getName().replace("Areas/", "");
            }
            if (gamesStr != null && (config = HashMapHandler.getConfigGameID(gamesStr)) != null) {
                String TeamColor = config.getString("SpawnLocations." + value8 + ".Name", value8);
                TeamColor = TeamColor.replace("[", "").replace("]", "");
                return MSG.chatColors(TeamColor);
            }
            return "N/A";
        }
        if (params.startsWith("teams_") && params.endsWith("_status")) {
            Map<String, List<Player>> teamsMap;
            String value9 = params.substring("teams_".length(), params.length() - "_status".length());
            String gamesStr = HashMapHandler.getPlayerGameID(p.getUniqueId());
            if (gamesStr == null && p.getPlayer() != null) {
                gamesStr = p.getPlayer().getWorld().getName().replace("Areas/", "");
            }
            if (gamesStr != null && (teamsMap = TeamManager.teamsPerGame.get(gamesStr)) != null && teamsMap.containsKey(value9)) {
                List<Player> teamPlayers = teamsMap.get(value9);
                boolean hasAlive = false;
                if (teamPlayers != null) {
                    for (Player pl : teamPlayers) {
                        if (pl == null || !TeamManager.isPlayerAlive(gamesStr, pl)) continue;
                        hasAlive = true;
                        break;
                    }
                }
                return hasAlive ? "\u00a7a\u2705" : "\u00a7c\u274c";
            }
            return "\u00a7c\u274c";
        }
        if (params.startsWith("teams_") && params.endsWith("_players_alive")) {
            Map<String, List<Player>> teamsMap;
            String value10 = params.substring("teams_".length(), params.length() - "_players_alive".length());
            String gamesStr = HashMapHandler.getPlayerGameID(p.getUniqueId());
            if (gamesStr == null && p.getPlayer() != null) {
                gamesStr = p.getPlayer().getWorld().getName().replace("Areas/", "");
            }
            if (gamesStr != null && (teamsMap = TeamManager.teamsPerGame.get(gamesStr)) != null && teamsMap.containsKey(value10)) {
                List<Player> teamPlayers = teamsMap.get(value10);
                int alive = 0;
                if (teamPlayers != null) {
                    for (Player pl : teamPlayers) {
                        if (pl == null || !TeamManager.isPlayerAlive(gamesStr, pl)) continue;
                        ++alive;
                    }
                }
                return String.valueOf(alive);
            }
            return "0";
        }
        if (params.equalsIgnoreCase("game_teams_left")) {
            Map<String, List<Player>> teams;
            String value11 = HashMapHandler.getPlayerGameID(p.getUniqueId());
            if (value11 == null && p.getPlayer() != null) {
                value11 = p.getPlayer().getWorld().getName().replace("Areas/", "");
            }
            if (value11 != null && (teams = TeamManager.teamsPerGame.get(value11)) != null) {
                int kills = 0;
                Iterator<Map.Entry<String, List<Player>>> var31 = teams.entrySet().iterator();
                while (true) {
                    if (!var31.hasNext()) {
                        return String.valueOf(kills);
                    }
                    Map.Entry<String, List<Player>> entry = var31.next();
                    List<Player> teamPlayers = entry.getValue();
                    if (teamPlayers == null || teamPlayers.isEmpty()) continue;
                    boolean hasLivingPlayer = false;
                    for (Player teamPlayer : teamPlayers) {
                        if (teamPlayer == null || !teamPlayer.isOnline() || teamPlayer.isDead()) continue;
                        hasLivingPlayer = true;
                        break;
                    }
                    if (!hasLivingPlayer) continue;
                    ++kills;
                }
            }
            return "0";
        }
        if (params.equalsIgnoreCase("game_teams_player_left")) {
            Map<String, List<Player>> teams;
            String value12 = HashMapHandler.getPlayerGameID(p.getUniqueId());
            if (value12 == null && p.getPlayer() != null) {
                value12 = p.getPlayer().getWorld().getName().replace("Areas/", "");
            }
            if (value12 != null && (teams = TeamManager.teamsPerGame.get(value12)) != null) {
                for (Map.Entry<String, List<Player>> entry : teams.entrySet()) {
                    List<Player> validGames = entry.getValue();
                    if (validGames == null || !validGames.contains(p.getPlayer())) continue;
                    int livingTeammates = 0;
                    for (Player teamPlayer : validGames) {
                        if (teamPlayer == null || !teamPlayer.isOnline() || teamPlayer.isDead()) continue;
                        ++livingTeammates;
                    }
                    return String.valueOf(livingTeammates);
                }
            }
            return "0";
        }
        if (params.equalsIgnoreCase("game_team_player")) {
            String value13 = HashMapHandler.getPlayerGameID(p.getUniqueId());
            if (value13 == null && p.getPlayer() != null) {
                value13 = p.getPlayer().getWorld().getName().replace("Areas/", "");
            }
            return value13 != null ? TeamManager.getPlayerTeam(value13, p.getPlayer()) : "N/A";
        }
        if (params.equalsIgnoreCase("game_team_player_name")) {
            String value14 = HashMapHandler.getPlayerGameID(p.getUniqueId());
            FileConfiguration config = HashMapHandler.getConfigGameID(value14);
            if (value14 != null && config != null) {
                String suffix = TeamManager.getPlayerTeam(value14, p.getPlayer());
                String TeamColor = config.getString("SpawnLocations." + suffix + ".Name");
                return MSG.chatColors(TeamColor);
            }
            return "N/A";
        }
        if (params.equalsIgnoreCase("game_team_player_color")) {
            String value15 = HashMapHandler.getPlayerGameID(p.getUniqueId());
            FileConfiguration config = HashMapHandler.getConfigGameID(value15);
            if (value15 != null && config != null) {
                String suffix = TeamManager.getPlayerTeam(value15, p.getPlayer());
                String TeamColor = config.getString("SpawnLocations." + suffix + ".Color");
                return TeamColor;
            }
            return "N/A";
        }
        if (params.startsWith("game_team_")) {
            String[] parts3 = params.split("_");
            if (parts3.length >= 5 && parts3[parts3.length - 1].equals("color")) {
                FileConfiguration config;
                String gamesStr = parts3[2];
                String suffix = parts3[3];
                if (gamesStr.equals("${player}") && p != null) {
                    gamesStr = HashMapHandler.getPlayerGameID(p.getUniqueId());
                }
                if ((config = HashMapHandler.getConfigGameID(gamesStr)) == null) {
                    return "Game not found";
                }
                String teamColor = config.getString("SpawnLocations." + suffix + ".Color", "Unknown");
                return teamColor;
            }
            return "Invalid format";
        }
        if (params.equalsIgnoreCase("games_current_players")) {
            String value16 = HashMapHandler.getPlayerGameID(p.getUniqueId());
            if (value16 == null && p.getPlayer() != null) {
                value16 = p.getPlayer().getWorld().getName().replace("Areas/", "");
            }
            if (value16 != null) {
                List<Player> members = HashMapHandler.getMembersGameID(value16);
                return String.valueOf(members.size());
            }
            return "0";
        }
        if (params.equalsIgnoreCase("games_players_started_count")) {
            String value17 = HashMapHandler.getPlayerGameID(p.getUniqueId());
            if (value17 == null && p.getPlayer() != null) {
                value17 = p.getPlayer().getWorld().getName().replace("Areas/", "");
            }
            if (value17 != null) {
                int position5 = HashMapHandler.getPlayersStartedGameID(value17);
                return String.valueOf(position5);
            }
            return "0";
        }
        if (params.equalsIgnoreCase("games_max_players")) {
            String value18 = HashMapHandler.getPlayerGameID(p.getUniqueId());
            if (value18 == null && p.getPlayer() != null) {
                value18 = p.getPlayer().getWorld().getName().replace("Areas/", "");
            }
            if (value18 != null) {
                FileConfiguration config = HashMapHandler.getConfigGameID(value18);
                String suffix = config.getString("SpawnLocations.MaximumPlayers");
                return suffix;
            }
            return "0";
        }
        if (params.equalsIgnoreCase("games_min_players")) {
            String value19 = HashMapHandler.getPlayerGameID(p.getUniqueId());
            if (value19 == null && p.getPlayer() != null) {
                value19 = p.getPlayer().getWorld().getName().replace("Areas/", "");
            }
            if (value19 != null) {
                FileConfiguration config = HashMapHandler.getConfigGameID(value19);
                String suffix = config.getString("SpawnLocations.MinimumPlayers");
                return suffix;
            }
            return "0";
        }
        if (params.startsWith("list")) {
            String value20 = params.substring("list_".length());
            if (value20.startsWith("mode_")) {
                String gamesStr = value20.substring("mode_".length());
                List<String> playtimeLeaderboard = FindGames.FindTeamMode(gamesStr);
                if (playtimeLeaderboard != null && !playtimeLeaderboard.isEmpty()) {
                    String var10000 = String.join((CharSequence)", ", playtimeLeaderboard.subList(0, playtimeLeaderboard.size() - 1));
                    return var10000 + " & " + playtimeLeaderboard.get(playtimeLeaderboard.size() - 1);
                }
                return "N/A";
            }
            if (value20.contains("maxteams") && value20.contains("maxplayers")) {
                String[] parts4;
                String[] var67 = parts4 = value20.split("_");
                int games = parts4.length;
                for (int alive = 0; alive < games; ++alive) {
                    String part = var67[alive];
                    System.out.println(part);
                }
                if (parts4.length == 4 && parts4[0].equals("maxteams") && parts4[2].equals("maxplayers")) {
                    try {
                        int kills = Integer.parseInt(parts4[1]);
                        games = Integer.parseInt(parts4[3]);
                        List<String> validGames = FindGames.FindTeamSize(games, kills);
                        if (validGames != null && !validGames.isEmpty()) {
                            String var10000 = String.join((CharSequence)", ", validGames.subList(0, validGames.size() - 1));
                            return var10000 + " & " + validGames.get(validGames.size() - 1);
                        }
                        return "N/A";
                    }
                    catch (NumberFormatException var14) {
                        return "Invalid format";
                    }
                }
                System.out.println("Invalid format for maxteams and maxplayers in gameName: " + value20);
                return "Invalid format";
            }
            return "N/A";
        }
        if (params.startsWith("game_info")) {
            value = params.substring("game_info_".length());
            if (value.endsWith("_active") || value.endsWith("_total")) {
                value = value.substring(0, value.length() - 7);
            }
            Integer runningGames = LocalCache.getRunningGames(value);
            Integer totalGames = LocalCache.getTotalGames(value);
            if (runningGames == null || totalGames == null) {
                return "N/A";
            }
            if (params.endsWith("_active")) {
                return String.valueOf(runningGames);
            }
            if (params.endsWith("_total")) {
                return String.valueOf(totalGames);
            }
        }
        if (params.equalsIgnoreCase("game_id")) {
            value = HashMapHandler.getPlayerGameID(p.getUniqueId());
            if (value != null) {
                return value;
            }
            return "";
        }
        if (params.equalsIgnoreCase("game_displayname")) {
            value = HashMapHandler.getPlayerGameID(p.getUniqueId());
            if (value == null && p.getPlayer() != null) {
                value = p.getPlayer().getWorld().getName().replace("Areas/", "");
            }
            if (value != null) {
                FileConfiguration config = HashMapHandler.getConfigGameID(value);
                String suffix = MSG.chatColors(config.getString("Settings.DisplayName"));
                return suffix;
            }
            return "";
        }
        if (params.equalsIgnoreCase("game_timer")) {
            return this.getFormattedTimer(p.getPlayer(), HashMapHandler::getRemainingGameTime);
        }
        if (params.equalsIgnoreCase("item_timer")) {
            return this.getFormattedTimer(p.getPlayer(), HashMapHandler::getRemainingItemTime);
        }
        if (params.equalsIgnoreCase("lava_timer")) {
            return this.getFormattedTimer(p.getPlayer(), HashMapHandler::getLavaTime);
        }
        if (params.equalsIgnoreCase("kills")) {
            return DatabaseManager.getInstance().getSetting(p.getUniqueId(), "Kills");
        }
        if (params.equalsIgnoreCase("level")) {
            return DatabaseManager.getInstance().getSetting(p.getUniqueId(), "Level");
        }
        if (params.equalsIgnoreCase("level_xp")) {
            return DatabaseManager.getInstance().getSetting(p.getUniqueId(), "XP");
        }
        if (params.equalsIgnoreCase("level_xp_needed")) {
            int position6 = Integer.parseInt(DatabaseManager.getInstance().getSetting(p.getUniqueId(), "Level"));
            position6 = 750 * position6 + 250;
            return String.valueOf(position6);
        }
        if (params.equalsIgnoreCase("winstreak_current")) {
            return DatabaseManager.getInstance().getSetting(p.getUniqueId(), "winstreak");
        }
        if (params.equalsIgnoreCase("winstreak_highscore")) {
            return DatabaseManager.getInstance().getSetting(p.getUniqueId(), "total_winstreak");
        }
        if (params.equalsIgnoreCase("games_played")) {
            return DatabaseManager.getInstance().getSetting(p.getUniqueId(), "total_played_games");
        }
        if (params.equalsIgnoreCase("game_ratio")) {
            try {
                int position7 = Integer.parseInt(DatabaseManager.getInstance().getSetting(p.getUniqueId(), "total_played_games"));
                position7 = Integer.parseInt(DatabaseManager.getInstance().getSetting(p.getUniqueId(), "wins"));
                double winRatio = 0.0;
                if (position7 > 0) {
                    winRatio = (double)position7 / (double)position7;
                }
                winRatio = Math.min(winRatio, 1.0);
                return String.valueOf(winRatio);
            }
            catch (NullPointerException | NumberFormatException var15) {
                return "0.0";
            }
        }
        if (params.equalsIgnoreCase("gameid")) {
            String suffix;
            value = HashMapHandler.getPlayerGameID(p.getUniqueId());
            if (value == null && p.getPlayer() != null && p.getPlayer().isOnline() && (suffix = (world = p.getPlayer().getWorld()).getName()).startsWith("Areas/")) {
                value = suffix.substring("Areas/".length());
            }
            return value != null ? value : "N/A";
        }
        if (params.equalsIgnoreCase("games_losses")) {
            int position8 = Integer.parseInt(DatabaseManager.getInstance().getSetting(p.getUniqueId(), "total_played_games"));
            position8 = Integer.parseInt(DatabaseManager.getInstance().getSetting(p.getUniqueId(), "wins"));
            int kills = position8 - position8;
            return String.valueOf(kills);
        }
        if (params.equalsIgnoreCase("wins")) {
            return DatabaseManager.getInstance().getSetting(p.getUniqueId(), "wins");
        }
        if (params.equalsIgnoreCase("game_spectators_total")) {
            value = HashMapHandler.getPlayerGameID(p.getUniqueId());
            if (value != null && (world = Bukkit.getWorld((String)value)) != null) {
                int kills = 0;
                for (Player player : world.getPlayers()) {
                    if (player.getGameMode() != GameMode.SPECTATOR) continue;
                    ++kills;
                }
                return String.valueOf(kills);
            }
            return "0";
        }
        if (params.equalsIgnoreCase("player_isadmin")) {
            if (p.getPlayer().hasPermission("mpa.admin")) {
                return "yes";
            }
            return "no";
        }
        if (params.startsWith("leaderboard_xp_") && params.contains("_") && (parts = params.split("_")).length == 4) {
            try {
                position = Integer.parseInt(parts[2]);
                if (parts[3].equals("value")) {
                    String suffix = DatabaseManager.getInstance().getLeaderboardXPValue(position);
                    return suffix != null ? suffix : "No data";
                }
                if (parts[3].equals("name")) {
                    String suffix = DatabaseManager.getInstance().getLeaderboardXPName(position);
                    return suffix != null ? suffix : "No data";
                }
            }
            catch (NumberFormatException var22) {
                return "Invalid place number";
            }
        }
        if (params.startsWith("leaderboard_kills_") && params.contains("_") && (parts = params.split("_")).length == 4) {
            try {
                position = Integer.parseInt(parts[2]);
                if (parts[3].equals("value")) {
                    String suffix = DatabaseManager.getInstance().getLeaderboardKillsValue(position);
                    return suffix != null ? suffix : "No data";
                }
                if (parts[3].equals("name")) {
                    String suffix = DatabaseManager.getInstance().getLeaderboardKillsName(position);
                    return suffix != null ? suffix : "No data";
                }
            }
            catch (NumberFormatException var21) {
                return "Invalid place number";
            }
        }
        if (params.startsWith("leaderboard_level_") && params.contains("_") && (parts = params.split("_")).length == 4) {
            try {
                position = Integer.parseInt(parts[2]);
                if (parts[3].equals("value")) {
                    String suffix = DatabaseManager.getInstance().getLeaderboardLevelValue(position);
                    return suffix != null ? suffix : "No data";
                }
                if (parts[3].equals("name")) {
                    String suffix = DatabaseManager.getInstance().getLeaderboardLevelName(position);
                    return suffix != null ? suffix : "No data";
                }
            }
            catch (NumberFormatException var20) {
                return "Invalid place number";
            }
        }
        if (params.startsWith("leaderboard_wins_") && params.contains("_") && (parts = params.split("_")).length == 4) {
            try {
                position = Integer.parseInt(parts[2]);
                if (parts[3].equals("value")) {
                    String suffix = DatabaseManager.getInstance().getLeaderboardWinsValue(position);
                    return suffix != null ? suffix : "No data";
                }
                if (parts[3].equals("name")) {
                    String suffix = DatabaseManager.getInstance().getLeaderboardWinsName(position);
                    return suffix != null ? suffix : "No data";
                }
            }
            catch (NumberFormatException var19) {
                return "Invalid place number";
            }
        }
        if (params.startsWith("leaderboard_playtime_") && params.contains("_") && (parts = params.split("_")).length == 4) {
            try {
                position = Integer.parseInt(parts[2]);
                List<PlaytimeEntry> playtimeLeaderboard = this.getPlaytimeLeaderboard();
                if (position > 0 && position <= playtimeLeaderboard.size()) {
                    PlaytimeEntry entry = playtimeLeaderboard.get(position - 1);
                    if (parts[3].equals("value")) {
                        return this.formatPlaytimeForLeaderboard(entry.getPlaytimeSeconds());
                    }
                    if (parts[3].equals("name")) {
                        return entry.getPlayerName();
                    }
                }
                return "No data";
            }
            catch (NumberFormatException var16) {
                return "Invalid place number";
            }
        }
        if (params.equals("leaderboard_wins_position")) {
            position = DatabaseManager.getInstance().getPlayerLeaderboardRank(p.getUniqueId(), "wins");
            return position > 0 ? String.valueOf(position) : "N/A";
        }
        if (params.equals("leaderboard_kills_position")) {
            position = DatabaseManager.getInstance().getPlayerLeaderboardRank(p.getUniqueId(), "Kills");
            return position > 0 ? String.valueOf(position) : "N/A";
        }
        if (params.equals("leaderboard_xp_position")) {
            position = DatabaseManager.getInstance().getPlayerLeaderboardRank(p.getUniqueId(), "XP");
            return position > 0 ? String.valueOf(position) : "N/A";
        }
        if (params.equals("leaderboard_level_position")) {
            position = DatabaseManager.getInstance().getPlayerLeaderboardRank(p.getUniqueId(), "Level");
            return position > 0 ? String.valueOf(position) : "N/A";
        }
        if (params.equals("winrate")) {
            value = DatabaseManager.getInstance().getSetting(p.getUniqueId(), "wins");
            String gamesStr = DatabaseManager.getInstance().getSetting(p.getUniqueId(), "total_played_games");
            if (value != null && gamesStr != null) {
                int kills = Integer.parseInt(value);
                int games = Integer.parseInt(gamesStr);
                if (games > 0) {
                    double winrate = (double)kills / (double)games * 100.0;
                    return String.format("%.1f", winrate);
                }
            }
            return "0.0";
        }
        if (params.equals("kd_ratio")) {
            value = DatabaseManager.getInstance().getSetting(p.getUniqueId(), "Kills");
            position = 0;
            if (p.isOnline()) {
                position = p.getPlayer().getStatistic(Statistic.DEATHS);
            } else {
                try {
                    position = p.getStatistic(Statistic.DEATHS);
                }
                catch (Exception winrate) {
                    // empty catch block
                }
            }
            if (value != null) {
                int kills = Integer.parseInt(value);
                if (position > 0) {
                    double kd = (double)kills / (double)position;
                    return String.format("%.2f", kd);
                }
                if (kills > 0) {
                    return String.valueOf(kills);
                }
            }
            return "0.0";
        }
        if (params.equalsIgnoreCase("vanished")) {
            if (p != null && p.isOnline() && p.getPlayer() != null) {
                Player player = p.getPlayer();
                playerUUID = p.getUniqueId();
                boolean isVanished = PlayerVisibilityListener.isVanished(playerUUID);
                if (isVanished && player.hasPermission("mpa.vanish.placeholder")) {
                    return " &8[&6&lVanished&8]&r";
                }
            }
            return "";
        }
        if (!params.startsWith("leaderboard_yourposition_")) {
            if (params.equalsIgnoreCase("ishidden")) {
                if (p != null && p.isOnline() && p.getPlayer() != null) {
                    Player player = p.getPlayer();
                    playerUUID = p.getUniqueId();
                    PlayerVisibilityListener.VisibilityState state = PlayerVisibilityListener.getPlayerVisibilityState(playerUUID);
                    if (state != null && state.isHideMe() && player.hasPermission("mpa.hideme.placeholder")) {
                        return " &8[&6&lHidden&8]&r";
                    }
                }
                return "";
            }
            if (params.equalsIgnoreCase("hideothers")) {
                if (p != null && p.isOnline() && p.getPlayer() != null) {
                    Player player = p.getPlayer();
                    playerUUID = p.getUniqueId();
                    PlayerVisibilityListener.VisibilityState state = PlayerVisibilityListener.getPlayerVisibilityState(playerUUID);
                    if (state != null && state.isHideOthers() && player.hasPermission("mpa.hideothers.placeholder")) {
                        return " &8[&6&lHideOthers&8]&r";
                    }
                }
                return "";
            }
            if (params.startsWith("worldclock_")) {
                value = params.substring("worldclock_".length());
                if (value.startsWith("{") && value.endsWith("}")) {
                    value = value.substring(1, value.length() - 1);
                }
                try {
                    ZoneId zoneId = ZoneId.of(value);
                    ZonedDateTime now = ZonedDateTime.now(zoneId);
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy HH:mm:ss");
                    return now.format(formatter);
                }
                catch (Exception var18) {
                    return "Invalid timezone: " + value;
                }
            }
            if (params.equals("worldclock_available_zones")) {
                return String.join((CharSequence)", ", ZoneId.getAvailableZoneIds());
            }
            if (params.startsWith("addon_")) {
                if (MoonLab.getInstance().getAddonsManager() != null) {
                    value = MoonLab.getInstance().getAddonsManager().getPlaceholderValue(params, p);
                    return value != null ? value : "";
                }
                return "";
            }
            return "";
        }
        value = params.substring("leaderboard_yourposition_".length());
        if (p != null) {
            String suffix;
            position = DatabaseManager.getInstance().getLeaderboardYourPosition(p.getUniqueId(), value);
            if (position <= 0) {
                return "Not ranked";
            }
            if (position % 100 >= 11 && position % 100 <= 13) {
                suffix = "th";
            } else {
                switch (position % 10) {
                    case 1: {
                        suffix = "st";
                        break;
                    }
                    case 2: {
                        suffix = "nd";
                        break;
                    }
                    case 3: {
                        suffix = "rd";
                        break;
                    }
                    default: {
                        suffix = "th";
                    }
                }
            }
            return position + suffix;
        }
        return "N/A";
    }

    private List<PlaytimeEntry> getPlaytimeLeaderboard() {
        long currentTime = System.currentTimeMillis();
        if (!cachedPlaytimeLeaderboard.isEmpty() && currentTime - lastLeaderboardUpdate < 300000L) {
            return cachedPlaytimeLeaderboard;
        }
        ArrayList<PlaytimeEntry> newLeaderboard = new ArrayList<PlaytimeEntry>(100);
        OfflinePlayer[] offlinePlayers = Bukkit.getOfflinePlayers();
        int maxPlayersToProcess = Math.min(offlinePlayers.length, 5000);
        for (int i = 0; i < maxPlayersToProcess; ++i) {
            OfflinePlayer player = offlinePlayers[i];
            if (player == null || player.getName() == null) continue;
            UUID uuid = player.getUniqueId();
            if (DatabaseManager.getInstance().isPlayerExcludedFromLeaderboards(uuid)) continue;
            try {
                int playTimeTicks = player.getStatistic(Statistic.PLAY_ONE_MINUTE);
                long playtimeSeconds = playTimeTicks / 20;
                if (playtimeSeconds > 0L) {
                    this.insertIntoSortedLeaderboard(newLeaderboard, new PlaytimeEntry(player.getName(), playtimeSeconds), 100);
                }
                if (i % 1000 != 999) continue;
                System.gc();
                continue;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        cachedPlaytimeLeaderboard = newLeaderboard;
        lastLeaderboardUpdate = currentTime;
        return cachedPlaytimeLeaderboard;
    }

    private void insertIntoSortedLeaderboard(List<PlaytimeEntry> leaderboard, PlaytimeEntry entry, int maxSize) {
        int position;
        for (position = 0; position < leaderboard.size() && leaderboard.get(position).getPlaytimeSeconds() > entry.getPlaytimeSeconds(); ++position) {
        }
        if (position < maxSize) {
            leaderboard.add(position, entry);
            if (leaderboard.size() > maxSize) {
                leaderboard.remove(maxSize);
            }
        }
    }

    private String formatPlaytimeForLeaderboard(long seconds) {
        long days = TimeUnit.SECONDS.toDays(seconds);
        long hours = TimeUnit.SECONDS.toHours(seconds) % 24L;
        long minutes = TimeUnit.SECONDS.toMinutes(seconds) % 60L;
        if (days > 0L) {
            return days + "d " + hours + "h";
        }
        return hours > 0L ? hours + "h " + minutes + "m" : minutes + "m";
    }

    private String getFormattedTimer(Player p, Function<String, Integer> timeFunction) {
        String playerGameID = HashMapHandler.getPlayerGameID(p.getUniqueId());
        if (playerGameID == null) {
            String worldName = p.getWorld().getName();
            if (!worldName.startsWith("Areas/")) {
                return "0";
            }
            playerGameID = worldName.replace("Areas/", "");
        }
        return MoonLab.formatTime(timeFunction.apply(playerGameID));
    }

    private static void $$$reportNull$$$0(int var0) {
        throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "params", "org/kloppie74/MoonPillars/PaperMC/PlaceHolder", "onRequest"));
    }

    private static class PlaytimeEntry {
        private final String playerName;
        private final long playtimeSeconds;

        public PlaytimeEntry(String playerName, long playtimeSeconds) {
            this.playerName = playerName;
            this.playtimeSeconds = playtimeSeconds;
        }

        public String getPlayerName() {
            return this.playerName;
        }

        public long getPlaytimeSeconds() {
            return this.playtimeSeconds;
        }
    }
}

