/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.ClientBrandChecker;

public class ClientCommand
implements CommandExecutor,
TabCompleter {
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("mpa.notify.client")) {
            sender.sendMessage(MSG.chatColors("&cYou don't have permission to use this command."));
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(MSG.chatColors("&cUsage: /client <username>"));
            return true;
        }
        String targetName = args[0];
        Player target = Bukkit.getPlayerExact((String)targetName);
        if (target == null) {
            sender.sendMessage(MSG.chatColors("&cPlayer &f" + targetName + " &cis not online."));
            return true;
        }
        String clientBrand = ClientBrandChecker.getPlayerClientBrand(target);
        List<String> mods = ClientBrandChecker.getPlayerMods(target);
        String clientType = ClientBrandChecker.getClientTypeName(clientBrand);
        sender.sendMessage(MSG.chatColors("&8&m-------------------------------------"));
        sender.sendMessage(MSG.chatColors("&f" + target.getName() + "'s &7client information:"));
        sender.sendMessage(MSG.chatColors("&8\u2022 &7Client: &f" + clientType + " &8(&f" + clientBrand + "&8)"));
        if (!mods.isEmpty()) {
            sender.sendMessage(MSG.chatColors("&8\u2022 &7Mods: &f" + mods.size()));
            for (int i = 0; i < Math.min(mods.size(), 10); ++i) {
                String var10001 = mods.get(i);
                sender.sendMessage(MSG.chatColors("  &8- &f" + var10001));
            }
            if (mods.size() > 10) {
                int var11 = mods.size();
                sender.sendMessage(MSG.chatColors("  &8- &7...and " + (var11 - 10) + " more"));
            }
        } else {
            sender.sendMessage(MSG.chatColors("&8\u2022 &7No mods detected"));
        }
        sender.sendMessage(MSG.chatColors("&8&m-------------------------------------"));
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> completions = new ArrayList<String>();
        if (args.length == 1) {
            String partialName = args[0].toLowerCase();
            completions = Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(name -> name.toLowerCase().startsWith(partialName)).collect(Collectors.toList());
        }
        return completions;
    }
}

