/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandMap
 *  org.bukkit.command.PluginCommand
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.event.HandlerList
 *  org.bukkit.event.Listener
 *  org.bukkit.permissions.Permission
 *  org.bukkit.permissions.PermissionDefault
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 */
package org.kloppie74.MoonPillars.PaperMC.AddonsManager;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandMap;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.kloppie74.MoonPillars.PaperMC.AddonsManager.CommandDefinition;
import org.kloppie74.MoonPillars.PaperMC.AddonsManager.MoonAddon;
import org.kloppie74.MoonPillars.PaperMC.AddonsManager.PermissionDefinition;
import org.kloppie74.MoonPillars.PaperMC.AddonsManager.PlaceholderRegistry;
import org.kloppie74.MoonPillars.PaperMC.AddonsManager.SubcommandTabCompleter;

public class AddonsManager {
    private final JavaPlugin plugin;
    private final Map<String, MoonAddon> loadedAddons = new HashMap<String, MoonAddon>();
    private final List<URLClassLoader> classLoaders = new ArrayList<URLClassLoader>();
    private final Map<String, Command> dynamicCommands = new HashMap<String, Command>();
    private final Map<String, List<String>> allSubcommands = new HashMap<String, List<String>>();
    private final Map<String, Map<String, String>> subcommandDescriptions = new HashMap<String, Map<String, String>>();
    private PlaceholderRegistry placeholderRegistry;
    private final Map<String, List<Listener>> addonListeners = new HashMap<String, List<Listener>>();

    public AddonsManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.placeholderRegistry = new PlaceholderRegistry(plugin);
    }

    public void loadAddons(File addonsFolder) {
        File[] addonFiles;
        if (!addonsFolder.exists()) {
            addonsFolder.mkdirs();
        }
        if ((addonFiles = addonsFolder.listFiles((dir, name) -> name.endsWith(".jar"))) != null) {
            File[] var3 = addonFiles;
            int var4 = addonFiles.length;
            for (int var5 = 0; var5 < var4; ++var5) {
                File file = var3[var5];
                try {
                    this.loadAddon(file);
                    continue;
                }
                catch (Exception var8) {
                    this.plugin.getLogger().log(Level.SEVERE, "Failed to load addon: " + file.getName(), var8);
                }
            }
        }
    }

    private void loadAddon(File file) throws Exception {
        URLClassLoader classLoader = new URLClassLoader(new URL[]{file.toURI().toURL()}, this.getClass().getClassLoader());
        this.classLoaders.add(classLoader);
        try (JarFile jarFile = new JarFile(file);){
            Enumeration<JarEntry> entries = jarFile.entries();
            ArrayList<String> classNames = new ArrayList<String>();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                if (!entry.getName().endsWith(".class")) continue;
                String className = entry.getName().replace('/', '.').replace('\\', '.').replace(".class", "");
                classNames.add(className);
            }
            for (String className : classNames) {
                try {
                    Class<?> clazz = classLoader.loadClass(className);
                    if (!MoonAddon.class.isAssignableFrom(clazz) || clazz.isInterface()) continue;
                    MoonAddon addon = (MoonAddon)clazz.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                    this.enableAddon(addon);
                    break;
                }
                catch (Exception var11) {
                    this.plugin.getLogger().log(Level.WARNING, "Failed to load class: " + className, var11);
                }
            }
        }
    }

    private void enableAddon(MoonAddon addon) {
        try {
            String var10001;
            Logger var10000;
            String addonName = addon.getName();
            if (this.loadedAddons.containsKey(addonName)) {
                this.plugin.getLogger().warning("Addon with name " + addonName + " is already loaded. Skipping.");
                return;
            }
            this.plugin.getLogger().info("Enabling addon: " + addonName);
            addon.onEnable((Plugin)this.plugin);
            ArrayList<Listener> registered = new ArrayList<Listener>();
            for (Listener listener : addon.getListeners()) {
                this.plugin.getServer().getPluginManager().registerEvents(listener, (Plugin)this.plugin);
                registered.add(listener);
                var10000 = this.plugin.getLogger();
                var10001 = listener.getClass().getSimpleName();
                var10000.info("Registered listener " + var10001 + " from addon: " + addonName);
            }
            this.addonListeners.put(addonName, registered);
            Map<String, CommandExecutor> commands = addon.getCommands();
            Map<String, TabCompleter> tabCompleters = addon.getTabCompleters();
            Map<String, CommandDefinition> commandDefs = addon.getCommandDefinitions();
            for (Map.Entry<String, CommandExecutor> entry : commands.entrySet()) {
                String commandName = entry.getKey();
                CommandExecutor executor = entry.getValue();
                TabCompleter tabCompleter = tabCompleters.get(commandName);
                CommandDefinition commandDef = commandDefs.get(commandName);
                this.registerDynamicCommand(commandDef, executor, tabCompleter, addonName);
                this.plugin.getLogger().info("Registered command " + commandName + " from addon: " + addonName);
            }
            for (PermissionDefinition permDef : addon.getPermissionDefinitions()) {
                this.registerPermission(permDef, addonName);
                var10000 = this.plugin.getLogger();
                var10001 = permDef.getName();
                var10000.info("Registered permission " + var10001 + " from addon: " + addonName);
            }
            this.processSubcommands(addon);
            this.registerAddonPlaceholders(addon);
            this.loadedAddons.put(addonName, addon);
            this.plugin.getLogger().info("Enabled addon: " + addonName + " v" + addon.getVersion());
        }
        catch (Exception var13) {
            this.plugin.getLogger().severe("Failed to enable addon: " + addon.getName());
            var13.printStackTrace();
        }
    }

    private void processSubcommands(MoonAddon addon) {
        Map<String, List<String>> addonSubcommands = addon.getSubcommands();
        Map<String, String> addonSubcmdDescriptions = addon.getSubcommandDescriptions();
        for (Map.Entry<String, List<String>> entry : addonSubcommands.entrySet()) {
            String commandName = entry.getKey();
            List<String> subcommands = entry.getValue();
            if (!this.allSubcommands.containsKey(commandName)) {
                this.allSubcommands.put(commandName, new ArrayList());
            }
            this.allSubcommands.get(commandName).addAll(subcommands);
            if (!this.subcommandDescriptions.containsKey(commandName)) {
                this.subcommandDescriptions.put(commandName, new HashMap());
            }
            for (String subcommand : subcommands) {
                String key = commandName + "." + subcommand;
                if (!addonSubcmdDescriptions.containsKey(key)) continue;
                this.subcommandDescriptions.get(commandName).put(subcommand, addonSubcmdDescriptions.get(key));
            }
        }
    }

    private void registerAddonPlaceholders(MoonAddon addon) {
        Map<String, Function<OfflinePlayer, String>> addonPlaceholders = addon.getPlaceholders();
        if (addonPlaceholders != null && !addonPlaceholders.isEmpty()) {
            String addonName = addon.getName();
            this.placeholderRegistry.registerAddonPlaceholders(addonName, addonPlaceholders);
            Logger var10000 = this.plugin.getLogger();
            int var10001 = addonPlaceholders.size();
            var10000.info("Registered " + var10001 + " placeholders from addon: " + addonName);
        } else {
            this.plugin.getLogger().info("No placeholders to register for addon: " + addon.getName());
        }
    }

    private boolean hasSubcommands(String commandName) {
        return this.allSubcommands.containsKey(commandName) && !this.allSubcommands.get(commandName).isEmpty();
    }

    private void registerDynamicCommand(CommandDefinition commandDef, CommandExecutor executor, TabCompleter tabCompleter, String addonName) {
        try {
            if (commandDef == null) {
                this.plugin.getLogger().warning("Command definition is null for addon: " + addonName);
                return;
            }
            PluginCommand command = this.createPluginCommand(commandDef.getName(), (Plugin)this.plugin);
            if (command != null) {
                command.setDescription(commandDef.getDescription());
                command.setUsage(commandDef.getUsage());
                if (commandDef.getPermission() != null) {
                    command.setPermission(commandDef.getPermission());
                }
                if (commandDef.getPermissionMessage() != null) {
                    command.setPermissionMessage(commandDef.getPermissionMessage());
                }
                if (!commandDef.getAliases().isEmpty()) {
                    command.setAliases(commandDef.getAliases());
                }
                command.setExecutor(executor);
                if (tabCompleter != null) {
                    command.setTabCompleter(tabCompleter);
                } else if (executor instanceof TabCompleter) {
                    command.setTabCompleter((TabCompleter)executor);
                } else if (this.hasSubcommands(commandDef.getName())) {
                    command.setTabCompleter((TabCompleter)new SubcommandTabCompleter(this, commandDef.getName()));
                }
                this.getCommandMap().register(this.plugin.getName().toLowerCase(), (Command)command);
                this.dynamicCommands.put(commandDef.getName(), (Command)command);
                Logger var10000 = this.plugin.getLogger();
                String var10001 = commandDef.getName();
                var10000.info("Registered dynamic command " + var10001 + " from addon: " + addonName);
            } else {
                Logger var10000 = this.plugin.getLogger();
                String var10001 = commandDef.getName();
                var10000.warning("Failed to create dynamic command " + var10001 + " for addon: " + addonName);
            }
        }
        catch (Exception var6) {
            this.plugin.getLogger().log(Level.SEVERE, "Error registering dynamic command " + commandDef.getName(), var6);
        }
    }

    private void registerPermission(PermissionDefinition permDef, String addonName) {
        try {
            if (Bukkit.getPluginManager().getPermission(permDef.getName()) != null) {
                this.plugin.getLogger().warning("Permission " + permDef.getName() + " is already registered. Skipping.");
                return;
            }
            PermissionDefault defaultValue = PermissionDefault.getByName((String)permDef.getDefaultValue());
            if (defaultValue == null) {
                defaultValue = PermissionDefault.OP;
            }
            Permission permission = new Permission(permDef.getName(), permDef.getDescription(), defaultValue);
            Bukkit.getPluginManager().addPermission(permission);
            Logger var10000 = this.plugin.getLogger();
            String var10001 = permDef.getName();
            var10000.info("Registered permission " + var10001 + " from addon: " + addonName);
        }
        catch (Exception var5) {
            this.plugin.getLogger().log(Level.SEVERE, "Error registering permission " + permDef.getName(), var5);
        }
    }

    private PluginCommand createPluginCommand(String name, Plugin plugin) {
        try {
            Constructor constructor = PluginCommand.class.getDeclaredConstructor(String.class, Plugin.class);
            constructor.setAccessible(true);
            return (PluginCommand)constructor.newInstance(name, plugin);
        }
        catch (Exception var4) {
            plugin.getLogger().log(Level.SEVERE, "Failed to create plugin command: " + name, var4);
            return null;
        }
    }

    private CommandMap getCommandMap() throws Exception {
        Field commandMapField = Bukkit.getServer().getClass().getDeclaredField("commandMap");
        commandMapField.setAccessible(true);
        return (CommandMap)commandMapField.get(Bukkit.getServer());
    }

    public MoonAddon getAddon(String name) {
        return this.loadedAddons.get(name);
    }

    public void disableAddons() {
        try {
            CommandMap commandMap = this.getCommandMap();
            for (String commandName : this.dynamicCommands.keySet()) {
                Command command = this.dynamicCommands.get(commandName);
                command.unregister(commandMap);
            }
        }
        catch (Exception var7) {
            this.plugin.getLogger().severe("Failed to unregister commands");
            var7.printStackTrace();
        }
        for (List<Listener> listeners : this.addonListeners.values()) {
            for (Listener listener : listeners) {
                HandlerList.unregisterAll((Listener)listener);
            }
        }
        this.addonListeners.clear();
        for (MoonAddon addon : this.loadedAddons.values()) {
            try {
                this.plugin.getLogger().info("Disabling addon: " + addon.getName());
                addon.onDisable();
                this.plugin.getLogger().info("Disabled addon: " + addon.getName());
            }
            catch (Exception var6) {
                this.plugin.getLogger().severe("Failed to disable addon: " + addon.getName());
                var6.printStackTrace();
            }
        }
        for (URLClassLoader loader : this.classLoaders) {
            try {
                loader.close();
            }
            catch (IOException var5) {
                this.plugin.getLogger().severe("Failed to close class loader");
                var5.printStackTrace();
            }
        }
        this.placeholderRegistry.clearPlaceholders();
        this.loadedAddons.clear();
        this.classLoaders.clear();
        this.allSubcommands.clear();
        this.subcommandDescriptions.clear();
        this.dynamicCommands.clear();
    }

    public void disableAddon(String addonName) {
        MoonAddon addon = this.loadedAddons.get(addonName);
        if (addon == null) {
            this.plugin.getLogger().warning("Addon '" + addonName + "' not found.");
        } else {
            try {
                CommandMap commandMap = this.getCommandMap();
                Iterator<Map.Entry<String, Command>> it = this.dynamicCommands.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry<String, Command> entry = it.next();
                    String commandName = entry.getKey();
                    Command command = entry.getValue();
                    if (!addon.getCommands().containsKey(commandName)) continue;
                    command.unregister(commandMap);
                    it.remove();
                }
            }
            catch (Exception var9) {
                this.plugin.getLogger().severe("Failed to unregister commands for addon: " + addonName);
                var9.printStackTrace();
            }
            List<Listener> listeners = this.addonListeners.remove(addonName);
            if (listeners != null) {
                for (Listener listener : listeners) {
                    HandlerList.unregisterAll((Listener)listener);
                    Logger var10000 = this.plugin.getLogger();
                    String var10001 = listener.getClass().getSimpleName();
                    var10000.info("Unregistered listener " + var10001 + " from addon: " + addonName);
                }
            }
            try {
                this.plugin.getLogger().info("Disabling addon: " + addonName);
                addon.onDisable();
                this.plugin.getLogger().info("Disabled addon: " + addonName);
            }
            catch (Exception var8) {
                this.plugin.getLogger().severe("Failed to disable addon: " + addonName);
                var8.printStackTrace();
            }
            this.loadedAddons.remove(addonName);
            this.allSubcommands.remove(addonName);
            this.subcommandDescriptions.remove(addonName);
            this.placeholderRegistry.unregisterAddonPlaceholders(addonName);
        }
    }

    public boolean loadAddon(File addonsFolder, String addonName) {
        File[] addonFiles = addonsFolder.listFiles((dir, name) -> name.endsWith(".jar"));
        if (addonFiles == null) {
            return false;
        }
        File[] var4 = addonFiles;
        int var5 = addonFiles.length;
        for (int var6 = 0; var6 < var5; ++var6) {
            File file = var4[var6];
            if (!file.getName().equalsIgnoreCase(addonName + ".jar")) continue;
            try {
                this.loadAddon(file);
                return true;
            }
            catch (Exception var9) {
                this.plugin.getLogger().log(Level.SEVERE, "Failed to load addon: " + file.getName(), var9);
                return false;
            }
        }
        this.plugin.getLogger().warning("Addon jar for '" + addonName + "' not found in " + addonsFolder.getAbsolutePath());
        return false;
    }

    public Map<String, MoonAddon> getLoadedAddons() {
        return new HashMap<String, MoonAddon>(this.loadedAddons);
    }

    public List<String> getSubcommandsForCommand(String commandName) {
        return this.allSubcommands.containsKey(commandName) ? new ArrayList(this.allSubcommands.get(commandName)) : new ArrayList();
    }

    public String getSubcommandDescription(String command, String subcommand) {
        return this.subcommandDescriptions.containsKey(command) && this.subcommandDescriptions.get(command).containsKey(subcommand) ? this.subcommandDescriptions.get(command).get(subcommand) : null;
    }

    public PlaceholderRegistry getPlaceholderRegistry() {
        return this.placeholderRegistry;
    }

    public boolean hasPlaceholder(String identifier) {
        return this.placeholderRegistry.hasPlaceholder(identifier);
    }

    public String getPlaceholderValue(String identifier, OfflinePlayer player) {
        return this.placeholderRegistry.getPlaceholderValue(identifier, player);
    }
}

