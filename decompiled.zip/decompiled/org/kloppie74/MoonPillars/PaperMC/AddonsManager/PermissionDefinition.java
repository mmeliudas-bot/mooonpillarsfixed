/*
 * Decompiled with CFR 0.152.
 */
package org.kloppie74.MoonPillars.PaperMC.AddonsManager;

public class PermissionDefinition {
    private final String name;
    private final String description;
    private final String defaultValue;

    public PermissionDefinition(String name, String description, String defaultValue) {
        this.name = name;
        this.description = description;
        this.defaultValue = defaultValue;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public String getDefaultValue() {
        return this.defaultValue;
    }
}

