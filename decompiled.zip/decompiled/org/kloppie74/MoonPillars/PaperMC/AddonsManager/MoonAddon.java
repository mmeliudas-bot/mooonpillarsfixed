/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.event.Listener
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.AddonsManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.TabCompleter;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.AddonsManager.CommandDefinition;
import org.kloppie74.MoonPillars.PaperMC.AddonsManager.PermissionDefinition;

public interface MoonAddon {
    public String getName();

    public String getVersion();

    public void onEnable(Plugin var1);

    public void onDisable();

    public List<Listener> getListeners();

    public Map<String, CommandExecutor> getCommands();

    default public Map<String, CommandDefinition> getCommandDefinitions() {
        return new HashMap<String, CommandDefinition>();
    }

    default public List<PermissionDefinition> getPermissionDefinitions() {
        return new ArrayList<PermissionDefinition>();
    }

    default public Map<String, TabCompleter> getTabCompleters() {
        return new HashMap<String, TabCompleter>();
    }

    default public Map<String, List<String>> getSubcommands() {
        return new HashMap<String, List<String>>();
    }

    default public Map<String, String> getSubcommandDescriptions() {
        return new HashMap<String, String>();
    }

    default public Map<String, Function<OfflinePlayer, String>> getPlaceholders() {
        return new HashMap<String, Function<OfflinePlayer, String>>();
    }
}

