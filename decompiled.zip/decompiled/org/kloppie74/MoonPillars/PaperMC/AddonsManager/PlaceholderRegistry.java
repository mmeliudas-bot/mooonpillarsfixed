/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.plugin.java.JavaPlugin
 */
package org.kloppie74.MoonPillars.PaperMC.AddonsManager;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.function.Function;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.java.JavaPlugin;

public class PlaceholderRegistry {
    private final Map<String, Function<OfflinePlayer, String>> placeholders = new HashMap<String, Function<OfflinePlayer, String>>();
    private final JavaPlugin plugin;

    public PlaceholderRegistry(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void registerAddonPlaceholders(String addonName, Map<String, Function<OfflinePlayer, String>> placeholderMap) {
        for (Map.Entry<String, Function<OfflinePlayer, String>> entry : placeholderMap.entrySet()) {
            this.registerPlaceholder(addonName, entry.getKey(), entry.getValue());
        }
        Logger var10000 = this.plugin.getLogger();
        int var10001 = placeholderMap.size();
        var10000.info("Registered " + var10001 + " placeholders for addon: " + addonName);
        this.plugin.getLogger().info("Currently registered placeholders: " + this.getPlaceholdersList());
    }

    public void unregisterAddonPlaceholders(String addonName) {
        String normalizedAddonName = addonName.toLowerCase();
        String prefix = "addon_" + normalizedAddonName + "_";
        int removed = 0;
        Iterator<String> it = this.placeholders.keySet().iterator();
        while (it.hasNext()) {
            String key = it.next();
            if (!key.startsWith(prefix)) continue;
            it.remove();
            ++removed;
        }
        this.plugin.getLogger().info("Unregistered " + removed + " placeholders for addon: " + addonName);
        this.plugin.getLogger().info("Currently registered placeholders: " + this.getPlaceholdersList());
    }

    public void registerPlaceholder(String addonName, String name, Function<OfflinePlayer, String> supplier) {
        String normalizedAddonName = addonName.toLowerCase();
        String normalizedName = name.toLowerCase();
        String fullIdentifier = "addon_" + normalizedAddonName + "_" + normalizedName;
        this.placeholders.put(fullIdentifier, supplier);
        this.plugin.getLogger().info("Registered placeholder: " + fullIdentifier);
    }

    public String getPlaceholderValue(String identifier, OfflinePlayer player) {
        String normalizedIdentifier = identifier.toLowerCase();
        if (normalizedIdentifier.contains("addon_addon_")) {
            normalizedIdentifier = normalizedIdentifier.replace("addon_addon_", "addon_");
            this.plugin.getLogger().info("Fixed double addon_ prefix, now: " + normalizedIdentifier);
        }
        if (!this.placeholders.containsKey(normalizedIdentifier)) {
            this.plugin.getLogger().info("Placeholder not found: " + normalizedIdentifier);
            this.plugin.getLogger().info("Available placeholders: " + this.getPlaceholdersList());
            return null;
        }
        Function<OfflinePlayer, String> supplier = this.placeholders.get(normalizedIdentifier);
        try {
            String result = supplier.apply(player);
            return result != null ? result : "";
        }
        catch (Exception var6) {
            this.plugin.getLogger().log(Level.WARNING, "Error getting placeholder value for " + normalizedIdentifier, var6);
            return "Error";
        }
    }

    public boolean hasPlaceholder(String identifier) {
        String normalizedIdentifier = identifier.toLowerCase();
        if (normalizedIdentifier.contains("addon_addon_")) {
            normalizedIdentifier = normalizedIdentifier.replace("addon_addon_", "addon_");
        }
        boolean exists = this.placeholders.containsKey(normalizedIdentifier);
        this.plugin.getLogger().info("Placeholder exists check: " + normalizedIdentifier + " = " + exists);
        return exists;
    }

    public void clearPlaceholders() {
        this.placeholders.clear();
        this.plugin.getLogger().info("Cleared all placeholders");
    }

    public Map<String, Function<OfflinePlayer, String>> getPlaceholders() {
        return new HashMap<String, Function<OfflinePlayer, String>>(this.placeholders);
    }

    public String getPlaceholdersList() {
        StringBuilder sb = new StringBuilder();
        for (String key : this.placeholders.keySet()) {
            sb.append(key).append(", ");
        }
        return sb.length() > 0 ? sb.substring(0, sb.length() - 2) : "none";
    }
}

