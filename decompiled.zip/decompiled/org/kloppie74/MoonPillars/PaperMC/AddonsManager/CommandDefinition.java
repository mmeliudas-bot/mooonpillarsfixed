/*
 * Decompiled with CFR 0.152.
 */
package org.kloppie74.MoonPillars.PaperMC.AddonsManager;

import java.util.ArrayList;
import java.util.List;

public class CommandDefinition {
    private final String name;
    private final String description;
    private final String usage;
    private final String permission;
    private final String permissionMessage;
    private final List<String> aliases;

    public CommandDefinition(String name, String description, String usage) {
        this(name, description, usage, null, null, new ArrayList<String>());
    }

    public CommandDefinition(String name, String description, String usage, String permission, String permissionMessage, List<String> aliases) {
        this.name = name;
        this.description = description;
        this.usage = usage;
        this.permission = permission;
        this.permissionMessage = permissionMessage;
        this.aliases = aliases;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public String getUsage() {
        return this.usage;
    }

    public String getPermission() {
        return this.permission;
    }

    public String getPermissionMessage() {
        return this.permissionMessage;
    }

    public List<String> getAliases() {
        return this.aliases;
    }

    public static class Builder {
        private String name;
        private String description = "";
        private String usage = "";
        private String permission = null;
        private String permissionMessage = null;
        private List<String> aliases = new ArrayList<String>();

        public Builder(String name) {
            this.name = name;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder usage(String usage) {
            this.usage = usage;
            return this;
        }

        public Builder permission(String permission) {
            this.permission = permission;
            return this;
        }

        public Builder permissionMessage(String permissionMessage) {
            this.permissionMessage = permissionMessage;
            return this;
        }

        public Builder alias(String alias) {
            this.aliases.add(alias);
            return this;
        }

        public Builder aliases(List<String> aliases) {
            this.aliases.addAll(aliases);
            return this;
        }

        public CommandDefinition build() {
            return new CommandDefinition(this.name, this.description, this.usage, this.permission, this.permissionMessage, this.aliases);
        }
    }
}

