/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 */
package org.kloppie74.MoonPillars.PaperMC.AddonsManager;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.AddonsManager.AddonsManager;
import org.kloppie74.MoonPillars.PaperMC.AddonsManager.MoonAddon;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class AddonsCommand
implements CommandExecutor,
TabCompleter {
    private final MoonLab plugin;
    private final AddonsManager addonsManager;

    public AddonsCommand(MoonLab plugin, AddonsManager addonsManager) {
        this.plugin = plugin;
        this.addonsManager = addonsManager;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("moonpillars.admin.addons")) {
            sender.sendMessage(MSG.chatColors("&cYou don't have permission to use this command."));
            return true;
        }
        if (args.length == 0) {
            this.displayHelp(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "list": {
                this.listAddons(sender);
                break;
            }
            case "reload": {
                if (args.length == 1) {
                    this.reloadAddons(sender);
                    break;
                }
                if (args.length == 2) {
                    this.reloadSingleAddon(sender, args[1]);
                    break;
                }
                sender.sendMessage(MSG.chatColors("&cUsage: /addons reload [addon]"));
                break;
            }
            case "info": {
                if (args.length < 2) {
                    sender.sendMessage(MSG.chatColors("&cUsage: /addons info <addon>"));
                    return true;
                }
                this.displayAddonInfo(sender, args[1]);
                break;
            }
            case "disable": {
                if (args.length < 2) {
                    sender.sendMessage(MSG.chatColors("&cUsage: /addons disable <addon>"));
                    return true;
                }
                this.disableSingleAddon(sender, args[1]);
                break;
            }
            default: {
                this.displayHelp(sender);
            }
        }
        return true;
    }

    private void disableSingleAddon(CommandSender sender, String addonName) {
        Map<String, MoonAddon> addons = this.addonsManager.getLoadedAddons();
        MoonAddon addon = addons.get(addonName);
        if (addon == null) {
            sender.sendMessage(MSG.chatColors("&cAddon '" + addonName + "' not found."));
        } else {
            sender.sendMessage(MSG.chatColors("&eDisabling addon '" + addonName + "'..."));
            this.addonsManager.disableAddon(addonName);
            sender.sendMessage(MSG.chatColors("&aAddon '" + addonName + "' disabled successfully!"));
        }
    }

    private void reloadSingleAddon(CommandSender sender, String addonName) {
        Map<String, MoonAddon> addons = this.addonsManager.getLoadedAddons();
        MoonAddon addon = addons.get(addonName);
        if (addon == null) {
            sender.sendMessage(MSG.chatColors("&cAddon '" + addonName + "' not found."));
        } else {
            sender.sendMessage(MSG.chatColors("&eDisabling addon '" + addonName + "'..."));
            this.addonsManager.disableAddon(addonName);
            File addonsFolder = new File(MoonLab.getInstance().getDataFolder(), "Addons");
            sender.sendMessage(MSG.chatColors("&eLoading addon '" + addonName + "'..."));
            boolean loaded = this.addonsManager.loadAddon(addonsFolder, addonName);
            if (loaded) {
                sender.sendMessage(MSG.chatColors("&aAddon '" + addonName + "' reloaded successfully!"));
            } else {
                sender.sendMessage(MSG.chatColors("&cFailed to reload addon '" + addonName + "'."));
            }
        }
    }

    private void displayHelp(CommandSender sender) {
        sender.sendMessage(MSG.chatColors("&6&lMoonPillars Addons Commands"));
        sender.sendMessage(MSG.chatColors("&e/addons list &7- List all loaded addons"));
        sender.sendMessage(MSG.chatColors("&e/addons reload &7- Reload all addons"));
        sender.sendMessage(MSG.chatColors("&e/addons info <addon> &7- Display info about an addon"));
        sender.sendMessage(MSG.chatColors("&e/addons disable <addon> &7- Disable a specific addon"));
    }

    private void listAddons(CommandSender sender) {
        Map<String, MoonAddon> addons = this.addonsManager.getLoadedAddons();
        if (addons.isEmpty()) {
            sender.sendMessage(MSG.chatColors("&eNo addons are currently loaded."));
        } else {
            sender.sendMessage(MSG.chatColors("&6&lLoaded Addons &7(" + addons.size() + ")"));
            for (MoonAddon addon : addons.values()) {
                String var10001 = addon.getName();
                sender.sendMessage(MSG.chatColors("&e- " + var10001 + " &7(v" + addon.getVersion() + ")"));
            }
        }
    }

    private void reloadAddons(CommandSender sender) {
        sender.sendMessage(MSG.chatColors("&eDisabling all addons..."));
        this.addonsManager.disableAddons();
        sender.sendMessage(MSG.chatColors("&eLoading addons..."));
        File addonsFolder = new File(MoonLab.getInstance().getDataFolder(), "Addons");
        this.addonsManager.loadAddons(addonsFolder);
        sender.sendMessage(MSG.chatColors("&aAddons reloaded successfully!"));
    }

    private void displayAddonInfo(CommandSender sender, String addonName) {
        Map<String, MoonAddon> addons = this.addonsManager.getLoadedAddons();
        MoonAddon addon = addons.get(addonName);
        if (addon == null) {
            sender.sendMessage(MSG.chatColors("&cAddon '" + addonName + "' not found."));
        } else {
            sender.sendMessage(MSG.chatColors("&6&lAddon Information"));
            sender.sendMessage(MSG.chatColors("&eName: &f" + addon.getName()));
            sender.sendMessage(MSG.chatColors("&eVersion: &f" + addon.getVersion()));
            int listeners = addon.getListeners() != null ? addon.getListeners().size() : 0;
            int commands = addon.getCommands() != null ? addon.getCommands().size() : 0;
            sender.sendMessage(MSG.chatColors("&eRegistered Listeners: &f" + listeners));
            sender.sendMessage(MSG.chatColors("&eRegistered Commands: &f" + commands));
        }
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (args.length == 1) {
            completions.add("list");
            completions.add("reload");
            completions.add("info");
            completions.add("disable");
            return this.filterCompletions(completions, args[0]);
        }
        if (args.length != 2 || !args[0].equalsIgnoreCase("info") && !args[0].equalsIgnoreCase("reload") && !args[0].equalsIgnoreCase("disable")) {
            return completions;
        }
        completions.addAll(this.addonsManager.getLoadedAddons().keySet());
        return this.filterCompletions(completions, args[1]);
    }

    private List<String> filterCompletions(List<String> completions, String current) {
        if (current.isEmpty()) {
            return completions;
        }
        ArrayList<String> filteredCompletions = new ArrayList<String>();
        for (String completion : completions) {
            if (!completion.toLowerCase().startsWith(current.toLowerCase())) continue;
            filteredCompletions.add(completion);
        }
        return filteredCompletions;
    }
}

