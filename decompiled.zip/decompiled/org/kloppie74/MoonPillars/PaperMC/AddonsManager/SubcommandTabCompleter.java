/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 */
package org.kloppie74.MoonPillars.PaperMC.AddonsManager;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.kloppie74.MoonPillars.PaperMC.AddonsManager.AddonsManager;

public class SubcommandTabCompleter
implements TabCompleter {
    private final AddonsManager addonsManager;
    private final String commandName;

    public SubcommandTabCompleter(AddonsManager addonsManager, String commandName) {
        this.addonsManager = addonsManager;
        this.commandName = commandName;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> subcommands = this.addonsManager.getSubcommandsForCommand(this.commandName);
            return this.filterCompletions(subcommands, args[0]);
        }
        return new ArrayList<String>();
    }

    private List<String> filterCompletions(List<String> completions, String currentArg) {
        return currentArg.isEmpty() ? completions : completions.stream().filter(s -> s.toLowerCase().startsWith(currentArg.toLowerCase())).collect(Collectors.toList());
    }
}

