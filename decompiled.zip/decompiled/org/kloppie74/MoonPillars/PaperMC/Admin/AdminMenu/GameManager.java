/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.AdminMenu;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminMenu.MenuManager;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.ForceStart;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.LeaveGameManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class GameManager
implements Listener {
    private static final int SIZE = 45;
    private static final String TITLE = MSG.chatColors("&8\u2726 &bGame Manager &8\u2726");

    public static Inventory AdminMenu(Player player) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)45, (String)TITLE);
        GameManager.fillBackground(inv);
        inv.setItem(11, GameManager.createMenuButton(Material.RED_DYE, "&cForce End A Game", "&7View and stop active games.", "&8Click to select a game to end."));
        inv.setItem(13, GameManager.createMenuButton(Material.GREEN_DYE, "&aForce Start A Game", "&7View and start available games.", "&8Click to select a game to start."));
        inv.setItem(15, GameManager.createMenuButton(Material.ORANGE_DYE, "&eForce Kick Player", "&7Kick a player from a game.", "&8Click to select a game."));
        inv.setItem(36, GameManager.createMenuButton(Material.BARRIER, "&c&lExit", "&7Return to Admin Menu."));
        inv.setItem(4, GameManager.createMenuButton(Material.NETHER_STAR, "&bGame Control Center", "&7Manage games and players."));
        GameManager.decorateBorders(inv, Material.BLUE_STAINED_GLASS_PANE);
        return inv;
    }

    private static void fillBackground(Inventory inv) {
        ItemStack bg = new ItemStack(Material.LIGHT_GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = bg.getItemMeta();
        meta.setDisplayName(" ");
        meta.addItemFlags(ItemFlag.values());
        bg.setItemMeta(meta);
        for (int i = 0; i < inv.getSize(); ++i) {
            inv.setItem(i, bg);
        }
    }

    private static void decorateBorders(Inventory inv, Material borderMat) {
        int[] borderSlots;
        ItemStack border = new ItemStack(borderMat);
        ItemMeta meta = border.getItemMeta();
        meta.setDisplayName(" ");
        meta.addItemFlags(ItemFlag.values());
        border.setItemMeta(meta);
        int[] var5 = borderSlots = new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 17, 18, 26, 27, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44};
        int var6 = borderSlots.length;
        for (int var7 = 0; var7 < var6; ++var7) {
            int slot = var5[var7];
            inv.setItem(slot, border);
        }
    }

    private static ItemStack createMenuButton(Material mat, String display, String ... loreLines) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(MSG.chatColors(display));
        ArrayList<String> lore = new ArrayList<String>();
        if (loreLines != null) {
            String[] var6 = loreLines;
            int var7 = loreLines.length;
            for (int var8 = 0; var8 < var7; ++var8) {
                String l = var6[var8];
                lore.add(MSG.chatColors(l));
            }
        }
        meta.setLore(lore);
        meta.addItemFlags(ItemFlag.values());
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void OnInventoryClick(InventoryClickEvent event) {
        Inventory inv = event.getClickedInventory();
        Player player = (Player)event.getWhoClicked();
        if (inv != null && event.getView().getTitle().equals(TITLE)) {
            event.setCancelled(true);
            ItemStack clicked = event.getCurrentItem();
            if (clicked != null && clicked.getType() != Material.AIR) {
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1.15f);
                if (event.getSlot() == 36) {
                    player.closeInventory();
                    Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(MenuManager.AdminMenu(player)), 1L);
                }
                if (event.getSlot() == 11) {
                    player.openInventory(GameManager.ForceEndGameMenu(player));
                }
                if (event.getSlot() == 13) {
                    player.openInventory(GameManager.ForceStartGameMenu(player));
                }
                if (event.getSlot() == 15) {
                    player.openInventory(GameManager.ForceSelectGameMenu(player));
                }
            }
        }
    }

    public static Inventory ForceEndGameMenu(Player player) {
        Inventory menu = Bukkit.createInventory((InventoryHolder)player, (int)36, (String)MSG.chatColors("&cForce End A Game"));
        GameManager.fillBackground(menu);
        for (String game : HashMapHandler.getAllMapGameIDs()) {
            if (!HashMapHandler.getIsGamePlaying(game).booleanValue()) continue;
            ItemStack gameItem = GameManager.createMenuButton(Material.PAPER, "&c" + game, "&7Click to force-stop this game.");
            menu.addItem(new ItemStack[]{gameItem});
        }
        return menu;
    }

    @EventHandler
    public void OnForceEndGameClick(InventoryClickEvent event) {
        Inventory inv = event.getClickedInventory();
        Player player = (Player)event.getWhoClicked();
        if (inv != null && event.getView().getTitle().equals(MSG.chatColors("&cForce End A Game"))) {
            String gameName;
            event.setCancelled(true);
            ItemStack clicked = event.getCurrentItem();
            if (clicked != null && clicked.getType() != Material.AIR && clicked.hasItemMeta() && clicked.getItemMeta().hasDisplayName() && HashMapHandler.getIsGamePlaying(gameName = clicked.getItemMeta().getDisplayName().replace("\u00a7c", "")).booleanValue()) {
                org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.GameManager.endGame(gameName, true);
                player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.6f, 1.3f);
                player.closeInventory();
                Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(GameManager.AdminMenu(player)), 1L);
            }
        }
    }

    public static Inventory ForceStartGameMenu(Player player) {
        Inventory menu = Bukkit.createInventory((InventoryHolder)player, (int)36, (String)MSG.chatColors("&aForce Start A Game"));
        GameManager.fillBackground(menu);
        for (String game : HashMapHandler.getAllMapGameIDs()) {
            List<Player> members;
            if (HashMapHandler.getIsGamePlaying(game).booleanValue() || (members = HashMapHandler.getMembersGameID(game)) == null) continue;
            ItemStack gameItem = GameManager.createMenuButton(Material.PAPER, "&a" + game, "&7Click to force-start this game!");
            menu.addItem(new ItemStack[]{gameItem});
        }
        return menu;
    }

    @EventHandler
    public void OnForceStartGameClick(InventoryClickEvent event) {
        Inventory inv = event.getClickedInventory();
        Player player = (Player)event.getWhoClicked();
        if (inv != null && event.getView().getTitle().equals(MSG.chatColors("&aForce Start A Game"))) {
            String gameName;
            event.setCancelled(true);
            ItemStack clicked = event.getCurrentItem();
            if (clicked != null && clicked.getType() != Material.AIR && clicked.hasItemMeta() && clicked.getItemMeta().hasDisplayName() && !HashMapHandler.getIsGamePlaying(gameName = clicked.getItemMeta().getDisplayName().replace("\u00a7a", "")).booleanValue()) {
                ForceStart.ForceStart(player, gameName);
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.1f);
                player.closeInventory();
                Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(GameManager.AdminMenu(player)), 1L);
            }
        }
    }

    public static Inventory ForceSelectGameMenu(Player player) {
        Inventory menu = Bukkit.createInventory((InventoryHolder)player, (int)36, (String)MSG.chatColors("&eSelect Game for Kick"));
        GameManager.fillBackground(menu);
        for (String game : HashMapHandler.getAllMapGameIDs()) {
            List<Player> members = HashMapHandler.getMembersGameID(game);
            if (members == null) continue;
            ItemStack gameItem = GameManager.createMenuButton(Material.PAPER, "&c" + game, "&7Click to manage players of this game!");
            menu.addItem(new ItemStack[]{gameItem});
        }
        return menu;
    }

    @EventHandler
    public void OnForceSelectGameClick(InventoryClickEvent event) {
        Inventory inv = event.getClickedInventory();
        Player player = (Player)event.getWhoClicked();
        if (inv != null && event.getView().getTitle().equals(MSG.chatColors("&eSelect Game for Kick"))) {
            event.setCancelled(true);
            ItemStack clicked = event.getCurrentItem();
            if (clicked != null && clicked.getType() != Material.AIR && clicked.hasItemMeta() && clicked.getItemMeta().hasDisplayName()) {
                String gameName = clicked.getItemMeta().getDisplayName().replace("\u00a7c", "");
                player.openInventory(GameManager.ForcekickPlayerMenu(player, gameName));
            }
        }
    }

    public static Inventory ForcekickPlayerMenu(Player player, String game) {
        Inventory menu = Bukkit.createInventory((InventoryHolder)player, (int)36, (String)MSG.chatColors("&eSelect Player to Kick"));
        GameManager.fillBackground(menu);
        List<Player> members = HashMapHandler.getMembersGameID(game);
        if (members != null) {
            for (Player member : members) {
                ItemStack playerItem = GameManager.createMenuButton(Material.PLAYER_HEAD, "&c" + member.getName(), "&7Click to kick this player from the game!");
                menu.addItem(new ItemStack[]{playerItem});
            }
        }
        return menu;
    }

    @EventHandler
    public void OnForcekickPlayerClick(InventoryClickEvent event) {
        Inventory inv = event.getClickedInventory();
        Player player = (Player)event.getWhoClicked();
        if (inv != null && event.getView().getTitle().equals(MSG.chatColors("&eSelect Player to Kick"))) {
            event.setCancelled(true);
            ItemStack clicked = event.getCurrentItem();
            if (clicked != null && clicked.getType() != Material.AIR && clicked.hasItemMeta() && clicked.getItemMeta().hasDisplayName()) {
                String targetPlayerName = clicked.getItemMeta().getDisplayName().replace("\u00a7c", "");
                Player targetPlayer = Bukkit.getPlayer((String)targetPlayerName);
                if (targetPlayer != null) {
                    LeaveGameManager.FinalLeaveGame(targetPlayer, true);
                    player.sendMessage(MSG.chatColors("&aYou have successfully kicked " + targetPlayer.getName() + " from the game."));
                    player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.7f, 1.3f);
                    player.closeInventory();
                    Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(GameManager.AdminMenu(player)), 1L);
                } else {
                    player.sendMessage(MSG.chatColors("&cThe player could not be found."));
                }
            }
        }
    }
}

