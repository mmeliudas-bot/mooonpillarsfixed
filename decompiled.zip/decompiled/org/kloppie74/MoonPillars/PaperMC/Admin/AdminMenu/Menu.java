/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.AdminMenu;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminMenu.MenuManager;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;

public class Menu
extends AdminSubCommand {
    @Override
    public String getName() {
        return "menu";
    }

    @Override
    public String getDescription() {
        return "Open the admin Menu!";
    }

    @Override
    public String getSyntax() {
        return "/mpa menu";
    }

    public static double roundToHalf(double value) {
        return (double)Math.round(value * 2.0) / 2.0;
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("mpa.menu")) {
            player.openInventory(MenuManager.AdminMenu(player));
        } else {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        Bukkit.getConsoleSender().sendMessage("You cant use this command as a console!");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            completions.add("setspawn ");
        }
        Collections.sort(completions);
        return completions;
    }
}

