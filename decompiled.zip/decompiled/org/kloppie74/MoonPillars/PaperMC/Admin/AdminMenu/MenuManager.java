/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.AdminMenu;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminMenu.GameManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class MenuManager
implements Listener {
    public static final int SIZE = 54;
    public static final String TITLE = MSG.chatColors("&8\u2726 &cAdmin Control Panel &8\u2726");
    private static final Map<UUID, String> AdminmenuEditCache = new HashMap<UUID, String>();

    public static Inventory AdminMenu(Player player) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)54, (String)TITLE);
        MenuManager.fillBackground(inv);
        inv.setItem(20, MenuManager.createMenuButton(Material.COMMAND_BLOCK, "&bGame Manager", "&7Manage, start, end, or spectate games.", "&8Click to open the Game Manager."));
        inv.setItem(22, MenuManager.createUpdateButton(player));
        inv.setItem(24, MenuManager.createMenuButton(Material.REDSTONE_TORCH, "&cCreate Debug", "&7Run the /debug command.", "&8Click to execute /debug."));
        inv.setItem(38, MenuManager.createServerSettingItem(Material.PAPER, "&aServer IP", "WebSettings.IP", "&fYour current IP: &b", "&7Click to edit your IP."));
        inv.setItem(40, MenuManager.createServerSettingItem(Material.REDSTONE, "&6Server Port", "WebSettings.Port", "&fYour current Port: &b", "&7Click to edit your Port."));
        inv.setItem(42, MenuManager.createServerSettingItem(Material.OAK_SIGN, "&eServer Name", "WebSettings.ServerName", "&fYour current Name: &b", "&7Click to edit your Name."));
        inv.setItem(44, MenuManager.createServerSettingItem(Material.FILLED_MAP, "&9Server Banner (URL)", "WebSettings.BannerURL", "&fYour current Banner URL: &b", "&7Shift-click to show URL."));
        inv.setItem(45, MenuManager.createMenuButton(Material.BARRIER, "&c&lExit", "&7Close the admin panel.", null));
        MenuManager.decorateBorders(inv, Material.BLUE_STAINED_GLASS_PANE);
        inv.setItem(4, MenuManager.createMenuButton(Material.NETHER_STAR, "&6MoonPillars Admin", "&fWelcome, &b" + player.getName() + "&f!", "&7Control your server with style."));
        MoonLab.PlayerMenu.put(player.getUniqueId(), "AdminMenu");
        return inv;
    }

    private static void fillBackground(Inventory inv) {
        ItemStack bg = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = bg.getItemMeta();
        meta.setDisplayName(" ");
        meta.addItemFlags(ItemFlag.values());
        bg.setItemMeta(meta);
        for (int i = 0; i < inv.getSize(); ++i) {
            inv.setItem(i, bg);
        }
    }

    private static void decorateBorders(Inventory inv, Material borderMat) {
        int[] borderSlots;
        ItemStack border = new ItemStack(borderMat);
        ItemMeta meta = border.getItemMeta();
        meta.setDisplayName(" ");
        meta.addItemFlags(ItemFlag.values());
        border.setItemMeta(meta);
        int[] var5 = borderSlots = new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 17, 18, 26, 27, 35, 36, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53};
        int var6 = borderSlots.length;
        for (int var7 = 0; var7 < var6; ++var7) {
            int slot = var5[var7];
            inv.setItem(slot, border);
        }
    }

    private static ItemStack createMenuButton(Material mat, String display, String ... loreLines) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(MSG.chatColors(display));
        ArrayList<String> lore = new ArrayList<String>();
        if (loreLines != null) {
            String[] var6 = loreLines;
            int var7 = loreLines.length;
            for (int var8 = 0; var8 < var7; ++var8) {
                String l = var6[var8];
                lore.add(MSG.chatColors(l));
            }
        }
        meta.setLore(lore);
        meta.addItemFlags(ItemFlag.values());
        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack createUpdateButton(Player player) {
        String[] stringArray;
        String title;
        String latestVersion = MoonLab.getLatestVersion();
        String currentVersion = MoonLab.getInstance().getDescription().getVersion();
        boolean outdated = MenuManager.isNewerVersion(currentVersion, latestVersion);
        Material mat = outdated ? Material.BELL : Material.LIME_DYE;
        String string = title = outdated ? "&6&lUpdate Available!" : "&a&lUp To Date";
        if (outdated) {
            String[] stringArray2 = new String[4];
            stringArray2[0] = "&7A new version is available.";
            stringArray2[1] = "&7Your Version: &f" + currentVersion;
            stringArray2[2] = "&7Latest Version: &b" + latestVersion;
            stringArray = stringArray2;
            stringArray2[3] = "&eClick to start update!";
        } else {
            String[] stringArray3 = new String[2];
            stringArray3[0] = "&7You are running the latest version.";
            stringArray = stringArray3;
            stringArray3[1] = "&7Current Version: &f" + currentVersion;
        }
        String[] lore = stringArray;
        return MenuManager.createMenuButton(mat, title, lore);
    }

    private static ItemStack createServerSettingItem(Material mat, String display, String configKey, String valuePrefix, String actionHint) {
        FileConfiguration config = SettingsManager.getInstance().getSettings();
        String value = config.getString(configKey, "Not set");
        List<String> lore = Arrays.asList("&8Setting: " + configKey, "&7", valuePrefix + value, "&7", actionHint);
        return MenuManager.createMenuButton(mat, display, lore.toArray(new String[0]));
    }

    private static List<Integer> extractVersionNumbers(String version) {
        String cleaned = version.replaceAll("[^\\d.]", "");
        if (cleaned.startsWith(".")) {
            cleaned = cleaned.substring(1);
        }
        ArrayList<Integer> numbers = new ArrayList<Integer>();
        for (String part : cleaned.split("\\.")) {
            if (part.isEmpty()) continue;
            numbers.add(Integer.parseInt(part));
        }
        return numbers;
    }

    public static boolean isNewerVersion(String oldVersion, String newVersion) {
        List<Integer> oldNums = MenuManager.extractVersionNumbers(oldVersion);
        List<Integer> newNums = MenuManager.extractVersionNumbers(newVersion);
        int maxLength = Math.max(oldNums.size(), newNums.size());
        for (int i = 0; i < maxLength; ++i) {
            int newNum;
            int oldNum = i < oldNums.size() ? oldNums.get(i) : 0;
            int n = newNum = i < newNums.size() ? newNums.get(i) : 0;
            if (newNum > oldNum) {
                return true;
            }
            if (newNum >= oldNum) continue;
            return false;
        }
        return false;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Inventory inv = event.getClickedInventory();
        Player player = (Player)event.getWhoClicked();
        String CurrentGUI = MoonLab.PlayerMenu.get(player.getUniqueId());
        FileConfiguration config = SettingsManager.getInstance().getSettings();
        if (CurrentGUI != null && event.getView().getTitle().equals(TITLE)) {
            event.setCancelled(true);
            ItemStack clicked = event.getCurrentItem();
            if (clicked != null && clicked.getType() != Material.AIR) {
                String bannerURL;
                String name = clicked.getItemMeta().getDisplayName();
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1.2f);
                if (event.getSlot() == 20) {
                    player.closeInventory();
                    Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(GameManager.AdminMenu(player)), 1L);
                }
                if (event.getSlot() == 24) {
                    player.closeInventory();
                    player.performCommand("debug");
                }
                if (event.getSlot() == 22) {
                    bannerURL = MoonLab.getLatestVersion();
                    String currentVersion = MoonLab.getInstance().getDescription().getVersion();
                    if (MenuManager.isNewerVersion(currentVersion, bannerURL)) {
                        MoonLab.updatePlugin(bannerURL);
                        player.sendMessage(MSG.chatColors("&eDownloading the latest version! &7(&6MoonPillars-" + bannerURL + ".jar&7)"));
                    } else {
                        player.sendMessage(MSG.chatColors("&aYou are already running the latest version!"));
                    }
                }
                if (event.getSlot() == 45) {
                    player.closeInventory();
                }
                if (event.getSlot() == 38) {
                    player.closeInventory();
                    AdminmenuEditCache.put(player.getUniqueId(), "ServerIP");
                    player.sendMessage(MSG.chatColors("&bSend the new server IP in the chat!"));
                }
                if (event.getSlot() == 40) {
                    player.closeInventory();
                    AdminmenuEditCache.put(player.getUniqueId(), "ServerPort");
                    player.sendMessage(MSG.chatColors("&bSend the new server port in the chat!"));
                }
                if (event.getSlot() == 42) {
                    player.closeInventory();
                    AdminmenuEditCache.put(player.getUniqueId(), "ServerName");
                    player.sendMessage(MSG.chatColors("&bSend the new server name in the chat!"));
                }
                if (event.getSlot() == 44) {
                    if (event.isShiftClick()) {
                        bannerURL = config.getString("WebSettings.BannerURL");
                        player.sendMessage((String)(bannerURL != null ? "&bCurrent Banner URL: " + bannerURL : "&cNo Banner URL set in config."));
                    } else {
                        player.closeInventory();
                        AdminmenuEditCache.put(player.getUniqueId(), "BannerURL");
                        player.sendMessage(MSG.chatColors("&bSend the new banner URL in the chat!"));
                    }
                }
            }
        }
    }

    @EventHandler
    public void onAdminChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        FileConfiguration config = SettingsManager.getInstance().getSettings();
        if (AdminmenuEditCache.containsKey(player.getUniqueId())) {
            String editSetting = AdminmenuEditCache.get(player.getUniqueId());
            String message = event.getMessage();
            event.setCancelled(true);
            switch (editSetting.toLowerCase()) {
                case "serverip": {
                    config.set("WebSettings.IP", (Object)message);
                    player.sendMessage(MSG.chatColors("&aServer IP updated!"));
                    break;
                }
                case "serverport": {
                    config.set("WebSettings.Port", (Object)message);
                    player.sendMessage(MSG.chatColors("&aServer Port updated!"));
                    break;
                }
                case "servername": {
                    config.set("WebSettings.ServerName", (Object)message);
                    player.sendMessage(MSG.chatColors("&aServer Name updated!"));
                    break;
                }
                case "bannerurl": {
                    config.set("WebSettings.BannerURL", (Object)message);
                    player.sendMessage(MSG.chatColors("&aBanner URL updated!"));
                }
            }
            Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> {
                player.openInventory(MenuManager.AdminMenu(player));
                AdminmenuEditCache.remove(player.getUniqueId());
                SettingsManager.saveSettings("Settings");
            });
        }
    }
}

