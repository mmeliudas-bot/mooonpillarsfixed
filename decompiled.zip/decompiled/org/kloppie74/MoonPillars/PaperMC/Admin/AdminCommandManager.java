/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.ConsoleCommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.jetbrains.annotations.NotNull
 */
package org.kloppie74.MoonPillars.PaperMC.Admin;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Stream;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminMenu.Menu;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.PortalManager;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.SignFunctions.AddCommandToSign;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.SignFunctions.RemoveClickableSign;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.SignFunctions.RemoveCommandFromSign;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.SignFunctions.SetClickableSign;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.WebEditor;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.givexp;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.leaderboards;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.reload;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.selectcosmetic;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.setDBStats;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.setspawn;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.setup;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.startlava;
import org.kloppie74.MoonPillars.PaperMC.Admin.UltraCosmetics.cancelcage;
import org.kloppie74.MoonPillars.PaperMC.Admin.UltraCosmetics.createcage;
import org.kloppie74.MoonPillars.PaperMC.Admin.UltraCosmetics.editcage;
import org.kloppie74.MoonPillars.PaperMC.Admin.UltraCosmetics.savecage;
import org.kloppie74.MoonPillars.PaperMC.Admin.V5Setup.FirstSetupDB;
import org.kloppie74.MoonPillars.PaperMC.Admin.V5Setup.SetupMenu;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class AdminCommandManager
implements CommandExecutor,
TabCompleter {
    private final List<AdminSubCommand> adminsubcommands = new ArrayList<AdminSubCommand>();

    public AdminCommandManager() {
        this.adminsubcommands.add(new setup());
        this.adminsubcommands.add(new givexp());
        this.adminsubcommands.add(new createcage());
        this.adminsubcommands.add(new editcage());
        this.adminsubcommands.add(new savecage());
        this.adminsubcommands.add(new cancelcage());
        this.adminsubcommands.add(new setspawn());
        this.adminsubcommands.add(new selectcosmetic());
        this.adminsubcommands.add(new Menu());
        this.adminsubcommands.add(new setDBStats());
        this.adminsubcommands.add(new reload());
        this.adminsubcommands.add(new SetClickableSign());
        this.adminsubcommands.add(new AddCommandToSign());
        this.adminsubcommands.add(new RemoveCommandFromSign());
        this.adminsubcommands.add(new RemoveClickableSign());
        this.adminsubcommands.add(new leaderboards());
        this.adminsubcommands.add(new startlava());
        this.adminsubcommands.add(new PortalManager());
        this.adminsubcommands.add(new WebEditor());
    }

    public AdminSubCommand getSubCommand(String name) {
        AdminSubCommand sub;
        Iterator<AdminSubCommand> var2 = this.adminsubcommands.iterator();
        do {
            if (var2.hasNext()) continue;
            return null;
        } while (!(sub = var2.next()).getName().equalsIgnoreCase(name));
        return sub;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String setup2;
        if (!(sender instanceof Player)) {
            if (sender instanceof ConsoleCommandSender) {
                ConsoleCommandSender consoleSender = (ConsoleCommandSender)sender;
                if (args.length > 0) {
                    AdminSubCommand subCommand = this.getSubCommand(args[0]);
                    if (subCommand != null) {
                        subCommand.performConsole((CommandSender)consoleSender, args);
                        return true;
                    }
                    this.showUsage((CommandSender)consoleSender);
                    return true;
                }
                this.showUsage((CommandSender)consoleSender);
                return true;
            }
            sender.sendMessage(MSG.chatColors("&cThis command can only be used by a player or the console."));
            return false;
        }
        Player player = (Player)sender;
        if (player.isOp() && ((setup2 = FirstSetupDB.getInstance().getSetting("SetupComplete")) == null || !setup2.equalsIgnoreCase("true"))) {
            player.sendMessage(MSG.chatColors("&6Welcome to &eMoonPillars&6!"));
            player.sendMessage(MSG.chatColors("&7It looks like you're running the plugin for the first time."));
            player.sendMessage(MSG.chatColors("&bYou'll be guided through a short setup. Please answer the questions to proceed."));
            player.sendMessage(MSG.chatColors("&7Need help? Join our discord: &9https://discord.gg/Ya6NwdEMd6"));
            player.sendMessage(MSG.chatColors("&7The setup GUI will open in 5 seconds..."));
            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> SetupMenu.openAnonymousData(player), 100L);
            return true;
        }
        if (args.length > 0) {
            AdminSubCommand subCommand = this.getSubCommand(args[0]);
            if (subCommand != null) {
                subCommand.perform(player, args);
                return true;
            }
            if (player.hasPermission("mpa.help")) {
                this.showUsage((CommandSender)player);
            } else {
                MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
            }
            return true;
        }
        if (player.hasPermission("mpa.help")) {
            this.showUsage((CommandSender)player);
        } else {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        }
        return true;
    }

    private void showUsage(CommandSender sender) {
        sender.sendMessage(MSG.chatColors("&8&l&m-------------------------------"));
        sender.sendMessage(MSG.chatColors("&b&lMoonPillars Admin &7- Command Overview"));
        sender.sendMessage(MSG.chatColors("&8&l&m-------------------------------"));
        LinkedHashMap<String, List<String>> categories = new LinkedHashMap<String, List<String>>();
        categories.put("&6System & Setup:", Arrays.asList("setup", "createcage", "editcage", "savecage", "setspawn", "reload", "disablegames"));
        categories.put("&6Player Management:", Arrays.asList("giveshards", "givexp", "setDBStats"));
        categories.put("&6Cosmetics:", Arrays.asList("selectcosmetic"));
        categories.put("&6Menu & Utility:", Arrays.asList("menu", "giveluckyblock", "leaderboards", "startlava", "PortalManager", "WebEditor"));
        categories.put("&6Sign Management:", Arrays.asList("SetClickableSign", "AddCommandToSign", "RemoveCommandFromSign", "RemoveClickableSign"));
        HashMap<String, AdminSubCommand> subCommandMap = new HashMap<String, AdminSubCommand>();
        for (AdminSubCommand sub : this.adminsubcommands) {
            subCommandMap.put(sub.getName(), sub);
        }
        Iterator<Object> var4 = categories.entrySet().iterator();
        while (true) {
            if (!var4.hasNext()) {
                sender.sendMessage(MSG.chatColors("&8&l&m-------------------------------"));
                sender.sendMessage(MSG.chatColors("&7Tip: Use <tab> for command suggestions!"));
                return;
            }
            Map.Entry entry = (Map.Entry)var4.next();
            String cat = (String)entry.getKey();
            List cmds = (List)entry.getValue();
            Stream var10000 = cmds.stream();
            Objects.requireNonNull(subCommandMap);
            boolean anyInCat = var10000.anyMatch(subCommandMap::containsKey);
            if (!anyInCat) continue;
            sender.sendMessage(MSG.chatColors(cat));
            for (String cmd : cmds) {
                AdminSubCommand sub = (AdminSubCommand)subCommandMap.get(cmd);
                if (sub == null) continue;
                String info = sub.getDescription() != null ? sub.getDescription() : "";
                String var10001 = sub.getName();
                sender.sendMessage(MSG.chatColors("&e/mpa " + var10001 + (String)(info.isEmpty() ? "" : " &7- " + info)));
            }
            sender.sendMessage("");
        }
    }

    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (args.length == 1) {
            String subCommand = args[0].toLowerCase();
            for (AdminSubCommand adminSubCommand : this.adminsubcommands) {
                String subCommandName = adminSubCommand.getName().toLowerCase();
                if (!subCommandName.startsWith(subCommand)) continue;
                completions.add(subCommandName);
            }
        } else if (args.length >= 2) {
            String subCommand = args[0].toLowerCase();
            String input = args[1].toLowerCase();
            int var29 = -1;
            switch (subCommand.hashCode()) {
                case -1514485697: {
                    if (!subCommand.equals("setdbstats")) break;
                    var29 = 3;
                    break;
                }
                case -1245578807: {
                    if (!subCommand.equals("givexp")) break;
                    var29 = 2;
                    break;
                }
                case -979066663: {
                    if (!subCommand.equals("disablegames")) break;
                    var29 = 0;
                    break;
                }
                case 109329021: {
                    if (!subCommand.equals("setup")) break;
                    var29 = 1;
                    break;
                }
                case 457015243: {
                    if (!subCommand.equals("selectcosmetic")) break;
                    var29 = 5;
                    break;
                }
                case 2125697761: {
                    if (!subCommand.equals("importcage")) break;
                    var29 = 4;
                }
            }
            switch (var29) {
                case 1: {
                    File gamesFolder = new File(MoonLab.getInstance().getDataFolder(), "Games");
                    File[] gameFiles = gamesFolder.listFiles((dir, name) -> name.endsWith(".yml"));
                    if (gameFiles != null) {
                        for (File gameFile : gameFiles) {
                            String gameID = gameFile.getName().replace(".yml", "").toLowerCase();
                            completions.add(gameID);
                        }
                    }
                    break;
                }
                case 2: 
                case 4: {
                    Stream<String> players = Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(name -> name.toLowerCase().startsWith(input));
                    Objects.requireNonNull(completions);
                    players.forEach(completions::add);
                    if (!subCommand.equals("givexp")) break;
                    completions.add("all");
                    break;
                }
                case 3: {
                    Stream<String> playerNames = Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(name -> name.toLowerCase().startsWith(input));
                    Objects.requireNonNull(completions);
                    playerNames.forEach(completions::add);
                    for (OfflinePlayer offlinePlayer : Bukkit.getOfflinePlayers()) {
                        String name2;
                        if (offlinePlayer.getName() == null || !offlinePlayer.hasPlayedBefore() || offlinePlayer.isOnline() || !(name2 = offlinePlayer.getName()).toLowerCase().startsWith(input)) continue;
                        completions.add(name2);
                    }
                    break;
                }
                case 5: {
                    Stream<String> playersNames = Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(name -> name.toLowerCase().startsWith(input));
                    Objects.requireNonNull(completions);
                    playersNames.forEach(completions::add);
                }
            }
        }
        Collections.sort(completions);
        return completions;
    }
}

