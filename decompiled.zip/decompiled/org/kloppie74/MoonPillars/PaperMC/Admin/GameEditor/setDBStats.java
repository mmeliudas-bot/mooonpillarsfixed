/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.Admin.Cooldowns;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.DatabaseManager;

public class setDBStats
extends AdminSubCommand {
    @Override
    public String getName() {
        return "setDBStats";
    }

    @Override
    public String getDescription() {
        return "Give Database stats to a player!";
    }

    @Override
    public String getSyntax() {
        return "/mpa setDBStats {name} Setting Amount";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("mpa.setDBStats")) {
            if (!Cooldowns.isOnCooldown(player)) {
                if (args.length == 4) {
                    int amount;
                    String playerName = args[1];
                    Player targetPlayer = Bukkit.getPlayer((String)playerName);
                    if (targetPlayer == null) {
                        MessageSender.SendMessage(player, "Commands.Give-XP.Player-Not-Online", "{player}", playerName);
                        return;
                    }
                    String Setting = args[2];
                    boolean var6 = false;
                    try {
                        amount = Integer.parseInt(args[3]);
                    }
                    catch (NumberFormatException var8) {
                        player.sendMessage(MSG.chatColors("&cThats not an amount! &7(" + args[3] + ")"));
                        return;
                    }
                    DatabaseManager.getInstance().updateSetting(targetPlayer.getUniqueId(), Setting, amount);
                    player.sendMessage(MSG.chatColors("&7Added "));
                } else {
                    player.sendMessage(MSG.chatColors("&cWrong usage! Use it as /mpa givedbstats %player% %setting% %amount%"));
                }
                Cooldowns.startCooldown(player);
            } else {
                MessageSender.SendMessage(player, "Commands.Cooldown", "", "");
            }
        } else {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        if (args.length == 3) {
            int amount;
            String playerName = args[1];
            Player targetPlayer = Bukkit.getPlayer((String)playerName);
            if (targetPlayer == null) {
                sender.sendMessage(MSG.chatColors("&cPlayer not found."));
                return;
            }
            try {
                amount = Integer.parseInt(args[2]);
            }
            catch (NumberFormatException var8) {
                String text = "Invalid amount. Please enter a valid number.";
                sender.sendMessage(MSG.chatColors("&c" + text));
                return;
            }
            int newAMT = amount + Integer.parseInt(DatabaseManager.getInstance().getSetting(targetPlayer.getUniqueId(), "XP"));
            DatabaseManager.getInstance().updateSetting(targetPlayer.getUniqueId(), "XP", newAMT);
            sender.sendMessage(MSG.chatColors("&aSuccessfully gave " + amount + " XP to " + playerName + "."));
        } else {
            String playerName = "Please use " + this.getSyntax();
            sender.sendMessage(MSG.chatColors("&c" + playerName));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            completions.add("givexp");
        }
        Collections.sort(completions);
        return completions;
    }
}

