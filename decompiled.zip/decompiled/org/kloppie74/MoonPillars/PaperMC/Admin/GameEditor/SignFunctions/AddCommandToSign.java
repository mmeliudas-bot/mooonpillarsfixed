/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.block.Block
 *  org.bukkit.block.Sign
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.SignFunctions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class AddCommandToSign
extends AdminSubCommand {
    @Override
    public String getName() {
        return "addcommandtosign";
    }

    @Override
    public String getDescription() {
        return "Add a command to a clickable sign!";
    }

    @Override
    public String getSyntax() {
        return "/mpa addcommandtosign [PLAYER|CONSOLE] <command>";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (!player.hasPermission("mpa.addcommandtosign")) {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        } else if (args.length < 2) {
            player.sendMessage(MSG.chatColors("&cUsage: " + this.getSyntax()));
            player.sendMessage(MSG.chatColors("&cExample: /mpa addcommandtosign [PLAYER] spawn"));
            player.sendMessage(MSG.chatColors("&cExample: /mpa addcommandtosign [CONSOLE] give %player% diamond 1"));
            player.sendMessage(MSG.chatColors("&cExample: /mpa addcommandtosign [MESSAGE] &aWelcome to the server, %player%!"));
        } else {
            Block targetBlock = player.getTargetBlockExact(5);
            if (targetBlock != null && targetBlock.getState() instanceof Sign) {
                String executor = args[1].toUpperCase();
                if (!(executor.equals("[PLAYER]") || executor.equals("[CONSOLE]") || executor.equals("[MESSAGE]"))) {
                    player.sendMessage(MSG.chatColors("&cThe first parameter must be [PLAYER], [CONSOLE], or [MESSAGE]!"));
                } else {
                    StringBuilder commandBuilder = new StringBuilder();
                    for (int i = 2; i < args.length; ++i) {
                        commandBuilder.append(args[i]);
                        if (i >= args.length - 1) continue;
                        commandBuilder.append(" ");
                    }
                    String commandString = executor + " " + commandBuilder.toString();
                    FileConfiguration config = SettingsManager.getInstance().getClickableSigns();
                    String foundSignName = null;
                    String worldName = targetBlock.getWorld().getName();
                    int x = targetBlock.getX();
                    int y = targetBlock.getY();
                    int z = targetBlock.getZ();
                    ConfigurationSection signsSection = config.getConfigurationSection("ClickableSigns");
                    if (signsSection != null) {
                        for (String signName : signsSection.getKeys(false)) {
                            String signWorld = config.getString("ClickableSigns." + signName + ".World");
                            int signX = config.getInt("ClickableSigns." + signName + ".X");
                            int signY = config.getInt("ClickableSigns." + signName + ".Y");
                            int signZ = config.getInt("ClickableSigns." + signName + ".Z");
                            if (!worldName.equals(signWorld) || x != signX || y != signY || z != signZ) continue;
                            foundSignName = signName;
                            break;
                        }
                    }
                    if (foundSignName == null) {
                        player.sendMessage(MSG.chatColors("&cThis sign is not set as a clickable sign. Use /mpa setclickablesign first!"));
                    } else {
                        List commands = config.getStringList("ClickableSigns." + foundSignName + ".Commands");
                        commands.add(commandString);
                        config.set("ClickableSigns." + foundSignName + ".Commands", (Object)commands);
                        SettingsManager.getInstance();
                        SettingsManager.saveSettings("ClickableSigns");
                        player.sendMessage(MSG.chatColors("&aAdded command to sign '" + foundSignName + "': &r" + commandString));
                    }
                }
            } else {
                player.sendMessage(MSG.chatColors("&cYou must be looking at a sign to add a command!"));
            }
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        sender.sendMessage("This command can only be used by players.");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        Collections.sort(completions);
        return completions;
    }
}

