/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5;

import java.util.ArrayList;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.EditorMenu;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.WorldListeners;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class VoteSetting
implements Listener {
    private static final String MENU_VOTING_SETTINGS = "VotingSettings";

    public static Inventory createVotingSettingsGUI(Player player) {
        FileConfiguration config = WorldListeners.configEditer.get(player.getUniqueId());
        Inventory inventory = Bukkit.createInventory((InventoryHolder)null, (int)36, (String)MSG.chatColors("&bVoting Events"));
        ItemStack fillItem = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fillItemMeta = fillItem.getItemMeta();
        fillItemMeta.setDisplayName("\u00a7f ");
        fillItem.setItemMeta(fillItemMeta);
        for (int i = 0; i < inventory.getSize(); ++i) {
            inventory.setItem(i, fillItem);
        }
        boolean floorIsLavaEnabled = config.contains("Events.Voting.Floor-Is-Lava.Enabled") ? config.getBoolean("Events.Voting.Floor-Is-Lava.Enabled") : true;
        boolean elytraModeEnabled = config.contains("Events.Voting.Elytra-Mode.Enabled") ? config.getBoolean("Events.Voting.Elytra-Mode.Enabled") : true;
        boolean noFallModeEnabled = config.contains("Events.Voting.No-Fall-Mode.Enabled") ? config.getBoolean("Events.Voting.No-Fall-Mode.Enabled") : true;
        boolean oneHeartModeEnabled = config.contains("Events.Voting.1-Heart-Mode.Enabled") ? config.getBoolean("Events.Voting.1-Heart-Mode.Enabled") : true;
        boolean doubleHPEnabled = config.contains("Events.Voting.Double-HP.Enabled") ? config.getBoolean("Events.Voting.Double-HP.Enabled") : true;
        boolean playerSwapEnabled = config.contains("Events.Voting.Player-Swap.Enabled") ? config.getBoolean("Events.Voting.Player-Swap.Enabled") : true;
        boolean inventorySwapEnabled = config.contains("Events.Voting.Inventory-Swap.Enabled") ? config.getBoolean("Events.Voting.Inventory-Swap.Enabled") : true;
        boolean apocalypseEnabled = config.contains("Events.Voting.Apocalypse.Enabled") ? config.getBoolean("Events.Voting.Apocalypse.Enabled") : true;
        boolean synchronizationEnabled = config.contains("Events.Voting.Synchronization.Enabled") ? config.getBoolean("Events.Voting.Synchronization.Enabled") : true;
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eVoting Events"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7These events can be voted on by players"));
        infoLore.add(MSG.chatColors("&7before the game starts."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&7Click each item to toggle it on/off."));
        infoLore.add(MSG.chatColors("&7Green text = Enabled, Red text = Disabled"));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Enabled events appear in voting menu"));
        infoLore.add(MSG.chatColors("&8\u2192 Adds variety to each game"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inventory.setItem(4, infoItem);
        inventory.setItem(10, VoteSetting.createToggleItem("Elytra Mode", Material.ELYTRA, elytraModeEnabled, "Players receive elytras and can fly", "around the map"));
        inventory.setItem(12, VoteSetting.createToggleItem("No Fall Damage", Material.FEATHER, noFallModeEnabled, "Players take no damage from falling", "no matter the height"));
        inventory.setItem(14, VoteSetting.createToggleItem("One Heart Mode", Material.APPLE, oneHeartModeEnabled, "Players only have one heart of health", "making the game more intense"));
        inventory.setItem(16, VoteSetting.createToggleItem("Double Health", Material.GOLDEN_APPLE, doubleHPEnabled, "Players have double the normal health", "making battles last longer"));
        inventory.setItem(20, VoteSetting.createToggleItem("Player Swap", Material.ENDER_PEARL, playerSwapEnabled, "Players randomly swap positions", "with others periodically"));
        inventory.setItem(22, VoteSetting.createToggleItem("Inventory Swap", Material.CHEST, inventorySwapEnabled, "Players randomly swap inventories", "with others periodically"));
        inventory.setItem(24, VoteSetting.createToggleItem("Floor Is Lava", Material.LAVA_BUCKET, floorIsLavaEnabled, "After some time, the floor turns", "to lava, forcing players upward"));
        inventory.setItem(28, VoteSetting.createToggleItem("Apocalypse", Material.TNT, apocalypseEnabled, "Random solid blocks rain from the", "sky near the center of the map"));
        inventory.setItem(30, VoteSetting.createToggleItem("Synchronization", Material.NETHER_STAR, synchronizationEnabled, "All players receive the exact", "same random item each drop"));
        ItemStack backButton = new ItemStack(Material.ARROW);
        ItemMeta backMeta = backButton.getItemMeta();
        backMeta.setDisplayName(MSG.chatColors("&cBack to Menu"));
        ArrayList<String> backLore = new ArrayList<String>();
        backLore.add(MSG.chatColors("&7Return to the previous menu"));
        backLore.add(MSG.chatColors("&7"));
        backLore.add(MSG.chatColors("&8\u2192 All changes are saved automatically"));
        backMeta.setLore(backLore);
        backButton.setItemMeta(backMeta);
        inventory.setItem(31, backButton);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_VOTING_SETTINGS);
        return inventory;
    }

    private static ItemStack createToggleItem(String name, Material material, boolean enabled, String ... description) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(MSG.chatColors((enabled ? "&a" : "&c") + name));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Status: " + (enabled ? "&aEnabled" : "&cDisabled")));
        lore.add(MSG.chatColors("&7"));
        String[] var7 = description;
        int var8 = description.length;
        for (int var9 = 0; var9 < var8; ++var9) {
            String line = var7[var9];
            lore.add(MSG.chatColors("&7" + line));
        }
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Click to " + (enabled ? "disable" : "enable")));
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onVotingSettingsClick(InventoryClickEvent event) {
        Player player;
        String currentGUI;
        if (event.getWhoClicked() instanceof Player && (currentGUI = MoonLab.PlayerMenu.get((player = (Player)event.getWhoClicked()).getUniqueId())) != null && currentGUI.equals(MENU_VOTING_SETTINGS)) {
            ItemStack clicked;
            FileConfiguration config;
            event.setCancelled(true);
            Inventory inventory = event.getClickedInventory();
            if (inventory != null && (config = WorldListeners.configEditer.get(player.getUniqueId())) != null && (clicked = event.getCurrentItem()) != null && clicked.getType() != Material.GRAY_STAINED_GLASS_PANE && clicked.getType() != Material.OAK_SIGN) {
                if (event.getSlot() == 31 && clicked.getType() == Material.ARROW) {
                    player.closeInventory();
                    Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> {
                        if (EditorMenu.playerSetupPhase.containsKey(player.getUniqueId()) && EditorMenu.playerSetupPhase.get(player.getUniqueId()) == 11) {
                            player.openInventory(EditorMenu.createGuidedVotingInventory(player, config));
                        } else {
                            player.openInventory(EditorMenu.EditGuiInv(player, config));
                        }
                    }, 1L);
                } else {
                    String configPath = null;
                    String displayName = null;
                    switch (event.getSlot()) {
                        case 10: {
                            configPath = "Events.Voting.Elytra-Mode.Enabled";
                            displayName = "Elytra Mode";
                            break;
                        }
                        default: {
                            return;
                        }
                        case 12: {
                            configPath = "Events.Voting.No-Fall-Mode.Enabled";
                            displayName = "No Fall Damage";
                            break;
                        }
                        case 14: {
                            configPath = "Events.Voting.1-Heart-Mode.Enabled";
                            displayName = "One Heart Mode";
                            break;
                        }
                        case 16: {
                            configPath = "Events.Voting.Double-HP.Enabled";
                            displayName = "Double Health";
                            break;
                        }
                        case 20: {
                            configPath = "Events.Voting.Player-Swap.Enabled";
                            displayName = "Player Swap";
                            break;
                        }
                        case 22: {
                            configPath = "Events.Voting.Inventory-Swap.Enabled";
                            displayName = "Inventory Swap";
                            break;
                        }
                        case 24: {
                            configPath = "Events.Voting.Floor-Is-Lava.Enabled";
                            displayName = "Floor Is Lava";
                            break;
                        }
                        case 28: {
                            configPath = "Events.Voting.Apocalypse.Enabled";
                            displayName = "Apocalypse";
                            break;
                        }
                        case 30: {
                            configPath = "Events.Voting.Synchronization.Enabled";
                            displayName = "Synchronization";
                        }
                    }
                    if (configPath != null) {
                        boolean currentStatus = config.contains(configPath) ? config.getBoolean(configPath) : true;
                        config.set(configPath, (Object)(!currentStatus ? 1 : 0));
                        EditorMenu.SaveConfig(player);
                        player.sendMessage(MSG.chatColors("#87C8CE" + displayName + " voting event is now " + (!currentStatus ? "&aenabled" : "&cdisabled") + "#87C8CE!"));
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> {
                            MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_VOTING_SETTINGS);
                            player.openInventory(VoteSetting.createVotingSettingsGUI(player));
                        }, 1L);
                    }
                }
            }
        }
    }
}

