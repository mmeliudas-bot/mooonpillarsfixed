/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.EasterEggs.EasterEggManager;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.ChatManager.ChatListener;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.ScoreBoardAPI.NewScoreboard;
import org.kloppie74.MoonPillars.PaperMC.UltimateGuis.MenuManager;

public class reload
extends AdminSubCommand {
    @Override
    public String getName() {
        return "reload";
    }

    @Override
    public String getDescription() {
        return "Reload the config files!";
    }

    @Override
    public String getSyntax() {
        return "/mpa reload";
    }

    public static double roundToHalf(double value) {
        return (double)Math.round(value * 2.0) / 2.0;
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("mpa.reload")) {
            MenuManager.reloadMenus(player);
            SettingsManager.getInstance().reloadFiles(player);
            NewScoreboard.reloadCache(player);
            EasterEggManager.reload();
            ChatListener.getInstance().reloadChatFilter();
        } else {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        return completions;
    }
}

