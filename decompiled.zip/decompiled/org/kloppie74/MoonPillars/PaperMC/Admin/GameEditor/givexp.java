/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.Admin.Cooldowns;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.LevelManager.AddPlayerXP;

public class givexp
extends AdminSubCommand {
    @Override
    public String getName() {
        return "givexp";
    }

    @Override
    public String getDescription() {
        return "Give experience to a player.";
    }

    @Override
    public String getSyntax() {
        return "/mpa givexp {name} {amount}";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("mpa.givexp")) {
            if (!Cooldowns.isOnCooldown(player)) {
                if (args.length != 3) {
                    MessageSender.SendMessage(player, "Commands.Give-XP.Unknown-usage", "", "");
                } else {
                    int amount;
                    String targetName = args[1];
                    try {
                        amount = Integer.parseInt(args[2]);
                    }
                    catch (NumberFormatException var7) {
                        MessageSender.SendMessage(player, "Commands.Give-XP.Invalid-Amount", "", "");
                        return;
                    }
                    if (!targetName.equalsIgnoreCase("All")) {
                        Player targetPlayer = Bukkit.getPlayer((String)targetName);
                        if (targetPlayer == null) {
                            MessageSender.SendMessage(player, "Commands.Give-XP.Player-Not-Online", "{player}", targetName);
                            return;
                        }
                        AddPlayerXP.AddXP(targetPlayer, amount);
                        MessageSender.SendMessage(player, "Commands.Give-XP.Added-XP", "{amount}", String.valueOf(amount));
                    } else {
                        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
                            AddPlayerXP.AddXP(onlinePlayer, amount);
                            onlinePlayer.sendMessage(MSG.chatColors("&aYou have received " + amount + " XP!"));
                        }
                        MessageSender.SendMessage(player, "Commands.Give-XP.Added-XP-All", "{amount}", String.valueOf(amount));
                    }
                }
                Cooldowns.startCooldown(player);
            } else {
                MessageSender.SendMessage(player, "Commands.Cooldown", "", "");
            }
        } else {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        if (args.length == 3) {
            int amount;
            String targetName = args[1];
            try {
                amount = Integer.parseInt(args[2]);
            }
            catch (NumberFormatException var7) {
                sender.sendMessage(MSG.chatColors("&cInvalid amount. Please enter a valid number."));
                return;
            }
            if (targetName.equalsIgnoreCase("All")) {
                for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
                    AddPlayerXP.AddXP(onlinePlayer, amount);
                }
                sender.sendMessage(MSG.chatColors("&aAdded " + amount + " XP to all online players."));
            } else {
                Player targetPlayer = Bukkit.getPlayer((String)targetName);
                if (targetPlayer == null) {
                    sender.sendMessage(MSG.chatColors("&cPlayer not found."));
                    return;
                }
                AddPlayerXP.AddXP(targetPlayer, amount);
                sender.sendMessage(MSG.chatColors("&aAdded " + amount + " XP to " + targetName + "."));
            }
        } else {
            sender.sendMessage(MSG.chatColors("&cPlease use " + this.getSyntax()));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            completions.add("givexp");
        }
        Collections.sort(completions);
        return completions;
    }
}

