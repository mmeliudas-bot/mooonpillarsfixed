/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class leaderboards
extends AdminSubCommand {
    private static final Pattern UUID_PATTERN = Pattern.compile("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$");

    @Override
    public String getName() {
        return "leaderboards";
    }

    @Override
    public String getDescription() {
        return "Include or exclude players from leaderboards";
    }

    @Override
    public String getSyntax() {
        return "/mpa leaderboards <include/exclude> <playername/uuid>";
    }

    private boolean isValidUUID(String str) {
        return UUID_PATTERN.matcher(str).matches();
    }

    private boolean processLeaderboardAction(String targetIdentifier, String action, List<String> excludedPlayers) {
        String targetUuid;
        if (this.isValidUUID(targetIdentifier)) {
            targetUuid = targetIdentifier;
        } else {
            Player targetPlayer = Bukkit.getPlayer((String)targetIdentifier);
            if (targetPlayer != null) {
                targetUuid = targetPlayer.getUniqueId().toString();
            } else {
                OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((String)targetIdentifier);
                if (!offlinePlayer.hasPlayedBefore()) {
                    return false;
                }
                targetUuid = offlinePlayer.getUniqueId().toString();
            }
        }
        boolean isExcluded = excludedPlayers.contains(targetUuid);
        if (action.equals("exclude")) {
            if (!isExcluded) {
                excludedPlayers.add(targetUuid);
                return true;
            }
        } else if (isExcluded) {
            excludedPlayers.remove(targetUuid);
            return true;
        }
        return false;
    }

    private String getPlayerDisplayName(String identifier) {
        if (this.isValidUUID(identifier)) {
            try {
                UUID uuid = UUID.fromString(identifier);
                OfflinePlayer player = Bukkit.getOfflinePlayer((UUID)uuid);
                if (player.getName() != null) {
                    String var10000 = player.getName();
                    return var10000 + " (" + identifier + ")";
                }
                return identifier;
            }
            catch (IllegalArgumentException var4) {
                return identifier;
            }
        }
        return identifier;
    }

    @Override
    public void perform(Player player, String[] args) {
        if (!player.hasPermission("mpa.leaderboards")) {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        } else if (args.length < 3) {
            player.sendMessage(MSG.chatColors("&cUsage: " + this.getSyntax()));
        } else {
            String action = args[1].toLowerCase();
            String targetIdentifier = args[2];
            if (!action.equals("include") && !action.equals("exclude")) {
                player.sendMessage(MSG.chatColors("&cInvalid option. Use 'include' or 'exclude'."));
            } else {
                boolean success;
                FileConfiguration config = SettingsManager.getInstance().getSettings();
                ArrayList<String> excludedPlayers = config.getStringList("Leaderboards.ExcludedPlayers");
                if (excludedPlayers == null) {
                    excludedPlayers = new ArrayList<String>();
                }
                if (success = this.processLeaderboardAction(targetIdentifier, action, excludedPlayers)) {
                    String displayName = this.getPlayerDisplayName(targetIdentifier);
                    if (action.equals("exclude")) {
                        player.sendMessage(MSG.chatColors("&aPlayer &e" + displayName + "&a has been excluded from leaderboards."));
                    } else {
                        player.sendMessage(MSG.chatColors("&aPlayer &e" + displayName + "&a has been included in leaderboards."));
                    }
                    config.set("Leaderboards.ExcludedPlayers", excludedPlayers);
                    SettingsManager.getInstance();
                    SettingsManager.saveSettings("Settings");
                } else if (!this.isValidUUID(targetIdentifier) && !Bukkit.getOfflinePlayer((String)targetIdentifier).hasPlayedBefore() && Bukkit.getPlayer((String)targetIdentifier) == null) {
                    player.sendMessage(MSG.chatColors("&cCould not find player or UUID: &e" + targetIdentifier));
                } else {
                    String displayName = this.getPlayerDisplayName(targetIdentifier);
                    if (action.equals("exclude")) {
                        player.sendMessage(MSG.chatColors("&cPlayer &e" + displayName + "&c is already excluded from leaderboards."));
                    } else {
                        player.sendMessage(MSG.chatColors("&cPlayer &e" + displayName + "&c is already included in leaderboards."));
                    }
                }
            }
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("Usage: " + this.getSyntax());
        } else {
            String action = args[1].toLowerCase();
            String targetIdentifier = args[2];
            if (!action.equals("include") && !action.equals("exclude")) {
                sender.sendMessage("Invalid option. Use 'include' or 'exclude'.");
            } else {
                boolean success;
                FileConfiguration config = SettingsManager.getInstance().getSettings();
                ArrayList<String> excludedPlayers = config.getStringList("Leaderboards.ExcludedPlayers");
                if (excludedPlayers == null) {
                    excludedPlayers = new ArrayList<String>();
                }
                if (success = this.processLeaderboardAction(targetIdentifier, action, excludedPlayers)) {
                    String displayName = this.getPlayerDisplayName(targetIdentifier);
                    if (action.equals("exclude")) {
                        sender.sendMessage("Player " + displayName + " has been excluded from leaderboards.");
                    } else {
                        sender.sendMessage("Player " + displayName + " has been included in leaderboards.");
                    }
                    config.set("Leaderboards.ExcludedPlayers", excludedPlayers);
                    SettingsManager.getInstance();
                    SettingsManager.saveSettings("Settings");
                } else if (!this.isValidUUID(targetIdentifier) && !Bukkit.getOfflinePlayer((String)targetIdentifier).hasPlayedBefore() && Bukkit.getPlayer((String)targetIdentifier) == null) {
                    sender.sendMessage("Could not find player or UUID: " + targetIdentifier);
                } else {
                    String displayName = this.getPlayerDisplayName(targetIdentifier);
                    if (action.equals("exclude")) {
                        sender.sendMessage("Player " + displayName + " is already excluded from leaderboards.");
                    } else {
                        sender.sendMessage("Player " + displayName + " is already included in leaderboards.");
                    }
                }
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!sender.hasPermission("mpa.leaderboards")) {
            return completions;
        }
        if (args.length == 2) {
            completions.add("include");
            completions.add("exclude");
        } else if (args.length == 3) {
            Bukkit.getOnlinePlayers().forEach(player -> completions.add(player.getName()));
            FileConfiguration config = SettingsManager.getInstance().getSettings();
            List excludedPlayers = config.getStringList("Leaderboards.ExcludedPlayers");
            if (excludedPlayers != null) {
                completions.addAll(excludedPlayers);
            }
        }
        Collections.sort(completions);
        return completions;
    }
}

