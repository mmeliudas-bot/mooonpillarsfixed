/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.EditorMenu;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.WorldListeners;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class TeamManagerMenu
implements Listener {
    private static final String SETUP_PHASE_KEY = "TeamSetupPhase";
    private static final int SETUP_MAX_TEAMS = 1;
    private static final int SETUP_PLAYERS_PER_TEAM = 2;
    private static final int SETUP_CREATE_TEAMS = 3;
    private static final int SETUP_TEAM_NAMES = 4;
    private static final int SETUP_TEAM_COLORS = 5;
    private static final int SETUP_COMPLETE = 6;
    private static final String MENU_SETUP_CHOICE = "TeamSetupChoice";
    private static final String MENU_MANUAL = "TeamManagerMenu";
    private static final String MENU_GUIDED_MAX_TEAMS = "GuidedMaxTeams";
    private static final String MENU_GUIDED_PLAYERS_PER_TEAM = "GuidedPlayersPerTeam";
    private static final String MENU_GUIDED_CREATE_TEAMS = "GuidedCreateTeams";
    private static final String MENU_GUIDED_TEAM_NAMES = "GuidedTeamNames";
    private static final String MENU_GUIDED_TEAM_COLORS = "GuidedTeamColors";
    private static final String MENU_GUIDED_COMPLETE = "GuidedComplete";
    private static final String MENU_DELETE_TEAM = "DeleteATeam";
    private static final String MENU_SET_TEAM_NAME = "SetATeamName";
    private static final String MENU_SET_TEAM_COLOR = "SetATeamColor";
    private static final Map<UUID, Integer> playerSetupPhase = new HashMap<UUID, Integer>();

    public static Inventory createSetupChoiceMenu(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bTeam Manager Setup"));
        TeamManagerMenu.fillInventory(inv);
        ItemStack manualSetup = new ItemStack(Material.CRAFTING_TABLE);
        ItemMeta manualMeta = manualSetup.getItemMeta();
        manualMeta.setDisplayName(MSG.chatColors("&bManual Setup"));
        ArrayList<String> manualLore = new ArrayList<String>();
        manualLore.add(MSG.chatColors("&7Click to access all team"));
        manualLore.add(MSG.chatColors("&7management options at once."));
        manualLore.add(MSG.chatColors("&7"));
        manualLore.add(MSG.chatColors("&7For experienced users."));
        manualLore.add(MSG.chatColors("&7"));
        manualLore.add(MSG.chatColors("&8\u2192 Provides access to all team settings"));
        manualLore.add(MSG.chatColors("&8\u2192 Allows setting max teams, players per team"));
        manualLore.add(MSG.chatColors("&8\u2192 Create and delete teams"));
        manualLore.add(MSG.chatColors("&8\u2192 Customize team names and colors"));
        manualMeta.setLore(manualLore);
        manualSetup.setItemMeta(manualMeta);
        inv.setItem(11, manualSetup);
        ItemStack guidedSetup = new ItemStack(Material.COMPASS);
        ItemMeta guidedMeta = guidedSetup.getItemMeta();
        guidedMeta.setDisplayName(MSG.chatColors("&aGuided Setup"));
        ArrayList<String> guidedLore = new ArrayList<String>();
        guidedLore.add(MSG.chatColors("&7Click to start a step-by-step"));
        guidedLore.add(MSG.chatColors("&7process to set up your teams."));
        guidedLore.add(MSG.chatColors("&7"));
        guidedLore.add(MSG.chatColors("&7Recommended for new users."));
        guidedLore.add(MSG.chatColors("&7"));
        guidedLore.add(MSG.chatColors("&8\u2192 Walks you through each setup step"));
        guidedLore.add(MSG.chatColors("&8\u2192 Provides guidance at each stage"));
        guidedLore.add(MSG.chatColors("&8\u2192 Ensures proper team configuration"));
        guidedLore.add(MSG.chatColors("&8\u2192 Simplifies the setup process"));
        guidedMeta.setLore(guidedLore);
        guidedSetup.setItemMeta(guidedMeta);
        inv.setItem(15, guidedSetup);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eTeam Setup Information"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Team setup process:"));
        infoLore.add(MSG.chatColors("&71. Set maximum teams"));
        infoLore.add(MSG.chatColors("&72. Set players per team"));
        infoLore.add(MSG.chatColors("&73. Create teams"));
        infoLore.add(MSG.chatColors("&74. Set team names"));
        infoLore.add(MSG.chatColors("&75. Set team colors"));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 This guides you through the full setup"));
        infoLore.add(MSG.chatColors("&8\u2192 Follow steps in order for best results"));
        infoLore.add(MSG.chatColors("&8\u2192 Make sure to complete all steps"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(13, infoItem);
        ItemStack backItem = TeamManagerMenu.createBackButton();
        inv.setItem(22, backItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_SETUP_CHOICE);
        return inv;
    }

    public static Inventory EditGuiInv(Player player, FileConfiguration Config) {
        Inventory EditGuiInv = Bukkit.createInventory((InventoryHolder)player, (int)45, (String)MSG.chatColors("&bTeam Manager"));
        TeamManagerMenu.fillInventory(EditGuiInv);
        ItemStack backItem = TeamManagerMenu.createBackButton();
        EditGuiInv.setItem(40, backItem);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eTeam Setup Information"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Team setup process:"));
        infoLore.add(MSG.chatColors("&71. Set maximum teams"));
        infoLore.add(MSG.chatColors("&72. Set players per team"));
        infoLore.add(MSG.chatColors("&73. Create teams"));
        infoLore.add(MSG.chatColors("&74. Set team names"));
        infoLore.add(MSG.chatColors("&75. Set team colors"));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Configure all settings in any order"));
        infoLore.add(MSG.chatColors("&8\u2192 Be sure to set max teams & players per team first"));
        infoLore.add(MSG.chatColors("&8\u2192 Create all teams before naming them"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        EditGuiInv.setItem(4, infoItem);
        ItemStack CreateTeam = TeamManagerMenu.GetCreateTeamItem(player, Config);
        EditGuiInv.setItem(10, CreateTeam);
        ItemStack DeleteTeam = TeamManagerMenu.GetDeleteTeamItem(player, Config);
        EditGuiInv.setItem(19, DeleteTeam);
        ItemStack MaxTeams = TeamManagerMenu.GetMaxTeams(player, Config);
        EditGuiInv.setItem(12, MaxTeams);
        ItemStack MaxPlayersPerTeam = TeamManagerMenu.GetMaxPlayersPerTeam(player, Config);
        EditGuiInv.setItem(21, MaxPlayersPerTeam);
        ItemStack SetTeamName = TeamManagerMenu.GetSetTeamNameItem(player, Config);
        EditGuiInv.setItem(14, SetTeamName);
        ItemStack SetTeamColor = TeamManagerMenu.GetSetTeamColorItem(player, Config);
        EditGuiInv.setItem(23, SetTeamColor);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_MANUAL);
        return EditGuiInv;
    }

    public static Inventory createGuidedMaxTeamsInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 1: Set Maximum Teams"));
        TeamManagerMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 1: Maximum Teams"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7First, set the maximum number of teams"));
        infoLore.add(MSG.chatColors("&7for your game. This will limit how many"));
        infoLore.add(MSG.chatColors("&7teams you can create later."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&7Click the bed icon to set the value."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Determines total number of teams"));
        infoLore.add(MSG.chatColors("&8\u2192 Affects total player capacity"));
        infoLore.add(MSG.chatColors("&8\u2192 Recommended: 2-8 teams for most games"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack maxTeamsItem = TeamManagerMenu.GetMaxTeams(player, config);
        inv.setItem(13, maxTeamsItem);
        ItemStack progressItem = TeamManagerMenu.createProgressIndicator(1, 5);
        inv.setItem(22, progressItem);
        ItemStack nextItem = TeamManagerMenu.createNextButton();
        inv.setItem(18, nextItem);
        ItemStack backItem = TeamManagerMenu.createBackButton();
        inv.setItem(26, backItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_MAX_TEAMS);
        playerSetupPhase.put(player.getUniqueId(), 1);
        return inv;
    }

    public static Inventory createGuidedPlayersPerTeamInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 2: Set Players Per Team"));
        TeamManagerMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 2: Players Per Team"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Now, set how many players can"));
        infoLore.add(MSG.chatColors("&7join each team. This determines"));
        infoLore.add(MSG.chatColors("&7the team size for your game."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&7Click the player head to set the value."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Sets the size of each team"));
        infoLore.add(MSG.chatColors("&8\u2192 Total players = Teams \u00d7 Players per team"));
        infoLore.add(MSG.chatColors("&8\u2192 Common values: 1 (solo), 2 (duos), 4 (squads)"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack playersPerTeamItem = TeamManagerMenu.GetMaxPlayersPerTeam(player, config);
        inv.setItem(13, playersPerTeamItem);
        ItemStack progressItem = TeamManagerMenu.createProgressIndicator(2, 5);
        inv.setItem(22, progressItem);
        ItemStack nextItem = TeamManagerMenu.createNextButton();
        inv.setItem(18, nextItem);
        ItemStack prevItem = TeamManagerMenu.createPrevButton();
        inv.setItem(26, prevItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_PLAYERS_PER_TEAM);
        playerSetupPhase.put(player.getUniqueId(), 2);
        return inv;
    }

    public static Inventory createGuidedCreateTeamsInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 3: Create Teams"));
        TeamManagerMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 3: Create Teams"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Now, create the actual teams."));
        infoLore.add(MSG.chatColors("&7Click the green dye to create a new team."));
        infoLore.add(MSG.chatColors("&7You can create multiple teams."));
        infoLore.add(MSG.chatColors("&7"));
        int maxTeams = config.getInt("SpawnLocations.MaxTeams", 0);
        int currentTeams = 0;
        ConfigurationSection spawnLocations = config.getConfigurationSection("SpawnLocations");
        if (spawnLocations != null) {
            for (String key : spawnLocations.getKeys(false)) {
                if (!key.startsWith("Team")) continue;
                ++currentTeams;
            }
        }
        infoLore.add(MSG.chatColors("&7Teams created: &f" + currentTeams + "/" + maxTeams));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Creates a team with default name/color"));
        infoLore.add(MSG.chatColors("&8\u2192 Teams are numbered sequentially (Team1, Team2, etc.)"));
        infoLore.add(MSG.chatColors("&8\u2192 You must create all teams up to your max teams value"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack createTeamItem = TeamManagerMenu.GetCreateTeamItem(player, config);
        inv.setItem(13, createTeamItem);
        ItemStack progressItem = TeamManagerMenu.createProgressIndicator(3, 5);
        inv.setItem(22, progressItem);
        ItemStack nextItem = TeamManagerMenu.createNextButton();
        inv.setItem(18, nextItem);
        ItemStack prevItem = TeamManagerMenu.createPrevButton();
        inv.setItem(26, prevItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_CREATE_TEAMS);
        playerSetupPhase.put(player.getUniqueId(), 3);
        return inv;
    }

    public static Inventory createGuidedTeamNamesInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 4: Set Team Names"));
        TeamManagerMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 4: Set Team Names"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Now, customize the names of your teams."));
        infoLore.add(MSG.chatColors("&7Click the name tag to see and edit"));
        infoLore.add(MSG.chatColors("&7all team names."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Customize team display names"));
        infoLore.add(MSG.chatColors("&8\u2192 You can use color codes with & symbol"));
        infoLore.add(MSG.chatColors("&8\u2192 Example: &f[&cRed Team&f]"));
        infoLore.add(MSG.chatColors("&8\u2192 Names appear in team chat and scoreboards"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack teamNameItem = TeamManagerMenu.GetSetTeamNameItem(player, config);
        inv.setItem(13, teamNameItem);
        ItemStack progressItem = TeamManagerMenu.createProgressIndicator(4, 5);
        inv.setItem(22, progressItem);
        ItemStack nextItem = TeamManagerMenu.createNextButton();
        inv.setItem(18, nextItem);
        ItemStack prevItem = TeamManagerMenu.createPrevButton();
        inv.setItem(26, prevItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_TEAM_NAMES);
        playerSetupPhase.put(player.getUniqueId(), 4);
        return inv;
    }

    public static Inventory createGuidedTeamColorsInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 5: Set Team Colors"));
        TeamManagerMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 5: Set Team Colors"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Finally, set the colors for each team."));
        infoLore.add(MSG.chatColors("&7Click the orange dye to see and edit"));
        infoLore.add(MSG.chatColors("&7all team colors."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Set team color codes (RED, BLUE, GREEN, etc.)"));
        infoLore.add(MSG.chatColors("&8\u2192 Colors affect team chat and scoreboard display"));
        infoLore.add(MSG.chatColors("&8\u2192 Match colors with team names for consistency"));
        infoLore.add(MSG.chatColors("&8\u2192 Available colors: RED, BLUE, GREEN, YELLOW, etc."));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack teamColorItem = TeamManagerMenu.GetSetTeamColorItem(player, config);
        inv.setItem(13, teamColorItem);
        ItemStack progressItem = TeamManagerMenu.createProgressIndicator(5, 5);
        inv.setItem(22, progressItem);
        ItemStack finishItem = new ItemStack(Material.EMERALD);
        ItemMeta finishMeta = finishItem.getItemMeta();
        finishMeta.setDisplayName(MSG.chatColors("&aFinish Setup"));
        ArrayList<String> finishLore = new ArrayList<String>();
        finishLore.add(MSG.chatColors("&7Click to complete the team setup process"));
        finishLore.add(MSG.chatColors("&7"));
        finishLore.add(MSG.chatColors("&8\u2192 Finalizes all team settings"));
        finishLore.add(MSG.chatColors("&8\u2192 Returns to main editor menu"));
        finishLore.add(MSG.chatColors("&8\u2192 Saves all configuration changes"));
        finishMeta.setLore(finishLore);
        finishItem.setItemMeta(finishMeta);
        inv.setItem(18, finishItem);
        ItemStack prevItem = TeamManagerMenu.createPrevButton();
        inv.setItem(26, prevItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_TEAM_COLORS);
        playerSetupPhase.put(player.getUniqueId(), 5);
        return inv;
    }

    public static Inventory createGuidedCompleteInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&aTeam Setup Complete!"));
        TeamManagerMenu.fillInventory(inv);
        ItemStack completeItem = new ItemStack(Material.EMERALD);
        ItemMeta completeMeta = completeItem.getItemMeta();
        completeMeta.setDisplayName(MSG.chatColors("&aSetup Complete!"));
        ArrayList<String> completeLore = new ArrayList<String>();
        completeLore.add(MSG.chatColors("&7Congratulations! You have successfully"));
        completeLore.add(MSG.chatColors("&7set up your teams. Here's a summary:"));
        completeLore.add(MSG.chatColors("&7"));
        int maxTeams = config.getInt("SpawnLocations.MaxTeams", 0);
        int playersPerTeam = config.getInt("SpawnLocations.PlayersPerTeam", 0);
        completeLore.add(MSG.chatColors("&7Max Teams: &f" + maxTeams));
        completeLore.add(MSG.chatColors("&7Players Per Team: &f" + playersPerTeam));
        completeLore.add(MSG.chatColors("&7"));
        completeLore.add(MSG.chatColors("&7Teams Created:"));
        ConfigurationSection spawnLocations = config.getConfigurationSection("SpawnLocations");
        if (spawnLocations != null) {
            for (String key : spawnLocations.getKeys(false)) {
                if (!key.startsWith("Team")) continue;
                String teamName = spawnLocations.getString(key + ".Name", "Unknown");
                String color = spawnLocations.getString(key + ".Color", "RESET");
                completeLore.add(MSG.chatColors("&f" + key + " - " + teamName + " (" + color + ")"));
            }
        }
        completeLore.add(MSG.chatColors("&7"));
        completeLore.add(MSG.chatColors("&8\u2192 All team settings have been saved"));
        completeLore.add(MSG.chatColors("&8\u2192 You can edit teams again at any time"));
        completeLore.add(MSG.chatColors("&8\u2192 Total game capacity: " + maxTeams * playersPerTeam + " players"));
        completeMeta.setLore(completeLore);
        completeItem.setItemMeta(completeMeta);
        inv.setItem(13, completeItem);
        ItemStack mainMenuItem = new ItemStack(Material.OAK_DOOR);
        ItemMeta mainMenuMeta = mainMenuItem.getItemMeta();
        mainMenuMeta.setDisplayName(MSG.chatColors("&bReturn to Main Menu"));
        ArrayList<String> mainMenuLore = new ArrayList<String>();
        mainMenuLore.add(MSG.chatColors("&7Click to return to the main editor menu"));
        mainMenuLore.add(MSG.chatColors("&7"));
        mainMenuLore.add(MSG.chatColors("&8\u2192 Exits team setup"));
        mainMenuLore.add(MSG.chatColors("&8\u2192 Returns to main game editor"));
        mainMenuMeta.setLore(mainMenuLore);
        mainMenuItem.setItemMeta(mainMenuMeta);
        inv.setItem(22, mainMenuItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_COMPLETE);
        playerSetupPhase.put(player.getUniqueId(), 6);
        return inv;
    }

    private static ItemStack createProgressIndicator(int currentStep, int totalSteps) {
        ItemStack progressItem = new ItemStack(Material.COMPASS);
        ItemMeta progressMeta = progressItem.getItemMeta();
        progressMeta.setDisplayName(MSG.chatColors("&eSetup Progress"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Step " + currentStep + " of " + totalSteps));
        lore.add(MSG.chatColors("&7"));
        StringBuilder progressBar = new StringBuilder("&7[");
        for (int i = 1; i <= totalSteps; ++i) {
            if (i == currentStep) {
                progressBar.append("&a\u25a0");
                continue;
            }
            if (i < currentStep) {
                progressBar.append("&2\u25a0");
                continue;
            }
            progressBar.append("&7\u25a0");
        }
        progressBar.append("&7]");
        lore.add(MSG.chatColors(progressBar.toString()));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Shows your current progress"));
        lore.add(MSG.chatColors("&8\u2192 Green: Current step"));
        lore.add(MSG.chatColors("&8\u2192 Dark green: Completed steps"));
        lore.add(MSG.chatColors("&8\u2192 Gray: Upcoming steps"));
        progressMeta.setLore(lore);
        progressItem.setItemMeta(progressMeta);
        return progressItem;
    }

    private static ItemStack createNextButton() {
        ItemStack nextItem = new ItemStack(Material.LIME_DYE);
        ItemMeta nextMeta = nextItem.getItemMeta();
        nextMeta.setDisplayName(MSG.chatColors("&aNext Step"));
        ArrayList<String> nextLore = new ArrayList<String>();
        nextLore.add(MSG.chatColors("&7Click to proceed to the next step"));
        nextLore.add(MSG.chatColors("&7"));
        nextLore.add(MSG.chatColors("&8\u2192 Saves current progress"));
        nextLore.add(MSG.chatColors("&8\u2192 Advances to the next setup step"));
        nextMeta.setLore(nextLore);
        nextItem.setItemMeta(nextMeta);
        return nextItem;
    }

    private static ItemStack createPrevButton() {
        ItemStack prevItem = new ItemStack(Material.RED_DYE);
        ItemMeta prevMeta = prevItem.getItemMeta();
        prevMeta.setDisplayName(MSG.chatColors("&cPrevious Step"));
        ArrayList<String> prevLore = new ArrayList<String>();
        prevLore.add(MSG.chatColors("&7Click to return to the previous step"));
        prevLore.add(MSG.chatColors("&7"));
        prevLore.add(MSG.chatColors("&8\u2192 Saves current progress"));
        prevLore.add(MSG.chatColors("&8\u2192 Returns to the previous setup step"));
        prevMeta.setLore(prevLore);
        prevItem.setItemMeta(prevMeta);
        return prevItem;
    }

    private static ItemStack createBackButton() {
        ItemStack backItem = new ItemStack(Material.ARROW);
        ItemMeta backMeta = backItem.getItemMeta();
        backMeta.setDisplayName(MSG.chatColors("&cGo Back"));
        ArrayList<String> backLore = new ArrayList<String>();
        backLore.add(MSG.chatColors("&7Click to return to the previous menu"));
        backLore.add(MSG.chatColors("&7"));
        backLore.add(MSG.chatColors("&8\u2192 Saves any changes made"));
        backLore.add(MSG.chatColors("&8\u2192 Returns to the previous menu"));
        backMeta.setLore(backLore);
        backItem.setItemMeta(backMeta);
        return backItem;
    }

    private static void fillInventory(Inventory inv) {
        Material material = Material.GRAY_STAINED_GLASS_PANE;
        ItemStack fillItem = new ItemStack(material);
        ItemMeta meta = fillItem.getItemMeta();
        meta.setDisplayName("\u00a7f ");
        fillItem.setItemMeta(meta);
        for (int i = 0; i < inv.getSize(); ++i) {
            inv.setItem(i, fillItem);
        }
    }

    public static ItemStack GetCreateTeamItem(Player player, FileConfiguration config) {
        Material item = Material.GREEN_DYE;
        ItemStack itemStack = new ItemStack(item);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(MSG.chatColors("&aCreate a new Team"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Click to create a new team!"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Your Current Teams:"));
        ConfigurationSection spawnLocations = config.getConfigurationSection("SpawnLocations");
        if (spawnLocations != null) {
            for (String key : spawnLocations.getKeys(false)) {
                if (!key.startsWith("Team")) continue;
                String teamName = spawnLocations.getString(key + ".Name", "Unknown");
                lore.add(MSG.chatColors("&f" + key + " &f- " + teamName));
            }
        }
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Creates a new team with default settings"));
        lore.add(MSG.chatColors("&8\u2192 Teams are assigned default names and colors"));
        lore.add(MSG.chatColors("&8\u2192 Limited by your Maximum Teams setting"));
        lore.add(MSG.chatColors("&8\u2192 You can customize names and colors later"));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    public static ItemStack GetDeleteTeamItem(Player player, FileConfiguration config) {
        Material Item2 = Material.RED_DYE;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        ItemMeta2.setDisplayName(MSG.chatColors("&cDelete a Team"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Click to delete a team!"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Your Current Teams:"));
        ConfigurationSection spawnLocations = config.getConfigurationSection("SpawnLocations");
        if (spawnLocations != null) {
            for (String key : spawnLocations.getKeys(false)) {
                if (!key.startsWith("Team")) continue;
                String teamName = spawnLocations.getString(key + ".Name", "Unknown");
                lore.add(MSG.chatColors("&f" + key + " &f- " + teamName));
            }
        }
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Permanently removes a team"));
        lore.add(MSG.chatColors("&8\u2192 Cannot be undone - use with caution"));
        lore.add(MSG.chatColors("&8\u2192 May require adjusting max teams afterward"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetMaxTeams(Player player, FileConfiguration Config) {
        Material Item2 = Material.WHITE_BED;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        int maxTeams = Config.getInt("SpawnLocations.MaxTeams", 0);
        ItemMeta2.setDisplayName(MSG.chatColors("&bSet Maximum Teams"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Click to set the maximum teams!"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Max Teams: &f" + maxTeams));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Determines how many teams can be created"));
        lore.add(MSG.chatColors("&8\u2192 Affects total player capacity"));
        lore.add(MSG.chatColors("&8\u2192 Total capacity = Max Teams \u00d7 Players Per Team"));
        lore.add(MSG.chatColors("&8\u2192 Should be set before creating teams"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetMaxPlayersPerTeam(Player player, FileConfiguration Config) {
        Material item = Material.PLAYER_HEAD;
        ItemStack itemStack = new ItemStack(item);
        SkullMeta skullMeta = (SkullMeta)itemStack.getItemMeta();
        if (skullMeta != null) {
            skullMeta.setDisplayName(MSG.chatColors("&bPlayers Per Team"));
            skullMeta.setOwningPlayer((OfflinePlayer)player);
            int PlayersPerTeam = Config.getInt("SpawnLocations.PlayersPerTeam", 0);
            ArrayList<String> lore = new ArrayList<String>();
            lore.add(MSG.chatColors("&7Click to set the players per team!"));
            lore.add(MSG.chatColors("&7"));
            lore.add(MSG.chatColors("&7Current Players Per Team: &f" + PlayersPerTeam));
            lore.add(MSG.chatColors("&7"));
            lore.add(MSG.chatColors("&8\u2192 Determines team size"));
            lore.add(MSG.chatColors("&8\u2192 Common values: 1 (solo), 2 (duos), 4 (squads)"));
            lore.add(MSG.chatColors("&8\u2192 Affects total player capacity"));
            lore.add(MSG.chatColors("&8\u2192 Required for proper team spawning"));
            skullMeta.setLore(lore);
            itemStack.setItemMeta((ItemMeta)skullMeta);
        }
        return itemStack;
    }

    public static ItemStack GetSetTeamNameItem(Player player, FileConfiguration config) {
        Material Item2 = Material.NAME_TAG;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        ItemMeta2.setDisplayName(MSG.chatColors("&bSet Team Names"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Click to edit team names!"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Your Current Teams:"));
        ConfigurationSection spawnLocations = config.getConfigurationSection("SpawnLocations");
        if (spawnLocations != null) {
            for (String key : spawnLocations.getKeys(false)) {
                if (!key.startsWith("Team")) continue;
                String teamName = spawnLocations.getString(key + ".Name", "Unknown");
                lore.add(MSG.chatColors("&f" + key + " &f- " + teamName));
            }
        }
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Customize display names for each team"));
        lore.add(MSG.chatColors("&8\u2192 Support color codes with & symbol"));
        lore.add(MSG.chatColors("&8\u2192 Example: &f[&cRed Team&f]"));
        lore.add(MSG.chatColors("&8\u2192 Names appear in chat and scoreboards"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetSetTeamColorItem(Player player, FileConfiguration config) {
        Material Item2 = Material.ORANGE_DYE;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        ItemMeta2.setDisplayName(MSG.chatColors("&bSet Team Colors"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Click to edit team colors!"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Your Current Teams:"));
        ConfigurationSection spawnLocations = config.getConfigurationSection("SpawnLocations");
        if (spawnLocations != null) {
            for (String key : spawnLocations.getKeys(false)) {
                if (!key.startsWith("Team")) continue;
                String teamName = spawnLocations.getString(key + ".Name", "Unknown");
                String color = spawnLocations.getString(key + ".Color", "RESET");
                lore.add(MSG.chatColors("&f" + key + " &f- " + teamName + " (" + color + ")"));
            }
        }
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Set color codes for each team"));
        lore.add(MSG.chatColors("&8\u2192 Available colors: RED, BLUE, GREEN, etc."));
        lore.add(MSG.chatColors("&8\u2192 Colors affect team chat and displays"));
        lore.add(MSG.chatColors("&8\u2192 Match with team names for consistency"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    @EventHandler
    public void OnInventoryClick(InventoryClickEvent event) {
        block22: {
            FileConfiguration config;
            String currentGUI;
            Player player;
            block50: {
                block49: {
                    block42: {
                        block48: {
                            block47: {
                                block46: {
                                    block45: {
                                        block44: {
                                            block43: {
                                                block41: {
                                                    block38: {
                                                        block40: {
                                                            block39: {
                                                                block35: {
                                                                    block37: {
                                                                        block36: {
                                                                            block32: {
                                                                                block34: {
                                                                                    block33: {
                                                                                        block29: {
                                                                                            block31: {
                                                                                                block30: {
                                                                                                    block26: {
                                                                                                        block28: {
                                                                                                            block27: {
                                                                                                                block23: {
                                                                                                                    block25: {
                                                                                                                        block24: {
                                                                                                                            Inventory inventory;
                                                                                                                            if (!(event.getWhoClicked() instanceof Player) || (inventory = event.getClickedInventory()) == null) break block22;
                                                                                                                            player = (Player)event.getWhoClicked();
                                                                                                                            currentGUI = MoonLab.PlayerMenu.get(player.getUniqueId());
                                                                                                                            config = WorldListeners.configEditer.get(player.getUniqueId());
                                                                                                                            if (currentGUI == null) break block22;
                                                                                                                            if (!currentGUI.equals(MENU_SETUP_CHOICE)) break block23;
                                                                                                                            event.setCancelled(true);
                                                                                                                            ItemStack clicked = event.getCurrentItem();
                                                                                                                            if (clicked == null) {
                                                                                                                                return;
                                                                                                                            }
                                                                                                                            if (event.getSlot() != 11) break block24;
                                                                                                                            player.closeInventory();
                                                                                                                            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.EditGuiInv(player, config)), 1L);
                                                                                                                            break block22;
                                                                                                                        }
                                                                                                                        if (event.getSlot() != 15) break block25;
                                                                                                                        player.closeInventory();
                                                                                                                        playerSetupPhase.put(player.getUniqueId(), 1);
                                                                                                                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.createGuidedMaxTeamsInventory(player, config)), 1L);
                                                                                                                        break block22;
                                                                                                                    }
                                                                                                                    if (event.getSlot() != 22) break block22;
                                                                                                                    player.closeInventory();
                                                                                                                    Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.EditGuiInv(player, config)), 1L);
                                                                                                                    break block22;
                                                                                                                }
                                                                                                                if (!currentGUI.equals(MENU_GUIDED_MAX_TEAMS)) break block26;
                                                                                                                event.setCancelled(true);
                                                                                                                ItemStack clicked = event.getCurrentItem();
                                                                                                                if (clicked == null) {
                                                                                                                    return;
                                                                                                                }
                                                                                                                if (event.getSlot() != 13) break block27;
                                                                                                                player.closeInventory();
                                                                                                                EditorMenu.AdminEditCache.put(player.getUniqueId(), "MaxTeams");
                                                                                                                player.sendMessage(MSG.chatColors("#87C8CEEnter a number in the chat to change the max teams"));
                                                                                                                break block22;
                                                                                                            }
                                                                                                            if (event.getSlot() != 18) break block28;
                                                                                                            player.closeInventory();
                                                                                                            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.createGuidedPlayersPerTeamInventory(player, config)), 1L);
                                                                                                            break block22;
                                                                                                        }
                                                                                                        if (event.getSlot() != 26) break block22;
                                                                                                        player.closeInventory();
                                                                                                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.createSetupChoiceMenu(player, config)), 1L);
                                                                                                        break block22;
                                                                                                    }
                                                                                                    if (!currentGUI.equals(MENU_GUIDED_PLAYERS_PER_TEAM)) break block29;
                                                                                                    event.setCancelled(true);
                                                                                                    ItemStack clicked = event.getCurrentItem();
                                                                                                    if (clicked == null) {
                                                                                                        return;
                                                                                                    }
                                                                                                    if (event.getSlot() != 13) break block30;
                                                                                                    player.closeInventory();
                                                                                                    EditorMenu.AdminEditCache.put(player.getUniqueId(), "PlayersPerTeam");
                                                                                                    player.sendMessage(MSG.chatColors("#87C8CEEnter a number in the chat to change the max players per team!"));
                                                                                                    break block22;
                                                                                                }
                                                                                                if (event.getSlot() != 18) break block31;
                                                                                                player.closeInventory();
                                                                                                Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.createGuidedCreateTeamsInventory(player, config)), 1L);
                                                                                                break block22;
                                                                                            }
                                                                                            if (event.getSlot() != 26) break block22;
                                                                                            player.closeInventory();
                                                                                            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.createGuidedMaxTeamsInventory(player, config)), 1L);
                                                                                            break block22;
                                                                                        }
                                                                                        if (!currentGUI.equals(MENU_GUIDED_CREATE_TEAMS)) break block32;
                                                                                        event.setCancelled(true);
                                                                                        ItemStack clicked = event.getCurrentItem();
                                                                                        if (clicked == null) {
                                                                                            return;
                                                                                        }
                                                                                        if (event.getSlot() != 13) break block33;
                                                                                        this.handleCreateTeam(player, config);
                                                                                        player.closeInventory();
                                                                                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.createGuidedCreateTeamsInventory(player, config)), 1L);
                                                                                        break block22;
                                                                                    }
                                                                                    if (event.getSlot() != 18) break block34;
                                                                                    player.closeInventory();
                                                                                    Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.createGuidedTeamNamesInventory(player, config)), 1L);
                                                                                    break block22;
                                                                                }
                                                                                if (event.getSlot() != 26) break block22;
                                                                                player.closeInventory();
                                                                                Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.createGuidedPlayersPerTeamInventory(player, config)), 1L);
                                                                                break block22;
                                                                            }
                                                                            if (!currentGUI.equals(MENU_GUIDED_TEAM_NAMES)) break block35;
                                                                            event.setCancelled(true);
                                                                            ItemStack clicked = event.getCurrentItem();
                                                                            if (clicked == null) {
                                                                                return;
                                                                            }
                                                                            if (event.getSlot() != 13) break block36;
                                                                            player.closeInventory();
                                                                            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.SetTeamNameInventory(player, config)), 1L);
                                                                            break block22;
                                                                        }
                                                                        if (event.getSlot() != 18) break block37;
                                                                        player.closeInventory();
                                                                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.createGuidedTeamColorsInventory(player, config)), 1L);
                                                                        break block22;
                                                                    }
                                                                    if (event.getSlot() != 26) break block22;
                                                                    player.closeInventory();
                                                                    Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.createGuidedCreateTeamsInventory(player, config)), 1L);
                                                                    break block22;
                                                                }
                                                                if (!currentGUI.equals(MENU_GUIDED_TEAM_COLORS)) break block38;
                                                                event.setCancelled(true);
                                                                ItemStack clicked = event.getCurrentItem();
                                                                if (clicked == null) {
                                                                    return;
                                                                }
                                                                if (event.getSlot() != 13) break block39;
                                                                player.closeInventory();
                                                                Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.SetTeamColorInventory(player, config)), 1L);
                                                                break block22;
                                                            }
                                                            if (event.getSlot() != 18) break block40;
                                                            player.closeInventory();
                                                            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.createGuidedCompleteInventory(player, config)), 1L);
                                                            break block22;
                                                        }
                                                        if (event.getSlot() != 26) break block22;
                                                        player.closeInventory();
                                                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.createGuidedTeamNamesInventory(player, config)), 1L);
                                                        break block22;
                                                    }
                                                    if (!currentGUI.equals(MENU_GUIDED_COMPLETE)) break block41;
                                                    event.setCancelled(true);
                                                    ItemStack clicked = event.getCurrentItem();
                                                    if (clicked == null) {
                                                        return;
                                                    }
                                                    if (event.getSlot() != 22) break block22;
                                                    player.closeInventory();
                                                    playerSetupPhase.remove(player.getUniqueId());
                                                    Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.EditGuiInv(player, config)), 1L);
                                                    break block22;
                                                }
                                                if (!currentGUI.equals(MENU_MANUAL)) break block42;
                                                ItemStack clicked = event.getCurrentItem();
                                                if (clicked == null) break block22;
                                                event.setCancelled(true);
                                                if (clicked.getType() == Material.GRAY_STAINED_GLASS_PANE) {
                                                    return;
                                                }
                                                if (event.getSlot() != 40) break block43;
                                                player.closeInventory();
                                                Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.EditGuiInv(player, config)), 1L);
                                                break block22;
                                            }
                                            if (event.getSlot() != 10) break block44;
                                            this.handleCreateTeam(player, config);
                                            player.closeInventory();
                                            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.EditGuiInv(player, config)), 1L);
                                            break block22;
                                        }
                                        if (event.getSlot() != 19) break block45;
                                        player.closeInventory();
                                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.createDeleteTeamInventory(player, config)), 1L);
                                        break block22;
                                    }
                                    if (event.getSlot() != 12) break block46;
                                    player.closeInventory();
                                    EditorMenu.AdminEditCache.put(player.getUniqueId(), "MaxTeams");
                                    player.sendMessage(MSG.chatColors("#87C8CEEnter a number in the chat to change the max teams"));
                                    break block22;
                                }
                                if (event.getSlot() != 21) break block47;
                                player.closeInventory();
                                EditorMenu.AdminEditCache.put(player.getUniqueId(), "PlayersPerTeam");
                                player.sendMessage(MSG.chatColors("#87C8CEEnter a number in the chat to change the max players per team!"));
                                break block22;
                            }
                            if (event.getSlot() != 14) break block48;
                            player.closeInventory();
                            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.SetTeamNameInventory(player, config)), 1L);
                            break block22;
                        }
                        if (event.getSlot() != 23) break block22;
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.SetTeamColorInventory(player, config)), 1L);
                        break block22;
                    }
                    if (!currentGUI.equals(MENU_DELETE_TEAM)) break block49;
                    event.setCancelled(true);
                    ItemStack clicked = event.getCurrentItem();
                    if (clicked == null) {
                        return;
                    }
                    if (event.getSlot() == 22) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> {
                            if (playerSetupPhase.containsKey(player.getUniqueId())) {
                                player.openInventory(TeamManagerMenu.createGuidedCreateTeamsInventory(player, config));
                            } else {
                                player.openInventory(TeamManagerMenu.EditGuiInv(player, config));
                            }
                        }, 1L);
                        return;
                    }
                    if (clicked.getType() != Material.PAPER) {
                        return;
                    }
                    String coloredTeamName = clicked.getItemMeta().getDisplayName();
                    String teamName = ChatColor.stripColor((String)coloredTeamName);
                    ConfigurationSection spawnLocations = config.getConfigurationSection("SpawnLocations");
                    if (spawnLocations == null) break block22;
                    for (String key : spawnLocations.getKeys(false)) {
                        if (!key.equalsIgnoreCase(teamName)) continue;
                        spawnLocations.set(key, null);
                        player.closeInventory();
                        EditorMenu.SaveConfig(player);
                        player.sendMessage(MSG.chatColors("#87C8CETeam " + teamName + " has been deleted!"));
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> {
                            if (playerSetupPhase.containsKey(player.getUniqueId())) {
                                player.openInventory(TeamManagerMenu.createGuidedCreateTeamsInventory(player, config));
                            } else {
                                player.openInventory(TeamManagerMenu.EditGuiInv(player, config));
                            }
                        }, 1L);
                        break block22;
                    }
                    break block22;
                }
                if (!currentGUI.equals(MENU_SET_TEAM_NAME)) break block50;
                event.setCancelled(true);
                ItemStack clicked = event.getCurrentItem();
                if (clicked == null) {
                    return;
                }
                if (event.getSlot() == 22) {
                    player.closeInventory();
                    Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> {
                        if (playerSetupPhase.containsKey(player.getUniqueId())) {
                            player.openInventory(TeamManagerMenu.createGuidedTeamNamesInventory(player, config));
                        } else {
                            player.openInventory(TeamManagerMenu.EditGuiInv(player, config));
                        }
                    }, 1L);
                    return;
                }
                if (clicked.getType() != Material.PAPER) {
                    return;
                }
                String coloredTeamName = clicked.getItemMeta().getDisplayName();
                String teamName = ChatColor.stripColor((String)coloredTeamName);
                ConfigurationSection spawnLocations = config.getConfigurationSection("SpawnLocations");
                if (spawnLocations == null) break block22;
                for (String key : spawnLocations.getKeys(false)) {
                    if (!key.equalsIgnoreCase(teamName)) continue;
                    player.closeInventory();
                    EditorMenu.AdminEditCache.put(player.getUniqueId(), "TeamNameSettings-" + key);
                    player.sendMessage(MSG.chatColors("#87C8CEEnter the new name of the team!"));
                    player.sendMessage(MSG.chatColors("#87C8CEYou can use color codes with &, for example: &f[&cRed Team&f]"));
                    break block22;
                }
                break block22;
            }
            if (currentGUI.equals(MENU_SET_TEAM_COLOR)) {
                event.setCancelled(true);
                ItemStack clicked = event.getCurrentItem();
                if (clicked == null) {
                    return;
                }
                if (event.getSlot() == 22) {
                    player.closeInventory();
                    Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> {
                        if (playerSetupPhase.containsKey(player.getUniqueId())) {
                            player.openInventory(TeamManagerMenu.createGuidedTeamColorsInventory(player, config));
                        } else {
                            player.openInventory(TeamManagerMenu.EditGuiInv(player, config));
                        }
                    }, 1L);
                    return;
                }
                if (clicked.getType() != Material.PAPER) {
                    return;
                }
                String coloredTeamName = clicked.getItemMeta().getDisplayName();
                String teamName = ChatColor.stripColor((String)coloredTeamName);
                ConfigurationSection spawnLocations = config.getConfigurationSection("SpawnLocations");
                if (spawnLocations != null) {
                    for (String key : spawnLocations.getKeys(false)) {
                        if (!key.equalsIgnoreCase(teamName)) continue;
                        player.closeInventory();
                        EditorMenu.AdminEditCache.put(player.getUniqueId(), "TeamColorSettings-" + key);
                        player.sendMessage(MSG.chatColors("#87C8CEEnter the new color of the team!"));
                        player.sendMessage(MSG.chatColors("#87C8CEAvailable colors: RED, BLUE, GREEN, YELLOW, AQUA, GOLD, PURPLE, etc."));
                        break;
                    }
                }
            }
        }
    }

    private void handleCreateTeam(Player player, FileConfiguration config) {
        int maxTeams = config.getInt("SpawnLocations.MaxTeams", 0);
        int nextTeamNumber = this.getNextAvailableTeamNumber(config, maxTeams);
        if (nextTeamNumber == -1) {
            player.sendMessage(String.valueOf(ChatColor.RED) + "No available slots for new teams. Increase max teams first.");
        } else {
            String teamName = "&f[Team" + nextTeamNumber + "]";
            String teamColor = this.getNextAvailableColor(config);
            if (teamColor == null) {
                player.sendMessage(String.valueOf(ChatColor.RED) + "No available colors left for new teams.");
            } else {
                config.set("SpawnLocations.Team" + nextTeamNumber + ".Name", (Object)teamName);
                config.set("SpawnLocations.Team" + nextTeamNumber + ".Color", (Object)teamColor);
                EditorMenu.SaveConfig(player);
                player.sendMessage(MSG.chatColors("#87C8CENew team created: " + teamName));
            }
        }
    }

    @EventHandler
    public void onAdminChat(AsyncPlayerChatEvent event) {
        String editSetting;
        Player player = event.getPlayer();
        FileConfiguration config = WorldListeners.configEditer.get(player.getUniqueId());
        if (EditorMenu.AdminEditCache.containsKey(player.getUniqueId()) && ((editSetting = EditorMenu.AdminEditCache.get(player.getUniqueId())).equalsIgnoreCase("MaxTeams") || editSetting.equalsIgnoreCase("PlayersPerTeam") || editSetting.contains("TeamColorSettings-") || editSetting.contains("TeamNameSettings-"))) {
            try {
                if (editSetting.equalsIgnoreCase("MaxTeams")) {
                    String message = event.getMessage().replaceAll("[^-?0-9]", "");
                    int newAmount = Integer.parseInt(message);
                    config.set("SpawnLocations.MaxTeams", (Object)newAmount);
                    player.sendMessage(MSG.chatColors("#87C8CEUpdated the maximum teams to " + newAmount + "!"));
                    this.returnToAppropriateMenu(player, config, MENU_GUIDED_MAX_TEAMS);
                } else if (editSetting.equalsIgnoreCase("PlayersPerTeam")) {
                    String message = event.getMessage().replaceAll("[^-?0-9]", "");
                    int newAmount = Integer.parseInt(message);
                    config.set("SpawnLocations.PlayersPerTeam", (Object)newAmount);
                    player.sendMessage(MSG.chatColors("#87C8CEUpdated the maximum players per team to " + newAmount + "!"));
                    this.returnToAppropriateMenu(player, config, MENU_GUIDED_PLAYERS_PER_TEAM);
                } else if (editSetting.contains("TeamColorSettings-")) {
                    String message = event.getMessage();
                    String team = editSetting.replace("TeamColorSettings-", "");
                    config.set("SpawnLocations." + team + ".Color", (Object)message.toUpperCase());
                    player.sendMessage(MSG.chatColors("#87C8CEUpdated color for " + team + " to " + message.toUpperCase() + "!"));
                    if (playerSetupPhase.containsKey(player.getUniqueId()) && playerSetupPhase.get(player.getUniqueId()) == 5) {
                        this.returnToAppropriateMenu(player, config, MENU_GUIDED_TEAM_COLORS);
                    } else {
                        this.returnToAppropriateMenu(player, config, null);
                    }
                } else if (editSetting.contains("TeamNameSettings-")) {
                    String message = event.getMessage();
                    String team = editSetting.replace("TeamNameSettings-", "");
                    config.set("SpawnLocations." + team + ".Name", (Object)message);
                    player.sendMessage(MSG.chatColors("#87C8CEUpdated name for " + team + " to " + message + "!"));
                    if (playerSetupPhase.containsKey(player.getUniqueId()) && playerSetupPhase.get(player.getUniqueId()) == 4) {
                        this.returnToAppropriateMenu(player, config, MENU_GUIDED_TEAM_NAMES);
                    } else {
                        this.returnToAppropriateMenu(player, config, null);
                    }
                }
                EditorMenu.SaveConfig(player);
                EditorMenu.AdminEditCache.remove(player.getUniqueId());
            }
            catch (NumberFormatException var7) {
                player.sendMessage(MSG.chatColors("&cUnknown number! Only use numbers!"));
            }
            event.setCancelled(true);
        }
    }

    private void returnToAppropriateMenu(Player player, FileConfiguration config, String guidedMenuType) {
        Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> {
            if (playerSetupPhase.containsKey(player.getUniqueId())) {
                int phase = playerSetupPhase.get(player.getUniqueId());
                if (guidedMenuType != null) {
                    if (guidedMenuType.equals(MENU_GUIDED_MAX_TEAMS)) {
                        player.openInventory(TeamManagerMenu.createGuidedMaxTeamsInventory(player, config));
                    } else if (guidedMenuType.equals(MENU_GUIDED_PLAYERS_PER_TEAM)) {
                        player.openInventory(TeamManagerMenu.createGuidedPlayersPerTeamInventory(player, config));
                    } else if (guidedMenuType.equals(MENU_GUIDED_TEAM_NAMES)) {
                        player.openInventory(TeamManagerMenu.createGuidedTeamNamesInventory(player, config));
                    } else if (guidedMenuType.equals(MENU_GUIDED_TEAM_COLORS)) {
                        player.openInventory(TeamManagerMenu.createGuidedTeamColorsInventory(player, config));
                    }
                } else {
                    switch (phase) {
                        case 1: {
                            player.openInventory(TeamManagerMenu.createGuidedMaxTeamsInventory(player, config));
                            break;
                        }
                        case 2: {
                            player.openInventory(TeamManagerMenu.createGuidedPlayersPerTeamInventory(player, config));
                            break;
                        }
                        case 3: {
                            player.openInventory(TeamManagerMenu.createGuidedCreateTeamsInventory(player, config));
                            break;
                        }
                        case 4: {
                            player.openInventory(TeamManagerMenu.createGuidedTeamNamesInventory(player, config));
                            break;
                        }
                        case 5: {
                            player.openInventory(TeamManagerMenu.createGuidedTeamColorsInventory(player, config));
                            break;
                        }
                        case 6: {
                            player.openInventory(TeamManagerMenu.createGuidedCompleteInventory(player, config));
                            break;
                        }
                        default: {
                            player.openInventory(TeamManagerMenu.EditGuiInv(player, config));
                        }
                    }
                }
            } else {
                player.openInventory(TeamManagerMenu.EditGuiInv(player, config));
            }
        });
    }

    private int getNextAvailableTeamNumber(FileConfiguration config, int maxTeams) {
        for (int i = 1; i <= maxTeams; ++i) {
            if (config.contains("SpawnLocations.Team" + i)) continue;
            return i;
        }
        return -1;
    }

    private String getNextAvailableColor(FileConfiguration config) {
        ArrayList<String> availableColors = new ArrayList<String>(Arrays.asList("RED", "BLUE", "GREEN", "YELLOW", "AQUA", "GOLD", "PURPLE", "DARK_RED", "DARK_BLUE", "DARK_GREEN", "DARK_AQUA", "DARK_PURPLE", "GRAY", "BLACK", "WHITE"));
        ConfigurationSection spawnLocations = config.getConfigurationSection("SpawnLocations");
        if (spawnLocations != null) {
            for (String key : spawnLocations.getKeys(false)) {
                String color;
                if (!key.startsWith("Team") || (color = spawnLocations.getString(key + ".Color")) == null) continue;
                availableColors.remove(color);
            }
        }
        return availableColors.isEmpty() ? null : (String)availableColors.get(0);
    }

    public static Inventory createDeleteTeamInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)null, (int)27, (String)(String.valueOf(ChatColor.RED) + "Select a Team to Delete"));
        TeamManagerMenu.fillInventory(inv);
        ConfigurationSection teamsSection = config.getConfigurationSection("SpawnLocations");
        if (teamsSection != null) {
            int slot = 10;
            for (String key : teamsSection.getKeys(false)) {
                if (!key.matches("Team\\d+") || slot >= 17) continue;
                String teamName = MSG.chatColors("&b" + key);
                String color = teamsSection.getString(key + ".Color", "N/A");
                String displayname = teamsSection.getString(key + ".Name", "N/A");
                String displayName = ChatColor.translateAlternateColorCodes((char)'&', (String)teamName);
                ItemStack teamItem = new ItemStack(Material.PAPER);
                ItemMeta meta = teamItem.getItemMeta();
                meta.setDisplayName(displayName);
                ArrayList<Object> lore = new ArrayList<Object>();
                lore.add(MSG.chatColors("&7DisplayName: " + displayname));
                String var10001 = String.valueOf(ChatColor.GRAY);
                lore.add(var10001 + "Color: " + ChatColor.translateAlternateColorCodes((char)'&', (String)color));
                lore.add(String.valueOf(ChatColor.GRAY) + "Click to delete this team.");
                lore.add(MSG.chatColors("&7"));
                lore.add(MSG.chatColors("&8\u2192 Permanently removes this team"));
                lore.add(MSG.chatColors("&8\u2192 This action cannot be undone"));
                meta.setLore(lore);
                teamItem.setItemMeta(meta);
                inv.setItem(slot, teamItem);
                if (slot % 9 == 7) {
                    slot += 3;
                    continue;
                }
                ++slot;
            }
        }
        ItemStack backItem = TeamManagerMenu.createBackButton();
        inv.setItem(22, backItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_DELETE_TEAM);
        return inv;
    }

    public static Inventory SetTeamNameInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)null, (int)27, (String)(String.valueOf(ChatColor.RED) + "Change a Team's Name"));
        TeamManagerMenu.fillInventory(inv);
        ConfigurationSection teamsSection = config.getConfigurationSection("SpawnLocations");
        if (teamsSection != null) {
            int slot = 10;
            for (String key : teamsSection.getKeys(false)) {
                if (!key.matches("Team\\d+") || slot >= 17) continue;
                String teamName = MSG.chatColors("&b" + key);
                String color = teamsSection.getString(key + ".Color", "N/A");
                String displayname = teamsSection.getString(key + ".Name", "N/A");
                String displayName = ChatColor.translateAlternateColorCodes((char)'&', (String)teamName);
                ItemStack teamItem = new ItemStack(Material.PAPER);
                ItemMeta meta = teamItem.getItemMeta();
                meta.setDisplayName(displayName);
                ArrayList<Object> lore = new ArrayList<Object>();
                lore.add(MSG.chatColors("&7Current Name: " + displayname));
                String var10001 = String.valueOf(ChatColor.GRAY);
                lore.add(var10001 + "Color: " + ChatColor.translateAlternateColorCodes((char)'&', (String)color));
                lore.add(String.valueOf(ChatColor.GRAY) + "Click to change this team's name.");
                lore.add(MSG.chatColors("&7"));
                lore.add(MSG.chatColors("&8\u2192 Set a custom display name"));
                lore.add(MSG.chatColors("&8\u2192 Use &-codes for colors"));
                lore.add(MSG.chatColors("&8\u2192 Example: &f[&cRed Team&f]"));
                meta.setLore(lore);
                teamItem.setItemMeta(meta);
                inv.setItem(slot, teamItem);
                if (slot % 9 == 7) {
                    slot += 3;
                    continue;
                }
                ++slot;
            }
        }
        ItemStack backItem = TeamManagerMenu.createBackButton();
        inv.setItem(22, backItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_SET_TEAM_NAME);
        return inv;
    }

    public static Inventory SetTeamColorInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)null, (int)27, (String)(String.valueOf(ChatColor.RED) + "Change a Team's Color"));
        TeamManagerMenu.fillInventory(inv);
        ConfigurationSection teamsSection = config.getConfigurationSection("SpawnLocations");
        if (teamsSection != null) {
            int slot = 10;
            for (String key : teamsSection.getKeys(false)) {
                if (!key.matches("Team\\d+") || slot >= 17) continue;
                String teamName = MSG.chatColors("&b" + key);
                String color = teamsSection.getString(key + ".Color", "N/A");
                String displayname = teamsSection.getString(key + ".Name", "N/A");
                String displayName = ChatColor.translateAlternateColorCodes((char)'&', (String)teamName);
                ItemStack teamItem = new ItemStack(Material.PAPER);
                ItemMeta meta = teamItem.getItemMeta();
                meta.setDisplayName(displayName);
                ArrayList<Object> lore = new ArrayList<Object>();
                lore.add(MSG.chatColors("&7DisplayName: " + displayname));
                String var10001 = String.valueOf(ChatColor.GRAY);
                lore.add(var10001 + "Current Color: " + ChatColor.translateAlternateColorCodes((char)'&', (String)color));
                lore.add(String.valueOf(ChatColor.GRAY) + "Click to change this team's color.");
                lore.add(MSG.chatColors("&7"));
                lore.add(MSG.chatColors("&8\u2192 Set team color code"));
                lore.add(MSG.chatColors("&8\u2192 Available: RED, BLUE, GREEN, YELLOW, etc."));
                lore.add(MSG.chatColors("&8\u2192 Controls team chat and scoreboard colors"));
                meta.setLore(lore);
                teamItem.setItemMeta(meta);
                inv.setItem(slot, teamItem);
                if (slot % 9 == 7) {
                    slot += 3;
                    continue;
                }
                ++slot;
            }
        }
        ItemStack backItem = TeamManagerMenu.createBackButton();
        inv.setItem(22, backItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_SET_TEAM_COLOR);
        return inv;
    }
}

