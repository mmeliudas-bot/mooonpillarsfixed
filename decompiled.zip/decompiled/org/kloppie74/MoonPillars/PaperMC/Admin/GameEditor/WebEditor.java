/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.ConsoleCommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;
import org.kloppie74.MoonPillars.PaperMC.WebEditor.WebEditorSessionManager;

public class WebEditor
extends AdminSubCommand {
    @Override
    public String getName() {
        return "WebEditor";
    }

    @Override
    public String getDescription() {
        return "Open or save with the web editor for plugin data files.";
    }

    @Override
    public String getSyntax() {
        return "/mpa webeditor <open/save> [id]";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (!player.hasPermission("mpa.WebEditor")) {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        } else if (args.length < 2) {
            player.sendMessage("\u00a7cUsage: /mpa webeditor <open/save> [id]");
        } else if (args[1].equalsIgnoreCase("open")) {
            String saveId = UUID.randomUUID().toString();
            WebEditorSessionManager.createSession(player, saveId, MoonLab.getInstance());
            ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
            String var10001 = player.getName();
            var10000.sendMessage("\u00a7aWeb editor session created for player: " + var10001 + " with token: " + saveId);
        } else if (args[1].equalsIgnoreCase("save")) {
            String saveId = args.length >= 3 ? args[2] : "default";
            WebEditorSessionManager.handleWebEditorSave(player, saveId);
            ConsoleCommandSender var10000 = Bukkit.getConsoleSender();
            String var10001 = player.getName();
            var10000.sendMessage("\u00a7aWeb editor save triggered by: " + var10001 + " with saveId: " + saveId);
        } else {
            player.sendMessage("\u00a7cUsage: /mpa webeditor <open/save> [id]");
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        sender.sendMessage("\u00a7cThis command can only be executed by players");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (args.length == 1) {
            completions.add("open");
            completions.add("save");
        }
        Collections.sort(completions);
        return completions;
    }
}

