/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Portals.PortalListener;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class PortalManager
extends AdminSubCommand {
    private static final Map<UUID, String> editingPortal = new HashMap<UUID, String>();
    private static final Map<UUID, Location> pos1 = new HashMap<UUID, Location>();
    private static final Map<UUID, Location> pos2 = new HashMap<UUID, Location>();

    @Override
    public String getName() {
        return "portal";
    }

    @Override
    public String getDescription() {
        return "Create and manage portals";
    }

    @Override
    public String getSyntax() {
        return "/mpa portal create <name> | edit <name> <parameter> <value> | list | delete <name>";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (!player.hasPermission("mpa.portal")) {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        } else if (args.length < 2) {
            player.sendMessage(MSG.chatColors("&cUsage: " + this.getSyntax()));
        } else {
            switch (args[1].toLowerCase()) {
                case "create": {
                    this.handleCreate(player, args);
                    break;
                }
                case "edit": {
                    this.handleEdit(player, args);
                    break;
                }
                case "list": {
                    this.listPortals(player);
                    break;
                }
                case "delete": {
                    this.deletePortal(player, args);
                    break;
                }
                case "setpos1": {
                    this.setPosition(player, 1);
                    break;
                }
                case "setpos2": {
                    this.setPosition(player, 2);
                    break;
                }
                default: {
                    player.sendMessage(MSG.chatColors("&cUnknown subcommand. Use create, edit, list, or delete."));
                }
            }
        }
    }

    private void handleCreate(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(MSG.chatColors("&cUsage: /mpa portal create <name>"));
        } else {
            String name = args[2];
            FileConfiguration config = SettingsManager.getInstance().getPortals();
            if (config.contains("Portals." + name)) {
                player.sendMessage(MSG.chatColors("&cA portal with that name already exists!"));
            } else {
                editingPortal.put(player.getUniqueId(), name);
                pos1.remove(player.getUniqueId());
                pos2.remove(player.getUniqueId());
                config.set("Portals." + name + ".World", (Object)player.getWorld().getName());
                config.set("Portals." + name + ".Min.X", (Object)0);
                config.set("Portals." + name + ".Min.Y", (Object)0);
                config.set("Portals." + name + ".Min.Z", (Object)0);
                config.set("Portals." + name + ".Max.X", (Object)0);
                config.set("Portals." + name + ".Max.Y", (Object)0);
                config.set("Portals." + name + ".Max.Z", (Object)0);
                config.set("Portals." + name + ".Action", (Object)"COMMAND");
                config.set("Portals." + name + ".Execute_Action_As", (Object)"PLAYER");
                config.set("Portals." + name + ".Execute", (Object)"");
                config.set("Portals." + name + ".Message", (Object)"&aYou entered a portal!");
                SettingsManager.getInstance();
                SettingsManager.saveSettings("Portals");
                player.sendMessage(MSG.chatColors("&aCreated new portal '" + name + "'"));
                player.sendMessage(MSG.chatColors("&aNow set the portal boundaries:"));
                player.sendMessage(MSG.chatColors("&a- Use /mpa portal setpos1 to set first corner"));
                player.sendMessage(MSG.chatColors("&a- Use /mpa portal setpos2 to set second corner"));
            }
        }
    }

    private void handleEdit(Player player, String[] args) {
        if (args.length < 4) {
            player.sendMessage(MSG.chatColors("&cUsage: /mpa portal edit <name> <parameter> <value>"));
            player.sendMessage(MSG.chatColors("&cParameters: action, execute_as, execute, message"));
        } else {
            String name = args[2];
            String parameter = args[3].toLowerCase();
            FileConfiguration config = SettingsManager.getInstance().getPortals();
            if (!config.contains("Portals." + name)) {
                player.sendMessage(MSG.chatColors("&cPortal '" + name + "' does not exist!"));
            } else {
                editingPortal.put(player.getUniqueId(), name);
                if (args.length < 5 && !parameter.equals("setpos1") && !parameter.equals("setpos2")) {
                    player.sendMessage(MSG.chatColors("&cYou must provide a value for the parameter!"));
                } else {
                    int var7 = -1;
                    switch (parameter.hashCode()) {
                        case -1422950858: {
                            if (!parameter.equals("action")) break;
                            var7 = 0;
                            break;
                        }
                        case -1319569547: {
                            if (!parameter.equals("execute")) break;
                            var7 = 3;
                            break;
                        }
                        case -1090979225: {
                            if (!parameter.equals("executeas")) break;
                            var7 = 2;
                            break;
                        }
                        case 539380028: {
                            if (!parameter.equals("execute_as")) break;
                            var7 = 1;
                            break;
                        }
                        case 954925063: {
                            if (!parameter.equals("message")) break;
                            var7 = 4;
                            break;
                        }
                        case 1985827775: {
                            if (!parameter.equals("setpos1")) break;
                            var7 = 5;
                            break;
                        }
                        case 1985827776: {
                            if (!parameter.equals("setpos2")) break;
                            var7 = 6;
                        }
                    }
                    switch (var7) {
                        case 0: {
                            String action = args[4].toUpperCase();
                            if (!action.equals("COMMAND") && !action.equals("TELEPORT")) {
                                player.sendMessage(MSG.chatColors("&cInvalid action. Use COMMAND or TELEPORT."));
                                break;
                            }
                            config.set("Portals." + name + ".Action", (Object)action);
                            player.sendMessage(MSG.chatColors("&aSet action to " + action));
                            break;
                        }
                        case 1: 
                        case 2: {
                            String executeAs = args[4].toUpperCase();
                            if (!executeAs.equals("PLAYER") && !executeAs.equals("CONSOLE")) {
                                player.sendMessage(MSG.chatColors("&cInvalid execute_as. Use PLAYER or CONSOLE."));
                                break;
                            }
                            config.set("Portals." + name + ".Execute_Action_As", (Object)executeAs);
                            player.sendMessage(MSG.chatColors("&aSet execute_as to " + executeAs));
                            break;
                        }
                        case 3: {
                            StringBuilder execute = new StringBuilder();
                            for (int i = 4; i < args.length; ++i) {
                                execute.append(args[i]).append(" ");
                            }
                            config.set("Portals." + name + ".Execute", (Object)execute.toString().trim());
                            player.sendMessage(MSG.chatColors("&aSet execute to: " + String.valueOf(execute)));
                            break;
                        }
                        case 4: {
                            StringBuilder message = new StringBuilder();
                            for (int i = 4; i < args.length; ++i) {
                                message.append(args[i]).append(" ");
                            }
                            config.set("Portals." + name + ".Message", (Object)message.toString().trim());
                            player.sendMessage(MSG.chatColors("&aSet message to: " + String.valueOf(message)));
                            player.sendMessage(MSG.chatColors("&aMessage will appear as: " + MSG.chatColors(message.toString().trim())));
                            break;
                        }
                        case 5: {
                            this.setPosition(player, 1);
                            break;
                        }
                        case 6: {
                            this.setPosition(player, 2);
                            break;
                        }
                        default: {
                            player.sendMessage(MSG.chatColors("&cUnknown parameter. Use action, execute_as, execute, message, setpos1, or setpos2."));
                        }
                    }
                    SettingsManager.getInstance();
                    SettingsManager.saveSettings("Portals");
                    if (PortalListener.getInstance() != null) {
                        PortalListener.getInstance().reloadPortals();
                    }
                }
            }
        }
    }

    private void setPosition(Player player, int posNum) {
        String portalName = editingPortal.get(player.getUniqueId());
        if (portalName == null) {
            player.sendMessage(MSG.chatColors("&cYou are not currently editing a portal. Use /mpa portal create or edit first."));
        } else {
            Location location = player.getLocation();
            if (posNum == 1) {
                pos1.put(player.getUniqueId(), location);
                String var10001 = this.formatLocation(location);
                player.sendMessage(MSG.chatColors("&aSet position 1 at " + var10001));
            } else {
                pos2.put(player.getUniqueId(), location);
                String var10001 = this.formatLocation(location);
                player.sendMessage(MSG.chatColors("&aSet position 2 at " + var10001));
            }
            if (pos1.containsKey(player.getUniqueId()) && pos2.containsKey(player.getUniqueId())) {
                this.updatePortalBoundaries(player, portalName);
            }
        }
    }

    private void updatePortalBoundaries(Player player, String portalName) {
        Location loc1 = pos1.get(player.getUniqueId());
        Location loc2 = pos2.get(player.getUniqueId());
        if (!loc1.getWorld().equals((Object)loc2.getWorld())) {
            player.sendMessage(MSG.chatColors("&cBoth positions must be in the same world!"));
        } else {
            FileConfiguration config = SettingsManager.getInstance().getPortals();
            double minX = Math.min(loc1.getX(), loc2.getX());
            double minY = Math.min(loc1.getY(), loc2.getY());
            double minZ = Math.min(loc1.getZ(), loc2.getZ());
            double maxX = Math.max(loc1.getX(), loc2.getX());
            double maxY = Math.max(loc1.getY(), loc2.getY());
            double maxZ = Math.max(loc1.getZ(), loc2.getZ());
            config.set("Portals." + portalName + ".World", (Object)loc1.getWorld().getName());
            config.set("Portals." + portalName + ".Min.X", (Object)minX);
            config.set("Portals." + portalName + ".Min.Y", (Object)minY);
            config.set("Portals." + portalName + ".Min.Z", (Object)minZ);
            config.set("Portals." + portalName + ".Max.X", (Object)maxX);
            config.set("Portals." + portalName + ".Max.Y", (Object)maxY);
            config.set("Portals." + portalName + ".Max.Z", (Object)maxZ);
            SettingsManager.getInstance();
            SettingsManager.saveSettings("Portals");
            if (PortalListener.getInstance() != null) {
                PortalListener.getInstance().reloadPortals();
            }
            player.sendMessage(MSG.chatColors("&aUpdated portal boundaries for '" + portalName + "'"));
            String var10001 = loc1.getWorld().getName();
            player.sendMessage(MSG.chatColors("&aRegion: " + var10001 + " from " + this.formatCoordinates(minX, minY, minZ) + " to " + this.formatCoordinates(maxX, maxY, maxZ)));
        }
    }

    private void listPortals(Player player) {
        FileConfiguration config = SettingsManager.getInstance().getPortals();
        if (config.contains("Portals") && !config.getConfigurationSection("Portals").getKeys(false).isEmpty()) {
            player.sendMessage(MSG.chatColors("&a=== Portal List ==="));
            for (String portalName : config.getConfigurationSection("Portals").getKeys(false)) {
                String world = config.getString("Portals." + portalName + ".World", "unknown");
                String action = config.getString("Portals." + portalName + ".Action", "COMMAND");
                String execute = config.getString("Portals." + portalName + ".Execute", "");
                player.sendMessage(MSG.chatColors("&a" + portalName + " &7- &fWorld: " + world + " | Action: " + action + " | Execute: " + execute));
            }
        } else {
            player.sendMessage(MSG.chatColors("&cNo portals have been created yet."));
        }
    }

    private void deletePortal(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(MSG.chatColors("&cUsage: /mpa portal delete <name>"));
        } else {
            String name = args[2];
            FileConfiguration config = SettingsManager.getInstance().getPortals();
            if (!config.contains("Portals." + name)) {
                player.sendMessage(MSG.chatColors("&cPortal '" + name + "' does not exist!"));
            } else {
                config.set("Portals." + name, null);
                SettingsManager.getInstance();
                SettingsManager.saveSettings("Portals");
                if (PortalListener.getInstance() != null) {
                    PortalListener.getInstance().reloadPortals();
                }
                if (name.equals(editingPortal.get(player.getUniqueId()))) {
                    editingPortal.remove(player.getUniqueId());
                    pos1.remove(player.getUniqueId());
                    pos2.remove(player.getUniqueId());
                }
                player.sendMessage(MSG.chatColors("&aDeleted portal '" + name + "'"));
            }
        }
    }

    private String formatLocation(Location location) {
        return String.format("%.1f, %.1f, %.1f", location.getX(), location.getY(), location.getZ());
    }

    private String formatCoordinates(double x, double y, double z) {
        return String.format("%.1f, %.1f, %.1f", x, y, z);
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        sender.sendMessage("This command can only be used by players.");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (args.length == 2) {
            completions.addAll(Arrays.asList("create", "edit", "list", "delete", "setpos1", "setpos2"));
        } else if (args.length == 3) {
            FileConfiguration config;
            String parameter = args[1].toLowerCase();
            if ((parameter.equals("edit") || parameter.equals("delete")) && (config = SettingsManager.getInstance().getPortals()).contains("Portals")) {
                completions.addAll(config.getConfigurationSection("Portals").getKeys(false));
            }
        } else if (args.length == 4 && args[1].equalsIgnoreCase("edit")) {
            completions.addAll(Arrays.asList("action", "execute_as", "execute", "message", "setpos1", "setpos2"));
        } else if (args.length == 5) {
            String parameter = args[3].toLowerCase();
            if (parameter.equals("action")) {
                completions.addAll(Arrays.asList("COMMAND", "TELEPORT"));
            } else if (parameter.equals("execute_as") || parameter.equals("executeas")) {
                completions.addAll(Arrays.asList("PLAYER", "CONSOLE"));
            }
        }
        Collections.sort(completions);
        return completions;
    }
}

