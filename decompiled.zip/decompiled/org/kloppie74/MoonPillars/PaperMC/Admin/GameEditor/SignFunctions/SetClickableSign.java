/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.block.Block
 *  org.bukkit.block.Sign
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.SignFunctions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class SetClickableSign
extends AdminSubCommand {
    @Override
    public String getName() {
        return "setclickablesign";
    }

    @Override
    public String getDescription() {
        return "Set a clickable sign at your current target block!";
    }

    @Override
    public String getSyntax() {
        return "/mpa setclickablesign [name]";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (!player.hasPermission("mpa.setclickablesign")) {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        } else {
            Block targetBlock = player.getTargetBlockExact(5);
            if (targetBlock != null && targetBlock.getState() instanceof Sign) {
                Object name;
                if (args.length < 2) {
                    String var10000 = UUID.randomUUID().toString();
                    name = "sign_" + var10000.substring(0, 8);
                } else {
                    name = args[1];
                }
                FileConfiguration config = SettingsManager.getInstance().getClickableSigns();
                String worldName = targetBlock.getWorld().getName();
                int x = targetBlock.getX();
                int y = targetBlock.getY();
                int z = targetBlock.getZ();
                config.set("ClickableSigns." + (String)name + ".World", (Object)worldName);
                config.set("ClickableSigns." + (String)name + ".X", (Object)x);
                config.set("ClickableSigns." + (String)name + ".Y", (Object)y);
                config.set("ClickableSigns." + (String)name + ".Z", (Object)z);
                config.set("ClickableSigns." + (String)name + ".Commands", new ArrayList());
                SettingsManager.getInstance();
                SettingsManager.saveSettings("ClickableSigns");
                player.sendMessage(MSG.chatColors("&aClickable sign '" + (String)name + "' set at " + worldName + " " + x + ", " + y + ", " + z));
            } else {
                player.sendMessage(MSG.chatColors("&cYou must be looking at a sign to make it clickable!"));
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        Collections.sort(completions);
        return completions;
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        sender.sendMessage("This command can only be used by players.");
    }
}

