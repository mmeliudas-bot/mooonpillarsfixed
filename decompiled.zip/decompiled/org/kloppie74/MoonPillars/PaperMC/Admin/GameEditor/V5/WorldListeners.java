/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.World
 *  org.bukkit.WorldCreator
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class WorldListeners {
    private static final Map<String, FileConfiguration> configCache = new HashMap<String, FileConfiguration>();
    public static final Map<UUID, FileConfiguration> configEditer = new HashMap<UUID, FileConfiguration>();

    public static FileConfiguration GetConfig(String GameFile) {
        if (configCache.containsKey(GameFile)) {
            return configCache.get(GameFile);
        }
        File settingsFile = new File(MoonLab.getInstance().getDataFolder(), "Games/" + GameFile + ".yml");
        if (!settingsFile.exists()) {
            try {
                settingsFile.getParentFile().mkdirs();
                settingsFile.createNewFile();
                System.out.println("New Game file made: " + settingsFile.getPath());
            }
            catch (IOException var3) {
                var3.printStackTrace();
                return null;
            }
        }
        YamlConfiguration config = YamlConfiguration.loadConfiguration((File)settingsFile);
        configCache.put(GameFile, (FileConfiguration)config);
        return config;
    }

    public static World CreateWorld(String gameWorld) {
        File sourceZipFile = new File(MoonLab.getInstance().getDataFolder(), "Storage/World.zip");
        File destinationZipFile = new File(MoonLab.getInstance().getDataFolder(), "Games/" + gameWorld + ".zip");
        try {
            if (!sourceZipFile.exists()) {
                throw new FileNotFoundException("Source ZIP file does not exist: " + sourceZipFile.getAbsolutePath());
            }
            WorldListeners.copyFile(sourceZipFile, destinationZipFile);
            WorldListeners.unzip(destinationZipFile, gameWorld);
            return WorldListeners.LoadWorld(gameWorld);
        }
        catch (IOException var4) {
            throw new RuntimeException("Failed to copy, extract the resource, or load it: " + var4.getMessage(), var4);
        }
    }

    private static void copyFile(File sourceFile, File destinationFile) throws IOException {
        Files.copy(sourceFile.toPath(), destinationFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
    }

    public static World EditWorld(String gameWorld, Player player) {
        File zipFile = new File(MoonLab.getInstance().getDataFolder(), "Games/" + gameWorld + ".zip");
        if (zipFile.exists()) {
            try {
                WorldListeners.unzip(zipFile, gameWorld);
                return WorldListeners.LoadWorld(gameWorld);
            }
            catch (IOException var4) {
                player.sendMessage(MSG.chatColors("&cWorld folder not found!"));
                throw new RuntimeException("Failed to unzip or load the world file: " + zipFile.getName(), var4);
            }
        }
        player.sendMessage(MSG.chatColors("&cWorld zip file does not exist!"));
        return null;
    }

    public static World LoadWorld(String WorldName) {
        World world = Bukkit.getWorld((String)WorldName);
        if (world != null) {
            return world;
        }
        WorldCreator creator = new WorldCreator(WorldName);
        world = creator.createWorld();
        return world;
    }

    public static void UnloadWorld(String worldName) {
        World world = Bukkit.getWorld((String)worldName);
        if (world != null) {
            File worldFolder = world.getWorldFolder();
            File destinationZip = new File(MoonLab.getInstance().getDataFolder(), "Games/" + worldName + ".zip");
            boolean isUnloaded = Bukkit.unloadWorld((World)world, (boolean)true);
            if (isUnloaded) {
                try {
                    WorldListeners.zipWorldFolder(worldFolder, destinationZip);
                    Bukkit.getConsoleSender().sendMessage("World saved and zipped: " + worldName);
                    WorldListeners.deleteWorldFolder(worldFolder);
                }
                catch (IOException var6) {
                    var6.printStackTrace();
                }
            } else {
                Bukkit.getConsoleSender().sendMessage("Failed to unload world: " + worldName);
            }
        }
    }

    private static void zipWorldFolder(File sourceFolder, File destinationFile) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(destinationFile);
             ZipOutputStream zos = new ZipOutputStream(fos);){
            File[] files = sourceFolder.listFiles();
            if (files != null) {
                File[] var5 = files;
                int var6 = files.length;
                for (int var7 = 0; var7 < var6; ++var7) {
                    File file = var5[var7];
                    WorldListeners.zipFile(file, file.getName(), zos);
                }
            }
        }
    }

    private static void zipFile(File fileToZip, String fileName, ZipOutputStream zos) throws IOException {
        block8: {
            block9: {
                if (fileToZip.isHidden() || fileToZip.getName().equals("uid.dat")) break block8;
                if (!fileToZip.isDirectory()) break block9;
                if (!((String)fileName).endsWith("/")) {
                    fileName = (String)fileName + "/";
                }
                zos.putNextEntry(new ZipEntry((String)fileName));
                zos.closeEntry();
                File[] children = fileToZip.listFiles();
                if (children == null) break block8;
                File[] var4 = children;
                int var5 = children.length;
                for (int length = 0; length < var5; ++length) {
                    File childFile = var4[length];
                    WorldListeners.zipFile(childFile, (String)fileName + childFile.getName(), zos);
                }
                break block8;
            }
            try (FileInputStream fis = new FileInputStream(fileToZip);){
                int length;
                ZipEntry zipEntry = new ZipEntry((String)fileName);
                zos.putNextEntry(zipEntry);
                byte[] bytes = new byte[1024];
                while ((length = fis.read(bytes)) >= 0) {
                    zos.write(bytes, 0, length);
                }
            }
        }
    }

    private static void unzip(File zipFilePath, String destDirectory) throws IOException {
        File destDir = new File(destDirectory);
        if (!destDir.exists()) {
            destDir.mkdirs();
        }
        try (ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFilePath));){
            ZipEntry entry;
            while ((entry = zipIn.getNextEntry()) != null) {
                String filePath = destDirectory + File.separator + entry.getName();
                if (entry.isDirectory()) {
                    new File(filePath).mkdirs();
                } else {
                    try (BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));){
                        int bytesRead;
                        byte[] buffer = new byte[4096];
                        while ((bytesRead = zipIn.read(buffer)) != -1) {
                            bos.write(buffer, 0, bytesRead);
                        }
                    }
                }
                zipIn.closeEntry();
            }
        }
    }

    private static void deleteWorldFolder(File folder) {
        File[] files = folder.listFiles();
        if (files != null) {
            File[] var2 = files;
            int var3 = files.length;
            for (int var4 = 0; var4 < var3; ++var4) {
                File file = var2[var4];
                if (file.isDirectory()) {
                    WorldListeners.deleteWorldFolder(file);
                    continue;
                }
                file.delete();
            }
        }
        folder.delete();
    }

    public static void deleteZipFile(String worldName) {
        File zipFile = new File(MoonLab.getInstance().getDataFolder(), "Games/" + worldName + ".zip");
        if (zipFile.exists()) {
            if (zipFile.delete()) {
                Bukkit.getConsoleSender().sendMessage("ZIP-File Deleted: " + zipFile.getPath());
            } else {
                Bukkit.getConsoleSender().sendMessage("Was not able to delete: " + zipFile.getPath());
            }
        } else {
            Bukkit.getConsoleSender().sendMessage("ZIP-File not found: " + zipFile.getPath());
        }
    }

    public static void deleteYMLFile(String worldName) {
        File ymlFile = new File(MoonLab.getInstance().getDataFolder(), "Games/" + worldName + ".yml");
        if (ymlFile.exists()) {
            if (ymlFile.delete()) {
                Bukkit.getConsoleSender().sendMessage("YML-File Deleted: " + ymlFile.getPath());
            } else {
                Bukkit.getConsoleSender().sendMessage("Was not able to delete: " + ymlFile.getPath());
            }
        } else {
            Bukkit.getConsoleSender().sendMessage("YML-File not found: " + ymlFile.getPath());
        }
    }
}

