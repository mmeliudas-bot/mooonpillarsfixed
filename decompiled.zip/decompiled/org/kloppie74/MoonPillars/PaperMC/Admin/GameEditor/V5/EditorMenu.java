/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryType
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5;

import java.io.File;
import java.io.IOException;
import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.EditItems;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.RewardCommandEditorGUI;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.TeamManagerMenu;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.VoteSetting;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.WorldListeners;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class EditorMenu
implements Listener {
    private static final String MENU_SETUP_CHOICE = "EditorSetupChoice";
    private static final String MENU_MANUAL = "EditGUI";
    private static final String MENU_GUIDED_DISPLAY_NAME = "GuidedDisplayName";
    private static final String MENU_GUIDED_TEAMS = "GuidedTeams";
    private static final String MENU_GUIDED_PLAYERS = "GuidedPlayers";
    private static final String MENU_GUIDED_BUILD_HEIGHT = "GuidedBuildHeight";
    private static final String MENU_GUIDED_BUILD_RANGE = "GuidedBuildRange";
    private static final String MENU_GUIDED_DEATH_LIMIT = "GuidedDeathLimit";
    private static final String MENU_GUIDED_TIMERS = "GuidedTimers";
    private static final String MENU_GUIDED_BORDER = "GuidedBorder";
    private static final String MENU_GUIDED_BREAK_BLOCKS = "GuidedBreakBlocks";
    private static final String MENU_GUIDED_BLACKLIST = "GuidedBlacklist";
    private static final String MENU_GUIDED_VOTING = "GuidedVoting";
    private static final String MENU_GUIDED_REWARDS = "GuidedRewards";
    private static final String MENU_GUIDED_COMPLETE = "GuidedComplete";
    private static final int SETUP_DISPLAY_NAME = 1;
    private static final int SETUP_TEAMS = 2;
    private static final int SETUP_PLAYERS = 3;
    private static final int SETUP_BUILD_HEIGHT = 4;
    private static final int SETUP_BUILD_RANGE = 5;
    private static final int SETUP_DEATH_LIMIT = 6;
    private static final int SETUP_TIMERS = 7;
    private static final int SETUP_BORDER = 8;
    private static final int SETUP_BREAK_BLOCKS = 9;
    private static final int SETUP_BLACKLIST = 10;
    public static final int SETUP_VOTING = 11;
    private static final int SETUP_REWARDS = 12;
    private static final int SETUP_COMPLETE = 13;
    public static final Map<UUID, Integer> playerSetupPhase = new HashMap<UUID, Integer>();
    public static final Map<UUID, String> AdminEditCache = new HashMap<UUID, String>();
    public static Map<UUID, Integer> PageCache = new HashMap<UUID, Integer>();

    public static void SaveConfig(Player player) {
        FileConfiguration config = WorldListeners.configEditer.get(player.getUniqueId());
        String WorldName = player.getWorld().getName().toLowerCase();
        File file = new File(MoonLab.getInstance().getDataFolder(), "Games/" + WorldName + ".yml");
        try {
            config.save(file);
        }
        catch (IOException var5) {
            throw new RuntimeException(var5);
        }
    }

    public static Inventory createSetupChoiceMenu(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bGame Editor Setup"));
        EditorMenu.fillInventory(inv);
        ItemStack manualSetup = new ItemStack(Material.CRAFTING_TABLE);
        ItemMeta manualMeta = manualSetup.getItemMeta();
        manualMeta.setDisplayName(MSG.chatColors("&bManual Setup"));
        ArrayList<String> manualLore = new ArrayList<String>();
        manualLore.add(MSG.chatColors("&7Click to access all game settings"));
        manualLore.add(MSG.chatColors("&7at once in a single interface."));
        manualLore.add(MSG.chatColors("&7"));
        manualLore.add(MSG.chatColors("&7For experienced users."));
        manualLore.add(MSG.chatColors("&7"));
        manualLore.add(MSG.chatColors("&8\u2192 All options available immediately"));
        manualLore.add(MSG.chatColors("&8\u2192 Configure settings in any order"));
        manualLore.add(MSG.chatColors("&8\u2192 Quick access to all game parameters"));
        manualMeta.setLore(manualLore);
        manualSetup.setItemMeta(manualMeta);
        inv.setItem(11, manualSetup);
        ItemStack guidedSetup = new ItemStack(Material.COMPASS);
        ItemMeta guidedMeta = guidedSetup.getItemMeta();
        guidedMeta.setDisplayName(MSG.chatColors("&aGuided Setup"));
        ArrayList<String> guidedLore = new ArrayList<String>();
        guidedLore.add(MSG.chatColors("&7Click to start a step-by-step"));
        guidedLore.add(MSG.chatColors("&7process to set up your game."));
        guidedLore.add(MSG.chatColors("&7"));
        guidedLore.add(MSG.chatColors("&7Recommended for new users."));
        guidedLore.add(MSG.chatColors("&7"));
        guidedLore.add(MSG.chatColors("&8\u2192 Walks you through each setup step"));
        guidedLore.add(MSG.chatColors("&8\u2192 Provides guidance at each stage"));
        guidedLore.add(MSG.chatColors("&8\u2192 Ensures proper game configuration"));
        guidedLore.add(MSG.chatColors("&8\u2192 Simplifies the setup process"));
        guidedMeta.setLore(guidedLore);
        guidedSetup.setItemMeta(guidedMeta);
        inv.setItem(15, guidedSetup);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eGame Setup Information"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Game setup process:"));
        infoLore.add(MSG.chatColors("&71. Set game display name"));
        infoLore.add(MSG.chatColors("&72. Configure teams"));
        infoLore.add(MSG.chatColors("&73. Set player limits"));
        infoLore.add(MSG.chatColors("&74. Configure build settings"));
        infoLore.add(MSG.chatColors("&75. Set game timers"));
        infoLore.add(MSG.chatColors("&76. Configure gameplay options"));
        infoLore.add(MSG.chatColors("&77. Set up rewards"));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 This guides you through the full setup"));
        infoLore.add(MSG.chatColors("&8\u2192 Follow steps in order for best results"));
        infoLore.add(MSG.chatColors("&8\u2192 Make sure to complete all steps"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(13, infoItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_SETUP_CHOICE);
        return inv;
    }

    public static Inventory EditGuiInv(Player player, FileConfiguration Config) {
        Inventory EditGuiInv = Bukkit.createInventory((InventoryHolder)player, (int)54, (String)MSG.chatColors("&bEdit Menu!"));
        Material item = Material.GRAY_STAINED_GLASS_PANE;
        ItemStack fillItem = new ItemStack(item);
        ItemMeta fillItemMeta = fillItem.getItemMeta();
        fillItemMeta.setDisplayName("\u00a7f ");
        fillItem.setItemMeta(fillItemMeta);
        for (int i = 0; i < EditGuiInv.getSize(); ++i) {
            EditGuiInv.setItem(i, fillItem);
        }
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eGame Setup Information"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Configure all aspects of your game:"));
        infoLore.add(MSG.chatColors("&7- Team setup and player limits"));
        infoLore.add(MSG.chatColors("&7- Build settings and game boundaries"));
        infoLore.add(MSG.chatColors("&7- Game timers and events"));
        infoLore.add(MSG.chatColors("&7- Items and rewards"));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 You can configure settings in any order"));
        infoLore.add(MSG.chatColors("&8\u2192 Save your changes when complete"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        EditGuiInv.setItem(4, infoItem);
        Material Barrier = Material.BARRIER;
        ItemStack BarrierItem = new ItemStack(Barrier);
        ItemMeta BarrierItemMeta = BarrierItem.getItemMeta();
        BarrierItemMeta.setDisplayName(MSG.chatColors("&c&lQuit GUI"));
        ArrayList<String> barrierLore = new ArrayList<String>();
        barrierLore.add(MSG.chatColors("&7Click to exit the editor"));
        barrierLore.add(MSG.chatColors("&7"));
        barrierLore.add(MSG.chatColors("&8\u2192 Returns to the game"));
        barrierLore.add(MSG.chatColors("&8\u2192 All changes are saved automatically"));
        BarrierItemMeta.setLore(barrierLore);
        BarrierItem.setItemMeta(BarrierItemMeta);
        EditGuiInv.setItem(48, BarrierItem);
        ItemStack SaveItem = EditorMenu.GetSaveAreaItem(player, Config);
        EditGuiInv.setItem(50, SaveItem);
        ItemStack Presave = EditorMenu.GetPreSaveItem(player, Config);
        EditGuiInv.setItem(51, Presave);
        ItemStack MaxPlayers = EditorMenu.GetMaxPlayersItem(player, Config);
        EditGuiInv.setItem(10, MaxPlayers);
        ItemStack MinPlayers = EditorMenu.GetMinPlayersItem(player, Config);
        EditGuiInv.setItem(11, MinPlayers);
        ItemStack TeamManager2 = EditorMenu.GetTeamManager(player, Config);
        EditGuiInv.setItem(12, TeamManager2);
        ItemStack LobbyTimer = EditorMenu.GetLobbyTimerItem(player, Config);
        EditGuiInv.setItem(28, LobbyTimer);
        ItemStack CageTimer = EditorMenu.GetCageTimerItem(player, Config);
        EditGuiInv.setItem(29, CageTimer);
        ItemStack GameTime = EditorMenu.GetGameTimeItem(player, Config);
        EditGuiInv.setItem(30, GameTime);
        ItemStack ItemTime = EditorMenu.GetItemTimeItem(player, Config);
        EditGuiInv.setItem(31, ItemTime);
        ItemStack RewardsItems = EditorMenu.GetRewardItem(player, Config);
        EditGuiInv.setItem(14, RewardsItems);
        ItemStack BlackListed = EditorMenu.GetBlackListedItem(player, Config);
        EditGuiInv.setItem(15, BlackListed);
        ItemStack Vote = EditorMenu.GetVotingItem(player, Config);
        EditGuiInv.setItem(24, Vote);
        ItemStack Border = EditorMenu.GetBorderItem(player, Config);
        EditGuiInv.setItem(33, Border);
        ItemStack BorderTimer = EditorMenu.GetBorderTimerItem(player, Config);
        EditGuiInv.setItem(34, BorderTimer);
        ItemStack BreakMapBlocks = EditorMenu.GetMapBlocksItem(player, Config);
        EditGuiInv.setItem(25, BreakMapBlocks);
        ItemStack MapName = EditorMenu.GetMapNameItem(player, Config);
        EditGuiInv.setItem(16, MapName);
        ItemStack BuildHigh = EditorMenu.GetBuildHighItem(player, Config);
        EditGuiInv.setItem(19, BuildHigh);
        ItemStack BuildRange = EditorMenu.GetBuildRangeItem(player, Config);
        EditGuiInv.setItem(20, BuildRange);
        ItemStack DeathHeight = EditorMenu.GetDeathHighItem(player, Config);
        EditGuiInv.setItem(21, DeathHeight);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_MANUAL);
        return EditGuiInv;
    }

    public static Inventory createGuidedDisplayNameInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 1: Set Game Display Name"));
        EditorMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 1: Game Display Name"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7First, set a display name for your game."));
        infoLore.add(MSG.chatColors("&7This name will be shown to players in"));
        infoLore.add(MSG.chatColors("&7the game lobby and menus."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&7Click the anvil icon to set the name."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Choose a descriptive, catchy name"));
        infoLore.add(MSG.chatColors("&8\u2192 This is what players will see"));
        infoLore.add(MSG.chatColors("&8\u2192 Can include color codes with & symbol"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack mapNameItem = EditorMenu.GetMapNameItem(player, config);
        inv.setItem(13, mapNameItem);
        ItemStack progressItem = EditorMenu.createProgressIndicator(1, 12);
        inv.setItem(22, progressItem);
        ItemStack nextItem = EditorMenu.createNextButton();
        inv.setItem(18, nextItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_DISPLAY_NAME);
        playerSetupPhase.put(player.getUniqueId(), 1);
        return inv;
    }

    public static Inventory createGuidedTeamsInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 2: Configure Teams"));
        EditorMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 2: Team Configuration"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Now, set up the teams for your game."));
        infoLore.add(MSG.chatColors("&7Configure team count, team sizes,"));
        infoLore.add(MSG.chatColors("&7and team names and colors."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&7Click the player head to open the team manager."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 You'll enter the team setup wizard"));
        infoLore.add(MSG.chatColors("&8\u2192 Complete all team setup steps"));
        infoLore.add(MSG.chatColors("&8\u2192 Return here when finished"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack teamManagerItem = EditorMenu.GetTeamManager(player, config);
        inv.setItem(13, teamManagerItem);
        ItemStack progressItem = EditorMenu.createProgressIndicator(2, 12);
        inv.setItem(22, progressItem);
        ItemStack nextItem = EditorMenu.createNextButton();
        inv.setItem(18, nextItem);
        ItemStack prevItem = EditorMenu.createPrevButton();
        inv.setItem(26, prevItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_TEAMS);
        playerSetupPhase.put(player.getUniqueId(), 2);
        return inv;
    }

    public static Inventory createGuidedPlayersInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 3: Player Limits"));
        EditorMenu.fillInventory(inv);
        int maxTeams = config.getInt("SpawnLocations.MaxTeams", 0);
        int playersPerTeam = config.getInt("SpawnLocations.PlayersPerTeam", 0);
        int suggestedMaxPlayers = maxTeams * playersPerTeam;
        int suggestedMinPlayers = Math.max(2, (int)((double)suggestedMaxPlayers * 0.6));
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 3: Player Limits"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Set the minimum and maximum"));
        infoLore.add(MSG.chatColors("&7number of players for your game."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&7Based on your team settings:"));
        infoLore.add(MSG.chatColors("&7Suggested max players: &f" + suggestedMaxPlayers));
        infoLore.add(MSG.chatColors("&7Suggested min players: &f" + suggestedMinPlayers));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Maximum should equal teams \u00d7 players per team"));
        infoLore.add(MSG.chatColors("&8\u2192 Minimum should be at least 60% of maximum"));
        infoLore.add(MSG.chatColors("&8\u2192 Min players must allow at least 2 teams"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack maxPlayersItem = EditorMenu.GetMaxPlayersItem(player, config);
        inv.setItem(12, maxPlayersItem);
        ItemStack minPlayersItem = EditorMenu.GetMinPlayersItem(player, config);
        inv.setItem(14, minPlayersItem);
        ItemStack autoSetItem = new ItemStack(Material.EMERALD);
        ItemMeta autoSetMeta = autoSetItem.getItemMeta();
        autoSetMeta.setDisplayName(MSG.chatColors("&aAuto-Set Player Limits"));
        ArrayList<String> autoSetLore = new ArrayList<String>();
        autoSetLore.add(MSG.chatColors("&7Click to automatically set player limits"));
        autoSetLore.add(MSG.chatColors("&7based on your team configuration."));
        autoSetLore.add(MSG.chatColors("&7"));
        autoSetLore.add(MSG.chatColors("&7This will set:"));
        autoSetLore.add(MSG.chatColors("&7Max: " + suggestedMaxPlayers + " players"));
        autoSetLore.add(MSG.chatColors("&7Min: " + suggestedMinPlayers + " players"));
        autoSetLore.add(MSG.chatColors("&7"));
        autoSetLore.add(MSG.chatColors("&8\u2192 Uses values calculated from your team settings"));
        autoSetLore.add(MSG.chatColors("&8\u2192 Ensures compatible player counts"));
        autoSetMeta.setLore(autoSetLore);
        autoSetItem.setItemMeta(autoSetMeta);
        inv.setItem(13, autoSetItem);
        ItemStack progressItem = EditorMenu.createProgressIndicator(3, 12);
        inv.setItem(22, progressItem);
        ItemStack nextItem = EditorMenu.createNextButton();
        inv.setItem(18, nextItem);
        ItemStack prevItem = EditorMenu.createPrevButton();
        inv.setItem(26, prevItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_PLAYERS);
        playerSetupPhase.put(player.getUniqueId(), 3);
        return inv;
    }

    public static Inventory createGuidedBuildHeightInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 4: Build Height"));
        EditorMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 4: Build Height Limit"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Set the maximum height that players"));
        infoLore.add(MSG.chatColors("&7can build up to in your game."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&7Click the brick icon to set the build height."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Prevents players from building too high"));
        infoLore.add(MSG.chatColors("&8\u2192 Typically set to 100-150 blocks"));
        infoLore.add(MSG.chatColors("&8\u2192 Consider your map's design"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack buildHeightItem = EditorMenu.GetBuildHighItem(player, config);
        inv.setItem(13, buildHeightItem);
        ItemStack progressItem = EditorMenu.createProgressIndicator(4, 12);
        inv.setItem(22, progressItem);
        ItemStack nextItem = EditorMenu.createNextButton();
        inv.setItem(18, nextItem);
        ItemStack prevItem = EditorMenu.createPrevButton();
        inv.setItem(26, prevItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_BUILD_HEIGHT);
        playerSetupPhase.put(player.getUniqueId(), 4);
        return inv;
    }

    public static Inventory createGuidedBuildRangeInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 5: Build Range"));
        EditorMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 5: Build Range Limit"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Set the maximum distance from spawn"));
        infoLore.add(MSG.chatColors("&7that players can build in."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&7Click the brick icon to set the build range."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Prevents players from building too far"));
        infoLore.add(MSG.chatColors("&8\u2192 Typically set to match your map size"));
        infoLore.add(MSG.chatColors("&8\u2192 Recommended: 50-200 blocks"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack buildRangeItem = EditorMenu.GetBuildRangeItem(player, config);
        inv.setItem(13, buildRangeItem);
        ItemStack progressItem = EditorMenu.createProgressIndicator(5, 12);
        inv.setItem(22, progressItem);
        ItemStack nextItem = EditorMenu.createNextButton();
        inv.setItem(18, nextItem);
        ItemStack prevItem = EditorMenu.createPrevButton();
        inv.setItem(26, prevItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_BUILD_RANGE);
        playerSetupPhase.put(player.getUniqueId(), 5);
        return inv;
    }

    public static Inventory createGuidedDeathLimitInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 6: Death Height"));
        EditorMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 6: Death Height Limit"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Set the Y-coordinate below which"));
        infoLore.add(MSG.chatColors("&7players will die when they fall."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&7Click the brick icon to set the death height."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Players below this height will die"));
        infoLore.add(MSG.chatColors("&8\u2192 Set based on your map's lowest point"));
        infoLore.add(MSG.chatColors("&8\u2192 Typically 5-10 blocks below map edge"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack deathHeightItem = EditorMenu.GetDeathHighItem(player, config);
        inv.setItem(13, deathHeightItem);
        ItemStack progressItem = EditorMenu.createProgressIndicator(6, 12);
        inv.setItem(22, progressItem);
        ItemStack nextItem = EditorMenu.createNextButton();
        inv.setItem(18, nextItem);
        ItemStack prevItem = EditorMenu.createPrevButton();
        inv.setItem(26, prevItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_DEATH_LIMIT);
        playerSetupPhase.put(player.getUniqueId(), 6);
        return inv;
    }

    public static Inventory createGuidedTimersInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)36, (String)MSG.chatColors("&bStep 7: Game Timers"));
        EditorMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 7: Game Timers"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Configure the various timers"));
        infoLore.add(MSG.chatColors("&7that control your game's flow."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&7Click each clock to set its timer value."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Lobby: time in lobby before teleport"));
        infoLore.add(MSG.chatColors("&8\u2192 Cage: countdown before game starts"));
        infoLore.add(MSG.chatColors("&8\u2192 Game: total game duration"));
        infoLore.add(MSG.chatColors("&8\u2192 Item: interval for random items"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack lobbyTimerItem = EditorMenu.GetLobbyTimerItem(player, config);
        inv.setItem(11, lobbyTimerItem);
        ItemStack cageTimerItem = EditorMenu.GetCageTimerItem(player, config);
        inv.setItem(13, cageTimerItem);
        ItemStack gameTimerItem = EditorMenu.GetGameTimeItem(player, config);
        inv.setItem(15, gameTimerItem);
        ItemStack itemTimerItem = EditorMenu.GetItemTimeItem(player, config);
        inv.setItem(22, itemTimerItem);
        ItemStack progressItem = EditorMenu.createProgressIndicator(7, 12);
        inv.setItem(31, progressItem);
        ItemStack nextItem = EditorMenu.createNextButton();
        inv.setItem(27, nextItem);
        ItemStack prevItem = EditorMenu.createPrevButton();
        inv.setItem(35, prevItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_TIMERS);
        playerSetupPhase.put(player.getUniqueId(), 7);
        return inv;
    }

    public static Inventory createGuidedBorderInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 8: Border Settings"));
        EditorMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 8: Border Settings"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Configure the world border"));
        infoLore.add(MSG.chatColors("&7settings for your game."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&7Enable/disable the border and set its timer."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Border forces players to the center"));
        infoLore.add(MSG.chatColors("&8\u2192 Typically activated near end of game"));
        infoLore.add(MSG.chatColors("&8\u2192 Timer controls how fast it shrinks"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack borderItem = EditorMenu.GetBorderItem(player, config);
        inv.setItem(12, borderItem);
        ItemStack borderTimerItem = EditorMenu.GetBorderTimerItem(player, config);
        inv.setItem(14, borderTimerItem);
        ItemStack progressItem = EditorMenu.createProgressIndicator(8, 12);
        inv.setItem(22, progressItem);
        ItemStack nextItem = EditorMenu.createNextButton();
        inv.setItem(18, nextItem);
        ItemStack prevItem = EditorMenu.createPrevButton();
        inv.setItem(26, prevItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_BORDER);
        playerSetupPhase.put(player.getUniqueId(), 8);
        return inv;
    }

    public static Inventory createGuidedBreakBlocksInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 9: Block Breaking"));
        EditorMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 9: Block Breaking"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Decide whether players can break"));
        infoLore.add(MSG.chatColors("&7existing blocks in your map."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&7Click the dye item to toggle this setting."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Enabled: Players can break map blocks"));
        infoLore.add(MSG.chatColors("&8\u2192 Disabled: Map remains intact"));
        infoLore.add(MSG.chatColors("&8\u2192 Players can always place and break their own blocks"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack breakBlocksItem = EditorMenu.GetMapBlocksItem(player, config);
        inv.setItem(13, breakBlocksItem);
        ItemStack progressItem = EditorMenu.createProgressIndicator(9, 12);
        inv.setItem(22, progressItem);
        ItemStack nextItem = EditorMenu.createNextButton();
        inv.setItem(18, nextItem);
        ItemStack prevItem = EditorMenu.createPrevButton();
        inv.setItem(26, prevItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_BREAK_BLOCKS);
        playerSetupPhase.put(player.getUniqueId(), 9);
        return inv;
    }

    public static Inventory createGuidedBlacklistInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 10: Item Control"));
        EditorMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 10: Item Control"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Configure which items are allowed"));
        infoLore.add(MSG.chatColors("&7or prohibited in your game."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&7Click the barrier icon to manage items."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Blacklist: Ban specific items"));
        infoLore.add(MSG.chatColors("&8\u2192 Whitelist: Only allow listed items"));
        infoLore.add(MSG.chatColors("&8\u2192 Controls random item drops and crafting"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack blacklistItem = EditorMenu.GetBlackListedItem(player, config);
        inv.setItem(13, blacklistItem);
        ItemStack progressItem = EditorMenu.createProgressIndicator(10, 12);
        inv.setItem(22, progressItem);
        ItemStack nextItem = EditorMenu.createNextButton();
        inv.setItem(18, nextItem);
        ItemStack prevItem = EditorMenu.createPrevButton();
        inv.setItem(26, prevItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_BLACKLIST);
        playerSetupPhase.put(player.getUniqueId(), 10);
        return inv;
    }

    public static Inventory createGuidedVotingInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 11: Voting Events"));
        EditorMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 11: Voting Events"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Configure special game modes that"));
        infoLore.add(MSG.chatColors("&7players can vote for before the game."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&7Click the paper icon to manage voting events."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Enable/disable different voting options"));
        infoLore.add(MSG.chatColors("&8\u2192 Adds variety to your game"));
        infoLore.add(MSG.chatColors("&8\u2192 Special modes like Floor is Lava, Elytra mode, etc."));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack votingItem = EditorMenu.GetVotingItem(player, config);
        inv.setItem(13, votingItem);
        ItemStack progressItem = EditorMenu.createProgressIndicator(11, 12);
        inv.setItem(22, progressItem);
        ItemStack nextItem = EditorMenu.createNextButton();
        inv.setItem(18, nextItem);
        ItemStack prevItem = EditorMenu.createPrevButton();
        inv.setItem(26, prevItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_VOTING);
        playerSetupPhase.put(player.getUniqueId(), 11);
        return inv;
    }

    public static Inventory createGuidedRewardsInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)27, (String)MSG.chatColors("&bStep 12: Game Rewards"));
        EditorMenu.fillInventory(inv);
        ItemStack infoItem = new ItemStack(Material.OAK_SIGN);
        ItemMeta infoMeta = infoItem.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&eStep 12: Game Rewards"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7Configure rewards for different"));
        infoLore.add(MSG.chatColors("&7game events and outcomes."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&7Click the emerald to set up rewards."));
        infoLore.add(MSG.chatColors("&7"));
        infoLore.add(MSG.chatColors("&8\u2192 Configure rewards for kills, wins, etc."));
        infoLore.add(MSG.chatColors("&8\u2192 Set up commands to run for different events"));
        infoLore.add(MSG.chatColors("&8\u2192 Add incentives for players"));
        infoMeta.setLore(infoLore);
        infoItem.setItemMeta(infoMeta);
        inv.setItem(4, infoItem);
        ItemStack rewardsItem = EditorMenu.GetRewardItem(player, config);
        inv.setItem(13, rewardsItem);
        ItemStack progressItem = EditorMenu.createProgressIndicator(12, 12);
        inv.setItem(22, progressItem);
        ItemStack finishItem = new ItemStack(Material.EMERALD);
        ItemMeta finishMeta = finishItem.getItemMeta();
        finishMeta.setDisplayName(MSG.chatColors("&aFinish Setup"));
        ArrayList<String> finishLore = new ArrayList<String>();
        finishLore.add(MSG.chatColors("&7Click to complete the game setup process"));
        finishLore.add(MSG.chatColors("&7"));
        finishLore.add(MSG.chatColors("&8\u2192 Finalizes all game settings"));
        finishLore.add(MSG.chatColors("&8\u2192 Validates your configuration"));
        finishLore.add(MSG.chatColors("&8\u2192 Prepares your game for play"));
        finishMeta.setLore(finishLore);
        finishItem.setItemMeta(finishMeta);
        inv.setItem(18, finishItem);
        ItemStack prevItem = EditorMenu.createPrevButton();
        inv.setItem(26, prevItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_REWARDS);
        playerSetupPhase.put(player.getUniqueId(), 12);
        return inv;
    }

    public static Inventory createGuidedCompleteInventory(Player player, FileConfiguration config) {
        Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)36, (String)MSG.chatColors("&aGame Setup Complete!"));
        EditorMenu.fillInventory(inv);
        ItemStack completeItem = new ItemStack(Material.EMERALD);
        ItemMeta completeMeta = completeItem.getItemMeta();
        completeMeta.setDisplayName(MSG.chatColors("&aSetup Complete!"));
        ArrayList<String> completeLore = new ArrayList<String>();
        completeLore.add(MSG.chatColors("&7Congratulations! You have successfully"));
        completeLore.add(MSG.chatColors("&7configured your game. Here's a summary:"));
        completeLore.add(MSG.chatColors("&7"));
        String displayName = config.getString("Settings.DisplayName", "Unknown");
        int maxTeams = config.getInt("SpawnLocations.MaxTeams", 0);
        int playersPerTeam = config.getInt("SpawnLocations.PlayersPerTeam", 0);
        int maxPlayers = config.getInt("SpawnLocations.MaximumPlayers", 0);
        int minPlayers = config.getInt("SpawnLocations.MinimumPlayers", 0);
        completeLore.add(MSG.chatColors("&7Game Name: &f" + displayName));
        completeLore.add(MSG.chatColors("&7Teams: &f" + maxTeams));
        completeLore.add(MSG.chatColors("&7Players Per Team: &f" + playersPerTeam));
        completeLore.add(MSG.chatColors("&7Player Limits: &f" + minPlayers + "-" + maxPlayers));
        completeLore.add(MSG.chatColors("&7"));
        completeLore.add(MSG.chatColors("&8\u2192 All game settings have been saved"));
        completeLore.add(MSG.chatColors("&8\u2192 You can edit settings again at any time"));
        completeLore.add(MSG.chatColors("&8\u2192 Your game is now ready to save and play"));
        completeMeta.setLore(completeLore);
        completeItem.setItemMeta(completeMeta);
        inv.setItem(13, completeItem);
        ItemStack saveItem = EditorMenu.GetSaveAreaItem(player, config);
        inv.setItem(21, saveItem);
        ItemStack preSaveItem = EditorMenu.GetPreSaveItem(player, config);
        preSaveItem.setItemMeta(EditorMenu.updateItemMeta(preSaveItem.getItemMeta(), "&6Pre-Save Game", Arrays.asList(MSG.chatColors("&7Click to pre-save your game"), MSG.chatColors("&7This saves your progress but keeps the game inactive"), MSG.chatColors("&7"), MSG.chatColors("&8\u2192 Save current settings"), MSG.chatColors("&8\u2192 Continue setup later with /mpa setup"), MSG.chatColors("&8\u2192 Game will not be playable yet"))));
        inv.setItem(23, preSaveItem);
        ItemStack editorItem = new ItemStack(Material.CRAFTING_TABLE);
        ItemMeta editorMeta = editorItem.getItemMeta();
        editorMeta.setDisplayName(MSG.chatColors("&bReturn to Editor"));
        ArrayList<String> editorLore = new ArrayList<String>();
        editorLore.add(MSG.chatColors("&7Click to return to the main editor menu"));
        editorLore.add(MSG.chatColors("&7"));
        editorLore.add(MSG.chatColors("&8\u2192 Access all game settings in one place"));
        editorLore.add(MSG.chatColors("&8\u2192 Make additional adjustments"));
        editorMeta.setLore(editorLore);
        editorItem.setItemMeta(editorMeta);
        inv.setItem(31, editorItem);
        MoonLab.PlayerMenu.put(player.getUniqueId(), MENU_GUIDED_COMPLETE);
        playerSetupPhase.put(player.getUniqueId(), 13);
        return inv;
    }

    private static ItemMeta updateItemMeta(ItemMeta meta, String displayName, List<String> lore) {
        meta.setDisplayName(MSG.chatColors(displayName));
        meta.setLore(lore);
        return meta;
    }

    private static ItemStack createProgressIndicator(int currentStep, int totalSteps) {
        ItemStack progressItem = new ItemStack(Material.COMPASS);
        ItemMeta progressMeta = progressItem.getItemMeta();
        progressMeta.setDisplayName(MSG.chatColors("&eSetup Progress"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Step " + currentStep + " of " + totalSteps));
        lore.add(MSG.chatColors("&7"));
        StringBuilder progressBar = new StringBuilder("&7[");
        for (int i = 1; i <= totalSteps; ++i) {
            if (i == currentStep) {
                progressBar.append("&a\u25a0");
                continue;
            }
            if (i < currentStep) {
                progressBar.append("&2\u25a0");
                continue;
            }
            progressBar.append("&7\u25a0");
        }
        progressBar.append("&7]");
        lore.add(MSG.chatColors(progressBar.toString()));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Shows your current progress"));
        lore.add(MSG.chatColors("&8\u2192 Green: Current step"));
        lore.add(MSG.chatColors("&8\u2192 Dark green: Completed steps"));
        lore.add(MSG.chatColors("&8\u2192 Gray: Upcoming steps"));
        progressMeta.setLore(lore);
        progressItem.setItemMeta(progressMeta);
        return progressItem;
    }

    private static ItemStack createNextButton() {
        ItemStack nextItem = new ItemStack(Material.LIME_DYE);
        ItemMeta nextMeta = nextItem.getItemMeta();
        nextMeta.setDisplayName(MSG.chatColors("&aNext Step"));
        ArrayList<String> nextLore = new ArrayList<String>();
        nextLore.add(MSG.chatColors("&7Click to proceed to the next step"));
        nextLore.add(MSG.chatColors("&7"));
        nextLore.add(MSG.chatColors("&8\u2192 Saves current progress"));
        nextLore.add(MSG.chatColors("&8\u2192 Advances to the next setup step"));
        nextMeta.setLore(nextLore);
        nextItem.setItemMeta(nextMeta);
        return nextItem;
    }

    private static ItemStack createPrevButton() {
        ItemStack prevItem = new ItemStack(Material.RED_DYE);
        ItemMeta prevMeta = prevItem.getItemMeta();
        prevMeta.setDisplayName(MSG.chatColors("&cPrevious Step"));
        ArrayList<String> prevLore = new ArrayList<String>();
        prevLore.add(MSG.chatColors("&7Click to return to the previous step"));
        prevLore.add(MSG.chatColors("&7"));
        prevLore.add(MSG.chatColors("&8\u2192 Saves current progress"));
        prevLore.add(MSG.chatColors("&8\u2192 Returns to the previous setup step"));
        prevMeta.setLore(prevLore);
        prevItem.setItemMeta(prevMeta);
        return prevItem;
    }

    private static void fillInventory(Inventory inv) {
        Material material = Material.GRAY_STAINED_GLASS_PANE;
        ItemStack fillItem = new ItemStack(material);
        ItemMeta meta = fillItem.getItemMeta();
        meta.setDisplayName("\u00a7f ");
        fillItem.setItemMeta(meta);
        for (int i = 0; i < inv.getSize(); ++i) {
            inv.setItem(i, fillItem);
        }
    }

    public static ItemStack GetSaveAreaItem(Player player, FileConfiguration config) {
        String displayName;
        List<String> requiredSettings = List.of("Settings.DisplayName", "Settings.Can-Break-Map-Blocks", "Settings.LobbyTimer", "Settings.CageTimer", "Settings.GameTimer", "Settings.ItemTimer", "Settings.DeathHeight", "Settings.BuildHeight", "Settings.BuildRange", "Settings.RandomItems.Type", "SpawnLocations.PlayersPerTeam", "SpawnLocations.MaxTeams", "SpawnLocations.MaximumPlayers", "SpawnLocations.MinimumPlayers", "Settings.SpawnPoint.X", "Settings.SpawnPoint.Y", "Settings.SpawnPoint.Z", "Settings.Spawn-Area.Loc1.X", "Settings.Spawn-Area.Loc1.Y", "Settings.Spawn-Area.Loc1.Z", "Settings.Spawn-Area.Loc2.X", "Settings.Spawn-Area.Loc2.Y", "Settings.Spawn-Area.Loc2.Z", "Rewards.OnStartGameRewards.Enabled", "Rewards.OnKillRewards.Enabled", "Rewards.OnKillRewards.Rewards.Killed-By-Player.Enabled", "Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killed-Player", "Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killer", "Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Remaining-Players", "Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Enabled", "Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Rewards.Killed-Player", "Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Rewards.Remaining-Players", "Rewards.OnLeaveRewards.Enabled", "Rewards.OnLeaveRewards.Rewards.left-Player", "Rewards.OnLeaveRewards.Rewards.Remaining-Players", "Rewards.OnEndGameRewards.Enabled", "Rewards.OnEndGameRewards.Rewards.Spectators", "Rewards.OnEndGameRewards.Rewards.Winners");
        ArrayList<String> missingSettings = new ArrayList<String>();
        ArrayList<CallSite> correctlySetSettings = new ArrayList<CallSite>();
        for (String setting : requiredSettings) {
            if (config.isSet(setting) && config.get(setting) != null) {
                correctlySetSettings.add((CallSite)((Object)(setting + ": " + config.get(setting).toString())));
                continue;
            }
            missingSettings.add(setting);
        }
        int maxTeams = config.getInt("SpawnLocations.MaxTeams");
        int playersPerTeam = config.getInt("SpawnLocations.PlayersPerTeam");
        int maximumPlayers = config.getInt("SpawnLocations.MaximumPlayers");
        int minimumPlayers = config.getInt("SpawnLocations.MinimumPlayers");
        ArrayList<Object> spawnIssues = new ArrayList<Object>();
        ArrayList<CallSite> correctlySetSpawns = new ArrayList<CallSite>();
        if (maxTeams * playersPerTeam != maximumPlayers) {
            spawnIssues.add("  \u00a77- MaxTeams * PlayersPerTeam does not equal MaximumPlayers (" + maxTeams + " * " + playersPerTeam + " != " + maximumPlayers + " It need to be: " + maxTeams * playersPerTeam + ")");
        }
        if (minimumPlayers < playersPerTeam * 2) {
            spawnIssues.add("  \u00a77- MinimumPlayers must be at least 2 * PlayersPerTeam (" + minimumPlayers + " < " + playersPerTeam * 2 + ")");
        }
        if (minimumPlayers > maximumPlayers) {
            spawnIssues.add("  \u00a77- MinimumPlayers cannot be greater than MaximumPlayers (" + minimumPlayers + " > " + maximumPlayers + ")");
        }
        if (!(config.isSet("Settings.SpawnPoint.X") && config.isSet("Settings.SpawnPoint.Y") && config.isSet("Settings.SpawnPoint.Z"))) {
            spawnIssues.add("  \u00a77- SpawnPoint is not fully set");
        }
        if (!(config.isSet("Settings.Spawn-Area.Loc1.X") && config.isSet("Settings.Spawn-Area.Loc1.Y") && config.isSet("Settings.Spawn-Area.Loc1.Z") && config.isSet("Settings.Spawn-Area.Loc2.X") && config.isSet("Settings.Spawn-Area.Loc2.Y") && config.isSet("Settings.Spawn-Area.Loc2.Z"))) {
            spawnIssues.add("  \u00a77- Spawn-Area is not fully set");
        }
        for (int i = 1; i <= maxTeams; ++i) {
            String teamPath = "SpawnLocations.Team" + i;
            if (!config.isConfigurationSection(teamPath)) {
                spawnIssues.add("&cMissing spawn location for Team " + i + " (entire team missing)");
                continue;
            }
            boolean teamHasIssues = false;
            for (int j = 1; j <= playersPerTeam; ++j) {
                String playerPath = teamPath + ".Player" + j;
                if (!config.isConfigurationSection(playerPath)) {
                    if (!teamHasIssues) {
                        spawnIssues.add("&cIssues in spawn location for Team " + i + ":");
                        teamHasIssues = true;
                    }
                    spawnIssues.add("  \u00a77- Missing Player " + j);
                    continue;
                }
                correctlySetSpawns.add((CallSite)((Object)(teamPath + ".Player" + j)));
            }
        }
        boolean allSettingsCorrect = missingSettings.isEmpty() && spawnIssues.isEmpty();
        Material itemMaterial = allSettingsCorrect ? Material.GREEN_DYE : Material.RED_DYE;
        ItemStack itemStack = new ItemStack(itemMaterial);
        ItemMeta itemMeta = itemStack.getItemMeta();
        ArrayList<String> loresArray = new ArrayList<String>();
        if (allSettingsCorrect) {
            displayName = MSG.chatColors("&aSave and Activate Game");
            loresArray.add(MSG.chatColors("\u00a7aAll settings and spawns are correctly configured."));
            loresArray.add(MSG.chatColors("&7"));
            loresArray.add(MSG.chatColors("&7Click to save and activate your game."));
            loresArray.add(MSG.chatColors("&7Players will be able to join after server restart."));
            loresArray.add(MSG.chatColors("&7"));
            loresArray.add(MSG.chatColors("&8\u2192 Finalizes all game settings"));
            loresArray.add(MSG.chatColors("&8\u2192 Makes game available to players"));
        } else {
            displayName = MSG.chatColors("&cSetup Required");
            loresArray.add(MSG.chatColors("&cYour game is not ready to be saved yet."));
            loresArray.add(MSG.chatColors("&7"));
            if (!missingSettings.isEmpty()) {
                loresArray.add(MSG.chatColors("\u00a7cSome settings are missing or incorrect:"));
                for (String string : missingSettings) {
                    loresArray.add(MSG.chatColors("\u00a77- " + string));
                }
            }
            if (!spawnIssues.isEmpty()) {
                loresArray.add(MSG.chatColors("\u00a7cSpawn issues found:"));
                for (String string : spawnIssues) {
                    loresArray.add(MSG.chatColors(string));
                }
            }
            loresArray.add(MSG.chatColors("&7"));
            loresArray.add(MSG.chatColors("&8\u2192 Complete all setup steps first"));
            loresArray.add(MSG.chatColors("&8\u2192 Fix the issues listed above"));
        }
        itemMeta.setDisplayName(MSG.chatColors(displayName));
        itemMeta.setLore(loresArray);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    private static boolean isZero(Object value) {
        if (value instanceof Number) {
            return ((Number)value).doubleValue() == 0.0;
        }
        return value instanceof String ? ((String)value).isEmpty() : false;
    }

    public static ItemStack GetPreSaveItem(Player player, FileConfiguration Config) {
        Material Item2 = Material.ORANGE_DYE;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        ItemMeta2.setDisplayName(MSG.chatColors("&6Pre-Save Game"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Click to pre-save the map!"));
        lore.add(MSG.chatColors("&7You can continue editing later using /mpa setup " + player.getWorld().getName()));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&cNote: Players won't be able to play this map after server restart!"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Saves current progress"));
        lore.add(MSG.chatColors("&8\u2192 Allows you to continue setup later"));
        lore.add(MSG.chatColors("&8\u2192 Game remains unavailable to players"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetRewardItem(Player player, FileConfiguration Config) {
        Material Item2 = Material.EMERALD;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        ItemMeta2.setDisplayName(MSG.chatColors("&aEdit Game Rewards"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Click to configure rewards for:"));
        lore.add(MSG.chatColors("&7- Kills and deaths"));
        lore.add(MSG.chatColors("&7- Game wins"));
        lore.add(MSG.chatColors("&7- Game start events"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Set commands to run for different events"));
        lore.add(MSG.chatColors("&8\u2192 Configure rewards for winners"));
        lore.add(MSG.chatColors("&8\u2192 Add special rewards for kills"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetMaxPlayersItem(Player player, FileConfiguration Config) {
        Material Item2 = Material.PLAYER_HEAD;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        int MaxPlayers = Config.getInt("SpawnLocations.MaximumPlayers");
        ItemMeta2.setDisplayName(MSG.chatColors("&bMaximum Players"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Click to set the maximum player count!"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current maximum: &f" + MaxPlayers + " players"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Sets the total game capacity"));
        lore.add(MSG.chatColors("&8\u2192 Should equal MaxTeams \u00d7 PlayersPerTeam"));
        lore.add(MSG.chatColors("&8\u2192 Game starts when enough players join"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetMinPlayersItem(Player player, FileConfiguration Config) {
        Material Item2 = Material.PLAYER_HEAD;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        int MinPlayers = Config.getInt("SpawnLocations.MinimumPlayers");
        ItemMeta2.setDisplayName(MSG.chatColors("&bMinimum Players"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Click to set the minimum player count!"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current minimum: &f" + MinPlayers + " players"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Sets the minimum players to start"));
        lore.add(MSG.chatColors("&8\u2192 Should allow at least 2 teams to play"));
        lore.add(MSG.chatColors("&8\u2192 Recommended: 60% of maximum players"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetTeamManager(Player player, FileConfiguration Config) {
        Material Item2 = Material.PLAYER_HEAD;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        int maxTeams = Config.getInt("SpawnLocations.MaxTeams", 0);
        int playersPerTeam = Config.getInt("SpawnLocations.PlayersPerTeam", 0);
        ItemMeta2.setDisplayName(MSG.chatColors("&bTeam Manager"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Click to open the team management menu."));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Teams: &f" + maxTeams));
        lore.add(MSG.chatColors("&7Players Per Team: &f" + playersPerTeam));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Create and delete teams"));
        lore.add(MSG.chatColors("&8\u2192 Set team sizes and maximum teams"));
        lore.add(MSG.chatColors("&8\u2192 Customize team names and colors"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetBorderItem(Player player, FileConfiguration Config) {
        Material Item2 = Material.STRUCTURE_VOID;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        boolean Border = Config.getBoolean("Events.Border.Enabled");
        ItemMeta2.setDisplayName(MSG.chatColors("&bBorder Event"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Should the world border start closing"));
        lore.add(MSG.chatColors("&7when the game timer is over?"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Setting: " + (Border ? "&aEnabled" : "&cDisabled")));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Click to toggle on/off"));
        lore.add(MSG.chatColors("&8\u2192 Forces players to the center"));
        lore.add(MSG.chatColors("&8\u2192 Prevents hiding at map edges"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetBorderTimerItem(Player player, FileConfiguration Config) {
        Material Item2 = Material.CLOCK;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        int Border = Config.getInt("Events.Border.Close-Border-Timer");
        String FormattedTime = EditorMenu.formatTime(Border);
        ItemMeta2.setDisplayName(MSG.chatColors("&bBorder Close Timer"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7How long will it take for the border to shrink?"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Time: &f" + FormattedTime));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Sets shrinking duration"));
        lore.add(MSG.chatColors("&8\u2192 Shorter = faster & more aggressive"));
        lore.add(MSG.chatColors("&8\u2192 Longer = slower & more gradual"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetMapBlocksItem(Player player, FileConfiguration config) {
        boolean canBreakMapBlocks = config.getBoolean("Settings.Can-Break-Map-Blocks");
        Material itemMaterial = canBreakMapBlocks ? Material.GREEN_DYE : Material.RED_DYE;
        ItemStack itemStack = new ItemStack(itemMaterial);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(MSG.chatColors("&bCan Break Map Blocks?"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Can players break blocks that are"));
        lore.add(MSG.chatColors("&7part of the original map?"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Setting: " + (canBreakMapBlocks ? "&aYes" : "&cNo")));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Click to toggle on/off"));
        lore.add(MSG.chatColors("&8\u2192 Players can always break blocks they place"));
        lore.add(MSG.chatColors("&8\u2192 Affects map conservation"));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    public static ItemStack GetMapNameItem(Player player, FileConfiguration config) {
        String MapName = config.getString("Settings.DisplayName", "Unnamed Game");
        Material itemMaterial = Material.ANVIL;
        ItemStack itemStack = new ItemStack(itemMaterial);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(MSG.chatColors("&bGame Display Name"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Set a name for your game. This will be"));
        lore.add(MSG.chatColors("&7shown to players in menus and lobbies."));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Name: &f" + MapName));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Can use color codes with &"));
        lore.add(MSG.chatColors("&8\u2192 Choose something descriptive"));
        lore.add(MSG.chatColors("&8\u2192 Appears in %mpa_game_displayname% placeholder"));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    public static String formatTime(int seconds) {
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    public static ItemStack GetLobbyTimerItem(Player player, FileConfiguration Config) {
        Material Item2 = Material.CLOCK;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        int WaitingTime = Config.getInt("Settings.LobbyTimer");
        String FormattedTime = EditorMenu.formatTime(WaitingTime);
        ItemMeta2.setDisplayName(MSG.chatColors("&bLobby Timer"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7How long should players wait in the lobby"));
        lore.add(MSG.chatColors("&7before teleporting to their cages?"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Time: &f" + FormattedTime));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Sets pre-game lobby duration"));
        lore.add(MSG.chatColors("&8\u2192 Gives players time to join"));
        lore.add(MSG.chatColors("&8\u2192 Recommended: 30-60 seconds"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetCageTimerItem(Player player, FileConfiguration Config) {
        Material Item2 = Material.CLOCK;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        int WaitingTime = Config.getInt("Settings.CageTimer");
        String FormattedTime = EditorMenu.formatTime(WaitingTime);
        ItemMeta2.setDisplayName(MSG.chatColors("&bCage Timer"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7How long should players wait in their cages"));
        lore.add(MSG.chatColors("&7before the game starts?"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Time: &f" + FormattedTime));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Sets pre-game countdown"));
        lore.add(MSG.chatColors("&8\u2192 Allows players to prepare"));
        lore.add(MSG.chatColors("&8\u2192 Recommended: 10-15 seconds"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetVotingItem(Player player, FileConfiguration config) {
        Material item = Material.PAPER;
        ItemStack itemStack = new ItemStack(item);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(MSG.chatColors("&bVoting Events"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Click to configure special game modes"));
        lore.add(MSG.chatColors("&7that players can vote for."));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Settings:"));
        lore.add(MSG.chatColors("&7"));
        boolean floorIsLavaEnabled = config.contains("Events.Voting.Floor-Is-Lava.Enabled") ? config.getBoolean("Events.Voting.Floor-Is-Lava.Enabled") : true;
        boolean elytraModeEnabled = config.contains("Events.Voting.Elytra-Mode.Enabled") ? config.getBoolean("Events.Voting.Elytra-Mode.Enabled") : true;
        boolean noFallModeEnabled = config.contains("Events.Voting.No-Fall-Mode.Enabled") ? config.getBoolean("Events.Voting.No-Fall-Mode.Enabled") : true;
        boolean oneHeartModeEnabled = config.contains("Events.Voting.1-Heart-Mode.Enabled") ? config.getBoolean("Events.Voting.1-Heart-Mode.Enabled") : true;
        boolean doubleHPEnabled = config.contains("Events.Voting.Double-HP.Enabled") ? config.getBoolean("Events.Voting.Double-HP.Enabled") : true;
        boolean playerSwapEnabled = config.contains("Events.Voting.Player-Swap.Enabled") ? config.getBoolean("Events.Voting.Player-Swap.Enabled") : true;
        boolean inventorySwapEnabled = config.contains("Events.Voting.Inventory-Swap.Enabled") ? config.getBoolean("Events.Voting.Inventory-Swap.Enabled") : true;
        EditorMenu.addSettingStatus(lore, "Floor-Is-Lava", floorIsLavaEnabled);
        EditorMenu.addSettingStatus(lore, "Elytra-Mode", elytraModeEnabled);
        EditorMenu.addSettingStatus(lore, "No-Fall-Mode", noFallModeEnabled);
        EditorMenu.addSettingStatus(lore, "1-Heart-Mode", oneHeartModeEnabled);
        EditorMenu.addSettingStatus(lore, "Double-HP", doubleHPEnabled);
        EditorMenu.addSettingStatus(lore, "Player-Swap", playerSwapEnabled);
        EditorMenu.addSettingStatus(lore, "Inventory-Swap", inventorySwapEnabled);
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Enable/disable voting options"));
        lore.add(MSG.chatColors("&8\u2192 Players vote before game starts"));
        lore.add(MSG.chatColors("&8\u2192 Adds variety to gameplay"));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    private static void addSettingStatus(List<String> lore, String settingName, boolean isEnabled) {
        String status = isEnabled ? "&aEnabled" : "&cDisabled";
        lore.add(MSG.chatColors("&7" + settingName + ": " + status));
    }

    public static ItemStack GetGameTimeItem(Player player, FileConfiguration Config) {
        Material Item2 = Material.CLOCK;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        int WaitingTime = Config.getInt("Settings.GameTimer");
        String FormattedTime = EditorMenu.formatTime(WaitingTime);
        ItemMeta2.setDisplayName(MSG.chatColors("&bGame Timer"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7How long should the main game last?"));
        lore.add(MSG.chatColors("&7After this time, border may start shrinking."));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Time: &f" + FormattedTime));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Sets main game duration"));
        lore.add(MSG.chatColors("&8\u2192 Border shrinks after this time (if enabled)"));
        lore.add(MSG.chatColors("&8\u2192 Recommended: 5-15 minutes"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetItemTimeItem(Player player, FileConfiguration Config) {
        Material Item2 = Material.CLOCK;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        int WaitingTime = Config.getInt("Settings.ItemTimer");
        String FormattedTime = EditorMenu.formatTime(WaitingTime);
        ItemMeta2.setDisplayName(MSG.chatColors("&bRandom Item Timer"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7How often should random items be"));
        lore.add(MSG.chatColors("&7given to players during the game?"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Time: &f" + FormattedTime));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Sets interval for random items"));
        lore.add(MSG.chatColors("&8\u2192 Lower = more frequent items"));
        lore.add(MSG.chatColors("&8\u2192 Recommended: 30-60 seconds"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetBlackListedItem(Player player, FileConfiguration Config) {
        Material Item2 = Material.BARRIER;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        String itemType = Config.getString("Settings.RandomItems.Type", "Blacklisted");
        int itemCount = Config.getStringList("Settings.RandomItems.List").size();
        ItemMeta2.setDisplayName(MSG.chatColors("&bItem Control"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Click to manage which items are"));
        lore.add(MSG.chatColors("&7allowed or prohibited in your game."));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Mode: &f" + itemType));
        lore.add(MSG.chatColors("&7Items in list: &f" + itemCount));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Blacklist: Ban specific items"));
        lore.add(MSG.chatColors("&8\u2192 Whitelist: Only allow listed items"));
        lore.add(MSG.chatColors("&8\u2192 Affects random drops and crafting"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetBuildHighItem(Player player, FileConfiguration Config) {
        Material Item2 = Material.BRICKS;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        String BuildHeight = Config.getString("Settings.BuildHeight", "Not set");
        ItemMeta2.setDisplayName(MSG.chatColors("&bBuild Height Limit"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Set the maximum height that players"));
        lore.add(MSG.chatColors("&7can build up to in your game."));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Y-limit: &f" + BuildHeight));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Prevents excessive skybuilding"));
        lore.add(MSG.chatColors("&8\u2192 Typically set to 100-150 blocks"));
        lore.add(MSG.chatColors("&8\u2192 Consider your map's design"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetBuildRangeItem(Player player, FileConfiguration Config) {
        Material Item2 = Material.BRICKS;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        String BuildRange = Config.getString("Settings.BuildRange", "Not set");
        ItemMeta2.setDisplayName(MSG.chatColors("&bBuild Range Limit"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Set the maximum distance from spawn"));
        lore.add(MSG.chatColors("&7that players can build in."));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Range: &f" + BuildRange + " blocks"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Prevents building too far away"));
        lore.add(MSG.chatColors("&8\u2192 Keeps players within game area"));
        lore.add(MSG.chatColors("&8\u2192 Recommended: 50-200 blocks"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public static ItemStack GetDeathHighItem(Player player, FileConfiguration Config) {
        Material Item2 = Material.BRICKS;
        ItemStack ItemStack2 = new ItemStack(Item2);
        ItemMeta ItemMeta2 = ItemStack2.getItemMeta();
        String DeathRange = Config.getString("Settings.DeathHeight", "Not set");
        ItemMeta2.setDisplayName(MSG.chatColors("&bDeath Height"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Set the Y-coordinate below which"));
        lore.add(MSG.chatColors("&7players will die when they fall."));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Y-level: &f" + DeathRange));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Players below this height will die"));
        lore.add(MSG.chatColors("&8\u2192 Set based on your map's lowest point"));
        lore.add(MSG.chatColors("&8\u2192 Typically 5-10 blocks below map edge"));
        ItemMeta2.setLore(lore);
        ItemStack2.setItemMeta(ItemMeta2);
        return ItemStack2;
    }

    public void openBlacklistedItemsGUI(Player player, int page) {
        FileConfiguration config = WorldListeners.configEditer.get(player.getUniqueId());
        Inventory inv = Bukkit.createInventory((InventoryHolder)null, (int)54, (String)"Blacklisted/Whitelisted items");
        List blacklistedItems = config.getStringList("Settings.RandomItems.List");
        int startIndex = (page - 1) * 45;
        int endIndex = Math.min(startIndex + 45, blacklistedItems.size());
        for (int i = startIndex; i < endIndex; ++i) {
            String itemName = (String)blacklistedItems.get(i);
            ItemStack item = new ItemStack(Material.matchMaterial((String)itemName), 1);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(MSG.chatColors("#BDD3D5" + itemName));
            ArrayList<String> loresArray = new ArrayList<String>();
            loresArray.add(MSG.chatColors("#BDD3D5Click to remove the item"));
            loresArray.add(MSG.chatColors("#BDD3D5from the blacklisted/whitelisted item list!"));
            loresArray.add(MSG.chatColors("&7"));
            loresArray.add(MSG.chatColors("&8\u2192 Remove from control list"));
            loresArray.add(MSG.chatColors("&8\u2192 Changes game balance"));
            meta.setLore(loresArray);
            item.setItemMeta(meta);
            inv.addItem(new ItemStack[]{item});
        }
        Material paneItem = Material.GRAY_STAINED_GLASS_PANE;
        ItemStack fillItem = new ItemStack(paneItem);
        ItemMeta fillItemMeta = fillItem.getItemMeta();
        fillItemMeta.setDisplayName("\u00a7f ");
        fillItem.setItemMeta(fillItemMeta);
        for (int i = 45; i < inv.getSize(); ++i) {
            inv.setItem(i, fillItem);
        }
        if (page > 1) {
            inv.setItem(52, this.createNavigationItem("Previous Page", Material.ARROW));
        }
        if (endIndex < blacklistedItems.size()) {
            inv.setItem(53, this.createNavigationItem("Next Page", Material.ARROW));
        }
        if (!PageCache.containsKey(player.getUniqueId())) {
            PageCache.put(player.getUniqueId(), 1);
        } else {
            PageCache.put(player.getUniqueId(), page);
        }
        Material Barrier = Material.BARRIER;
        ItemStack BarrierItem = new ItemStack(Barrier);
        ItemMeta BarrierItemMeta = BarrierItem.getItemMeta();
        BarrierItemMeta.setDisplayName(MSG.chatColors("&cBack to Menu"));
        ArrayList<String> barrierLore = new ArrayList<String>();
        barrierLore.add(MSG.chatColors("&7Return to the main editor menu"));
        barrierLore.add(MSG.chatColors("&7"));
        barrierLore.add(MSG.chatColors("&8\u2192 Changes are saved automatically"));
        BarrierItemMeta.setLore(barrierLore);
        BarrierItem.setItemMeta(BarrierItemMeta);
        inv.setItem(46, BarrierItem);
        ItemStack BlackWhiteItems = EditorMenu.GetBlackWhiteType(player, config);
        inv.setItem(48, BlackWhiteItems);
        MoonLab.PlayerMenu.put(player.getUniqueId(), "Blacklisted-WhitelistedItems");
        player.openInventory(inv);
    }

    public static ItemStack GetBlackWhiteType(Player player, FileConfiguration config) {
        String itemType = config.getString("Settings.RandomItems.Type", "Blacklisted");
        Material itemMaterial = itemType.equalsIgnoreCase("Whitelisted") ? Material.WHITE_DYE : Material.BLACK_DYE;
        ItemStack itemStack = new ItemStack(itemMaterial);
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(MSG.chatColors("&bItem Control Mode"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Click to toggle between Blacklist and Whitelist mode."));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&7Current Mode: " + (itemType.equalsIgnoreCase("Whitelisted") ? "&fWhitelist" : "&8Blacklist")));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Blacklist: Listed items are prohibited"));
        lore.add(MSG.chatColors("&8\u2192 Whitelist: Only listed items are allowed"));
        lore.add(MSG.chatColors("&8\u2192 Click to switch modes"));
        itemMeta.setLore(lore);
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    private ItemStack createNavigationItem(String name, Material material) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Click to navigate pages"));
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void OnInventoryClick(InventoryClickEvent event) {
        Inventory inventory;
        if (event.getWhoClicked() instanceof Player && (inventory = event.getClickedInventory()) != null) {
            Player player = (Player)event.getWhoClicked();
            String currentGUI = MoonLab.PlayerMenu.get(player.getUniqueId());
            FileConfiguration config = WorldListeners.configEditer.get(player.getUniqueId());
            if (currentGUI != null) {
                ItemStack clicked;
                if (currentGUI.equals(MENU_SETUP_CHOICE)) {
                    event.setCancelled(true);
                    ItemStack clicked2 = event.getCurrentItem();
                    if (clicked2 == null) {
                        return;
                    }
                    if (event.getSlot() == 11) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.EditGuiInv(player, config)), 1L);
                    } else if (event.getSlot() == 15) {
                        player.closeInventory();
                        playerSetupPhase.put(player.getUniqueId(), 1);
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedDisplayNameInventory(player, config)), 1L);
                    }
                } else if (currentGUI.equalsIgnoreCase("Blacklisted-WhitelistedItems")) {
                    ItemStack clicked3 = event.getCurrentItem();
                    if (clicked3 != null && clicked3.getType() != Material.AIR) {
                        event.setCancelled(true);
                        if (event.getSlot() == 52) {
                            int maxTeams = PageCache.get(player.getUniqueId()) - 1;
                            player.closeInventory();
                            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> this.openBlacklistedItemsGUI(player, maxTeams), 1L);
                            return;
                        }
                        if (event.getSlot() == 53) {
                            int maxTeams = PageCache.get(player.getUniqueId()) + 1;
                            player.closeInventory();
                            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> this.openBlacklistedItemsGUI(player, maxTeams), 1L);
                            return;
                        }
                        if (event.getSlot() == 46) {
                            player.closeInventory();
                            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> {
                                if (playerSetupPhase.containsKey(player.getUniqueId()) && playerSetupPhase.get(player.getUniqueId()) == 10) {
                                    player.openInventory(EditorMenu.createGuidedBlacklistInventory(player, config));
                                } else {
                                    player.openInventory(EditorMenu.EditGuiInv(player, config));
                                }
                            }, 1L);
                            return;
                        }
                        if (event.getSlot() == 48) {
                            String currentType = config.getString("Settings.RandomItems.Type", "Blacklisted");
                            String itemTypeName = currentType.equalsIgnoreCase("Whitelisted") ? "Blacklisted" : "Whitelisted";
                            config.set("Settings.RandomItems.Type", (Object)itemTypeName);
                            EditorMenu.SaveConfig(player);
                            player.sendMessage(MSG.chatColors("#87C8CEYou have updated your item control mode to: &f" + itemTypeName));
                            player.closeInventory();
                            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> this.openBlacklistedItemsGUI(player, 1), 1L);
                            return;
                        }
                        Material itemType = clicked3.getType();
                        String itemTypeName = itemType.name();
                        ArrayList<String> blacklistedItems = config.getStringList("Settings.RandomItems.List");
                        if (blacklistedItems == null) {
                            blacklistedItems = new ArrayList<String>();
                        }
                        if (inventory.getType() == InventoryType.PLAYER) {
                            event.setCancelled(true);
                            if (!blacklistedItems.contains(itemTypeName)) {
                                blacklistedItems.add(itemTypeName);
                                config.set("Settings.RandomItems.List", blacklistedItems);
                            }
                        } else {
                            event.setCancelled(true);
                            blacklistedItems.remove(itemTypeName);
                            config.set("Settings.RandomItems.List", blacklistedItems);
                        }
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> {
                            this.openBlacklistedItemsGUI(player, 1);
                            EditorMenu.SaveConfig(player);
                        }, 1L);
                    }
                } else if (currentGUI.equals(MENU_GUIDED_DISPLAY_NAME)) {
                    event.setCancelled(true);
                    ItemStack clicked4 = event.getCurrentItem();
                    if (clicked4 == null) {
                        return;
                    }
                    if (event.getSlot() == 13) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "MapName");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter the display name for your game!"));
                        player.sendMessage(MSG.chatColors("#87C8CEYou can use color codes with &, for example: &bIce &eBattle"));
                    } else if (event.getSlot() == 18) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedTeamsInventory(player, config)), 1L);
                    }
                } else if (currentGUI.equals(MENU_GUIDED_TEAMS)) {
                    event.setCancelled(true);
                    ItemStack clicked5 = event.getCurrentItem();
                    if (clicked5 == null) {
                        return;
                    }
                    if (event.getSlot() == 13) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.createSetupChoiceMenu(player, config)), 1L);
                    } else if (event.getSlot() == 18) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedPlayersInventory(player, config)), 1L);
                    } else if (event.getSlot() == 26) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedDisplayNameInventory(player, config)), 1L);
                    }
                } else if (currentGUI.equals(MENU_GUIDED_PLAYERS)) {
                    event.setCancelled(true);
                    ItemStack clicked6 = event.getCurrentItem();
                    if (clicked6 == null) {
                        return;
                    }
                    if (event.getSlot() == 12) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "MaximumPlayers");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number for the maximum players!"));
                    } else if (event.getSlot() == 14) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "MinimumPlayers");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number for the minimum players!"));
                    } else if (event.getSlot() == 13) {
                        int maxTeams = config.getInt("SpawnLocations.MaxTeams", 0);
                        int playersPerTeam = config.getInt("SpawnLocations.PlayersPerTeam", 0);
                        int suggestedMaxPlayers = maxTeams * playersPerTeam;
                        int suggestedMinPlayers = Math.max(2, (int)((double)suggestedMaxPlayers * 0.6));
                        if (maxTeams > 0 && playersPerTeam > 0) {
                            config.set("SpawnLocations.MaximumPlayers", (Object)suggestedMaxPlayers);
                            config.set("SpawnLocations.MinimumPlayers", (Object)suggestedMinPlayers);
                            EditorMenu.SaveConfig(player);
                            player.sendMessage(MSG.chatColors("#87C8CEAutomatically set player limits:"));
                            player.sendMessage(MSG.chatColors("#87C8CE - Maximum Players: " + suggestedMaxPlayers));
                            player.sendMessage(MSG.chatColors("#87C8CE - Minimum Players: " + suggestedMinPlayers));
                            player.closeInventory();
                            Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedPlayersInventory(player, config)), 1L);
                        } else {
                            player.sendMessage(MSG.chatColors("&cCannot auto-set player limits: Please configure teams first!"));
                        }
                    } else if (event.getSlot() == 18) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedBuildHeightInventory(player, config)), 1L);
                    } else if (event.getSlot() == 26) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedTeamsInventory(player, config)), 1L);
                    }
                } else if (currentGUI.equals(MENU_GUIDED_BUILD_HEIGHT)) {
                    event.setCancelled(true);
                    ItemStack clicked7 = event.getCurrentItem();
                    if (clicked7 == null) {
                        return;
                    }
                    if (event.getSlot() == 13) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "BuildHeight");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number for the maximum build height!"));
                    } else if (event.getSlot() == 18) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedBuildRangeInventory(player, config)), 1L);
                    } else if (event.getSlot() == 26) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedPlayersInventory(player, config)), 1L);
                    }
                } else if (currentGUI.equals(MENU_GUIDED_BUILD_RANGE)) {
                    event.setCancelled(true);
                    ItemStack clicked8 = event.getCurrentItem();
                    if (clicked8 == null) {
                        return;
                    }
                    if (event.getSlot() == 13) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "BuildRange");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number for the maximum build range!"));
                    } else if (event.getSlot() == 18) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedDeathLimitInventory(player, config)), 1L);
                    } else if (event.getSlot() == 26) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedBuildHeightInventory(player, config)), 1L);
                    }
                } else if (currentGUI.equals(MENU_GUIDED_DEATH_LIMIT)) {
                    event.setCancelled(true);
                    ItemStack clicked9 = event.getCurrentItem();
                    if (clicked9 == null) {
                        return;
                    }
                    if (event.getSlot() == 13) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "DeathHeight");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number for the death height limit!"));
                    } else if (event.getSlot() == 18) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedTimersInventory(player, config)), 1L);
                    } else if (event.getSlot() == 26) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedBuildRangeInventory(player, config)), 1L);
                    }
                } else if (currentGUI.equals(MENU_GUIDED_TIMERS)) {
                    event.setCancelled(true);
                    ItemStack clicked10 = event.getCurrentItem();
                    if (clicked10 == null) {
                        return;
                    }
                    if (event.getSlot() == 11) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "LobbyTimer");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number (in seconds) for the lobby timer!"));
                    } else if (event.getSlot() == 13) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "CageTimer");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number (in seconds) for the cage timer!"));
                    } else if (event.getSlot() == 15) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "GameTimer");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number (in seconds) for the game timer!"));
                    } else if (event.getSlot() == 22) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "ItemTimer");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number (in seconds) for the random item timer!"));
                    } else if (event.getSlot() == 27) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedBorderInventory(player, config)), 1L);
                    } else if (event.getSlot() == 35) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedDeathLimitInventory(player, config)), 1L);
                    }
                } else if (currentGUI.equals(MENU_GUIDED_BORDER)) {
                    event.setCancelled(true);
                    ItemStack clicked11 = event.getCurrentItem();
                    if (clicked11 == null) {
                        return;
                    }
                    if (event.getSlot() == 12) {
                        boolean BreakBlocks = config.getBoolean("Events.Border.Enabled");
                        config.set("Events.Border.Enabled", (Object)(!BreakBlocks ? 1 : 0));
                        EditorMenu.SaveConfig(player);
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedBorderInventory(player, config)), 1L);
                    } else if (event.getSlot() == 14) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "BorderTimer");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number (in seconds) for the border shrinking timer!"));
                    } else if (event.getSlot() == 18) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedBreakBlocksInventory(player, config)), 1L);
                    } else if (event.getSlot() == 26) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedTimersInventory(player, config)), 1L);
                    }
                } else if (currentGUI.equals(MENU_GUIDED_BREAK_BLOCKS)) {
                    event.setCancelled(true);
                    ItemStack clicked12 = event.getCurrentItem();
                    if (clicked12 == null) {
                        return;
                    }
                    if (event.getSlot() == 13) {
                        boolean BreakBlocks = config.getBoolean("Settings.Can-Break-Map-Blocks");
                        config.set("Settings.Can-Break-Map-Blocks", (Object)(!BreakBlocks ? 1 : 0));
                        EditorMenu.SaveConfig(player);
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedBreakBlocksInventory(player, config)), 1L);
                    } else if (event.getSlot() == 18) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedBlacklistInventory(player, config)), 1L);
                    } else if (event.getSlot() == 26) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedBorderInventory(player, config)), 1L);
                    }
                } else if (currentGUI.equals(MENU_GUIDED_BLACKLIST)) {
                    event.setCancelled(true);
                    ItemStack clicked13 = event.getCurrentItem();
                    if (clicked13 == null) {
                        return;
                    }
                    if (event.getSlot() == 13) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> this.openBlacklistedItemsGUI(player, 1), 1L);
                    } else if (event.getSlot() == 18) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedVotingInventory(player, config)), 1L);
                    } else if (event.getSlot() == 26) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedBreakBlocksInventory(player, config)), 1L);
                    }
                } else if (currentGUI.equals(MENU_GUIDED_VOTING)) {
                    event.setCancelled(true);
                    ItemStack clicked14 = event.getCurrentItem();
                    if (clicked14 == null) {
                        return;
                    }
                    if (event.getSlot() == 13) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(VoteSetting.createVotingSettingsGUI(player)), 1L);
                    } else if (event.getSlot() == 18) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedRewardsInventory(player, config)), 1L);
                    } else if (event.getSlot() == 26) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedBlacklistInventory(player, config)), 1L);
                    }
                } else if (currentGUI.equals(MENU_GUIDED_REWARDS)) {
                    event.setCancelled(true);
                    ItemStack clicked15 = event.getCurrentItem();
                    if (clicked15 == null) {
                        return;
                    }
                    if (event.getSlot() == 13) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> RewardCommandEditorGUI.open(player, null), 1L);
                    } else if (event.getSlot() == 18) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedCompleteInventory(player, config)), 1L);
                    } else if (event.getSlot() == 26) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createGuidedVotingInventory(player, config)), 1L);
                    }
                } else if (currentGUI.equals(MENU_GUIDED_COMPLETE)) {
                    event.setCancelled(true);
                    ItemStack clicked16 = event.getCurrentItem();
                    if (clicked16 == null) {
                        return;
                    }
                    if (event.getSlot() == 21) {
                        if (clicked16.getType() == Material.GREEN_DYE) {
                            this.handleSaveGame(player, config, true);
                        } else {
                            player.sendMessage(MSG.chatColors("&cYour game is not ready to be activated yet. Please fix the remaining issues first."));
                        }
                    } else if (event.getSlot() == 23) {
                        this.handleSaveGame(player, config, false);
                    } else if (event.getSlot() == 31) {
                        player.closeInventory();
                        playerSetupPhase.remove(player.getUniqueId());
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.EditGuiInv(player, config)), 1L);
                    }
                } else if (currentGUI.equals(MENU_MANUAL) && (clicked = event.getCurrentItem()) != null) {
                    event.setCancelled(true);
                    if (clicked.getType() == Material.GRAY_STAINED_GLASS_PANE) {
                        return;
                    }
                    if (clicked.getType().equals((Object)Material.BARRIER) && event.getSlot() == 48) {
                        event.setCancelled(true);
                        player.closeInventory();
                    } else if (event.getSlot() == 10) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "MaximumPlayers");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number in the chat to edit the maximum players"));
                    } else if (event.getSlot() == 11) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "MinimumPlayers");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number in the chat to edit the minimum required players"));
                    } else if (event.getSlot() == 12) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(TeamManagerMenu.createSetupChoiceMenu(player, config)), 1L);
                    } else if (event.getSlot() == 14) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> RewardCommandEditorGUI.open(player, null), 1L);
                    } else if (event.getSlot() == 28) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "LobbyTimer");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number in the chat to change the Lobby Timer"));
                    } else if (event.getSlot() == 29) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "CageTimer");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number in the chat to change the Cage Timer"));
                    } else if (event.getSlot() == 30) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "GameTimer");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number in the chat to change the Game Timer"));
                    } else if (event.getSlot() == 31) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "ItemTimer");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number in the chat to change the random item timer"));
                    } else if (event.getSlot() == 19) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "BuildHeight");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number in the chat to change the Build Height!"));
                    } else if (event.getSlot() == 20) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "BuildRange");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number in the chat to change the Build Range!"));
                    } else if (event.getSlot() == 21) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "DeathHeight");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number in the chat to change the Death Height!"));
                    } else if (event.getSlot() == 15) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> this.openBlacklistedItemsGUI(player, 1), 1L);
                    } else if (event.getSlot() == 24) {
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(VoteSetting.createVotingSettingsGUI(player)), 1L);
                    } else if (event.getSlot() == 33) {
                        boolean BreakBlocks = config.getBoolean("Events.Border.Enabled");
                        config.set("Events.Border.Enabled", (Object)(!BreakBlocks ? 1 : 0));
                        EditorMenu.SaveConfig(player);
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.EditGuiInv(player, config)), 1L);
                    } else if (event.getSlot() == 25) {
                        boolean BreakBlocks = config.getBoolean("Settings.Can-Break-Map-Blocks");
                        config.set("Settings.Can-Break-Map-Blocks", (Object)(!BreakBlocks ? 1 : 0));
                        EditorMenu.SaveConfig(player);
                        player.closeInventory();
                        Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.EditGuiInv(player, config)), 1L);
                    } else if (event.getSlot() == 16) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "MapName");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter the new map name!"));
                    } else if (event.getSlot() == 34) {
                        player.closeInventory();
                        AdminEditCache.put(player.getUniqueId(), "BorderTimer");
                        player.sendMessage(MSG.chatColors("#87C8CEEnter a number in the chat to change the border timer!"));
                    } else if (event.getSlot() == 50 && clicked.getType().equals((Object)Material.GREEN_DYE)) {
                        this.handleSaveGame(player, config, true);
                    } else if (event.getSlot() == 51 && clicked.getType().equals((Object)Material.ORANGE_DYE)) {
                        this.handleSaveGame(player, config, false);
                    }
                }
            }
        }
    }

    private void handleSaveGame(Player player, FileConfiguration config, boolean activate) {
        String worldname = player.getWorld().getName();
        player.closeInventory();
        if (activate) {
            player.sendMessage(MSG.chatColors("&aThe game is ready to be played!"));
            player.sendMessage(MSG.chatColors("&aPlayers will be able to join this game after server restart! #(" + worldname + ")"));
            config.set("Settings.LoadMap", (Object)true);
        } else {
            player.sendMessage(MSG.chatColors("&eYou have pre-saved the game!"));
            player.sendMessage(MSG.chatColors("&eThe game &6#(" + worldname + ") &eis not ready to be played yet!"));
            player.sendMessage(MSG.chatColors("&eComplete the map setup by using &6/mpa setup " + worldname));
        }
        EditorMenu.SaveConfig(player);
        String World2 = SettingsManager.getInstance().getSettings().getString("LobbySettings.World");
        int X = SettingsManager.getInstance().getSettings().getInt("LobbySettings.Spawn.X");
        int Y = SettingsManager.getInstance().getSettings().getInt("LobbySettings.Spawn.Y");
        int Z = SettingsManager.getInstance().getSettings().getInt("LobbySettings.Spawn.Z");
        Location location = new Location(Bukkit.getWorld((String)World2), (double)X, (double)Y, (double)Z);
        player.teleport(location);
        player.getInventory().clear();
        WorldListeners.UnloadWorld(worldname);
        WorldListeners.configEditer.remove(player.getUniqueId());
        AdminEditCache.remove(player.getUniqueId());
        MoonLab.PlayerMenu.put(player.getUniqueId(), "NA");
        EditItems.SetTeamNumber.remove(player.getUniqueId());
        EditItems.SetPositionNumber.remove(player.getUniqueId());
        playerSetupPhase.remove(player.getUniqueId());
    }

    @EventHandler
    public void onAdminChat(AsyncPlayerChatEvent event) {
        String editSetting;
        Player player = event.getPlayer();
        FileConfiguration config = WorldListeners.configEditer.get(player.getUniqueId());
        if (config != null && AdminEditCache.containsKey(player.getUniqueId()) && ((editSetting = AdminEditCache.get(player.getUniqueId())).equalsIgnoreCase("MaximumPlayers") || editSetting.equalsIgnoreCase("MinimumPlayers") || editSetting.equalsIgnoreCase("LobbyTimer") || editSetting.equalsIgnoreCase("CageTimer") || editSetting.equalsIgnoreCase("GameTimer") || editSetting.equalsIgnoreCase("ItemTimer") || editSetting.equalsIgnoreCase("DeathHeight") || editSetting.equalsIgnoreCase("BuildHeight") || editSetting.equalsIgnoreCase("BuildRange") || editSetting.equalsIgnoreCase("BorderTimer") || editSetting.equalsIgnoreCase("MapName") || editSetting.equalsIgnoreCase("LavaTimer"))) {
            String message = event.getMessage();
            try {
                if (editSetting.equalsIgnoreCase("MapName")) {
                    config.set("Settings.DisplayName", (Object)message);
                    player.sendMessage(MSG.chatColors("#87C8CEUpdated the game name to: " + message));
                } else {
                    String numericMessage = message.replaceAll("[^-?0-9]", "");
                    int newAmount = Integer.parseInt(numericMessage);
                    if (editSetting.equalsIgnoreCase("MinimumPlayers")) {
                        config.set("SpawnLocations.MinimumPlayers", (Object)newAmount);
                        player.sendMessage(MSG.chatColors("#87C8CEUpdated the minimum required players to " + newAmount + "!"));
                    } else if (editSetting.equalsIgnoreCase("MaximumPlayers")) {
                        config.set("SpawnLocations.MaximumPlayers", (Object)newAmount);
                        player.sendMessage(MSG.chatColors("#87C8CEUpdated the maximum players to " + newAmount + "!"));
                    } else if (editSetting.equalsIgnoreCase("LobbyTimer")) {
                        config.set("Settings.LobbyTimer", (Object)newAmount);
                        player.sendMessage(MSG.chatColors("#87C8CEUpdated the Lobby Timer to " + newAmount + " seconds!"));
                    } else if (editSetting.equalsIgnoreCase("CageTimer")) {
                        config.set("Settings.CageTimer", (Object)newAmount);
                        player.sendMessage(MSG.chatColors("#87C8CEUpdated the Cage Timer to " + newAmount + " seconds!"));
                    } else if (editSetting.equalsIgnoreCase("GameTimer")) {
                        config.set("Settings.GameTimer", (Object)newAmount);
                        player.sendMessage(MSG.chatColors("#87C8CEUpdated the Game Timer to " + newAmount + " seconds!"));
                    } else if (editSetting.equalsIgnoreCase("ItemTimer")) {
                        config.set("Settings.ItemTimer", (Object)newAmount);
                        player.sendMessage(MSG.chatColors("#87C8CEUpdated the Random Item Timer to " + newAmount + " seconds!"));
                    } else if (editSetting.equalsIgnoreCase("DeathHeight")) {
                        config.set("Settings.DeathHeight", (Object)newAmount);
                        player.sendMessage(MSG.chatColors("#87C8CEUpdated the Death Height to Y=" + newAmount + "!"));
                    } else if (editSetting.equalsIgnoreCase("BuildHeight")) {
                        config.set("Settings.BuildHeight", (Object)newAmount);
                        player.sendMessage(MSG.chatColors("#87C8CEUpdated the maximum Build Height to Y=" + newAmount + "!"));
                    } else if (editSetting.equalsIgnoreCase("BuildRange")) {
                        config.set("Settings.BuildRange", (Object)newAmount);
                        player.sendMessage(MSG.chatColors("#87C8CEUpdated the maximum Build Range to " + newAmount + " blocks!"));
                    } else if (editSetting.equalsIgnoreCase("BorderTimer")) {
                        config.set("Events.Border.Close-Border-Timer", (Object)newAmount);
                        player.sendMessage(MSG.chatColors("#87C8CEUpdated the Border Timer to " + newAmount + " seconds!"));
                    }
                }
                EditorMenu.SaveConfig(player);
                AdminEditCache.remove(player.getUniqueId());
                Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> {
                    if (playerSetupPhase.containsKey(player.getUniqueId())) {
                        int phase = playerSetupPhase.get(player.getUniqueId());
                        switch (phase) {
                            case 1: {
                                player.openInventory(EditorMenu.createGuidedDisplayNameInventory(player, config));
                                break;
                            }
                            default: {
                                player.openInventory(EditorMenu.EditGuiInv(player, config));
                                break;
                            }
                            case 3: {
                                player.openInventory(EditorMenu.createGuidedPlayersInventory(player, config));
                                break;
                            }
                            case 4: {
                                player.openInventory(EditorMenu.createGuidedBuildHeightInventory(player, config));
                                break;
                            }
                            case 5: {
                                player.openInventory(EditorMenu.createGuidedBuildRangeInventory(player, config));
                                break;
                            }
                            case 6: {
                                player.openInventory(EditorMenu.createGuidedDeathLimitInventory(player, config));
                                break;
                            }
                            case 7: {
                                player.openInventory(EditorMenu.createGuidedTimersInventory(player, config));
                                break;
                            }
                            case 8: {
                                player.openInventory(EditorMenu.createGuidedBorderInventory(player, config));
                                break;
                            }
                        }
                    } else {
                        player.openInventory(EditorMenu.EditGuiInv(player, config));
                    }
                });
            }
            catch (NumberFormatException var8) {
                player.sendMessage(MSG.chatColors("&cInvalid input! Please enter a valid number."));
            }
            event.setCancelled(true);
        }
    }
}

