/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.block.Block
 *  org.bukkit.block.Sign
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.SignFunctions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class RemoveClickableSign
extends AdminSubCommand {
    @Override
    public String getName() {
        return "removeclickablesign";
    }

    @Override
    public String getDescription() {
        return "Remove a clickable sign at your current target block!";
    }

    @Override
    public String getSyntax() {
        return "/mpa removeclickablesign";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (!player.hasPermission("mpa.removeclickablesign")) {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        } else {
            Block targetBlock = player.getTargetBlockExact(5);
            if (targetBlock != null && targetBlock.getState() instanceof Sign) {
                FileConfiguration config = SettingsManager.getInstance().getClickableSigns();
                String foundSignName = null;
                String worldName = targetBlock.getWorld().getName();
                int x = targetBlock.getX();
                int y = targetBlock.getY();
                int z = targetBlock.getZ();
                ConfigurationSection signsSection = config.getConfigurationSection("ClickableSigns");
                if (signsSection != null) {
                    for (String signName : signsSection.getKeys(false)) {
                        String signWorld = config.getString("ClickableSigns." + signName + ".World");
                        int signX = config.getInt("ClickableSigns." + signName + ".X");
                        int signY = config.getInt("ClickableSigns." + signName + ".Y");
                        int signZ = config.getInt("ClickableSigns." + signName + ".Z");
                        if (!worldName.equals(signWorld) || x != signX || y != signY || z != signZ) continue;
                        foundSignName = signName;
                        break;
                    }
                }
                if (foundSignName == null) {
                    player.sendMessage(MSG.chatColors("&cThis sign is not set as a clickable sign!"));
                } else {
                    config.set("ClickableSigns." + foundSignName, null);
                    SettingsManager.getInstance();
                    SettingsManager.saveSettings("ClickableSigns");
                    player.sendMessage(MSG.chatColors("&aRemoved clickable sign '" + foundSignName + "'"));
                }
            } else {
                player.sendMessage(MSG.chatColors("&cYou must be looking at a sign to remove it!"));
            }
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        sender.sendMessage("This command can only be used by players.");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        Collections.sort(completions);
        return completions;
    }
}

