/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.VoteEvent;

public class startlava
extends AdminSubCommand {
    @Override
    public String getName() {
        return "startlava";
    }

    @Override
    public String getDescription() {
        return "Start a lava event! Optional: specify time in seconds between raises";
    }

    @Override
    public String getSyntax() {
        return "/mpa startlava [timeInSeconds]";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("mpa.startlava")) {
            int timePerRaise = 0;
            if (args.length > 0) {
                try {
                    timePerRaise = Integer.parseInt(args[1]);
                    if (timePerRaise <= 0) {
                        MessageSender.SendMessage(player, "Commands.Invalid-Number", "", "");
                        return;
                    }
                }
                catch (NumberFormatException var5) {
                    MessageSender.SendMessage(player, "Commands.Invalid-Number", "", "");
                    return;
                }
            }
            VoteEvent.startLava(player, timePerRaise);
            if (timePerRaise > 0) {
                player.sendMessage("\u00a7aLava rising started with " + timePerRaise + " seconds between each level!");
            } else {
                player.sendMessage("\u00a7aLava rising started with default timing!");
            }
        } else {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        sender.sendMessage("\u00a7cThis command can only be executed by players");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        Collections.sort(completions);
        return completions;
    }
}

