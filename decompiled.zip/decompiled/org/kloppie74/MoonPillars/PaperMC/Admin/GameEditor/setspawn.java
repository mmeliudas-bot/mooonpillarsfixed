/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class setspawn
extends AdminSubCommand {
    @Override
    public String getName() {
        return "setspawn";
    }

    @Override
    public String getDescription() {
        return "Set the Plugin's spawn point!";
    }

    @Override
    public String getSyntax() {
        return "/mpa setspawn";
    }

    public static double roundToHalf(double value) {
        return (double)Math.round(value * 2.0) / 2.0;
    }

    public static float roundToNearestMultipleOf45(float value) {
        return Math.round(value / 45.0f) * 45;
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("mpa.setspawn")) {
            float Yaw;
            String World2 = player.getWorld().getName();
            double X = setspawn.roundToHalf(player.getLocation().getX());
            double Y = setspawn.roundToHalf(player.getLocation().getY());
            double Z = setspawn.roundToHalf(player.getLocation().getZ());
            float Pitch = player.getLocation().getPitch();
            for (Yaw = setspawn.roundToNearestMultipleOf45(player.getLocation().getYaw()); Yaw < 0.0f; Yaw += 360.0f) {
            }
            Yaw %= 360.0f;
            FileConfiguration config = SettingsManager.getInstance().getSettings();
            config.set("LobbySettings.World", (Object)World2);
            config.set("LobbySettings.Spawn.X", (Object)X);
            config.set("LobbySettings.Spawn.Y", (Object)Y);
            config.set("LobbySettings.Spawn.Z", (Object)Z);
            config.set("LobbySettings.Spawn.Pitch", (Object)Math.round(Pitch));
            config.set("LobbySettings.Spawn.Rotate", (Object)Math.round(Yaw));
            SettingsManager.getInstance();
            SettingsManager.saveSettings("Settings");
            player.sendMessage(MSG.chatColors("&aUpdated the spawn location to &e" + X + ", " + Y + ", " + Z + " &awith pitch: &e" + Math.round(Pitch) + "\u00b0 &aand rotation: &e" + Math.round(Yaw) + "\u00b0"));
        } else {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        sender.sendMessage(MSG.chatColors("&cThis command can only be used by players."));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        return completions;
    }
}

