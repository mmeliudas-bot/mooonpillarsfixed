/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.Admin.Cooldowns;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.EditItems;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.EditorMenu;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.WorldListeners;
import org.kloppie74.MoonPillars.PaperMC.GameAPI.GameHandler.HashMapHandler;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class setup
extends AdminSubCommand {
    @Override
    public String getName() {
        return "setup";
    }

    @Override
    public String getDescription() {
        return "Setup a new area!";
    }

    @Override
    public String getSyntax() {
        return "/mpa setup {name}";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("mpa.setup")) {
            if (!Cooldowns.isOnCooldown(player)) {
                if (args.length == 2) {
                    World world;
                    String areaName = args[1].toLowerCase();
                    String gameID = HashMapHandler.getPlayerGameID(player.getUniqueId());
                    if (gameID != null) {
                        MessageSender.SendMessage(player, "Games.Player-Is-In-Game", "", "");
                        return;
                    }
                    if (WorldListeners.configEditer.containsKey(player.getUniqueId())) {
                        return;
                    }
                    File gameFile = this.findOrCreateGameFile(areaName, player);
                    if (gameFile == null) {
                        return;
                    }
                    FileConfiguration config = WorldListeners.GetConfig(areaName);
                    if (config == null) {
                        MessageSender.SendMessage(player, "Commands.Setup-Area.Config-Creation-Failed", "Failed to create or load configuration for " + areaName, "");
                        return;
                    }
                    if (gameFile.exists()) {
                        world = WorldListeners.EditWorld(areaName, player);
                    } else {
                        world = WorldListeners.CreateWorld(areaName);
                        setup.SetNullConfig(config);
                        WorldListeners.configEditer.put(player.getUniqueId(), config);
                        EditorMenu.SaveConfig(player);
                        MessageSender.SendMessage(player, "Commands.Setup-Area.Area-Created", "", "");
                    }
                    WorldListeners.configEditer.put(player.getUniqueId(), config);
                    Location location = new Location(world, 0.5, 5.0, 0.5);
                    player.teleport(location);
                    player.getInventory().clear();
                    EditItems.GiveEditMenuItem(player);
                    EditItems.GivePositionItem(player, 1, 1);
                    EditItems.GiveSpawnItem(player);
                    player.setGameMode(GameMode.CREATIVE);
                    player.setFlying(true);
                } else {
                    MessageSender.SendMessage(player, "Commands.Setup-Area.Unknown-Usage", "", "");
                }
                Cooldowns.startCooldown(player);
            }
        } else {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        }
    }

    private File findOrCreateGameFile(String areaName, Player player) {
        String prefix;
        File potentialSubDir;
        File gamesFolder = new File(MoonLab.getInstance().getDataFolder(), "Games");
        String subDir = "";
        if (areaName.contains("/")) {
            boolean created;
            String[] parts = areaName.split("/", 2);
            subDir = parts[0];
            String fileName = parts[1];
            File potentialSubDir2 = new File(gamesFolder, subDir);
            if (!potentialSubDir2.exists() && !(created = potentialSubDir2.mkdirs())) {
                MessageSender.SendMessage(player, "Commands.Setup-Area.Directory-Creation-Failed", "", "");
                return null;
            }
            return new File(potentialSubDir2, fileName + ".zip");
        }
        if (areaName.contains("-") && (potentialSubDir = new File(gamesFolder, prefix = areaName.split("-")[0])).exists() && potentialSubDir.isDirectory()) {
            return new File(potentialSubDir, areaName + ".zip");
        }
        return new File(gamesFolder, areaName + ".zip");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        File gamesFolder;
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            completions.add("setup");
        } else if (args.length == 2 && (gamesFolder = new File(MoonLab.getInstance().getDataFolder(), "Games")).exists() && gamesFolder.isDirectory()) {
            setup.addGameFilesRecursively(gamesFolder, "", completions, args[1].toLowerCase());
            File[] subdirs = gamesFolder.listFiles(File::isDirectory);
            if (subdirs != null) {
                File[] var8 = subdirs;
                int var9 = subdirs.length;
                for (int var10 = 0; var10 < var9; ++var10) {
                    File dir = var8[var10];
                    String dirName = dir.getName() + "/";
                    if (!dirName.toLowerCase().startsWith(args[1].toLowerCase())) continue;
                    completions.add(dirName);
                }
            }
        }
        Collections.sort(completions);
        return completions;
    }

    public static void addGameFilesRecursively(File directory, String prefix, List<String> completions, String filter) {
        File[] files = directory.listFiles();
        if (files != null) {
            File[] var5 = files;
            int var6 = files.length;
            for (int var7 = 0; var7 < var6; ++var7) {
                String gameName;
                File file = var5[var7];
                if (file.isDirectory()) {
                    setup.addGameFilesRecursively(file, prefix + file.getName() + "/", completions, filter);
                    continue;
                }
                if (!file.getName().endsWith(".zip") || !(gameName = prefix + file.getName().replace(".zip", "")).toLowerCase().startsWith(filter)) continue;
                completions.add(gameName);
            }
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
    }

    public static void SetNullConfig(FileConfiguration config) {
        config.set("Events.Border.Enabled", null);
        config.set("Events.Border.Close-Border-Timer", null);
        config.set("Events.Voting.Floor-Is-Lava.Enabled", null);
        config.set("Events.Voting.Floor-Is-Lava.Lava-Timer", null);
        config.set("Events.Voting.Elytra-Mode.Enabled", null);
        config.set("Events.Voting.No-Fall-Mode.Enabled", null);
        config.set("Events.Voting.1-Heart-Mode.Enabled", null);
        config.set("Events.WinEvents.Commands", null);
        config.set("Events.StartEvents.Commands", null);
        config.set("Events.DeathEvents.DeathMSG", null);
        config.set("Settings.DisplayName", null);
        config.set("Settings.Can-Break-Map-Blocks", null);
        config.set("Settings.LobbyTimer", null);
        config.set("Settings.CageTimer", null);
        config.set("Settings.GameTimer", null);
        config.set("Settings.ItemTimer", null);
        config.set("Settings.DeathHeight", null);
        config.set("Settings.BuildHeight", null);
        config.set("Settings.BuildRange", null);
        config.set("Settings.SpawnPoint.X", null);
        config.set("Settings.SpawnPoint.Y", null);
        config.set("Settings.SpawnPoint.Z", null);
        config.set("Settings.Spawn-Area.Loc1.X", null);
        config.set("Settings.Spawn-Area.Loc1.Y", null);
        config.set("Settings.Spawn-Area.Loc1.Z", null);
        config.set("Settings.Spawn-Area.Loc2.X", null);
        config.set("Settings.Spawn-Area.Loc2.Y", null);
        config.set("Settings.Spawn-Area.Loc2.Z", null);
        config.set("Settings.BlacklistedItems", null);
        config.set("SpawnLocations.MaxTeams", null);
        config.set("SpawnLocations.PlayersPerTeam", null);
        config.set("SpawnLocations.MaximumPlayers", null);
        config.set("SpawnLocations.MinimumPlayers", null);
        config.set("SpawnLocations.Team1.Color", null);
        config.set("SpawnLocations.Team1.Name", null);
        config.set("SpawnLocations.Team1.Player1.X", null);
        config.set("SpawnLocations.Team1.Player1.Y", null);
        config.set("SpawnLocations.Team1.Player1.Z", null);
    }
}

