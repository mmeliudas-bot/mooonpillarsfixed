/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.Admin.Cooldowns;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.ImportCages;

public class importcage
extends AdminSubCommand {
    @Override
    public String getName() {
        return "importcage";
    }

    @Override
    public String getDescription() {
        return "Import a cage from a other worldedit plugin!";
    }

    @Override
    public String getSyntax() {
        return "/mpa importcage {name}";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (player.hasPermission("mpa.importcage")) {
            if (!Cooldowns.isOnCooldown(player)) {
                if (args.length == 2) {
                    String CageName = args[1];
                    ImportCages.ImportSchem(CageName, player);
                } else {
                    MessageSender.SendMessage(player, "Commands.Import-Cage.Unknown-usage", "", "");
                }
                Cooldowns.startCooldown(player);
            } else {
                MessageSender.SendMessage(player, "Commands.Cooldown", "", "");
            }
        } else {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        Player player = (Player)sender;
        if (args.length == 2) {
            String CageName = args[1];
            ImportCages.ImportSchem(CageName, player);
        } else {
            String CageName = "Please use " + this.getSyntax();
            sender.sendMessage(MSG.chatColors("&c" + CageName));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 1) {
            completions.add("importcage");
        }
        Collections.sort(completions);
        return completions;
    }
}

