/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.EditorMenu;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.WorldListeners;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class RewardCommandEditorGUI
implements Listener {
    private static final Map<UUID, RewardAdditionData> pendingAdditions = new HashMap<UUID, RewardAdditionData>();
    private static final Map<UUID, EditorSession> playerSessions = new HashMap<UUID, EditorSession>();

    public static void addPendingReward(Player player, String rewardType, String subCategory, String subSubCategory) {
        pendingAdditions.put(player.getUniqueId(), new RewardAdditionData(rewardType, subCategory, subSubCategory));
    }

    public static void open(Player player, String rewardType) {
        RewardCommandEditorGUI.ensureAllRewardSections(player);
        if (rewardType == null || rewardType.isEmpty()) {
            rewardType = "OnStartGameRewards";
        }
        EditorSession session = new EditorSession(rewardType);
        FileConfiguration config = WorldListeners.configEditer.get(player.getUniqueId());
        session.loadSubCategories(config);
        session.loadSubSubCategories(config);
        playerSessions.put(player.getUniqueId(), session);
        RewardCommandEditorGUI.openRewardEditor(player);
    }

    private static void openRewardEditor(Player player) {
        EditorSession session = playerSessions.get(player.getUniqueId());
        if (session == null) {
            player.sendMessage(MSG.chatColors("&cError: Session not found."));
        } else {
            FileConfiguration config = WorldListeners.configEditer.get(player.getUniqueId());
            String displayTitle = RewardCommandEditorGUI.generateTitle(session);
            Inventory inv = Bukkit.createInventory((InventoryHolder)player, (int)54, (String)MSG.chatColors("&bRewards: " + displayTitle));
            String rewardsPath = RewardCommandEditorGUI.getRewardsPath(session);
            List rewards = config.getStringList(rewardsPath);
            RewardCommandEditorGUI.displayRewards(inv, rewards);
            RewardCommandEditorGUI.fillSeparator(inv);
            RewardCommandEditorGUI.createControlPanel(player, inv, session, config);
            player.openInventory(inv);
            MoonLab.PlayerMenu.put(player.getUniqueId(), "RewardEditor");
        }
    }

    private static String generateTitle(EditorSession session) {
        StringBuilder title = new StringBuilder(session.rewardType);
        if (session.getCurrentSubCategory() != null) {
            title.append(" - ").append(session.getCurrentSubCategory());
            if (session.getCurrentSubSubCategory() != null) {
                title.append(" - ").append(session.getCurrentSubSubCategory());
            }
        }
        return title.toString();
    }

    private static String getRewardsPath(EditorSession session) {
        StringBuilder path = new StringBuilder("Rewards.").append(session.rewardType);
        if (session.rewardType.equals("OnStartGameRewards")) {
            path.append(".Rewards");
        } else if (session.getCurrentSubCategory() != null) {
            path.append(".Rewards.").append(session.getCurrentSubCategory());
            if (session.getCurrentSubSubCategory() != null) {
                path.append(".Rewards.").append(session.getCurrentSubSubCategory());
            }
            path.append(".Rewards");
        }
        return path.toString();
    }

    private static void displayRewards(Inventory inv, List<String> rewards) {
        for (int i = 0; i < Math.min(rewards.size(), 36); ++i) {
            String reward = rewards.get(i);
            ItemStack paper = new ItemStack(Material.PAPER);
            ItemMeta meta = paper.getItemMeta();
            meta.setDisplayName(MSG.chatColors("&eReward Line " + (i + 1)));
            ArrayList<String> lore = new ArrayList<String>();
            lore.add(MSG.chatColors("&7" + reward));
            lore.add(MSG.chatColors("&cClick to delete this reward."));
            meta.setLore(lore);
            paper.setItemMeta(meta);
            inv.setItem(i, paper);
        }
    }

    private static void fillSeparator(Inventory inv) {
        ItemStack separator = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = separator.getItemMeta();
        meta.setDisplayName(" ");
        separator.setItemMeta(meta);
        for (int i = 36; i < 45; ++i) {
            inv.setItem(i, separator);
        }
    }

    private static void createControlPanel(Player player, Inventory inv, EditorSession session, FileConfiguration config) {
        ItemStack categoryItem = new ItemStack(Material.COMPASS);
        ItemMeta categoryMeta = categoryItem.getItemMeta();
        categoryMeta.setDisplayName(MSG.chatColors("&eSwitch Category"));
        ArrayList<String> categoryLore = new ArrayList<String>();
        categoryLore.add(MSG.chatColors("&7Current: &b" + session.rewardType));
        categoryLore.add(MSG.chatColors("&7Click to cycle through categories"));
        categoryLore.add(MSG.chatColors("&7Available categories:"));
        categoryLore.add(MSG.chatColors("&7- OnStartGameRewards"));
        categoryLore.add(MSG.chatColors("&7- OnKillRewards"));
        categoryLore.add(MSG.chatColors("&7- OnLeaveRewards"));
        categoryLore.add(MSG.chatColors("&7- OnEndGameRewards"));
        categoryMeta.setLore(categoryLore);
        categoryItem.setItemMeta(categoryMeta);
        inv.setItem(45, categoryItem);
        ItemStack subCatItem = new ItemStack(Material.MAP);
        ItemMeta subCatMeta = subCatItem.getItemMeta();
        subCatMeta.setDisplayName(MSG.chatColors("&eSwitch Sub-category"));
        ArrayList<String> subCatLore = new ArrayList<String>();
        String var10001 = session.getCurrentSubCategory() != null ? "&b" + session.getCurrentSubCategory() : "&cNone";
        subCatLore.add(MSG.chatColors("&7Current: " + var10001));
        subCatLore.add(MSG.chatColors("&7Click to cycle through sub-categories"));
        if (!session.subCategories.isEmpty()) {
            subCatLore.add(MSG.chatColors("&7Available sub-categories:"));
            for (String subCat : session.subCategories) {
                subCatLore.add(MSG.chatColors("&7- " + subCat));
            }
        }
        subCatMeta.setLore(subCatLore);
        subCatItem.setItemMeta(subCatMeta);
        inv.setItem(46, subCatItem);
        ItemStack subSubCatItem = new ItemStack(Material.PAPER);
        ItemMeta subSubCatMeta = subSubCatItem.getItemMeta();
        subSubCatMeta.setDisplayName(MSG.chatColors("&eSwitch Sub-sub-category"));
        ArrayList<String> subSubCatLore = new ArrayList<String>();
        var10001 = session.getCurrentSubSubCategory() != null ? "&b" + session.getCurrentSubSubCategory() : "&cNone";
        subSubCatLore.add(MSG.chatColors("&7Current: " + var10001));
        subSubCatLore.add(MSG.chatColors("&7Click to cycle through sub-sub-categories"));
        if (!session.subSubCategories.isEmpty()) {
            subSubCatLore.add(MSG.chatColors("&7Available sub-sub-categories:"));
            for (String subSubCat : session.subSubCategories) {
                subSubCatLore.add(MSG.chatColors("&7- " + subSubCat));
            }
        }
        subSubCatMeta.setLore(subSubCatLore);
        subSubCatItem.setItemMeta(subSubCatMeta);
        inv.setItem(47, subSubCatItem);
        boolean enabled = RewardCommandEditorGUI.isCurrentSectionEnabled(session, config);
        ItemStack toggleItem = new ItemStack(enabled ? Material.GREEN_DYE : Material.RED_DYE);
        ItemMeta toggleMeta = toggleItem.getItemMeta();
        toggleMeta.setDisplayName(MSG.chatColors(enabled ? "&aEnabled" : "&cDisabled"));
        ArrayList<String> toggleLore = new ArrayList<String>();
        toggleLore.add(MSG.chatColors("&7Click to " + (enabled ? "disable" : "enable") + " these rewards"));
        toggleMeta.setLore(toggleLore);
        toggleItem.setItemMeta(toggleMeta);
        inv.setItem(49, toggleItem);
        ItemStack addItem = new ItemStack(Material.EMERALD);
        ItemMeta addMeta = addItem.getItemMeta();
        addMeta.setDisplayName(MSG.chatColors("&aAdd Reward"));
        ArrayList<String> addLore = new ArrayList<String>();
        addLore.add(MSG.chatColors("&7Click to add a new reward via chat"));
        addMeta.setLore(addLore);
        addItem.setItemMeta(addMeta);
        inv.setItem(50, addItem);
        ItemStack resetItem = new ItemStack(Material.REDSTONE);
        ItemMeta resetMeta = resetItem.getItemMeta();
        resetMeta.setDisplayName(MSG.chatColors("&cReset to Default"));
        ArrayList<String> resetLore = new ArrayList<String>();
        resetLore.add(MSG.chatColors("&7Click to reset rewards to default values"));
        resetMeta.setLore(resetLore);
        resetItem.setItemMeta(resetMeta);
        inv.setItem(51, resetItem);
        ItemStack infoBook = new ItemStack(Material.KNOWLEDGE_BOOK);
        ItemMeta infoMeta = infoBook.getItemMeta();
        infoMeta.setDisplayName(MSG.chatColors("&bCustom Placeholders"));
        ArrayList<String> infoLore = new ArrayList<String>();
        infoLore.add(MSG.chatColors("&7${death} - Returns the killed player"));
        infoLore.add(MSG.chatColors("&7${killer} - Returns the killer"));
        infoLore.add(MSG.chatColors("&7${player} - Returns the player name"));
        infoLore.add(MSG.chatColors("&7${leftplayer} - Returns player that left"));
        infoLore.add(MSG.chatColors("&7${winnerteamname} - Returns winner team name"));
        infoMeta.setLore(infoLore);
        infoBook.setItemMeta(infoMeta);
        inv.setItem(53, infoBook);
    }

    private static boolean isCurrentSectionEnabled(EditorSession session, FileConfiguration config) {
        String enabledPath = "Rewards." + session.rewardType + ".Enabled";
        if (session.getCurrentSubCategory() != null) {
            String var10000 = session.rewardType;
            enabledPath = "Rewards." + var10000 + ".Rewards." + session.getCurrentSubCategory() + ".Enabled";
            if (session.getCurrentSubSubCategory() != null) {
                var10000 = session.rewardType;
                enabledPath = "Rewards." + var10000 + ".Rewards." + session.getCurrentSubCategory() + ".Rewards." + session.getCurrentSubSubCategory() + ".Enabled";
            }
        }
        return config.getBoolean(enabledPath, true);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Player player;
        String currentGUI;
        if (event.getWhoClicked() instanceof Player && (currentGUI = MoonLab.PlayerMenu.get((player = (Player)event.getWhoClicked()).getUniqueId())) != null && currentGUI.equals("RewardEditor")) {
            FileConfiguration config;
            EditorSession session;
            event.setCancelled(true);
            if (event.getCurrentItem() != null && event.getCurrentItem().hasItemMeta() && (session = playerSessions.get(player.getUniqueId())) != null && (config = WorldListeners.configEditer.get(player.getUniqueId())) != null) {
                int slot = event.getSlot();
                if (slot == 45) {
                    session.nextCategory();
                    session.loadSubCategories(config);
                    session.loadSubSubCategories(config);
                    RewardCommandEditorGUI.openRewardEditor(player);
                } else if (slot == 46) {
                    session.nextSubCategory();
                    session.loadSubSubCategories(config);
                    RewardCommandEditorGUI.openRewardEditor(player);
                } else if (slot == 47) {
                    session.nextSubSubCategory();
                    RewardCommandEditorGUI.openRewardEditor(player);
                } else if (slot == 49) {
                    RewardCommandEditorGUI.toggleCurrentSection(player, session, config);
                } else if (slot == 50) {
                    player.closeInventory();
                    player.sendMessage(MSG.chatColors("&aType the new reward in chat:"));
                    RewardCommandEditorGUI.addPendingReward(player, session.rewardType, session.getCurrentSubCategory(), session.getCurrentSubSubCategory());
                } else if (slot == 51) {
                    RewardCommandEditorGUI.resetToDefaults(player, session, config);
                } else if (slot >= 0 && slot < 36) {
                    RewardCommandEditorGUI.deleteReward(player, slot, session, config);
                }
            }
        }
    }

    private static void toggleCurrentSection(Player player, EditorSession session, FileConfiguration config) {
        boolean currentValue;
        String enabledPath = "Rewards." + session.rewardType + ".Enabled";
        if (session.getCurrentSubCategory() != null) {
            String var10000 = session.rewardType;
            enabledPath = "Rewards." + var10000 + ".Rewards." + session.getCurrentSubCategory() + ".Enabled";
            if (session.getCurrentSubSubCategory() != null) {
                var10000 = session.rewardType;
                enabledPath = "Rewards." + var10000 + ".Rewards." + session.getCurrentSubCategory() + ".Rewards." + session.getCurrentSubSubCategory() + ".Enabled";
            }
        }
        config.set(enabledPath, (Object)(!(currentValue = config.getBoolean(enabledPath, true)) ? 1 : 0));
        String var10001 = session.rewardType;
        player.sendMessage(MSG.chatColors("&aToggled " + var10001 + (String)(session.getCurrentSubCategory() != null ? " - " + session.getCurrentSubCategory() : "") + (String)(session.getCurrentSubSubCategory() != null ? " - " + session.getCurrentSubSubCategory() : "") + " to " + !currentValue));
        RewardCommandEditorGUI.openRewardEditor(player);
        EditorMenu.SaveConfig(player);
    }

    private static void resetToDefaults(Player player, EditorSession session, FileConfiguration config) {
        String rewardsPath = RewardCommandEditorGUI.getRewardsPath(session);
        ArrayList<String> defaultRewards = new ArrayList<String>();
        if (session.rewardType.equals("OnStartGameRewards")) {
            defaultRewards.addAll(Arrays.asList("[COMMAND:CONSOLE] eco give ${player} 500", "[MESSAGE:PLAYER] Welcome ${player}, the game is starting now!", "[MESSAGE:PLAYER] Prepare yourself and good luck!"));
        } else if (session.rewardType.equals("OnKillRewards")) {
            if (session.getCurrentSubCategory() != null && session.getCurrentSubSubCategory() != null) {
                if (session.getCurrentSubCategory().equals("Killed-By-Player")) {
                    if (session.getCurrentSubSubCategory().equals("Killed-Player")) {
                        defaultRewards.addAll(Arrays.asList("[COMMAND:CONSOLE] eco give ${player} 500", "[MESSAGE:PLAYER] ${death}, you have been eliminated by ${killer}. Better luck next time!", "[MESSAGE:PLAYER] Learn from your defeat against ${killer} and come back stronger!"));
                    } else if (session.getCurrentSubSubCategory().equals("Killer")) {
                        defaultRewards.addAll(Arrays.asList("[COMMAND:CONSOLE] eco give ${player} 500", "[MESSAGE:PLAYER] Excellent work, ${killer}! You have defeated ${death}!", "[MESSAGE:PLAYER] Your skills are turning the tide of battle, ${killer}!"));
                    } else if (session.getCurrentSubSubCategory().equals("Remaining-Players")) {
                        defaultRewards.addAll(Arrays.asList("[COMMAND:CONSOLE] eco give ${player} 500", "[MESSAGE:PLAYER] A competitor has fallen! ${killer} eliminated ${death}.", "[MESSAGE:PLAYER] Stay on guard, ${player}! ${killer} is on a rampage!"));
                    }
                } else if (session.getCurrentSubCategory().equals("Not-Killed-By-Player")) {
                    if (session.getCurrentSubSubCategory().equals("Killed-Player")) {
                        defaultRewards.addAll(Arrays.asList("[COMMAND:CONSOLE] eco give ${player} 500", "[MESSAGE:PLAYER] ${death}, you have been eliminated. Better luck next time!"));
                    } else if (session.getCurrentSubSubCategory().equals("Remaining-Players")) {
                        defaultRewards.addAll(Arrays.asList("[COMMAND:CONSOLE] eco give ${player} 500", "[MESSAGE:PLAYER] A player has fallen! ${death} has been eliminated.", "[MESSAGE:PLAYER] The challenge continues, ${player}!"));
                    }
                }
            }
        } else if (session.rewardType.equals("OnLeaveRewards")) {
            if (session.getCurrentSubCategory() != null) {
                if (session.getCurrentSubCategory().equals("left-Player")) {
                    defaultRewards.addAll(Arrays.asList("[COMMAND:CONSOLE] eco give ${player} 500", "[MESSAGE:PLAYER] Farewell ${player}, you have left the battle."));
                } else if (session.getCurrentSubCategory().equals("Remaining-Players")) {
                    defaultRewards.addAll(Arrays.asList("[COMMAND:CONSOLE] eco give ${player} 500", "[MESSAGE:PLAYER] A player has departed, ${player}.", "[MESSAGE:PLAYER] The challenge continues\u2014stay focused!"));
                }
            }
        } else if (session.rewardType.equals("OnEndGameRewards") && session.getCurrentSubCategory() != null) {
            if (session.getCurrentSubCategory().equals("Spectators")) {
                defaultRewards.addAll(Arrays.asList("[COMMAND:CONSOLE] eco give ${player} 500", "[MESSAGE:PLAYER] The match is over, ${player}.", "[MESSAGE:PLAYER] Sit back and enjoy the post-game review."));
            } else if (session.getCurrentSubCategory().equals("Winners")) {
                defaultRewards.addAll(Arrays.asList("[COMMAND:CONSOLE] eco give ${player} 500", "[MESSAGE:PLAYER] Congratulations ${player}, you are victorious!", "[MESSAGE:PLAYER] Your skill and determination have paid off!", "[MESSAGE:PLAYER] ${winnerteamname} won the game!"));
            }
        }
        config.set(rewardsPath, defaultRewards);
        player.sendMessage(MSG.chatColors("&aReset rewards to default values."));
        RewardCommandEditorGUI.openRewardEditor(player);
        EditorMenu.SaveConfig(player);
    }

    private static void deleteReward(Player player, int slot, EditorSession session, FileConfiguration config) {
        String rewardsPath = RewardCommandEditorGUI.getRewardsPath(session);
        List rewards = config.getStringList(rewardsPath);
        if (slot < rewards.size()) {
            String removedReward = (String)rewards.remove(slot);
            config.set(rewardsPath, (Object)rewards);
            player.sendMessage(MSG.chatColors("&cReward deleted: " + removedReward));
            RewardCommandEditorGUI.openRewardEditor(player);
            EditorMenu.SaveConfig(player);
        }
    }

    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (pendingAdditions.containsKey(player.getUniqueId())) {
            event.setCancelled(true);
            RewardAdditionData data = pendingAdditions.remove(player.getUniqueId());
            String newReward = event.getMessage();
            Bukkit.getScheduler().runTask((Plugin)MoonLab.getInstance(), () -> {
                FileConfiguration config = WorldListeners.configEditer.get(player.getUniqueId());
                String path = data.subSubCategory != null ? "Rewards." + data.rewardType + ".Rewards." + data.subCategory + ".Rewards." + data.subSubCategory + ".Rewards" : (data.subCategory != null ? "Rewards." + data.rewardType + ".Rewards." + data.subCategory + ".Rewards" : "Rewards." + data.rewardType + ".Rewards");
                List rewards = config.getStringList(path);
                rewards.add(newReward);
                config.set(path, (Object)rewards);
                player.sendMessage(MSG.chatColors("&aNew reward added: " + newReward));
                RewardCommandEditorGUI.openRewardEditor(player);
                EditorMenu.SaveConfig(player);
            });
        }
    }

    public static void ensureAllRewardSections(Player player) {
        FileConfiguration config = WorldListeners.configEditer.get(player.getUniqueId());
        if (!config.contains("Rewards")) {
            config.createSection("Rewards");
        }
        if (!config.contains("Rewards.OnStartGameRewards")) {
            config.set("Rewards.OnStartGameRewards.Enabled", (Object)true);
            config.set("Rewards.OnStartGameRewards.Rewards", Arrays.asList("[COMMAND:CONSOLE] eco give ${player} 500", "[MESSAGE:PLAYER] Welcome ${player}, the game is starting now!", "[MESSAGE:PLAYER] Prepare yourself and good luck!"));
        }
        if (!config.contains("Rewards.OnKillRewards")) {
            config.set("Rewards.OnKillRewards.Enabled", (Object)true);
            config.createSection("Rewards.OnKillRewards.Rewards");
        }
        if (!config.contains("Rewards.OnKillRewards.Rewards.Killed-By-Player")) {
            config.createSection("Rewards.OnKillRewards.Rewards.Killed-By-Player");
            config.set("Rewards.OnKillRewards.Rewards.Killed-By-Player.Enabled", (Object)true);
            config.createSection("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards");
        }
        if (!config.contains("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killed-Player")) {
            config.createSection("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killed-Player");
            config.set("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killed-Player.Enabled", (Object)true);
            config.set("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killed-Player.Rewards", Arrays.asList("[COMMAND:CONSOLE] eco give ${death} 100", "[MESSAGE:PLAYER] ${death}, you have been eliminated by ${killer}. Better luck next time!", "[MESSAGE:PLAYER] Learn from your defeat against ${killer} and come back stronger!"));
        }
        if (!config.contains("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killer")) {
            config.createSection("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killer");
            config.set("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killer.Enabled", (Object)true);
            config.set("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Killer.Rewards", Arrays.asList("[COMMAND:CONSOLE] eco give ${killer} 500", "[MESSAGE:PLAYER] ${killer}, you've eliminated ${death}. Well done!", "[MESSAGE:PLAYER] Your combat skills are impressive, ${killer}!"));
        }
        if (!config.contains("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Remaining-Players")) {
            config.createSection("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Remaining-Players");
            config.set("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Remaining-Players.Enabled", (Object)true);
            config.set("Rewards.OnKillRewards.Rewards.Killed-By-Player.Rewards.Remaining-Players.Rewards", Arrays.asList("[MESSAGE:PLAYER] ${player}, a competitor has fallen! ${death} was eliminated by ${killer}.", "[MESSAGE:PLAYER] The battle continues, ${player}. Stay alert!"));
        }
        if (!config.contains("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player")) {
            config.createSection("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player");
            config.set("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Enabled", (Object)true);
            config.createSection("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Rewards");
        }
        if (!config.contains("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Rewards.Killed-Player")) {
            config.createSection("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Rewards.Killed-Player");
            config.set("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Rewards.Killed-Player.Enabled", (Object)true);
            config.set("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Rewards.Killed-Player.Rewards", Arrays.asList("[COMMAND:CONSOLE] eco give ${death} 100", "[MESSAGE:PLAYER] ${death}, you have been eliminated. Better luck next time!", "[MESSAGE:PLAYER] The environment has claimed ${death}."));
        }
        if (!config.contains("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Rewards.Remaining-Players")) {
            config.createSection("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Rewards.Remaining-Players");
            config.set("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Rewards.Remaining-Players.Enabled", (Object)true);
            config.set("Rewards.OnKillRewards.Rewards.Not-Killed-By-Player.Rewards.Remaining-Players.Rewards", Arrays.asList("[MESSAGE:PLAYER] ${player}, a competitor has fallen! ${death} has been eliminated.", "[MESSAGE:PLAYER] The battle continues, ${player}. Stay alert!"));
        }
        if (!config.contains("Rewards.OnLeaveRewards")) {
            config.set("Rewards.OnLeaveRewards.Enabled", (Object)true);
            config.createSection("Rewards.OnLeaveRewards.Rewards");
        }
        if (!config.contains("Rewards.OnLeaveRewards.Rewards.left-Player")) {
            config.createSection("Rewards.OnLeaveRewards.Rewards.left-Player");
            config.set("Rewards.OnLeaveRewards.Rewards.left-Player.Enabled", (Object)true);
            config.set("Rewards.OnLeaveRewards.Rewards.left-Player.Rewards", Arrays.asList("[COMMAND:CONSOLE] eco give ${leftplayer} 100", "[MESSAGE:PLAYER] Farewell ${leftplayer}, you have left the battle."));
        }
        if (!config.contains("Rewards.OnLeaveRewards.Rewards.Remaining-Players")) {
            config.createSection("Rewards.OnLeaveRewards.Rewards.Remaining-Players");
            config.set("Rewards.OnLeaveRewards.Rewards.Remaining-Players.Enabled", (Object)true);
            config.set("Rewards.OnLeaveRewards.Rewards.Remaining-Players.Rewards", Arrays.asList("[COMMAND:CONSOLE] eco give ${player} 25", "[MESSAGE:PLAYER] A player has departed, ${player}.", "[MESSAGE:PLAYER] The challenge continues\u2014stay focused!"));
        }
        if (!config.contains("Rewards.OnEndGameRewards")) {
            config.set("Rewards.OnEndGameRewards.Enabled", (Object)true);
            config.createSection("Rewards.OnEndGameRewards.Rewards");
        }
        if (!config.contains("Rewards.OnEndGameRewards.Rewards.Spectators")) {
            config.createSection("Rewards.OnEndGameRewards.Rewards.Spectators");
            config.set("Rewards.OnEndGameRewards.Rewards.Spectators.Enabled", (Object)true);
            config.set("Rewards.OnEndGameRewards.Rewards.Spectators.Rewards", Arrays.asList("[COMMAND:CONSOLE] eco give ${player} 200", "[MESSAGE:PLAYER] The match is over, ${player}.", "[MESSAGE:PLAYER] Thank you for spectating until the end!"));
        }
        if (!config.contains("Rewards.OnEndGameRewards.Rewards.Winners")) {
            config.createSection("Rewards.OnEndGameRewards.Rewards.Winners");
            config.set("Rewards.OnEndGameRewards.Rewards.Winners.Enabled", (Object)true);
            config.set("Rewards.OnEndGameRewards.Rewards.Winners.Rewards", Arrays.asList("[COMMAND:CONSOLE] eco give ${player} 1000", "[MESSAGE:PLAYER] Congratulations ${player}, you are victorious!", "[MESSAGE:PLAYER] Your skill and determination have paid off!", "[MESSAGE:PLAYER] ${winnerteamname} won the game!"));
        }
    }

    private static class RewardAdditionData {
        String rewardType;
        String subCategory;
        String subSubCategory;

        RewardAdditionData(String rewardType, String subCategory, String subSubCategory) {
            this.rewardType = rewardType;
            this.subCategory = subCategory;
            this.subSubCategory = subSubCategory;
        }
    }

    private static class EditorSession {
        String rewardType;
        List<String> categories = Arrays.asList("OnStartGameRewards", "OnKillRewards", "OnLeaveRewards", "OnEndGameRewards");
        List<String> subCategories = new ArrayList<String>();
        List<String> subSubCategories = new ArrayList<String>();
        int categoryIndex = 0;
        int subCategoryIndex = 0;
        int subSubCategoryIndex = 0;

        EditorSession(String rewardType) {
            this.rewardType = rewardType;
            this.categoryIndex = this.categories.indexOf(rewardType);
            if (this.categoryIndex < 0) {
                this.categoryIndex = 0;
            }
        }

        public String getCurrentCategory() {
            return this.categories.isEmpty() ? null : this.categories.get(this.categoryIndex);
        }

        public String getCurrentSubCategory() {
            return this.subCategories.isEmpty() ? null : this.subCategories.get(this.subCategoryIndex);
        }

        public String getCurrentSubSubCategory() {
            return this.subSubCategories.isEmpty() ? null : this.subSubCategories.get(this.subSubCategoryIndex);
        }

        public void nextCategory() {
            if (!this.categories.isEmpty()) {
                this.categoryIndex = (this.categoryIndex + 1) % this.categories.size();
                this.rewardType = this.categories.get(this.categoryIndex);
                this.subCategoryIndex = 0;
                this.subSubCategoryIndex = 0;
            }
        }

        public void nextSubCategory() {
            if (!this.subCategories.isEmpty()) {
                this.subCategoryIndex = (this.subCategoryIndex + 1) % this.subCategories.size();
                this.subSubCategoryIndex = 0;
            }
        }

        public void nextSubSubCategory() {
            if (!this.subSubCategories.isEmpty()) {
                this.subSubCategoryIndex = (this.subSubCategoryIndex + 1) % this.subSubCategories.size();
            }
        }

        public void loadSubCategories(FileConfiguration config) {
            this.subCategories.clear();
            if (!this.rewardType.equals("OnStartGameRewards")) {
                if (this.rewardType.equals("OnKillRewards")) {
                    this.subCategories.add("Killed-By-Player");
                    this.subCategories.add("Not-Killed-By-Player");
                } else if (this.rewardType.equals("OnLeaveRewards")) {
                    this.subCategories.add("left-Player");
                    this.subCategories.add("Remaining-Players");
                } else if (this.rewardType.equals("OnEndGameRewards")) {
                    this.subCategories.add("Spectators");
                    this.subCategories.add("Winners");
                }
            }
        }

        public void loadSubSubCategories(FileConfiguration config) {
            this.subSubCategories.clear();
            if (this.getCurrentSubCategory() != null && this.rewardType.equals("OnKillRewards")) {
                if (this.getCurrentSubCategory().equals("Killed-By-Player")) {
                    this.subSubCategories.add("Killed-Player");
                    this.subSubCategories.add("Killer");
                    this.subSubCategories.add("Remaining-Players");
                } else if (this.getCurrentSubCategory().equals("Not-Killed-By-Player")) {
                    this.subSubCategories.add("Killed-Player");
                    this.subSubCategories.add("Remaining-Players");
                }
            }
        }
    }
}

