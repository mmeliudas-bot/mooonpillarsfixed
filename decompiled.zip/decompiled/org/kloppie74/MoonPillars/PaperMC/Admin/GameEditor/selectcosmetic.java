/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler.CosmeticHandler;

public class selectcosmetic
extends AdminSubCommand {
    @Override
    public String getName() {
        return "selectcosmetic";
    }

    @Override
    public String getDescription() {
        return "Select a cosmetic for a player!";
    }

    @Override
    public String getSyntax() {
        return "/mpa selectcosmetic <Name> <Section> <ID>";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (!player.hasPermission("mpa.selectcosmetic")) {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        } else if (args.length != 4) {
            MessageSender.SendMessage(player, "Commands.Select-Cosmetic.Unknown-Usage", "", "");
        } else {
            String playerName = args[1];
            Player targetPlayer = Bukkit.getPlayer((String)playerName);
            if (targetPlayer == null) {
                MessageSender.SendMessage(player, "Commands.Select-Cosmetic.Player-Not-Online", "{player}", playerName);
            } else {
                String section = args[2];
                String id = args[3];
                try {
                    String columnName = this.getColumnName(section);
                    CosmeticHandler.getInstance().updateSelectedCosmetic(targetPlayer.getUniqueId(), columnName, id);
                    MessageSender.SendMessage(player, "Commands.Select-Cosmetic.Selected-Cosmetic", "{player}", targetPlayer.getName());
                }
                catch (IllegalArgumentException var8) {
                    MessageSender.SendMessage(player, "Commands.Select-Cosmetic.Unknown-Section", "", "");
                }
            }
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        String playerName;
        Player targetPlayer;
        if (args.length == 4 && (targetPlayer = Bukkit.getPlayer((String)(playerName = args[1]))) != null) {
            String section = args[2];
            String id = args[3];
            try {
                String columnName = this.getColumnName(section);
                CosmeticHandler.getInstance().updateSelectedCosmetic(targetPlayer.getUniqueId(), columnName, id);
            }
            catch (IllegalArgumentException illegalArgumentException) {
                // empty catch block
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (args.length == 3) {
            String arg = args[2].toLowerCase();
            List<String> sections = List.of("cages", "pillar", "bow", "kill", "win", "death", "killmessage");
            for (String section : sections) {
                if (!section.startsWith(arg)) continue;
                completions.add(section);
            }
        }
        return completions;
    }

    private String getColumnName(String section) {
        return switch (section.toLowerCase()) {
            case "cages" -> "Cage_Particle";
            case "pillar" -> "Pillar_Particle";
            case "bow" -> "Bow_Particle";
            case "kill" -> "Kill_Particle";
            case "win" -> "Win_Particle";
            case "death" -> "Death_Particle";
            case "killmessage" -> "Kill_Message_Particle";
            default -> throw new IllegalArgumentException("Invalid section: " + section);
        };
    }
}

