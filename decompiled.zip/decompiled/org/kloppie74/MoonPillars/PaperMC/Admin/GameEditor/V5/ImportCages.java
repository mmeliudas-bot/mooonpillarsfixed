/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class ImportCages {
    public static List<String> getSchematics() {
        Plugin worldEdit = Bukkit.getPluginManager().getPlugin("WorldEdit");
        Plugin fawe = Bukkit.getPluginManager().getPlugin("FastAsyncWorldEdit");
        Plugin awe = Bukkit.getPluginManager().getPlugin("AsyncWorldEdit");
        File schematicsFolder = null;
        if (fawe != null && fawe.isEnabled()) {
            schematicsFolder = new File(fawe.getDataFolder(), "schematics");
            System.out.println("FastAsyncWorldEdit detected. Fetching schematics...");
        } else if (worldEdit != null && worldEdit.isEnabled()) {
            schematicsFolder = new File(worldEdit.getDataFolder(), "schematics");
            System.out.println("WorldEdit detected. Fetching schematics...");
        } else {
            if (awe == null || !awe.isEnabled()) {
                System.out.println("No supported WorldEdit plugin found! Please install FastAsyncWorldEdit, WorldEdit, or AsyncWorldEdit.");
                return Collections.emptyList();
            }
            schematicsFolder = new File(awe.getDataFolder(), "schematics");
            System.out.println("AsyncWorldEdit detected. Fetching schematics...");
        }
        if (schematicsFolder != null && schematicsFolder.exists()) {
            File[] schematicFiles = schematicsFolder.listFiles((dir, name) -> name.endsWith(".schem") || name.endsWith(".schematic"));
            if (schematicFiles != null && schematicFiles.length != 0) {
                ArrayList<String> schematicNames = new ArrayList<String>();
                File[] var6 = schematicFiles;
                int var7 = schematicFiles.length;
                for (int var8 = 0; var8 < var7; ++var8) {
                    File schematic = var6[var8];
                    System.out.println("Found schematic: " + schematic.getName());
                    schematicNames.add(schematic.getName());
                }
                return schematicNames;
            }
            System.out.println("No schematics found in: " + schematicsFolder.getPath());
            return Collections.emptyList();
        }
        String var10001 = schematicsFolder != null ? schematicsFolder.getPath() : "null";
        System.out.println("Schematics folder not found: " + var10001);
        return Collections.emptyList();
    }

    public static void ImportSchem(String SchemName, Player player) {
        Plugin worldEdit = Bukkit.getPluginManager().getPlugin("WorldEdit");
        Plugin fawe = Bukkit.getPluginManager().getPlugin("FastAsyncWorldEdit");
        Plugin awe = Bukkit.getPluginManager().getPlugin("AsyncWorldEdit");
        if (fawe != null && fawe.isEnabled()) {
            ImportCages.importWithFAWE(SchemName, player);
        } else if (worldEdit != null && worldEdit.isEnabled()) {
            ImportCages.importWithWorldEdit(SchemName, player);
        } else if (awe != null && awe.isEnabled()) {
            ImportCages.importWithAWE(SchemName, player);
        } else {
            System.out.println("No supported plugin found!");
        }
    }

    private static void importWithFAWE(String SchemName, Player player) {
        ImportCages.copySchematic("FastAsyncWorldEdit", SchemName, player);
    }

    private static void importWithAWE(String SchemName, Player player) {
        ImportCages.copySchematic("AsyncWorldEdit", SchemName, player);
    }

    private static void importWithWorldEdit(String SchemName, Player player) {
        ImportCages.copySchematic("WorldEdit", SchemName, player);
    }

    public static void copySchematic(String pluginName, String SchemName, Player player) {
        File sourceFile = new File(Bukkit.getServer().getPluginManager().getPlugin(pluginName).getDataFolder(), "schematics/" + SchemName);
        File destDir = new File(MoonLab.getInstance().getDataFolder(), "Cages");
        File destFile = new File(destDir, SchemName);
        if (!sourceFile.exists()) {
            System.out.println("Schematic not found: " + sourceFile.getPath());
        } else {
            if (!destDir.exists()) {
                destDir.mkdirs();
            }
            try {
                Files.copy(sourceFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                System.out.println("Schematic copied to: " + destFile.getPath());
                MessageSender.SendMessage(player, "Commands.Import-Cage.Imported-Successful", "{name}", SchemName);
            }
            catch (IOException var7) {
                var7.printStackTrace();
                System.out.println("Error while trying to copy schematic!.");
                MessageSender.SendMessage(player, "Commands.Import-Cage.Imported-UnSuccessful", "{name}", SchemName);
            }
        }
    }
}

