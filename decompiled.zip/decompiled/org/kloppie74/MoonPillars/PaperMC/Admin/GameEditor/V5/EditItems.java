/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataContainer
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.Cooldowns;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.EditorMenu;
import org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.V5.WorldListeners;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class EditItems
implements Listener {
    public static Map<UUID, Integer> SetPositionNumber = new HashMap<UUID, Integer>();
    public static Map<UUID, Integer> SetTeamNumber = new HashMap<UUID, Integer>();

    public static void GiveEditMenuItem(Player player) {
        ItemStack item = new ItemStack(Material.KNOWLEDGE_BOOK);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(MSG.chatColors("&b&lGame Editor Menu"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Use this item to access the Game Editor"));
        lore.add(MSG.chatColors("&7where you can configure all game settings."));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 Configure teams and player limits"));
        lore.add(MSG.chatColors("&8\u2192 Set game timers and events"));
        lore.add(MSG.chatColors("&8\u2192 Manage allowed and banned items"));
        lore.add(MSG.chatColors("&8\u2192 Customize rewards and voting options"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&e&lClick to open the Game Editor"));
        meta.setLore(lore);
        NamespacedKey key = new NamespacedKey((Plugin)MoonLab.getInstance(), "custom_tag");
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, (Object)"editmenu_item");
        item.setItemMeta(meta);
        player.getInventory().setItem(0, item);
    }

    public static void GivePositionItem(Player player, int PositionNumber, int TeamNumber) {
        ItemStack item = new ItemStack(Material.STICK);
        ItemMeta meta = item.getItemMeta();
        if (!SetPositionNumber.containsKey(player.getUniqueId())) {
            SetPositionNumber.put(player.getUniqueId(), 1);
        }
        if (!SetTeamNumber.containsKey(player.getUniqueId())) {
            SetTeamNumber.put(player.getUniqueId(), 1);
        }
        meta.setDisplayName(MSG.chatColors("&e&lTeam Position Selector"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7Currently selecting:"));
        lore.add(MSG.chatColors("&7Team: &6" + TeamNumber + " &7Player: &6" + PositionNumber));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&b&lControls:"));
        lore.add(MSG.chatColors("&e\u2022 &7Left-click a block: &fSet position for current player"));
        lore.add(MSG.chatColors("&e\u2022 &7Right-click: &fCycle to next player position"));
        lore.add(MSG.chatColors("&e\u2022 &7Shift + right-click: &fCycle to next team"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 This sets where players spawn in-game"));
        lore.add(MSG.chatColors("&8\u2192 Players will face the direction you're facing"));
        lore.add(MSG.chatColors("&8\u2192 Set all positions for all teams"));
        meta.setLore(lore);
        NamespacedKey key = new NamespacedKey((Plugin)MoonLab.getInstance(), "custom_tag");
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, (Object)"position_item");
        item.setItemMeta(meta);
        player.getInventory().setItem(1, item);
    }

    public static void GiveSpawnItem(Player player) {
        ItemStack item = new ItemStack(Material.FEATHER);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(MSG.chatColors("&e&lSpawn Area Selector"));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(MSG.chatColors("&7This tool defines the temporary lobby area"));
        lore.add(MSG.chatColors("&7and the main game spawn point."));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&b&lControls:"));
        lore.add(MSG.chatColors("&e\u2022 &7Left-click: &fSet position 1 of lobby area"));
        lore.add(MSG.chatColors("&e\u2022 &7Right-click: &fSet position 2 of lobby area"));
        lore.add(MSG.chatColors("&e\u2022 &7Shift + click: &fSet main game spawn point"));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&c&lIMPORTANT:"));
        lore.add(MSG.chatColors("&7The area between position 1 and 2 will be"));
        lore.add(MSG.chatColors("&7temporarily generated as the lobby, then removed"));
        lore.add(MSG.chatColors("&7when players teleport to their team positions."));
        lore.add(MSG.chatColors("&7"));
        lore.add(MSG.chatColors("&8\u2192 This is NOT the game arena boundary"));
        lore.add(MSG.chatColors("&8\u2192 Only used for pre-game lobby"));
        lore.add(MSG.chatColors("&8\u2192 Main spawn is used for spectators"));
        meta.setLore(lore);
        NamespacedKey key = new NamespacedKey((Plugin)MoonLab.getInstance(), "custom_tag");
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, (Object)"spawnarea_item");
        item.setItemMeta(meta);
        player.getInventory().setItem(2, item);
    }

    @EventHandler
    public void OnDropEvent(PlayerDropItemEvent event) {
        ItemMeta meta;
        ItemStack item = event.getItemDrop().getItemStack();
        if (item != null && item.hasItemMeta() && (meta = item.getItemMeta()) != null) {
            String ItemID;
            NamespacedKey key = new NamespacedKey((Plugin)MoonLab.getInstance(), "custom_tag");
            PersistentDataContainer container = meta.getPersistentDataContainer();
            if (container.has(key, PersistentDataType.STRING) && ((ItemID = (String)container.get(key, PersistentDataType.STRING)).equalsIgnoreCase("position_item") || ItemID.equalsIgnoreCase("editmenu_item") || ItemID.equalsIgnoreCase("spawnarea_item"))) {
                event.setCancelled(true);
                event.getPlayer().sendMessage(MSG.chatColors("&c&lError: &7You cannot drop editor items!"));
            }
        }
    }

    @EventHandler
    public void OnInventoryClick(InventoryClickEvent event) {
        ItemMeta meta;
        ItemStack item = event.getCurrentItem();
        if (item != null && item.hasItemMeta() && (meta = item.getItemMeta()) != null) {
            String ItemID;
            NamespacedKey key = new NamespacedKey((Plugin)MoonLab.getInstance(), "custom_tag");
            PersistentDataContainer container = meta.getPersistentDataContainer();
            if (container.has(key, PersistentDataType.STRING) && ((ItemID = (String)container.get(key, PersistentDataType.STRING)).equalsIgnoreCase("position_item") || ItemID.equalsIgnoreCase("editmenu_item") || ItemID.equalsIgnoreCase("spawnarea_item"))) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void OnPlayerInteract(PlayerInteractEvent event) {
        ItemMeta meta;
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        if (item != null && item.hasItemMeta() && (meta = item.getItemMeta()) != null) {
            NamespacedKey key = new NamespacedKey((Plugin)MoonLab.getInstance(), "custom_tag");
            PersistentDataContainer container = meta.getPersistentDataContainer();
            if (container.has(key, PersistentDataType.STRING)) {
                event.setCancelled(true);
                String ItemID = (String)container.get(key, PersistentDataType.STRING);
                if (ItemID.equalsIgnoreCase("position_item")) {
                    this.handlePositionItem(event, player);
                } else if (ItemID.equalsIgnoreCase("spawnarea_item")) {
                    this.handleSpawnAreaItem(event, player);
                } else if (ItemID.equalsIgnoreCase("editmenu_item")) {
                    FileConfiguration config = WorldListeners.configEditer.get(player.getUniqueId());
                    if (config == null) {
                        return;
                    }
                    player.closeInventory();
                    Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> player.openInventory(EditorMenu.createSetupChoiceMenu(player, config)), 1L);
                }
            }
        }
    }

    private void handlePositionItem(PlayerInteractEvent event, Player player) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            if (event.getAction() == Action.LEFT_CLICK_BLOCK) {
                FileConfiguration config = WorldListeners.configEditer.get(player.getUniqueId());
                int PositionNumber = SetPositionNumber.get(player.getUniqueId());
                int TeamNumber = SetTeamNumber.get(player.getUniqueId());
                if (event.getClickedBlock() != null) {
                    int MaxTeams = event.getClickedBlock().getX();
                    int newTeamNumber = event.getClickedBlock().getY() + 1;
                    int Z = event.getClickedBlock().getZ();
                    double midX = (double)MaxTeams + 0.5;
                    double midY = newTeamNumber;
                    double midZ = (double)Z + 0.5;
                    float yaw = player.getLocation().getYaw();
                    float pitch = player.getLocation().getPitch();
                    String ConfigSecX = "SpawnLocations.Team" + TeamNumber + ".Player" + PositionNumber + ".X";
                    String ConfigSecY = "SpawnLocations.Team" + TeamNumber + ".Player" + PositionNumber + ".Y";
                    String ConfigSecZ = "SpawnLocations.Team" + TeamNumber + ".Player" + PositionNumber + ".Z";
                    String ConfigSecYaw = "SpawnLocations.Team" + TeamNumber + ".Player" + PositionNumber + ".Yaw";
                    String ConfigSecPitch = "SpawnLocations.Team" + TeamNumber + ".Player" + PositionNumber + ".Pitch";
                    String CageRotation = "SpawnLocations.Team" + TeamNumber + ".Player" + PositionNumber + ".Cage-Rotation";
                    config.set(ConfigSecX, (Object)midX);
                    config.set(ConfigSecY, (Object)midY);
                    config.set(ConfigSecZ, (Object)midZ);
                    config.set(ConfigSecYaw, (Object)Float.valueOf(yaw));
                    config.set(ConfigSecPitch, (Object)Float.valueOf(pitch));
                    config.set(CageRotation, (Object)0);
                    player.sendMessage(MSG.chatColors("&a&lPosition Set! &7Team " + TeamNumber + ", Player " + PositionNumber));
                    String var10001 = String.format("%.1f", midX);
                    player.sendMessage(MSG.chatColors("&7Location: &fX: " + var10001 + " Y: " + String.format("%.1f", midY) + " Z: " + String.format("%.1f", midZ) + " &7(Facing: &f" + this.getDirectionName(yaw) + "&7)"));
                }
                EditorMenu.SaveConfig(player);
            }
        } else if (player.isSneaking()) {
            if (!Cooldowns.isOnCooldown(player)) {
                int MaxTeams;
                FileConfiguration config = WorldListeners.configEditer.get(player.getUniqueId());
                int PositionNumber = SetPositionNumber.get(player.getUniqueId());
                int TeamNumber = SetTeamNumber.get(player.getUniqueId());
                int newTeamNumber = TeamNumber >= (MaxTeams = config.getInt("SpawnLocations.MaxTeams")) ? 1 : SetTeamNumber.get(player.getUniqueId()) + 1;
                SetTeamNumber.put(player.getUniqueId(), newTeamNumber);
                EditItems.GivePositionItem(player, PositionNumber, newTeamNumber);
                player.sendMessage(MSG.chatColors("&aChanged to Team " + newTeamNumber));
                Cooldowns.startCooldown(player);
            }
        } else if (!Cooldowns.isOnCooldown(player)) {
            FileConfiguration config = WorldListeners.configEditer.get(player.getUniqueId());
            int PositionNumber = SetPositionNumber.get(player.getUniqueId());
            int TeamNumber = SetTeamNumber.get(player.getUniqueId());
            int MaxTeams = config.getInt("SpawnLocations.PlayersPerTeam");
            int newTeamNumber = PositionNumber >= MaxTeams ? 1 : SetPositionNumber.get(player.getUniqueId()) + 1;
            SetPositionNumber.put(player.getUniqueId(), newTeamNumber);
            EditItems.GivePositionItem(player, newTeamNumber, TeamNumber);
            player.sendMessage(MSG.chatColors("&aChanged to Player Position " + newTeamNumber));
            Cooldowns.startCooldown(player);
        }
    }

    private String getDirectionName(float yaw) {
        if ((yaw %= 360.0f) < 0.0f) {
            yaw += 360.0f;
        }
        if (!((double)yaw >= 337.5) && !((double)yaw < 22.5)) {
            if ((double)yaw >= 22.5 && (double)yaw < 67.5) {
                return "South-West";
            }
            if ((double)yaw >= 67.5 && (double)yaw < 112.5) {
                return "West";
            }
            if ((double)yaw >= 112.5 && (double)yaw < 157.5) {
                return "North-West";
            }
            if ((double)yaw >= 157.5 && (double)yaw < 202.5) {
                return "North";
            }
            if ((double)yaw >= 202.5 && (double)yaw < 247.5) {
                return "North-East";
            }
            if ((double)yaw >= 247.5 && (double)yaw < 292.5) {
                return "East";
            }
            return (double)yaw >= 292.5 && (double)yaw < 337.5 ? "South-East" : "Unknown";
        }
        return "South";
    }

    private void handleSpawnAreaItem(PlayerInteractEvent event, Player player) {
        FileConfiguration config = WorldListeners.configEditer.get(player.getUniqueId());
        if (player.isSneaking()) {
            if (event.getAction() == Action.LEFT_CLICK_BLOCK || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
                if (event.getClickedBlock() != null) {
                    int X = event.getClickedBlock().getX();
                    int Y = event.getClickedBlock().getY() + 1;
                    int Z = event.getClickedBlock().getZ();
                    float yaw = player.getLocation().getYaw();
                    float pitch = player.getLocation().getPitch();
                    config.set("Settings.SpawnPoint.X", (Object)((double)X + 0.5));
                    config.set("Settings.SpawnPoint.Y", (Object)Y);
                    config.set("Settings.SpawnPoint.Z", (Object)((double)Z + 0.5));
                    config.set("Settings.SpawnPoint.Yaw", (Object)Float.valueOf(yaw));
                    config.set("Settings.SpawnPoint.Pitch", (Object)Float.valueOf(pitch));
                    player.sendMessage(MSG.chatColors("&a&lMain Spawn Set! &7Location: X: " + ((double)X + 0.5) + " Y: " + Y + " Z: " + ((double)Z + 0.5)));
                    player.sendMessage(MSG.chatColors("&7This is where spectators and players who join late will spawn."));
                }
                EditorMenu.SaveConfig(player);
            }
        } else if (event.getAction() == Action.LEFT_CLICK_BLOCK) {
            if (event.getClickedBlock() != null) {
                int X = event.getClickedBlock().getX();
                int Y = event.getClickedBlock().getY();
                int Z = event.getClickedBlock().getZ();
                config.set("Settings.Spawn-Area.Loc1.X", (Object)X);
                config.set("Settings.Spawn-Area.Loc1.Y", (Object)Y);
                config.set("Settings.Spawn-Area.Loc1.Z", (Object)Z);
                player.sendMessage(MSG.chatColors("&a&lLobby Area - Position 1 Set! &7X: " + X + " Y: " + Y + " Z: " + Z));
                if (config.isSet("Settings.Spawn-Area.Loc2.X")) {
                    int X1 = config.getInt("Settings.Spawn-Area.Loc2.X");
                    int Y1 = config.getInt("Settings.Spawn-Area.Loc2.Y");
                    int Z1 = config.getInt("Settings.Spawn-Area.Loc2.Z");
                    int width = Math.abs(X - X1) + 1;
                    int height = Math.abs(Y - Y1) + 1;
                    int depth = Math.abs(Z - Z1) + 1;
                    int volume = width * height * depth;
                    player.sendMessage(MSG.chatColors("&7Lobby area size: &f" + width + "\u00d7" + height + "\u00d7" + depth + " &7(&f" + volume + " blocks&7)"));
                }
            }
            EditorMenu.SaveConfig(player);
        } else if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            if (event.getClickedBlock() != null) {
                int X = event.getClickedBlock().getX();
                int Y = event.getClickedBlock().getY();
                int Z = event.getClickedBlock().getZ();
                config.set("Settings.Spawn-Area.Loc2.X", (Object)X);
                config.set("Settings.Spawn-Area.Loc2.Y", (Object)Y);
                config.set("Settings.Spawn-Area.Loc2.Z", (Object)Z);
                player.sendMessage(MSG.chatColors("&a&lLobby Area - Position 2 Set! &7X: " + X + " Y: " + Y + " Z: " + Z));
                if (config.isSet("Settings.Spawn-Area.Loc1.X")) {
                    int X1 = config.getInt("Settings.Spawn-Area.Loc1.X");
                    int Y1 = config.getInt("Settings.Spawn-Area.Loc1.Y");
                    int Z1 = config.getInt("Settings.Spawn-Area.Loc1.Z");
                    int width = Math.abs(X - X1) + 1;
                    int height = Math.abs(Y - Y1) + 1;
                    int depth = Math.abs(Z - Z1) + 1;
                    int volume = width * height * depth;
                    player.sendMessage(MSG.chatColors("&7Lobby area size: &f" + width + "\u00d7" + height + "\u00d7" + depth + " &7(&f" + volume + " blocks&7)"));
                }
            }
            EditorMenu.SaveConfig(player);
        }
    }
}

