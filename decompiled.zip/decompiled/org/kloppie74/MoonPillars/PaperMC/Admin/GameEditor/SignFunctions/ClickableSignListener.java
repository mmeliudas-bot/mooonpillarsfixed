/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.block.Block
 *  org.bukkit.block.Sign
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.player.PlayerInteractEvent
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.SignFunctions;

import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class ClickableSignListener
implements Listener {
    private static ClickableSignListener instance;
    private MoonLab plugin;

    public ClickableSignListener(MoonLab plugin) {
        this.plugin = plugin;
        instance = this;
    }

    public static ClickableSignListener getInstance() {
        return instance;
    }

    @EventHandler
    public void onSignClick(PlayerInteractEvent event) {
        Block clickedBlock;
        if ((event.getAction() == Action.RIGHT_CLICK_BLOCK || event.getAction() == Action.LEFT_CLICK_BLOCK) && (clickedBlock = event.getClickedBlock()) != null && clickedBlock.getState() instanceof Sign) {
            Player player = event.getPlayer();
            String worldName = clickedBlock.getWorld().getName();
            int x = clickedBlock.getX();
            int y = clickedBlock.getY();
            int z = clickedBlock.getZ();
            FileConfiguration config = SettingsManager.getInstance().getClickableSigns();
            ConfigurationSection signsSection = config.getConfigurationSection("ClickableSigns");
            if (signsSection != null) {
                for (String signName : signsSection.getKeys(false)) {
                    String signWorld = config.getString("ClickableSigns." + signName + ".World");
                    int signX = config.getInt("ClickableSigns." + signName + ".X");
                    int signY = config.getInt("ClickableSigns." + signName + ".Y");
                    int signZ = config.getInt("ClickableSigns." + signName + ".Z");
                    if (!worldName.equals(signWorld) || x != signX || y != signY || z != signZ) continue;
                    List commands = config.getStringList("ClickableSigns." + signName + ".Commands");
                    for (String command : commands) {
                        String message;
                        if (command.startsWith("[PLAYER]")) {
                            message = command.substring("[PLAYER]".length()).trim();
                            player.performCommand(message);
                            continue;
                        }
                        if (command.startsWith("[CONSOLE]")) {
                            message = command.substring("[CONSOLE]".length()).trim().replace("%player%", player.getName());
                            Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)message);
                            continue;
                        }
                        if (!command.startsWith("[MESSAGE]")) continue;
                        message = command.substring("[MESSAGE]".length()).trim().replace("%player%", player.getName());
                        player.sendMessage(MSG.chatColors(message));
                        String logMessage = "[Sign Message] " + player.getName() + " clicked sign '" + signName + "' and received: " + message;
                        Bukkit.getConsoleSender().sendMessage(MSG.chatColors("&7[ChatLog] " + logMessage));
                    }
                    event.setCancelled(true);
                    break;
                }
            }
        }
    }
}

