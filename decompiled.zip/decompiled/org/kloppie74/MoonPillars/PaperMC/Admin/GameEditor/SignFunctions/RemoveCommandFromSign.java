/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.block.Block
 *  org.bukkit.block.Sign
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.GameEditor.SignFunctions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class RemoveCommandFromSign
extends AdminSubCommand {
    @Override
    public String getName() {
        return "removecommandfromsign";
    }

    @Override
    public String getDescription() {
        return "Remove a command from a clickable sign!";
    }

    @Override
    public String getSyntax() {
        return "/mpa removecommandfromsign <index>";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (!player.hasPermission("mpa.removecommandfromsign")) {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        } else if (args.length < 2) {
            player.sendMessage(MSG.chatColors("&cUsage: " + this.getSyntax()));
        } else {
            Block targetBlock = player.getTargetBlockExact(5);
            if (targetBlock != null && targetBlock.getState() instanceof Sign) {
                int index;
                try {
                    index = Integer.parseInt(args[1]);
                }
                catch (NumberFormatException var18) {
                    player.sendMessage(MSG.chatColors("&cInvalid index. Please provide a valid number."));
                    return;
                }
                FileConfiguration config = SettingsManager.getInstance().getClickableSigns();
                String foundSignName = null;
                String worldName = targetBlock.getWorld().getName();
                int x = targetBlock.getX();
                int y = targetBlock.getY();
                int z = targetBlock.getZ();
                ConfigurationSection signsSection = config.getConfigurationSection("ClickableSigns");
                if (signsSection != null) {
                    for (String removedCommand : signsSection.getKeys(false)) {
                        String signWorld = config.getString("ClickableSigns." + removedCommand + ".World");
                        int signX = config.getInt("ClickableSigns." + removedCommand + ".X");
                        int signY = config.getInt("ClickableSigns." + removedCommand + ".Y");
                        int signZ = config.getInt("ClickableSigns." + removedCommand + ".Z");
                        if (!worldName.equals(signWorld) || x != signX || y != signY || z != signZ) continue;
                        foundSignName = removedCommand;
                        break;
                    }
                }
                if (foundSignName == null) {
                    player.sendMessage(MSG.chatColors("&cThis sign is not set as a clickable sign!"));
                } else {
                    List commands = config.getStringList("ClickableSigns." + foundSignName + ".Commands");
                    if (commands.isEmpty()) {
                        player.sendMessage(MSG.chatColors("&cThis sign doesn't have any commands!"));
                    } else if (index >= 0 && index < commands.size()) {
                        String removedCommand;
                        removedCommand = (String)commands.remove(index);
                        config.set("ClickableSigns." + foundSignName + ".Commands", (Object)commands);
                        SettingsManager.getInstance();
                        SettingsManager.saveSettings("ClickableSigns");
                        player.sendMessage(MSG.chatColors("&aRemoved command from sign '" + foundSignName + "': &r" + removedCommand));
                    } else {
                        int var10001 = commands.size();
                        player.sendMessage(MSG.chatColors("&cInvalid index. Use a number between 0 and " + (var10001 - 1)));
                        player.sendMessage(MSG.chatColors("&cAvailable commands:"));
                        for (int i = 0; i < commands.size(); ++i) {
                            player.sendMessage(MSG.chatColors("&c" + i + ": &r" + (String)commands.get(i)));
                        }
                    }
                }
            } else {
                player.sendMessage(MSG.chatColors("&cYou must be looking at a sign to remove a command!"));
            }
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        sender.sendMessage("This command can only be used by players.");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        Collections.sort(completions);
        return completions;
    }
}

