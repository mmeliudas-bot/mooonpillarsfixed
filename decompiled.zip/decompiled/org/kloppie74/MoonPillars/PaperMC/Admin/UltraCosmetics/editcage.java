/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldedit.EditSession
 *  com.sk89q.worldedit.WorldEdit
 *  com.sk89q.worldedit.bukkit.BukkitAdapter
 *  com.sk89q.worldedit.bukkit.BukkitPlayer
 *  com.sk89q.worldedit.extent.Extent
 *  com.sk89q.worldedit.extent.clipboard.Clipboard
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardReader
 *  com.sk89q.worldedit.function.operation.Operation
 *  com.sk89q.worldedit.function.operation.Operations
 *  com.sk89q.worldedit.math.BlockVector3
 *  com.sk89q.worldedit.session.ClipboardHolder
 *  org.bukkit.Color
 *  org.bukkit.Location
 *  org.bukkit.Particle
 *  org.bukkit.Particle$DustOptions
 *  org.bukkit.World
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.UltraCosmetics;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.bukkit.BukkitPlayer;
import com.sk89q.worldedit.extent.Extent;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.session.ClipboardHolder;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.Admin.Cooldowns;
import org.kloppie74.MoonPillars.PaperMC.Admin.UltraCosmetics.createcage;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class editcage
extends AdminSubCommand {
    private static final int MIN_WIDTH = 3;
    private static final int MIN_HEIGHT = 4;
    private static final Map<UUID, BukkitTask> particleTasks = new HashMap<UUID, BukkitTask>();

    @Override
    public String getName() {
        return "editcage";
    }

    @Override
    public String getDescription() {
        return "Edit an existing cage!";
    }

    @Override
    public String getSyntax() {
        return "/mpa editcage <name>";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (!player.hasPermission("mpa.editcage")) {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        } else if (Cooldowns.isOnCooldown(player)) {
            MessageSender.SendMessage(player, "Commands.Cooldown", "", "");
        } else if (args.length != 2) {
            MessageSender.SendMessage(player, "Commands.Edit-Cage.Unknown-Usage", "", "");
            Cooldowns.startCooldown(player);
        } else {
            String cageName = args[1];
            UUID playerId = player.getUniqueId();
            Map<UUID, createcage.CageEditSession> sessions = createcage.getActiveSessions();
            if (sessions.containsKey(playerId)) {
                createcage.CageEditSession currentSession = sessions.get(playerId);
                if (currentSession.getName().equals(cageName)) {
                    player.sendMessage(MSG.chatColors("&eYou are already editing cage &a" + cageName + "&e!"));
                } else {
                    player.sendMessage(MSG.chatColors("&cYou are already editing cage &e" + currentSession.getName() + "&c. Please save or cancel this session first."));
                }
            } else {
                FileConfiguration cosmeticsConfig = SettingsManager.getInstance().getCosmetics();
                if (!cosmeticsConfig.contains("Settings.Cages." + cageName)) {
                    player.sendMessage(MSG.chatColors("&cCage &e" + cageName + " &cdoesn't exist!"));
                } else {
                    File cagesDir = new File(MoonLab.getInstance().getDataFolder(), "Cages");
                    File schematicFile = new File(cagesDir, cageName + ".schem");
                    if (!schematicFile.exists()) {
                        player.sendMessage(MSG.chatColors("&cSchematic file for cage &e" + cageName + " &cdoes not exist! Please create it first."));
                    } else {
                        int width = cosmeticsConfig.getInt("Settings.Cages." + cageName + ".Width", 3);
                        int height = cosmeticsConfig.getInt("Settings.Cages." + cageName + ".Height", 4);
                        if (width < 3) {
                            width = 3;
                        }
                        if (height < 4) {
                            height = 4;
                        }
                        Location center = new Location(player.getWorld(), (double)player.getLocation().getBlockX() + 0.5, (double)player.getLocation().getBlockY(), (double)player.getLocation().getBlockZ() + 0.5, player.getLocation().getYaw(), player.getLocation().getPitch());
                        createcage.CageEditSession session = new createcage.CageEditSession(cageName, width, height, center);
                        sessions.put(playerId, session);
                        int playerLayer1 = Math.max(2, height / 2 - 1);
                        int playerLayer2 = playerLayer1 + 1;
                        session.setPlayerLayer1(playerLayer1);
                        session.setPlayerLayer2(playerLayer2);
                        player.sendMessage(MSG.chatColors("&aLoading cage &e" + cageName + "&a..."));
                        boolean loadSuccess = false;
                        try {
                            loadSuccess = this.loadAndPasteWithAPI(player, schematicFile, center);
                        }
                        catch (Exception var17) {
                            player.sendMessage(MSG.chatColors("&c[DEBUG] Error loading schematic with API: &e" + var17.getMessage()));
                        }
                        if (!loadSuccess) {
                            player.sendMessage(MSG.chatColors("&cFailed to load cage &e" + cageName + "&c. Creating a new structure instead."));
                        } else {
                            player.sendMessage(MSG.chatColors("&aCage &e" + cageName + " &ahas been loaded at your location!"));
                        }
                        this.startParticleDisplay(player, session);
                        player.sendMessage(MSG.chatColors("&aEditing cage &e" + cageName + "&a with dimensions &e" + width + "x" + width + "x" + height + "&a. Use &e/mpa savecage &ato save when done."));
                        Cooldowns.startCooldown(player);
                    }
                }
            }
        }
    }

    private boolean loadAndPasteWithAPI(Player player, File schematicFile, Location location) {
        try {
            BukkitPlayer worldEditPlayer = BukkitAdapter.adapt((Player)player);
            ClipboardFormat format = ClipboardFormats.findByFile((File)schematicFile);
            if (format != null) {
                boolean var29;
                Clipboard clipboard;
                try (ClipboardReader reader = format.getReader((InputStream)new FileInputStream(schematicFile));){
                    clipboard = reader.read();
                }
                BlockVector3 targetPos = BlockVector3.at((double)location.getX(), (double)location.getY(), (double)location.getZ());
                try (EditSession editSession = WorldEdit.getInstance().newEditSession(worldEditPlayer.getWorld());){
                    Operation operation = new ClipboardHolder(clipboard).createPaste((Extent)editSession).to(targetPos).ignoreAirBlocks(false).copyEntities(true).build();
                    Operations.complete((Operation)operation);
                    var29 = true;
                }
                return var29;
            }
            for (ClipboardFormat possibleFormat : ClipboardFormats.getAll()) {
                try {
                    boolean var13;
                    try (ClipboardReader reader = possibleFormat.getReader((InputStream)new FileInputStream(schematicFile));){
                        Clipboard clipboard = reader.read();
                        BlockVector3 targetPos = BlockVector3.at((double)location.getX(), (double)location.getY(), (double)location.getZ());
                        try (EditSession editSession = WorldEdit.getInstance().newEditSession(worldEditPlayer.getWorld());){
                            Operation operation = new ClipboardHolder(clipboard).createPaste((Extent)editSession).to(targetPos).ignoreAirBlocks(false).copyEntities(true).build();
                            Operations.complete((Operation)operation);
                            var13 = true;
                        }
                    }
                    return var13;
                }
                catch (Exception exception) {
                }
            }
            return false;
        }
        catch (Exception var23) {
            return false;
        }
    }

    private void startParticleDisplay(final Player player, final createcage.CageEditSession session) {
        final UUID playerId = player.getUniqueId();
        if (particleTasks.containsKey(playerId)) {
            particleTasks.get(playerId).cancel();
            particleTasks.remove(playerId);
        }
        BukkitTask task = new BukkitRunnable(){

            public void run() {
                if (player.isOnline() && createcage.getActiveSessions().containsKey(playerId)) {
                    editcage.this.displayCageParticles(player, session);
                } else {
                    this.cancel();
                    particleTasks.remove(playerId);
                }
            }
        }.runTaskTimer((Plugin)MoonLab.getInstance(), 0L, 10L);
        particleTasks.put(playerId, task);
    }

    private void displayCageParticles(Player player, createcage.CageEditSession session) {
        double y;
        Location center = session.getCenter();
        int width = session.getWidth();
        int height = session.getHeight();
        double halfWidth = (double)width / 2.0;
        double minX = center.getX() - halfWidth;
        double maxX = center.getX() + halfWidth;
        double minZ = center.getZ() - halfWidth;
        double maxZ = center.getZ() + halfWidth;
        double minY = center.getY();
        double maxY = center.getY() + (double)height;
        Particle.DustOptions blueDust = new Particle.DustOptions(Color.fromRGB((int)0, (int)0, (int)255), 1.0f);
        Particle.DustOptions greenDust = new Particle.DustOptions(Color.fromRGB((int)0, (int)255, (int)0), 1.0f);
        double stepSize = 0.15;
        for (y = minX; y <= maxX + 0.001; y += stepSize) {
            this.spawnDustParticle(player, new Location(center.getWorld(), y, minY, minZ), blueDust);
            this.spawnDustParticle(player, new Location(center.getWorld(), y, minY, maxZ), blueDust);
        }
        for (y = minZ; y <= maxZ + 0.001; y += stepSize) {
            this.spawnDustParticle(player, new Location(center.getWorld(), minX, minY, y), blueDust);
            this.spawnDustParticle(player, new Location(center.getWorld(), maxX, minY, y), blueDust);
        }
        for (y = minX; y <= maxX + 0.001; y += stepSize) {
            this.spawnDustParticle(player, new Location(center.getWorld(), y, maxY, minZ), blueDust);
            this.spawnDustParticle(player, new Location(center.getWorld(), y, maxY, maxZ), blueDust);
        }
        for (y = minZ; y <= maxZ + 0.001; y += stepSize) {
            this.spawnDustParticle(player, new Location(center.getWorld(), minX, maxY, y), blueDust);
            this.spawnDustParticle(player, new Location(center.getWorld(), maxX, maxY, y), blueDust);
        }
        for (y = minY; y <= maxY + 0.001; y += stepSize) {
            this.spawnDustParticle(player, new Location(center.getWorld(), minX, y, minZ), blueDust);
            this.spawnDustParticle(player, new Location(center.getWorld(), minX, y, maxZ), blueDust);
            this.spawnDustParticle(player, new Location(center.getWorld(), maxX, y, minZ), blueDust);
            this.spawnDustParticle(player, new Location(center.getWorld(), maxX, y, maxZ), blueDust);
        }
        int playerLayer1 = session.getPlayerLayer1();
        int playerLayer2 = session.getPlayerLayer2();
        double playerY1 = center.getY() + (double)playerLayer1;
        double playerY2 = center.getY() + (double)playerLayer2;
        this.displayExactPlayerBlockOutline(player, center.getWorld(), center.getX(), playerY1, center.getZ(), greenDust);
        this.displayExactPlayerBlockOutline(player, center.getWorld(), center.getX(), playerY2, center.getZ(), greenDust);
    }

    private void displayExactPlayerBlockOutline(Player player, World world, double x, double y, double z, Particle.DustOptions dustOptions) {
        double iy;
        double stepSize = 0.15;
        double pMinX = x - 0.5;
        double pMaxX = x + 0.5;
        double pMinZ = z - 0.5;
        double pMaxZ = z + 0.5;
        double pMinY = y;
        double pMaxY = y + 1.0;
        for (iy = pMinX; iy <= pMaxX + 0.001; iy += stepSize) {
            this.spawnDustParticle(player, new Location(world, iy, pMinY, pMinZ), dustOptions);
            this.spawnDustParticle(player, new Location(world, iy, pMinY, pMaxZ), dustOptions);
        }
        for (iy = pMinZ + stepSize; iy < pMaxZ; iy += stepSize) {
            this.spawnDustParticle(player, new Location(world, pMinX, pMinY, iy), dustOptions);
            this.spawnDustParticle(player, new Location(world, pMaxX, pMinY, iy), dustOptions);
        }
        for (iy = pMinX; iy <= pMaxX + 0.001; iy += stepSize) {
            this.spawnDustParticle(player, new Location(world, iy, pMaxY, pMinZ), dustOptions);
            this.spawnDustParticle(player, new Location(world, iy, pMaxY, pMaxZ), dustOptions);
        }
        for (iy = pMinZ + stepSize; iy < pMaxZ; iy += stepSize) {
            this.spawnDustParticle(player, new Location(world, pMinX, pMaxY, iy), dustOptions);
            this.spawnDustParticle(player, new Location(world, pMaxX, pMaxY, iy), dustOptions);
        }
        for (iy = pMinY + stepSize; iy < pMaxY; iy += stepSize) {
            this.spawnDustParticle(player, new Location(world, pMinX, iy, pMinZ), dustOptions);
            this.spawnDustParticle(player, new Location(world, pMinX, iy, pMaxZ), dustOptions);
            this.spawnDustParticle(player, new Location(world, pMaxX, iy, pMinZ), dustOptions);
            this.spawnDustParticle(player, new Location(world, pMaxX, iy, pMaxZ), dustOptions);
        }
    }

    private void spawnDustParticle(Player player, Location location, Particle.DustOptions dustOptions) {
        player.spawnParticle(Particle.REDSTONE, location, 1, 0.0, 0.0, 0.0, 0.0, (Object)dustOptions);
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        sender.sendMessage(MSG.chatColors("&cThis command can only be used by players."));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 2) {
            File[] files;
            File cagesDir;
            FileConfiguration cosmeticsConfig = SettingsManager.getInstance().getCosmetics();
            ConfigurationSection cagesSection = cosmeticsConfig.getConfigurationSection("Settings.Cages");
            if (cagesSection != null) {
                for (String key : cagesSection.getKeys(false)) {
                    if (!key.toLowerCase().startsWith(args[1].toLowerCase())) continue;
                    completions.add(key);
                }
            }
            if ((cagesDir = new File(MoonLab.getInstance().getDataFolder(), "Cages")).exists() && cagesDir.isDirectory() && (files = cagesDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".schem"))) != null) {
                File[] var10 = files;
                int var11 = files.length;
                for (int var12 = 0; var12 < var11; ++var12) {
                    File file = var10[var12];
                    String cageName = file.getName().replace(".schem", "");
                    if (!cageName.toLowerCase().startsWith(args[1].toLowerCase()) || completions.contains(cageName)) continue;
                    completions.add(cageName);
                }
            }
        }
        Collections.sort(completions);
        return completions;
    }
}

