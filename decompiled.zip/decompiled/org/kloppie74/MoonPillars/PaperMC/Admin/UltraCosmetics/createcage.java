/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Color
 *  org.bukkit.Location
 *  org.bukkit.Particle
 *  org.bukkit.Particle$DustOptions
 *  org.bukkit.World
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.UltraCosmetics;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.Admin.Cooldowns;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class createcage
extends AdminSubCommand {
    private static final Map<UUID, CageEditSession> activeSessions = new HashMap<UUID, CageEditSession>();
    private static final Map<UUID, BukkitTask> particleTasks = new HashMap<UUID, BukkitTask>();
    private static final int MIN_WIDTH = 3;
    private static final int MIN_HEIGHT = 4;

    @Override
    public String getName() {
        return "createcage";
    }

    @Override
    public String getDescription() {
        return "Create a new cage with specified dimensions!";
    }

    @Override
    public String getSyntax() {
        return "/mpa createcage <name> <width> <height>";
    }

    @Override
    public void perform(Player player, String[] args) {
        if (!player.hasPermission("mpa.createcage")) {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        } else if (Cooldowns.isOnCooldown(player)) {
            MessageSender.SendMessage(player, "Commands.Cooldown", "", "");
        } else if (args.length != 4) {
            MessageSender.SendMessage(player, "Commands.Create-Cage.Unknown-Usage", "", "");
            Cooldowns.startCooldown(player);
        } else {
            try {
                String cageName = args[1];
                int width = Integer.parseInt(args[2]);
                int height = Integer.parseInt(args[3]);
                if (this.cageExists(cageName)) {
                    player.sendMessage(MSG.chatColors("&cA cage with the name &e" + cageName + " &calready exists! Use &e/mpa editcage " + cageName + " &cinstead or choose a different name."));
                    return;
                }
                if (width < 3 || height < 4) {
                    player.sendMessage(MSG.chatColors("&cCage dimensions must be at least &e3x3x4 &cto ensure player has enough space!"));
                    return;
                }
                createcage.cancelExistingSession(player);
                Location center = player.getLocation().getBlock().getLocation().add(0.5, 0.0, 0.5);
                CageEditSession session = new CageEditSession(cageName, width, height, center);
                activeSessions.put(player.getUniqueId(), session);
                this.startParticleDisplay(player);
                player.sendMessage(MSG.chatColors("&bCage creation started!\n&7You are now in cage edit mode. Please review the following:\n&9\u25a0 &bBlue Particles&7: Indicate the cage boundaries.\n&a\u25a0 &aGreen Particles&7: Indicate the player spawn area.\n&e\n&eTo save your cage, use &6/mpa savecage&7.\n&7Make sure the dimensions and position are correct before saving."));
            }
            catch (NumberFormatException var8) {
                MessageSender.SendMessage(player, "Commands.Create-Cage.Invalid-Number", "", "");
            }
            Cooldowns.startCooldown(player);
        }
    }

    private boolean cageExists(String cageName) {
        File cagesDir = new File(MoonLab.getInstance().getDataFolder(), "Cages");
        File schematicFile = new File(cagesDir, cageName + ".schem");
        return schematicFile.exists();
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        sender.sendMessage(MSG.chatColors("&cThis command can only be used by players."));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!(sender instanceof Player)) {
            return completions;
        }
        if (args.length == 2) {
            completions.add("MyCage");
            completions.add("TestCage");
            completions.add("NewCage");
        } else if (args.length == 3) {
            completions.add(String.valueOf(3));
            completions.add("5");
            completions.add("7");
        } else if (args.length == 4) {
            completions.add(String.valueOf(4));
            completions.add("6");
            completions.add("8");
        }
        Collections.sort(completions);
        return completions;
    }

    public static void cancelExistingSession(Player player) {
        UUID playerId = player.getUniqueId();
        if (particleTasks.containsKey(playerId)) {
            particleTasks.get(playerId).cancel();
            particleTasks.remove(playerId);
        }
        activeSessions.remove(playerId);
    }

    public void startParticleDisplay(final Player player) {
        final UUID playerId = player.getUniqueId();
        final CageEditSession session = activeSessions.get(playerId);
        BukkitTask task = new BukkitRunnable(){

            public void run() {
                if (player.isOnline() && activeSessions.containsKey(playerId)) {
                    createcage.this.displayCageParticles(player, session);
                } else {
                    this.cancel();
                    particleTasks.remove(playerId);
                }
            }
        }.runTaskTimer((Plugin)MoonLab.getInstance(), 0L, 10L);
        if (particleTasks.containsKey(playerId)) {
            particleTasks.get(playerId).cancel();
        }
        particleTasks.put(playerId, task);
    }

    private void displayCageParticles(Player player, CageEditSession session) {
        double y;
        Location center = session.getCenter();
        int width = session.getWidth();
        int height = session.getHeight();
        double halfWidth = (double)width / 2.0;
        double minX = center.getX() - halfWidth;
        double maxX = center.getX() + halfWidth;
        double minZ = center.getZ() - halfWidth;
        double maxZ = center.getZ() + halfWidth;
        double minY = center.getY();
        double maxY = center.getY() + (double)height;
        Particle.DustOptions blueDust = new Particle.DustOptions(Color.fromRGB((int)0, (int)0, (int)255), 1.0f);
        Particle.DustOptions greenDust = new Particle.DustOptions(Color.fromRGB((int)0, (int)255, (int)0), 1.0f);
        double stepSize = 0.15;
        for (y = minX; y <= maxX + 0.001; y += stepSize) {
            this.spawnDustParticle(player, new Location(center.getWorld(), y, minY, minZ), blueDust);
            this.spawnDustParticle(player, new Location(center.getWorld(), y, minY, maxZ), blueDust);
        }
        for (y = minZ; y <= maxZ + 0.001; y += stepSize) {
            this.spawnDustParticle(player, new Location(center.getWorld(), minX, minY, y), blueDust);
            this.spawnDustParticle(player, new Location(center.getWorld(), maxX, minY, y), blueDust);
        }
        for (y = minX; y <= maxX + 0.001; y += stepSize) {
            this.spawnDustParticle(player, new Location(center.getWorld(), y, maxY, minZ), blueDust);
            this.spawnDustParticle(player, new Location(center.getWorld(), y, maxY, maxZ), blueDust);
        }
        for (y = minZ; y <= maxZ + 0.001; y += stepSize) {
            this.spawnDustParticle(player, new Location(center.getWorld(), minX, maxY, y), blueDust);
            this.spawnDustParticle(player, new Location(center.getWorld(), maxX, maxY, y), blueDust);
        }
        for (y = minY; y <= maxY + 0.001; y += stepSize) {
            this.spawnDustParticle(player, new Location(center.getWorld(), minX, y, minZ), blueDust);
            this.spawnDustParticle(player, new Location(center.getWorld(), minX, y, maxZ), blueDust);
            this.spawnDustParticle(player, new Location(center.getWorld(), maxX, y, minZ), blueDust);
            this.spawnDustParticle(player, new Location(center.getWorld(), maxX, y, maxZ), blueDust);
        }
        int playerLayer1 = Math.max(2, height / 2 - 1);
        int playerLayer2 = playerLayer1 + 1;
        session.setPlayerLayer1(playerLayer1);
        session.setPlayerLayer2(playerLayer2);
        double playerY1 = center.getY() + (double)playerLayer1;
        double playerY2 = center.getY() + (double)playerLayer2;
        this.displayExactPlayerBlockOutline(player, center.getWorld(), center.getX(), playerY1, center.getZ(), greenDust);
        this.displayExactPlayerBlockOutline(player, center.getWorld(), center.getX(), playerY2, center.getZ(), greenDust);
    }

    private void displayExactPlayerBlockOutline(Player player, World world, double x, double y, double z, Particle.DustOptions dustOptions) {
        double iy;
        double stepSize = 0.15;
        double pMinX = x - 0.5;
        double pMaxX = x + 0.5;
        double pMinZ = z - 0.5;
        double pMaxZ = z + 0.5;
        double pMinY = y;
        double pMaxY = y + 1.0;
        for (iy = pMinX; iy <= pMaxX + 0.001; iy += stepSize) {
            this.spawnDustParticle(player, new Location(world, iy, pMinY, pMinZ), dustOptions);
            this.spawnDustParticle(player, new Location(world, iy, pMinY, pMaxZ), dustOptions);
        }
        for (iy = pMinZ + stepSize; iy < pMaxZ; iy += stepSize) {
            this.spawnDustParticle(player, new Location(world, pMinX, pMinY, iy), dustOptions);
            this.spawnDustParticle(player, new Location(world, pMaxX, pMinY, iy), dustOptions);
        }
        for (iy = pMinX; iy <= pMaxX + 0.001; iy += stepSize) {
            this.spawnDustParticle(player, new Location(world, iy, pMaxY, pMinZ), dustOptions);
            this.spawnDustParticle(player, new Location(world, iy, pMaxY, pMaxZ), dustOptions);
        }
        for (iy = pMinZ + stepSize; iy < pMaxZ; iy += stepSize) {
            this.spawnDustParticle(player, new Location(world, pMinX, pMaxY, iy), dustOptions);
            this.spawnDustParticle(player, new Location(world, pMaxX, pMaxY, iy), dustOptions);
        }
        for (iy = pMinY + stepSize; iy < pMaxY; iy += stepSize) {
            this.spawnDustParticle(player, new Location(world, pMinX, iy, pMinZ), dustOptions);
            this.spawnDustParticle(player, new Location(world, pMinX, iy, pMaxZ), dustOptions);
            this.spawnDustParticle(player, new Location(world, pMaxX, iy, pMinZ), dustOptions);
            this.spawnDustParticle(player, new Location(world, pMaxX, iy, pMaxZ), dustOptions);
        }
    }

    private void spawnDustParticle(Player player, Location location, Particle.DustOptions dustOptions) {
        player.spawnParticle(Particle.REDSTONE, location, 1, 0.0, 0.0, 0.0, 0.0, (Object)dustOptions);
    }

    public static Map<UUID, CageEditSession> getActiveSessions() {
        return activeSessions;
    }

    public static class CageEditSession {
        private final String name;
        private final int width;
        private final int height;
        private final Location center;
        private int playerLayer1;
        private int playerLayer2;

        public CageEditSession(String name, int width, int height, Location center) {
            this.name = name;
            this.width = width;
            this.height = height;
            this.center = new Location(center.getWorld(), Math.floor(center.getX()) + 0.5, center.getY(), Math.floor(center.getZ()) + 0.5, center.getYaw(), center.getPitch());
            this.playerLayer1 = Math.max(2, height / 2 - 1);
            this.playerLayer2 = this.playerLayer1 + 1;
        }

        public String getName() {
            return this.name;
        }

        public int getWidth() {
            return this.width;
        }

        public int getHeight() {
            return this.height;
        }

        public Location getCenter() {
            return this.center;
        }

        public int getPlayerLayer1() {
            return this.playerLayer1;
        }

        public void setPlayerLayer1(int playerLayer1) {
            this.playerLayer1 = playerLayer1;
        }

        public int getPlayerLayer2() {
            return this.playerLayer2;
        }

        public void setPlayerLayer2(int playerLayer2) {
            this.playerLayer2 = playerLayer2;
        }

        public Location getPlayerSpawnLocation() {
            return new Location(this.center.getWorld(), this.center.getX(), this.center.getY() + (double)this.playerLayer1, this.center.getZ(), this.center.getYaw(), this.center.getPitch());
        }
    }
}

