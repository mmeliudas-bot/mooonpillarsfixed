/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.UltraCosmetics;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.kloppie74.MoonPillars.PaperMC.API.MessageSender;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.Admin.Cooldowns;
import org.kloppie74.MoonPillars.PaperMC.Admin.UltraCosmetics.WorldEditListener;
import org.kloppie74.MoonPillars.PaperMC.Admin.UltraCosmetics.createcage;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class savecage
extends AdminSubCommand {
    private static final int MIN_WIDTH = 3;
    private static final int MIN_HEIGHT = 4;

    @Override
    public String getName() {
        return "savecage";
    }

    @Override
    public String getDescription() {
        return "Save the current cage edit session!";
    }

    @Override
    public String getSyntax() {
        return "/mpa savecage";
    }

    @Override
    public void perform(final Player player, String[] args) {
        if (player.hasPermission("mpa.savecage")) {
            if (!Cooldowns.isOnCooldown(player)) {
                final UUID playerId = player.getUniqueId();
                final Map<UUID, createcage.CageEditSession> sessions = createcage.getActiveSessions();
                if (sessions.containsKey(playerId)) {
                    createcage.CageEditSession session = sessions.get(playerId);
                    final String cageName = session.getName();
                    final int width = Math.max(session.getWidth(), 3);
                    final int height = Math.max(session.getHeight(), 4);
                    final Location center = session.getCenter();
                    final Location playerSpawnLocation = session.getPlayerSpawnLocation();
                    player.sendMessage(MSG.chatColors("&e[DEBUG] Starting savecage process"));
                    player.sendMessage(MSG.chatColors("&e[DEBUG] Cage name: &b" + cageName));
                    player.sendMessage(MSG.chatColors("&e[DEBUG] Dimensions: &b" + width + "x" + width + "x" + height));
                    int var10001 = center.getBlockX();
                    player.sendMessage(MSG.chatColors("&e[DEBUG] Center: &b" + var10001 + ", " + center.getBlockY() + ", " + center.getBlockZ()));
                    var10001 = playerSpawnLocation.getBlockX();
                    player.sendMessage(MSG.chatColors("&e[DEBUG] Player spawn location: &b" + var10001 + ", " + playerSpawnLocation.getBlockY() + ", " + playerSpawnLocation.getBlockZ()));
                    var10001 = player.getLocation().getBlockX();
                    player.sendMessage(MSG.chatColors("&e[DEBUG] Current player location: &b" + var10001 + ", " + player.getLocation().getBlockY() + ", " + player.getLocation().getBlockZ()));
                    Location teleportLocation = new Location(playerSpawnLocation.getWorld(), (double)playerSpawnLocation.getBlockX() + 0.5, (double)playerSpawnLocation.getBlockY(), (double)playerSpawnLocation.getBlockZ() + 0.5, player.getLocation().getYaw(), player.getLocation().getPitch());
                    double var12 = teleportLocation.getX();
                    player.sendMessage(MSG.chatColors("&e[DEBUG] Teleporting to EXACT coordinates: &b" + var12 + ", " + teleportLocation.getY() + ", " + teleportLocation.getZ()));
                    player.teleport(teleportLocation);
                    new BukkitRunnable(){

                        public void run() {
                            Player var10000 = player;
                            double var10001 = player.getLocation().getX();
                            var10000.sendMessage(MSG.chatColors("&e[DEBUG] Player teleported to: &b" + var10001 + ", " + player.getLocation().getY() + ", " + player.getLocation().getZ()));
                            if (!(Math.abs(player.getLocation().getX() - ((double)playerSpawnLocation.getBlockX() + 0.5)) > 0.01) && !(Math.abs(player.getLocation().getZ() - ((double)playerSpawnLocation.getBlockZ() + 0.5)) > 0.01)) {
                                player.sendMessage(MSG.chatColors("&a[DEBUG] Player position verified as centered!"));
                            } else {
                                player.sendMessage(MSG.chatColors("&c[WARNING] Player position is not exactly centered on the block!"));
                            }
                            boolean saveSuccess = savecage.this.saveToSchematic(player, cageName, width, height, center);
                            if (saveSuccess) {
                                savecage.this.updateCosmeticsConfig(cageName, width, height);
                                player.sendMessage(MSG.chatColors("&aCage &e" + cageName + " &ahas been saved successfully! Dimensions: &e" + width + "x" + width + "x" + height));
                                sessions.remove(playerId);
                            } else {
                                player.sendMessage(MSG.chatColors("&cFailed to save cage &e" + cageName + "&c. Check console for errors."));
                            }
                        }
                    }.runTaskLater((Plugin)MoonLab.getInstance(), 5L);
                } else {
                    player.sendMessage(MSG.chatColors("&cYou don't have an active cage edit session. Use &e/mpa createcage &cor &e/mpa editcage &cfirst."));
                }
                Cooldowns.startCooldown(player);
            } else {
                MessageSender.SendMessage(player, "Commands.Cooldown", "", "");
            }
        } else {
            MessageSender.SendMessage(player, "Commands.Permissions-Denied", "", "");
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        sender.sendMessage(MSG.chatColors("&cThis command can only be used by players."));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return new ArrayList<String>();
    }

    private boolean saveToSchematic(Player player, String cageName, int width, int height, Location center) {
        try {
            player.sendMessage(MSG.chatColors("&e[DEBUG] saveToSchematic called"));
            double var10001 = player.getLocation().getX();
            player.sendMessage(MSG.chatColors("&e[DEBUG] Player position during save: &b" + var10001 + ", " + player.getLocation().getY() + ", " + player.getLocation().getZ()));
            File cagesDir = new File(MoonLab.getInstance().getDataFolder(), "Cages");
            if (!cagesDir.exists()) {
                cagesDir.mkdirs();
                player.sendMessage(MSG.chatColors("&e[DEBUG] Created Cages directory"));
            }
            int halfWidth = width / 2;
            Location pos1 = center.clone().add((double)(-halfWidth), 0.0, (double)(-halfWidth));
            Location pos2 = center.clone().add((double)halfWidth, (double)(height - 1), (double)halfWidth);
            player.sendMessage(MSG.chatColors("&e[DEBUG] Selection bounds:"));
            var10001 = pos1.getX();
            player.sendMessage(MSG.chatColors("&e[DEBUG] Pos1: &b" + var10001 + ", " + pos1.getY() + ", " + pos1.getZ()));
            var10001 = pos2.getX();
            player.sendMessage(MSG.chatColors("&e[DEBUG] Pos2: &b" + var10001 + ", " + pos2.getY() + ", " + pos2.getZ()));
            String schemName = cageName + ".schem";
            boolean playerInsideSelection = player.getLocation().getX() >= Math.min(pos1.getX(), pos2.getX()) && player.getLocation().getX() <= Math.max(pos1.getX(), pos2.getX()) && player.getLocation().getY() >= Math.min(pos1.getY(), pos2.getY()) && player.getLocation().getY() <= Math.max(pos1.getY(), pos2.getY()) && player.getLocation().getZ() >= Math.min(pos1.getZ(), pos2.getZ()) && player.getLocation().getZ() <= Math.max(pos1.getZ(), pos2.getZ());
            player.sendMessage(MSG.chatColors("&e[DEBUG] Player inside selection: &b" + playerInsideSelection));
            if (!playerInsideSelection) {
                player.sendMessage(MSG.chatColors("&c[WARNING] Player is not inside the selection bounds!"));
                player.sendMessage(MSG.chatColors("&c[WARNING] This may cause issues with the copy point."));
            }
            return WorldEditListener.saveSelection(player, pos1, pos2, schemName);
        }
        catch (Exception var12) {
            player.sendMessage(MSG.chatColors("&c[DEBUG] Error in saveToSchematic: &e" + var12.getMessage()));
            var12.printStackTrace();
            return false;
        }
    }

    private void updateCosmeticsConfig(String cageName, int width, int height) {
        FileConfiguration cosmeticsConfig = SettingsManager.getInstance().getCosmetics();
        boolean isNew = !cosmeticsConfig.contains("Settings.Cages." + cageName);
        cosmeticsConfig.set("Settings.Cages." + cageName + ".Cage", (Object)(cageName + ".schem"));
        cosmeticsConfig.set("Settings.Cages." + cageName + ".Width", (Object)width);
        cosmeticsConfig.set("Settings.Cages." + cageName + ".Height", (Object)height);
        if (isNew) {
            cosmeticsConfig.set("Settings.Cages." + cageName + ".Permission", (Object)("mpa.cosmetics.cage." + cageName.toLowerCase()));
            cosmeticsConfig.set("Settings.Cages." + cageName + ".Displayname", (Object)("&b&l" + cageName.toUpperCase() + " CAGE"));
            cosmeticsConfig.set("Settings.Cages." + cageName + ".Item", (Object)"GLASS");
            ArrayList<String> lore = new ArrayList<String>();
            lore.add("&8Pillars Cosmetic");
            lore.add("");
            lore.add("&e&l\u27a5 CLICK TO EQUIP");
            cosmeticsConfig.set("Settings.Cages." + cageName + ".Lore", lore);
        }
        SettingsManager.saveSettings("Cosmetics");
    }
}

