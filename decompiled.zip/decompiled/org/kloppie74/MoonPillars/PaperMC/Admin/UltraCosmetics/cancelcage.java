/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.UltraCosmetics;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.AdminSubCommand;
import org.kloppie74.MoonPillars.PaperMC.Admin.UltraCosmetics.createcage;

public class cancelcage
extends AdminSubCommand {
    @Override
    public String getName() {
        return "cancelcage";
    }

    @Override
    public String getDescription() {
        return "Cancel the current cage creation or edit session.";
    }

    @Override
    public String getSyntax() {
        return "/mpa cancelcage";
    }

    @Override
    public void perform(Player player, String[] args) {
        UUID playerId = player.getUniqueId();
        Map<UUID, createcage.CageEditSession> sessions = createcage.getActiveSessions();
        if (sessions.containsKey(playerId)) {
            createcage.cancelExistingSession(player);
            player.sendMessage(MSG.chatColors("&aYour cage creation/edit session has been cancelled."));
        } else {
            player.sendMessage(MSG.chatColors("&eYou are not currently editing or creating a cage."));
        }
    }

    @Override
    public void performConsole(CommandSender sender, String[] args) {
        sender.sendMessage(MSG.chatColors("&cThis command can only be used by players."));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return Collections.emptyList();
    }
}

