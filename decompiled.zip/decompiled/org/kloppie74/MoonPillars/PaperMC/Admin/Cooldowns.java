/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package org.kloppie74.MoonPillars.PaperMC.Admin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.entity.Player;

public class Cooldowns {
    private static final Map<UUID, Long> cooldowns = new HashMap<UUID, Long>();
    private static final int COOLDOWN_TIME = 100;

    public static boolean isOnCooldown(Player player) {
        UUID playerId = player.getUniqueId();
        if (cooldowns.containsKey(playerId)) {
            long timeLeft = cooldowns.get(playerId) + 100L - System.currentTimeMillis();
            if (timeLeft > 0L) {
                return true;
            }
            cooldowns.remove(playerId);
        }
        return false;
    }

    public static void startCooldown(Player player) {
        cooldowns.put(player.getUniqueId(), System.currentTimeMillis());
    }
}

