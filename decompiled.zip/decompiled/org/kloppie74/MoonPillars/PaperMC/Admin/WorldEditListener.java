/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldedit.EditSession
 *  com.sk89q.worldedit.WorldEdit
 *  com.sk89q.worldedit.bukkit.BukkitAdapter
 *  com.sk89q.worldedit.bukkit.BukkitPlayer
 *  com.sk89q.worldedit.bukkit.WorldEditPlugin
 *  com.sk89q.worldedit.extent.Extent
 *  com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard
 *  com.sk89q.worldedit.extent.clipboard.Clipboard
 *  com.sk89q.worldedit.extent.clipboard.io.BuiltInClipboardFormat
 *  com.sk89q.worldedit.extent.clipboard.io.ClipboardWriter
 *  com.sk89q.worldedit.function.operation.ForwardExtentCopy
 *  com.sk89q.worldedit.function.operation.Operation
 *  com.sk89q.worldedit.function.operation.Operations
 *  com.sk89q.worldedit.math.BlockVector3
 *  com.sk89q.worldedit.regions.CuboidRegion
 *  com.sk89q.worldedit.regions.Region
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Listener
 */
package org.kloppie74.MoonPillars.PaperMC.Admin;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.bukkit.BukkitPlayer;
import com.sk89q.worldedit.bukkit.WorldEditPlugin;
import com.sk89q.worldedit.extent.Extent;
import com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.BuiltInClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardWriter;
import com.sk89q.worldedit.function.operation.ForwardExtentCopy;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.CuboidRegion;
import com.sk89q.worldedit.regions.Region;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class WorldEditListener
implements Listener {
    private static final int MIN_WIDTH = 3;
    private static final int MIN_HEIGHT = 4;

    public static boolean saveSelection(Player player, Location pos1, Location pos2, String fileName) {
        try {
            File schematicFile;
            boolean isPlayerCentered;
            player.sendMessage(MSG.chatColors("&e[DEBUG] Starting saveSelection process"));
            double var10001 = player.getLocation().getX();
            player.sendMessage(MSG.chatColors("&e[DEBUG] Player position: &b" + var10001 + ", " + player.getLocation().getY() + ", " + player.getLocation().getZ()));
            boolean bl = isPlayerCentered = Math.abs(player.getLocation().getX() - Math.floor(player.getLocation().getX()) - 0.5) < 0.01 && Math.abs(player.getLocation().getZ() - Math.floor(player.getLocation().getZ()) - 0.5) < 0.01;
            if (!isPlayerCentered) {
                player.sendMessage(MSG.chatColors("&c[WARNING] Player is not exactly at .5 position in the block!"));
                var10001 = player.getLocation().getX();
                player.sendMessage(MSG.chatColors("&c[WARNING] Current X: " + var10001 + ", should be " + (Math.floor(player.getLocation().getX()) + 0.5)));
                var10001 = player.getLocation().getZ();
                player.sendMessage(MSG.chatColors("&c[WARNING] Current Z: " + var10001 + ", should be " + (Math.floor(player.getLocation().getZ()) + 0.5)));
            } else {
                player.sendMessage(MSG.chatColors("&a[DEBUG] Player position is perfectly centered at .5!"));
            }
            WorldEditPlugin worldEditPlugin = (WorldEditPlugin)Bukkit.getPluginManager().getPlugin("WorldEdit");
            if (worldEditPlugin == null) {
                player.sendMessage(MSG.chatColors("&cWorldEdit plugin is not available!"));
                return false;
            }
            player.sendMessage(MSG.chatColors("&e[DEBUG] WorldEdit plugin found"));
            BukkitPlayer worldEditPlayer = BukkitAdapter.adapt((Player)player);
            player.sendMessage(MSG.chatColors("&e[DEBUG] Selection Points:"));
            var10001 = pos1.getX();
            player.sendMessage(MSG.chatColors("&e[DEBUG] Pos1: &b" + var10001 + ", " + pos1.getY() + ", " + pos1.getZ()));
            var10001 = pos2.getX();
            player.sendMessage(MSG.chatColors("&e[DEBUG] Pos2: &b" + var10001 + ", " + pos2.getY() + ", " + pos2.getZ()));
            BlockVector3 min = BlockVector3.at((double)Math.min(pos1.getX(), pos2.getX()), (double)Math.min(pos1.getY(), pos2.getY()), (double)Math.min(pos1.getZ(), pos2.getZ()));
            BlockVector3 max = BlockVector3.at((double)Math.max(pos1.getX(), pos2.getX()), (double)Math.max(pos1.getY(), pos2.getY()), (double)Math.max(pos1.getZ(), pos2.getZ()));
            CuboidRegion region = new CuboidRegion(BukkitAdapter.adapt((World)player.getWorld()), min, max);
            int var24 = region.getWidth();
            player.sendMessage(MSG.chatColors("&e[DEBUG] Region dimensions: &b" + var24 + "x" + region.getHeight() + "x" + region.getLength()));
            BlockVector3 playerPosition = BlockVector3.at((double)player.getLocation().getX(), (double)player.getLocation().getY(), (double)player.getLocation().getZ());
            var24 = playerPosition.getX();
            player.sendMessage(MSG.chatColors("&e[DEBUG] Player position as origin: &b" + var24 + ", " + playerPosition.getY() + ", " + playerPosition.getZ()));
            if (!region.contains(playerPosition)) {
                player.sendMessage(MSG.chatColors("&c[WARNING] Player is not inside the selection region!"));
            }
            BlockArrayClipboard clipboard = new BlockArrayClipboard((Region)region);
            clipboard.setOrigin(playerPosition);
            var24 = clipboard.getOrigin().getX();
            player.sendMessage(MSG.chatColors("&e[DEBUG] Clipboard origin set to: &b" + var24 + ", " + clipboard.getOrigin().getY() + ", " + clipboard.getOrigin().getZ()));
            try (EditSession editSession = WorldEdit.getInstance().newEditSession(BukkitAdapter.adapt((World)player.getWorld()));){
                ForwardExtentCopy copy = new ForwardExtentCopy((Extent)editSession, (Region)region, (Extent)clipboard, region.getMinimumPoint());
                copy.setCopyingEntities(true);
                Operations.complete((Operation)copy);
                player.sendMessage(MSG.chatColors("&e[DEBUG] Copy operation completed"));
            }
            File cagesDir = new File(MoonLab.getInstance().getDataFolder(), "Cages");
            if (!cagesDir.exists()) {
                cagesDir.mkdirs();
                player.sendMessage(MSG.chatColors("&e[DEBUG] Created Cages directory"));
            }
            if ((schematicFile = new File(cagesDir, fileName)).exists()) {
                Files.delete(schematicFile.toPath());
                player.sendMessage(MSG.chatColors("&e[DEBUG] Deleted existing schematic file"));
            }
            try (ClipboardWriter writer = BuiltInClipboardFormat.SPONGE_SCHEMATIC.getWriter((OutputStream)new FileOutputStream(schematicFile));){
                writer.write((Clipboard)clipboard);
                player.sendMessage(MSG.chatColors("&e[DEBUG] Written clipboard to file"));
            }
            player.sendMessage(MSG.chatColors("&aSchematic saved successfully to &e" + schematicFile.getPath()));
            return true;
        }
        catch (Exception var21) {
            player.sendMessage(MSG.chatColors("&cError saving schematic: &e" + var21.getMessage()));
            var21.printStackTrace();
            return false;
        }
    }
}

