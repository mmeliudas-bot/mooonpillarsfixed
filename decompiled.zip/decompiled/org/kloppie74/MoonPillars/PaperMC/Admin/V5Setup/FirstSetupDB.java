/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.file.FileConfiguration
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.V5Setup;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;
import org.bukkit.configuration.file.FileConfiguration;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class FirstSetupDB {
    private static FirstSetupDB instance;
    private final String dbName = String.valueOf(MoonLab.getInstance().getDataFolder()) + "/Storage/Server-Database.db";

    public static void generateServerId() {
        FileConfiguration config = SettingsManager.getInstance().getSettings();
        String ServerID = UUID.randomUUID().toString().substring(0, 28);
        config.set("Settings.ServerID", (Object)ServerID);
        SettingsManager.saveSettings("Settings");
        FirstSetupDB.getInstance().updateSetting("serverID", ServerID);
    }

    public static String getServerID() {
        FileConfiguration config = SettingsManager.getInstance().getSettings();
        String serverID = config.getString("Settings.ServerID");
        if (serverID == null) {
            FirstSetupDB.generateServerId();
            serverID = config.getString("Settings.ServerID");
        }
        return serverID;
    }

    private FirstSetupDB() {
        this.createTable();
    }

    public static synchronized FirstSetupDB getInstance() {
        if (instance == null) {
            instance = new FirstSetupDB();
        }
        return instance;
    }

    private Connection connect() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
        }
        catch (ClassNotFoundException var2) {
            var2.printStackTrace();
        }
        return DriverManager.getConnection("jdbc:sqlite:" + this.dbName);
    }

    private void createTable() {
        block42: {
            FileConfiguration config = SettingsManager.getInstance().getSettings();
            if (config.getString("Settings.ServerID") == null || config.getString("Settings.ServerID").equalsIgnoreCase("null")) {
                FirstSetupDB.generateServerId();
            }
            String createTableSQL = "CREATE TABLE IF NOT EXISTS server_data (serverID VARCHAR(255) PRIMARY KEY,AnonymousData VARCHAR(255) NOT NULL,ImportData VARCHAR(255) NOT NULL,SetupComplete VARCHAR(255) NOT NULL);";
            try (Connection connection = this.connect();
                 Statement statement = connection.createStatement();){
                statement.executeUpdate(createTableSQL);
            }
            catch (SQLException var25) {
                var25.printStackTrace();
            }
            String serverID = FirstSetupDB.getServerID();
            String selectSQL = "SELECT COUNT(*) FROM server_data WHERE serverID = ?;";
            try (Connection connection = this.connect();
                 PreparedStatement selectStatement = connection.prepareStatement(selectSQL);){
                selectStatement.setString(1, serverID);
                try (ResultSet resultSet = selectStatement.executeQuery();){
                    if (!resultSet.next() || resultSet.getInt(1) != 0) break block42;
                    String insertSQL = "INSERT INTO server_data (serverID, AnonymousData, ImportData, SetupComplete) VALUES (?, ?, ?, ?);";
                    try (PreparedStatement insertStatement = connection.prepareStatement(insertSQL);){
                        insertStatement.setString(1, serverID);
                        insertStatement.setString(2, "false");
                        insertStatement.setString(3, "false");
                        insertStatement.setString(4, "false");
                        insertStatement.executeUpdate();
                    }
                }
            }
            catch (SQLException var22) {
                var22.printStackTrace();
            }
        }
    }

    public void updateSetting(String Setting, String newValue) {
        String serverID = FirstSetupDB.getServerID();
        String updateSQL = "UPDATE server_data SET " + Setting + " = ? WHERE serverID = ?;";
        try (Connection connection = this.connect();
             PreparedStatement preparedStatement = connection.prepareStatement(updateSQL);){
            preparedStatement.setString(1, newValue);
            preparedStatement.setString(2, serverID);
            preparedStatement.executeUpdate();
        }
        catch (SQLException var13) {
            var13.printStackTrace();
        }
    }

    public String getSetting(String Setting) {
        String serverID = FirstSetupDB.getServerID();
        String selectSQL = "SELECT " + Setting + " FROM server_data WHERE serverID = ?;";
        try {
            String var7;
            block21: {
                block20: {
                    try (Connection connection = this.connect();
                         PreparedStatement preparedStatement = connection.prepareStatement(selectSQL);){
                        preparedStatement.setString(1, serverID);
                        try (ResultSet resultSet = preparedStatement.executeQuery();){
                            if (!resultSet.next()) break block20;
                            var7 = resultSet.getString(Setting);
                            break block21;
                        }
                    }
                }
                return null;
            }
            return var7;
        }
        catch (SQLException var15) {
            var15.printStackTrace();
            return null;
        }
    }
}

