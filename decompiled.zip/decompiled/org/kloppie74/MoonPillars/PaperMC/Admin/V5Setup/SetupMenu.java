/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 */
package org.kloppie74.MoonPillars.PaperMC.Admin.V5Setup;

import java.util.ArrayList;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.kloppie74.MoonPillars.PaperMC.API.PublicAPI.MSG;
import org.kloppie74.MoonPillars.PaperMC.Admin.V5Setup.FirstSetupDB;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class SetupMenu
implements Listener {
    public static void openAnonymousData(Player player) {
        Inventory customGui = Bukkit.createInventory((InventoryHolder)null, (int)27, (String)MSG.chatColors("&cAnonymous Data"));
        ItemStack item1 = new ItemStack(Material.RED_STAINED_GLASS);
        ItemMeta itemMeta1 = item1.getItemMeta();
        if (itemMeta1 != null) {
            itemMeta1.setDisplayName(MSG.chatColors("&cDeny Anonymous Data"));
            ArrayList<String> lore = new ArrayList<String>();
            lore.add(MSG.chatColors("&7We will &c&lnot &r&7send any player & server data"));
            lore.add(MSG.chatColors("&7to our plugin developers!"));
            lore.add(MSG.chatColors("&7"));
            itemMeta1.setLore(lore);
            item1.setItemMeta(itemMeta1);
        }
        customGui.setItem(11, item1);
        ItemStack item2 = new ItemStack(Material.KNOWLEDGE_BOOK);
        ItemMeta itemMeta2 = item2.getItemMeta();
        if (itemMeta2 != null) {
            itemMeta2.setDisplayName(MSG.chatColors("&bSend Anonymous Data"));
            ArrayList<String> lore = new ArrayList<String>();
            lore.add(MSG.chatColors("&7Should we send Anonymous data to our developers?"));
            lore.add(MSG.chatColors("&7We will send the following data:"));
            lore.add(MSG.chatColors("&7- Server Software Version"));
            lore.add(MSG.chatColors("&7- Server Version"));
            lore.add(MSG.chatColors("&7- ServerID"));
            lore.add(MSG.chatColors("&7- PlayerID's"));
            itemMeta2.setLore(lore);
            item2.setItemMeta(itemMeta2);
        }
        customGui.setItem(13, item2);
        ItemStack item3 = new ItemStack(Material.GREEN_STAINED_GLASS);
        ItemMeta itemMeta3 = item3.getItemMeta();
        if (itemMeta3 != null) {
            itemMeta3.setDisplayName(MSG.chatColors("&aAccept Anonymous Data"));
            ArrayList<String> lore = new ArrayList<String>();
            lore.add(MSG.chatColors("&7Click to allow us to send Anonymous Data!"));
            lore.add(MSG.chatColors("&7"));
            itemMeta3.setLore(lore);
            item3.setItemMeta(itemMeta3);
        }
        customGui.setItem(15, item3);
        ItemStack grayGlass = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        for (int i = 0; i < customGui.getSize(); ++i) {
            if (customGui.getItem(i) != null) continue;
            customGui.setItem(i, grayGlass);
        }
        player.openInventory(customGui);
    }

    public void openImportData(Player player) {
        Inventory customGui = Bukkit.createInventory((InventoryHolder)null, (int)27, (String)MSG.chatColors("&eImport Data"));
        ItemStack item1 = new ItemStack(Material.RED_STAINED_GLASS);
        ItemMeta itemMeta1 = item1.getItemMeta();
        if (itemMeta1 != null) {
            itemMeta1.setDisplayName(MSG.chatColors("&cDeny Import Default Data"));
            ArrayList<String> lore = new ArrayList<String>();
            lore.add(MSG.chatColors("&7We will &c&lnot &r&7import our pre-setup configuration files!"));
            lore.add(MSG.chatColors("&7This import includes 4 pre-setup game area's!"));
            lore.add(MSG.chatColors("&7"));
            itemMeta1.setLore(lore);
            item1.setItemMeta(itemMeta1);
        }
        customGui.setItem(11, item1);
        ItemStack item2 = new ItemStack(Material.KNOWLEDGE_BOOK);
        ItemMeta itemMeta2 = item2.getItemMeta();
        if (itemMeta2 != null) {
            itemMeta2.setDisplayName(MSG.chatColors("&eImport Pre-configured DataFiles!"));
            ArrayList<String> lore = new ArrayList<String>();
            lore.add(MSG.chatColors("&7Should we import our pre-configured data files?"));
            lore.add(MSG.chatColors("&7We will import the following Files:"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Settings.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/ScoreBoards.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Items.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Cosmetics.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Commands.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Menus/cosmetic-bow.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Menus/cosmetic-cages.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Menus/cosmetic-kill.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Menus/cosmetic-win.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Menus/cosmetics.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Menus/joingame.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Menus/leaderboards.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Menus/MoonPillars-GUI.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/LangFiles/en.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Games/clouds1v1v1v1.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Games/clouds1v1v1v1.zip"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Games/clouds2v2v2v2.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Games/clouds2v2v2v2.zip"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Games/clouds3v3v3v3.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Games/clouds3v3v3v3.zip"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Games/clouds4v4v4v4.yml"));
            lore.add(MSG.chatColors("&7- ./MoonPillars/Games/clouds4v4v4v4.zip"));
            itemMeta2.setLore(lore);
            item2.setItemMeta(itemMeta2);
        }
        customGui.setItem(13, item2);
        ItemStack item3 = new ItemStack(Material.GREEN_STAINED_GLASS);
        ItemMeta itemMeta3 = item3.getItemMeta();
        if (itemMeta3 != null) {
            itemMeta3.setDisplayName(MSG.chatColors("&aAccept Pre-configured DataFiles"));
            ArrayList<String> lore = new ArrayList<String>();
            lore.add(MSG.chatColors("&7Click to import our Pre-configured DataFiles!"));
            lore.add(MSG.chatColors("&7"));
            itemMeta3.setLore(lore);
            item3.setItemMeta(itemMeta3);
        }
        customGui.setItem(15, item3);
        ItemStack grayGlass = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        for (int i = 0; i < customGui.getSize(); ++i) {
            if (customGui.getItem(i) != null) continue;
            customGui.setItem(i, grayGlass);
        }
        player.openInventory(customGui);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Material clickedItem;
        Player player;
        if (event.getView().getTitle().equals(MSG.chatColors("&cAnonymous Data"))) {
            event.setCancelled(true);
            player = (Player)event.getWhoClicked();
            if (event.getCurrentItem() != null) {
                clickedItem = event.getCurrentItem().getType();
                if (clickedItem == Material.RED_STAINED_GLASS) {
                    player.closeInventory();
                    FirstSetupDB.getInstance().updateSetting("AnonymousData", "false");
                    this.openImportData(player);
                } else if (clickedItem == Material.GREEN_STAINED_GLASS) {
                    player.closeInventory();
                    FirstSetupDB.getInstance().updateSetting("AnonymousData", "true");
                    this.openImportData(player);
                }
            }
        }
        if (event.getView().getTitle().equals(MSG.chatColors("&eImport Data"))) {
            event.setCancelled(true);
            player = (Player)event.getWhoClicked();
            if (event.getCurrentItem() != null) {
                clickedItem = event.getCurrentItem().getType();
                if (clickedItem == Material.RED_STAINED_GLASS) {
                    player.closeInventory();
                    FirstSetupDB.getInstance().updateSetting("ImportData", "false");
                    player.sendMessage(MSG.chatColors("&eWe will restart the server to apply the setup changes!"));
                    String var10001 = MSG.chatColors("&eAccepted Annonymous Data: ");
                    player.sendMessage(var10001 + FirstSetupDB.getInstance().getSetting("AnonymousData"));
                    var10001 = MSG.chatColors("&eImport default files: ");
                    player.sendMessage(var10001 + FirstSetupDB.getInstance().getSetting("ImportData"));
                    player.sendMessage(MSG.chatColors("&7Server will be restart in 5 seconds..."));
                    Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> Bukkit.getServer().shutdown(), 100L);
                } else if (clickedItem == Material.GREEN_STAINED_GLASS) {
                    player.closeInventory();
                    FirstSetupDB.getInstance().updateSetting("ImportData", "true");
                    player.sendMessage(MSG.chatColors("&eWe will restart the server to apply the setup changes!"));
                    String var10001 = MSG.chatColors("&eAccepted Annonymous Data: ");
                    player.sendMessage(var10001 + FirstSetupDB.getInstance().getSetting("AnonymousData"));
                    var10001 = MSG.chatColors("&eImport default files: ");
                    player.sendMessage(var10001 + FirstSetupDB.getInstance().getSetting("ImportData"));
                    player.sendMessage(MSG.chatColors("&7Server will be restart in 5 seconds..."));
                    Bukkit.getScheduler().runTaskLater((Plugin)MoonLab.getInstance(), () -> Bukkit.getServer().shutdown(), 100L);
                }
            }
        }
    }
}

