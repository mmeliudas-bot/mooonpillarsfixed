/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.entity.FallingBlock
 *  org.bukkit.entity.Pig
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.util.Vector
 */
package org.kloppie74.MoonPillars.PaperMC.Cosmetics.Custom_Particles;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Pig;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class CustomParticles {
    public static void CUSTOM_PIGS(final Player player) {
        new BukkitRunnable(){
            int ticks = 0;

            public void run() {
                if (this.ticks >= 100) {
                    this.cancel();
                } else {
                    Location loc = player.getLocation();
                    Vector forward = player.getLocation().getDirection().normalize();
                    Vector backward = forward.clone().multiply(-1);
                    Vector right = forward.clone().rotateAroundY(Math.toRadians(90.0));
                    Vector left = forward.clone().rotateAroundY(Math.toRadians(-90.0));
                    Vector up = new Vector(0, 1, 0);
                    CustomParticles.launchPig(player, loc, forward);
                    CustomParticles.launchPig(player, loc, backward);
                    CustomParticles.launchPig(player, loc, right);
                    CustomParticles.launchPig(player, loc, left);
                    CustomParticles.launchPig(player, loc, up);
                    this.ticks += 20;
                }
            }
        }.runTaskTimer((Plugin)MoonLab.getInstance(), 0L, 20L);
    }

    private static void launchPig(Player player, Location loc, Vector direction) {
        Pig pig = (Pig)player.getWorld().spawn(loc, Pig.class);
        pig.setVelocity(direction.multiply(1.2));
        pig.setInvulnerable(true);
    }

    public static void CUSTOM_ANVILRAIN(final Player player) {
        new BukkitRunnable(){
            int ticks = 0;

            public void run() {
                if (this.ticks >= 100) {
                    this.cancel();
                } else {
                    for (int i = 0; i < 20; ++i) {
                        Location loc = player.getLocation().clone().add(Math.random() * 50.0 - 25.0, 10.0, Math.random() * 50.0 - 25.0);
                        FallingBlock anvil = player.getWorld().spawnFallingBlock(loc, Material.ANVIL.createBlockData());
                        anvil.setVelocity(new Vector(0, -1, 0));
                        anvil.setHurtEntities(false);
                    }
                    this.ticks += 20;
                }
            }
        }.runTaskTimer((Plugin)MoonLab.getInstance(), 0L, 20L);
    }
}

