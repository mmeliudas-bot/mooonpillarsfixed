/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Particle
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Arrow
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.ProjectileLaunchEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 */
package org.kloppie74.MoonPillars.PaperMC.Cosmetics.Events;

import java.lang.reflect.Method;
import java.util.Arrays;
import org.bukkit.Particle;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler.CosmeticHandler;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;
import org.kloppie74.MoonPillars.PaperMC.MoonLab;

public class ParticleEventBows
implements Listener {
    @EventHandler
    public void onBowShoot(ProjectileLaunchEvent event) {
        if (event.getEntity() instanceof Arrow && event.getEntity().getShooter() instanceof Player) {
            Player player = (Player)event.getEntity().getShooter();
            FileConfiguration config = SettingsManager.getInstance().getCosmetics();
            String ParticleID = CosmeticHandler.getInstance().getSelectedCosmetic(player.getUniqueId(), "Bow_Particle");
            if (ParticleID == null) {
                return;
            }
            String particleName = config.getString("Settings.Particles.Bow." + (ParticleID = ParticleID.replace("Win_", "")) + ".Particle");
            if (particleName == null) {
                return;
            }
            final Particle particleType = this.getParticleByName(particleName.replace("Bow_", ""));
            if (particleType != null) {
                final Arrow arrow = (Arrow)event.getEntity();
                new BukkitRunnable(){

                    public void run() {
                        if (!arrow.isInBlock() && !arrow.isDead()) {
                            arrow.getWorld().spawnParticle(particleType, arrow.getLocation(), 1);
                        } else {
                            this.cancel();
                        }
                    }
                }.runTaskTimer((Plugin)MoonLab.getInstance(), 0L, 1L);
            }
        }
    }

    private Particle getParticleByName(String name) {
        try {
            Method valueOf = Particle.class.getMethod("valueOf", String.class);
            Particle particle = (Particle)valueOf.invoke(null, name.toUpperCase());
            return this.isValidParticle(particle) ? particle : null;
        }
        catch (Exception var4) {
            return null;
        }
    }

    private boolean isValidParticle(Particle particle) {
        return Arrays.asList(Particle.values()).contains(particle);
    }
}

