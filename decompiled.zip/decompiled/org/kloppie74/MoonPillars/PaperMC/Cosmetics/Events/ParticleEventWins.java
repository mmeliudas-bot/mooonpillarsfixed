/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Particle
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Listener
 */
package org.kloppie74.MoonPillars.PaperMC.Cosmetics.Events;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.kloppie74.MoonPillars.PaperMC.Cosmetics.Custom_Particles.CustomParticles;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler.CosmeticHandler;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class ParticleEventWins
implements Listener {
    public static void OnWinEvent(Player player) {
        String particleName;
        FileConfiguration config = SettingsManager.getInstance().getCosmetics();
        String ParticleID = CosmeticHandler.getInstance().getSelectedCosmetic(player.getUniqueId(), "Win_Particle");
        if (ParticleID != null && !ParticleID.isEmpty() && (particleName = config.getString("Settings.Particles.Win." + (ParticleID = ParticleID.replace("Win_", "")) + ".Particle")) != null && !particleName.isEmpty()) {
            if (particleName.contains("CUSTOM")) {
                if (particleName.equalsIgnoreCase("CUSTOM_ANVILRAIN")) {
                    CustomParticles.CUSTOM_ANVILRAIN(player);
                    return;
                }
                if (particleName.equalsIgnoreCase("CUSTOM_PIGS")) {
                    CustomParticles.CUSTOM_PIGS(player);
                    return;
                }
            } else {
                Particle particleType = ParticleEventWins.getParticleByName(particleName);
                if (particleType != null) {
                    Location loc = player.getLocation();
                    ParticleEventWins.spawnParticles(loc, particleType);
                }
            }
        }
    }

    public static void spawnParticles(Location loc, Particle particleType) {
        loc.getWorld().spawnParticle(particleType, loc, 20);
    }

    public static Particle getParticleByName(String name) {
        try {
            return Particle.valueOf((String)name.toUpperCase());
        }
        catch (IllegalArgumentException var2) {
            return null;
        }
    }
}

