/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Particle
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.PlayerDeathEvent
 */
package org.kloppie74.MoonPillars.PaperMC.Cosmetics.Events;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.Cosmetichandler.CosmeticHandler;
import org.kloppie74.MoonPillars.PaperMC.FileManagement.SettingsManager;

public class ParticleEventKills
implements Listener {
    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Location loc;
        Particle particleType;
        String particleName;
        String ParticleID;
        FileConfiguration config;
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        if (killer != null) {
            config = SettingsManager.getInstance().getCosmetics();
            ParticleID = CosmeticHandler.getInstance().getSelectedCosmetic(killer.getUniqueId(), "Kill_Particle");
            if (ParticleID == null) {
                return;
            }
            particleName = config.getString("Settings.Particles.Kill." + (ParticleID = ParticleID.replace("Kill_", "")) + ".Particle");
            if (particleName != null && (particleType = this.getParticleByName(particleName.replace("Kill_", ""))) != null) {
                loc = killer.getLocation();
                this.spawnParticles(loc, particleType);
            }
        }
        config = SettingsManager.getInstance().getCosmetics();
        ParticleID = CosmeticHandler.getInstance().getSelectedCosmetic(victim.getUniqueId(), "Death_Particle");
        if (ParticleID != null && (particleName = config.getString("Settings.Particles.Death." + (ParticleID = ParticleID.replace("Death_", "")) + ".Particle")) != null && (particleType = this.getParticleByName(particleName.replace("Death_", ""))) != null) {
            loc = victim.getLocation();
            this.spawnParticles(loc, particleType);
        }
    }

    private void spawnParticles(Location loc, Particle particleType) {
        loc.getWorld().spawnParticle(particleType, loc, 20);
    }

    private Particle getParticleByName(String name) {
        try {
            return Particle.valueOf((String)name.toUpperCase());
        }
        catch (IllegalArgumentException var3) {
            return null;
        }
    }
}

